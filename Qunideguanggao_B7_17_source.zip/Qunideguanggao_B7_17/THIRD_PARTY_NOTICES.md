# Third-party source inventory

## LTT rule data

The three original rule JSON files are stored under `app/src/main/assets/ltt` and are protected by frozen SHA-256 checks. The supplied repository license is retained at `third_party/litiaotiao/LICENSE`. No third-party APK payload is embedded.

## GKD selector/runtime source

The selector source and its license are retained under `third_party/gkd-selector`. JVM-compatible generated source is under `gkd-core`; `third_party/gkd-selector/source-manifest.json` maps every original file hash to its generated destination. Selected upstream runtime files and license are retained under `third_party/gkd-runtime-reference` for review.

## Primary GKD subscription

Source: `Lin-arm/GKD_subscription`, commit `e9cded29ecc8ccc9919683a79a730826c6bb8cb0`, subscription v593. The original JSON5, upstream README, normalized JSON and provenance hashes are retained under `third_party/gkd_subscription`. Only advertisement categories are packaged. The upstream repository does not expose a license in the reviewed snapshot; its README contains additional distribution conditions and is retained verbatim for review.

## Reviewed supplemental subscription

Source: `nullptr-leo/gkd-rules`, commit `8b93cfe2bda7bfcba6d9847f992a177c35aff7c4`, Apache License 2.0. A reviewed subset of 11 applications and 12 application-scoped advertisement groups is stored under `third_party/gkd_supplement`. Supplemental global rules and bank/payment targets are deliberately excluded. The full license and immutable provenance hashes are included.

## Tesseract

Tesseract4Android 4.9.0 is a build dependency. The Simplified Chinese `tessdata_fast` model is fetched during CI and verified against a frozen SHA-256. Runtime OCR is local and does not download or upload data.
