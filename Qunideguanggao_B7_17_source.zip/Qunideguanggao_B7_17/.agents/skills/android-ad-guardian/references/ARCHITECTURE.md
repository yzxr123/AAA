# 当前版本 B7.14

本文件旧版本段落仅作演进背景 发生冲突时以 AGENTS.md 和 docs/B7.14-audit.md 的当前实现为准

# B7.7 架构

实际调用链在 RuleEngine 与 AdAccessibilityService

明确教学期间只观察用户操作并运行教学复核 自动规则与 OCR 暂停
非教学期间为流程学习回放 旧单按钮学习 CLASS定向 LTT GKD 辅助匹配 OCR
流程回放独占正在执行的动作 阶段匹配等待必须有限
FlowPage 是不可变控件描述 不保留 AccessibilityNodeInfo 和屏幕正文
FlowJournal 是阶段录制状态 FlowStore 保存独立受限原子文件
FlowReplayEngine 重新确认每一步和终点 FlowTeachingOverlay 仅负责主线程窗口
ClassAdEngine 按包版本 Activity 范围处理 不修改目标APK 不调用目标SDK内部代码
继承 B7.6 的授权与后台实现 详见 docs/B7.6-audit.md
