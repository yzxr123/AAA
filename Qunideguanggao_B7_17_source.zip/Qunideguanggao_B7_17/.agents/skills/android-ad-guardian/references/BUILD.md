# B7.14 构建

versionName 0.7.14-b7.14
versionCode 34
原始包名与 dev-signing.jks 不变
完整源码 ZIP 和独立工作流成对使用
.github/workflows/build-apk.yml 是真实入口
内嵌 Python 按 ZIP 内部版本识别后复制到独立临时构建目录
支持下载括号 子目录和旧版本 ZIP 共存
新源码 REQUIRED 必须与 tests/test_ci_source_preparation.py一致

完整宿主测试 python3 tools/run_host_tests.py
CI使用原Gradle8.13 JDK17 AGP8.13.2 工具链
构建 :gkd-core:verifyGkdRuntime :gkd-core:verifyAndroidHost 和 :app:assembleRelease
随后运行 :app:lintRelease --warning-mode all
Android接口替身只位于tests 不进入生产APK

Lint配置
保留 abortOnError true checkReleaseBuilds true 和全部默认检查
QUERY_ALL_PACKAGES只在对应uses-permission元素作QueryAllPackagesPermission定向豁免
用途为用户主动发起的本地广泛安装应用SDK扫描 不是关闭全项目检查
已有可选WRITE_SECURE_SETTINGS声明上的ProtectedPermissions处理不扩散
Lint输出固定XML TXT HTML 并开启showAll
运行前只清理本轮固定Lint输出 不能沿用过期清洁报告

tools/report_lint.py --outcome [真实steps.lint.outcome]
此阶段仅收集报告 可以在Lint失败后继续用于上传完整证据
上传 lint-reports-B7.14 附件
然后 tools/report_lint.py --outcome [相同真实状态] --check
只有Gradle检查成功 XML可解析且错误数为0才发布APK
warning不隐藏 但不直接作为error处理
检查失败 报告缺失 XML损坏都必须失败
continue-on-error只为先保存诊断 后面必须保留独立失败门禁

APK50MiB限制是安装包文件大小 不是RAM测量
最终验证日志必须是本轮执行输出 不能引用历史通过数
