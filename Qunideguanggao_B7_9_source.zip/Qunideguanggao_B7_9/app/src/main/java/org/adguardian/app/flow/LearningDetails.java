package org.adguardian.app.flow;

import org.adguardian.app.engine.NodeTarget;
import org.adguardian.app.learning.LearnedRule;

/** User-requested details from existing sanitized records, never a fresh screen/body capture. */
public final class LearningDetails {
    private LearningDetails() { }
    private static String page(String activity){return activity.startsWith("@window:")?"按窗口结构确认":activity;}
    private static void target(StringBuilder out,NodeTarget t) {
        if(!t.label.isEmpty())out.append("按钮文字 ").append(t.label).append('\n');
        if(!t.id.isEmpty())out.append("控件标识 ").append(t.id).append('\n');
        out.append("控件类型 ").append(t.name).append('\n');
        out.append("相对位置 横向 ").append(Math.round(t.x*100)).append("% 纵向 ").append(Math.round(t.y*100)).append("%\n");
        out.append("每次重新查找唯一控件 不直接重放这个位置\n");
    }
    public static String describe(LearnedFlow flow) {
        StringBuilder out=new StringBuilder(flow.appName).append("\n应用 ").append(flow.packageName)
                .append("\n适配版本码 ").append(flow.versionCode).append("\n已记录 ").append(flow.steps.size()).append(" 步\n");
        for(int i=0;i<flow.steps.size();i++) {
            FlowStep step=flow.steps.get(i);
            out.append("\n第 ").append(i+1).append(" 步 ").append(step.back?"返回":"点击关闭控件").append('\n')
                    .append("页面 ").append(page(step.guard.activity)).append('\n');
            if(!step.back)target(out,step.target);
            out.append("页面结构条件 已保存\n");
        }
        return out.append("\n结束条件\n").append(page(flow.terminal.activity)).append("\n页面结构必须一致并连续确认两次\n不保存广告正文 课表内容 截图或输入文字").toString();
    }
    public static String describe(LearnedRule rule) {
        StringBuilder out=new StringBuilder(rule.appName).append("\n应用 ").append(rule.packageName)
                .append("\n适配版本码 ").append(rule.versionCode).append("\n页面 ").append(page(rule.activityName)).append('\n');
        target(out,rule.target);
        return out.append("页面结构条件 ").append(rule.pageGuard.isEmpty()?"旧规则使用现场广告证据":"已保存")
                .append("\n点击后仍需确认原目标消失").toString();
    }
}
