import android.os.*;
import android.view.accessibility.*;
import java.util.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.learning.*;
import org.adguardian.app.runtime.*;
import org.adguardian.app.classapp.*;

public class ReviewB79Tests {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("many identical post-close events cannot evict the pre-click recording page",()->{
   var f=new TeachingB77Tests.Fixture();f.start();var first=f.s.root.children.get(1);
   f.s.root=FlowsB77Tests.page("home",null);f.activity="host.example.Main";
   for(int i=0;i<15;i++){SystemClock.now=10100+i*10;f.observe();}
   f.teacher.clicked(RegressionB79Tests.click(f.pkg,first,10040,null));Handler.advance(10400);f.observe();Handler.advance(10700);f.observe();f.save();
   check(f.replay.store().all().size()==1,"event flood evicted the only pre-action snapshot");f.close();
  });
  FlowsB77Tests.run("single learned rule retries failed version query without leaving the app",()->{
   var f=LearningB79Tests.fresh();f.engine.store().add(new LearnedRule("retry","host.example","test","host.example.Main",1,NodeTarget.capture(f.n,f.s.root.bounds).forLearning(),true));
   var pm=new RegressionB78Tests.PM();pm.failures=1;f.s.pm=pm;
   try(var index=AccessibilityNodeIndex.build(f.s.root)){check(!f.engine.handle("host.example","host.example.Main",index),"unknown version may not act");}
   SystemClock.now=11200;try(var index=AccessibilityNodeIndex.build(f.s.root)){check(f.engine.handle("host.example","host.example.Main",index)&&f.n.clicks==1,"legacy replay cached a failed version for entire session");}
  });
  FlowsB77Tests.run("single learned rule cannot click after its target lookup changes foreground",()->{
   var f=LearningB79Tests.fresh();String[] fg={"host.example"};
   var root=new AccessibilityNodeInfo(){@Override public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByViewId(String id){fg[0]="other.example";return super.findAccessibilityNodeInfosByViewId(id);}};
   root.pkg="host.example";root.bounds=f.s.root.bounds;root.add(f.n);f.s.root=root;
   var e=new LearnedRuleEngine(f.s,f.worker,new ActionVerifier(f.s,f.worker,()->fg[0],()->{}),()->fg[0]);
   e.store().add(new LearnedRule("stale","host.example","test","host.example.Main",1,NodeTarget.capture(f.n,root.bounds).forLearning(),true));
   try(var index=AccessibilityNodeIndex.build(root)){check(!e.handle("host.example","host.example.Main",index)&&f.n.clicks==0&&f.s.gestures==0,"stale learned input crossed app boundary");}
  });
  FlowsB77Tests.run("a stale provider exception in the CLASS branch yields instead of aborting the rule thread",()->{
   var f=new ClassAdapterB77Tests.Fixture();var root=new AccessibilityNodeInfo(){@Override public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByViewId(String id){throw new IllegalStateException("provider replaced");}};
   root.pkg=ClassAdProfile.PACKAGE;root.bounds=new android.graphics.Rect(0,0,1080,2400);f.s.root=root;
   check(!f.handle(ClassAdProfile.VIDEO),"unreadable provider acted");f.engine.close();
  });
  FlowsB77Tests.run("recorded Back is not replayed when current Activity is unknown",()->{
   var s=new FlowsB77Tests.Service();var h=new Handler(Looper.getMainLooper());var f=FlowsB77Tests.flow();
   var first=f.steps.get(0);var after=FlowsB77Tests.snap(FlowsB77Tests.page("endcard","关闭"),"host.example.Ad");
   var e=new FlowReplayEngine(s,h,()->"host.example",()->{});e.store().add(new LearnedFlow("guard-back","host.example","test",1,AdType.POPUP,true,List.of(first,new FlowStep(after.guard,null,true,30000)),f.terminal));
   s.root=FlowsB77Tests.page("video","跳过");try(var index=AccessibilityNodeIndex.build(s.root)){e.handle("host.example","host.example.Ad",index);}
   s.root=FlowsB77Tests.page("endcard","关闭");SystemClock.now=10400;try(var index=AccessibilityNodeIndex.build(s.root)){e.handle("host.example","",index);}
   SystemClock.now=10800;try(var index=AccessibilityNodeIndex.build(s.root)){e.handle("host.example","",index);}
   check(s.backActions==0,"unknown window may not trigger a saved Back");e.close();
  });
  FlowsB77Tests.run("an unreadable second click while the first stage is pending cannot be saved as a one-step full flow",()->{
   var f=new TeachingB77Tests.Fixture();f.start();f.click();
   SystemClock.now=10200;f.s.root=FlowsB77Tests.page("endcard","关闭");f.observe();
   f.teacher.clicked(RegressionB79Tests.click(f.pkg,null,10220,null));Handler.advance(10220);
   f.move("home",null,"host.example.Main",10700);f.save();
   check(f.replay.store().all().isEmpty(),"missing second step was silently compressed into a completed one-step recording");f.close();
  });
  FlowsB77Tests.run("partial child data is not mislabeled as exceeding the node limit",()->{
   var r=FlowsB77Tests.page("home",null);r.children.add(null);
   try(var index=AccessibilityNodeIndex.build(r)){check(FlowPage.capture("host.example","host.example.Main",1,index)==null,"partial tree accepted");}
   var detail=ScanDiagnostics.explain(ScanDiagnostics.Area.PAGE);
   check(!detail.contains("上限")&&detail.contains("子控件"),"partial-data error misrepresented as oversized page: "+detail);
   var f=new ClassAdapterB77Tests.Fixture();var partial=new AccessibilityNodeInfo(){
    @Override public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByViewId(String id){return List.of();}
   };partial.pkg=ClassAdProfile.PACKAGE;partial.clickable=false;partial.bounds=new android.graphics.Rect(0,0,1080,2400);partial.children.add(null);f.s.root=partial;f.handle(ClassAdapterB77Tests.AD);
   detail=ScanDiagnostics.explain(ScanDiagnostics.Area.CLASS);f.engine.close();
   check(!detail.contains("上限")&&detail.contains("子控件"),"CLASS partial tree was mislabeled: "+detail);
  });
  FlowsB77Tests.run("corrupt single-button data is reported as unreadable instead of an empty record list",()->{
   java.io.File file=new java.io.File(new android.content.Context().getFilesDir(),"learned-ad-rules.bin");byte[] bad={0,1,2,3};java.nio.file.Files.write(file.toPath(),bad);
   var windows=new RegressionB76Tests.Windows();var service=ServiceFlowB77Tests.create(windows);
   try {
    var activity=new org.adguardian.app.MainActivity();var show=activity.getClass().getDeclaredMethod("showLearnedRules");show.setAccessible(true);show.invoke(activity);Handler.advance(10400);
    check(android.app.AlertDialog.lastMessage.contains("原文件已保留")&&!android.app.AlertDialog.lastMessage.contains("暂未保存"),"unreadable stored data was shown as no recorded data");
    check(Arrays.equals(bad,java.nio.file.Files.readAllBytes(file.toPath())),"corrupt file overwritten without user confirmation");
   }finally{service.onDestroy();Handler.advance(11000);file.delete();}
  });
  System.out.println("B7.9 review cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("B7.9 review regressions");
 }
}
