# 去你的广告 B7.9 项目状态

versionCode 29
versionName 0.7.9-b7.9
基线 B7.8 完整源码

本轮修复录制时间关联 两层快速点击 丢失Activity时的安全窗口条件
旧单按钮入口仍有128节点限制已统一修正
缺失子节点和损坏学习文件均不再被错误显示为空数据
新增实际加载的CLASS四组本地规则和课表结束页控件条件
主页可查看CLASS内置规则 两套记录管理可查看实际保存的数据

CLASS 仅 cn.luyiyuntech.stt versionCode1013
输入APK只读解析不修改 没有运行远程下发模板
原始社区规则 选择器 权限和签名内容未变
旧单按钮及流程数据格式继续可读 没有清除迁移或伪造录制数据

完整宿主测试已运行 退出码0
Python30 Kotlin19 Android接口模拟168 其中本轮新增Android38
见根目录VERIFICATION.txt与docs/B7.9-audit.md
没有Android SDK编译产物 没有真实手机运行保证
