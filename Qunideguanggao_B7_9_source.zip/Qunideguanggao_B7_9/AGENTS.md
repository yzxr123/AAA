# 去你的广告 B7.9

Read .agents/skills/android-ad-guardian/SKILL.md and docs/B7.9-audit.md before changes
Android phone application One offline APK No INTERNET permission No update subsystem
Keep app identity signing key original LTT bytes bundled GKD source and subscription unchanged
Do not require root Shizuku a companion app or WRITE_SECURE_SETTINGS
Never invoke onServiceConnected to pretend a framework rebind

## Preserved lifecycle

Authorization has known enabled known disabled unknown states
An unavailable settings read plus an empty manager list is not revocation
Retained positive authorization is only background retention policy not proof of a live service
Separate framework connection engine readiness and foreground guard status
User master/background off and explicit revocation must be honored
No hidden activities restart loops wake locks silent audio or claims of defeating OEM force stop
See docs/B7.6-audit.md for the inherited changes and limitations

## CLASS profile

Exact package cn.luyiyuntech.stt and versionCode 1013 only
Use only APK-evidenced Activities and actual resource IDs
tv_skip can be GONE Never click its historic position
TTFullScreenVideoActivity is ordinary fullscreen even though its namespace includes reward
Do not fold TTRewardVideoActivity or ordinary timetable pages into targeted closing
No generic Back No fabricated SDK IDs No blind corner tapping
Recheck each stage A completed input or missing first button is not proof the entire ad is over
Use bounded parents not the whole ad container
Class profile has a default-on separate switch

## Learning and replay

Primary multi-step implementation is flow/ FlowTeachingController FlowJournal FlowReplayEngine FlowStore
Single-button learning/ and its data must stay compatible
Explicit teaching only max180seconds max8steps No passive daily input recording
Pause other automation and OCR during either teaching mode
Capture immutable pre-action data and read event source at event intake
Explicit node selection does not inject a click Explicit Record and Back does inject one after guards
No first-step Back No Back on CLASS MainActivity
Commit a stage after two observations of target disappearance or a stable changed stage structure
Unchanged disabled visible targets are not disappearance
Unknown roots missing recorded steps incomplete traversals and unverified final pages cannot be success
Store only package version Activity structural digest safe target descriptor and expected terminal guard
No arbitrary content text screenshots passwords or coordinate-only macros
Replay must start at step1 and freshly resolve every target No mid-flow guessing
Exact package version guard and orientation unique target user switches apply to each action
A no-effect unchanged step yields after2500ms Step transition deadline30s total120s
Known unrelated Activities and user intervention cancel replay
Legacy learned-ad-rules.bin is untouched New flow file is separate atomic bounded and validated

## Runtime

Verified learned flow then legacy learned rule then CLASS profile then original LTT then real GKD subscription then constrained assistance then optional OCR
An active flow owns the action pipeline and blocks OCR Lower engines do not race its actions
Keep node caches event coalescing off-main query work delayed512pxRGB565OCR and all old switches
Use generation/foreground checks after expensive reads before injecting input
Diagnostic exceptions do not create fake permission or successful ads

## Delivery

Run tools/run_host_tests.py with all Python Kotlin and Java API-double tests
An API-double compilation is not Android SDK compilation or a real phone result
Deliver full Qunideguanggao_B7_9_source.zip and standalone build-apk-B7.9.yml
Inline workflow source preparation must accept renamed intact ZIPs nested folders and isolate old checkout files
Do not make users upload individual source files

## Inherited B7.8 boundary fixes
Preserve validated Activity candidates through coalescing of Dialog/View state events
Retry negative Activity and package metadata lookups with bounded TTL not session-long false caches
Critical teaching selection action verification and active replay refresh native cached roots
Never select the expected background app behind a different topmost application
Flow f2 guards ignore passive anonymous marketing content but preserve safe controls resource IDs and version scope
f1 stored guards remain compatible using the original B7.7 structural digest for unchanged pages
Explicit teaching node capture is limited to1024 with160ms budget Ordinary scans keep480 and existing budgets
Explicit picker teardown may retry120ms then300ms only within unchanged session app Activity orientation
ScanDiagnostics stores one enum-only record per subsystem in RAM No raw text screenshots coordinates or node handles
Full host command includes RegressionB78Tests Do not present API-double success as phone success
No device exit logs were supplied Background rebind remains unverified and must not be described as fixed


## B7.9 recording and actual CLASS assets
ClassAdEngine must load class/cn.luyiyuntech.stt_1013.json via ClassAdRules
Do not silently replace the four groups with guessed corner coordinates or report-only JSON
The new native promotion guard requires close AND tv_confirm AND btn_pay_now Only close is actionable
CLASS terminal fallback requires navigation_bar tv_today_date tv_weeks timetableView together
Native package version must equal1013 Unknown and other versions do not use these fixed parameters
Runtime asset and UI viewer are tested through the real RuleEngine and MainActivity

Both old single-button LearningController and FlowTeachingController use shared FlowPage metadata
TeachingHistory keeps max12 distinct pages for15seconds only during explicit teaching
Use getEventTime and event window to correlate the pre-click snapshot Never use only arrival-time page
Duplicate safe snapshots coalesce without losing the earlier pre-click page
A second explicit click can corroborate a previously observed changed stage before recording the next step
Do not count a missing second click as success Do not save a truncated sequence
Unknown Activity does not imply no nodes It requires at least2 distinct stable IDs and exact f2 structure
Known conflicting Activities never match A missing Activity never authorizes a recorded Back
Small picture and bounded clickable parent refer to one actual action region not duplicate candidates
The legacy128node capture path must not return Both paths allow up to1024 nodes within160ms cooperative budget
Null declared child means unavailable child not zero data or traversal-size overflow
Corrupt single-button or flow files must be reported unreadable and preserved Never show empty success
Management must display sanitized saved steps and targets Actual body text is never part of exported learning data
Original p1/f1 stored records remain supported without rewriting the user database

Run all Python Kotlin Java host tests including RegressionB79Tests LearningB79Tests EdgesB79Tests ReviewB79Tests
Regression evidence and selected fresh binary APK extracts are in docs
No device exists here No claim about all SDK dynamic templates or opaque Canvas learning
