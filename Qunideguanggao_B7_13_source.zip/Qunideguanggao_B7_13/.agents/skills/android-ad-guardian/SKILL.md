---
name: android-ad-guardian
description: Maintain the actual offline Android ad-skip project and its tested learning and service state boundaries
---

# 去你的广告 B7.13

Read AGENTS.md PROJECT_STATUS.md docs/B7.13-audit.md
Old version docs are history not current behavior

先确认真实源码和实机证据 不把历史通过数量当作本次验证
优先分开 目标定位 步骤变化 终点证明 草稿状态和正式规则
新完整流程保存可解码的v3局部目标与终点条件 旧f1f2原语义保留
草稿有可逐项审查的问题和确认前缀补录 不直接启用不完整草稿
补录产生新草稿 原草稿不删除 原执行流程不覆盖 仍需真实终点校验
写前备份原格式 写后回读 在实际设备上未验证的必须明确
CLASS四个已有模板使用schema2和明确包版本 阶段数据参与执行与诊断
不得把有SDK或者有Activity当作找到关闭按钮
普通健康检查只修复内部初始化 不定时移除系统辅助功能组件
手动增强修复要求明确操作真实权限与事务恢复标记 不自动重新授权
保持单APK本地事件驱动 OCR开关和原LTT GKD数据 不默认引入VPN或Hook
完整测试入口 python3 tools/run_host_tests.py
交付完整ZIP和独立工作流 不声称已有APK或手机效果除非实际完成测试
