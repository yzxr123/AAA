# B7.12 构建

versionName 0.7.12-b7.12
versionCode 32
原始包名和 dev-signing.jks 保持不变
同版本完整源码 ZIP 和独立工作流成对使用
.github/workflows/build-apk.yml 是真实入口
inline Python识别ZIP内部版本 后复制到独立构建目录
支持下载编号 中文重命名 子目录和旧版本 ZIP 共存
不允许悄悄退回缺少工具脚本的不完整工作目录

新源码 REQUIRED 与 tests/test_ci_source_preparation.py一致
清理已知遗留文件不删除新录制 后台增强及定向规则
运行 tools/run_host_tests.py
GitHub 用Gradle实际编译 gkd-core 测试和 app assembleRelease
所有 API替身仍在 tests 下 不进入生产APK
WRITE_SECURE_SETTINGS为明确可选开发权限 仅该声明使用针对性ProtectedPermissions lint说明
不能关掉整个lint来绕过编译错误
APK50MiB硬限是安装包体积 不是RAM测量
最终保存实际验证输出 不引用历史通过数作为本轮结果
