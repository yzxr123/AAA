# 去你的广告 B7.14

Android 手机应用
应用版本 0.7.14-b7.14 版本码34

基于完整B7.13修改
针对QUERY_ALL_PACKAGES的Lint错误保留扫描功能并增加单声明用途说明
CI完整输出并上传Lint XML TXT HTML与原始日志
Lint错误 缺失报告或任务失败会阻止发布 不再只显示堆栈末尾
同时修复CLASS录制与回放终点不一致 旧操作跨应用补发手势 和旧结果回调覆盖新操作

## GitHub只上传完整ZIP和工作流

不要解压源码ZIP
将 Qunideguanggao_B7_14_source.zip 上传仓库
将配套 build-apk-B7.14.yml 的全部内容替换到 .github/workflows/build-apk.yml
Actions中新启动 Build 去你的广告 B7.14
不要重跑使用旧提交的记录
支持ZIP带下载括号 放子目录 旧版ZIP共存
同版本有不同内容的两份ZIP时使用source_path明确指定

通过后生成 Qunideguanggao-B7.14.apk
本源码包不包含已经编译的B7.14 APK

## Lint报告

不需要为了消除警告删除全应用SDK检测
QueryAllPackagesPermission只在一条权限声明上定向处理
其它API 权限 资源和运行风险检查没有全局关闭
Lint报告先上传后执行发布门禁
完整诊断在Actions构建附件 lint-reports-B7.14
包含lint-results-release.xml txt html 原始lint-release.log和逐项摘要
仅有警告且检查成功时仍可发布 有error或无法完成检查则不发布
上次报告中的12个警告未提供完整详情 本轮不能称它们已经被修复

## 学习与CLASS

CLASS规则继续限定 cn.luyiyuntech.stt 版本1013
结束录制与实际回放使用同一个真实主页证明
只拿到MainActivity名称但没有足够主页控件时 不再生成无法完成的流程
草稿仍保留 可以继续审查补录和结束验证 不会被删除
真正回到主页仍能保存并启用

回放或CLASS点击失败后 再次检查当前前台与用户开关才允许手势回退
取消或换应用后 旧操作不能重新建立待执行状态
旧结果查询返回前重新核对票据代次 避免清掉新操作或误报完成
未改变原始LTT GKD规则与选择器 CLASS JSON OCR及签名
原来的学习文件和升级备份语义保留

## 后台范围

复查已有授权 连接 就绪和通知状态拆分及有限初始化恢复
本轮未改变周期巡检不修改系统授权的规则
不声称可以解决所有厂商清后台和强行停止后的自动恢复
未增加静音音频 无限Alarm 多进程互拉 VPN或联网

## 验证范围

完整命令 python3 tools/run_host_tests.py
本轮记录见VERIFICATION.txt与docs/B7.14-audit.md
本环境没有Android SDK Gradle或可连接手机
宿主真实Java/Kotlin代码使用Android接口替身 不是真机Binder GPU或OCR测试
没有把宿主通过当成实际lintRelease已通过
