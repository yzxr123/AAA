"""Small build-time regressions for the exact platform/config boundaries changed in B7.13."""
from pathlib import Path
import copy
import unittest
from test_class_rules import module
import json
ROOT=Path(__file__).resolve().parents[1]

class B713ContractTests(unittest.TestCase):
    def test_no_api31_copy_factories_in_new_api30_helpers(self):
        for name in ('FlowObservation','FlowCondition'):
            text=(ROOT/f'app/src/main/java/org/adguardian/app/flow/{name}.java').read_text()
            self.assertNotIn('List.copyOf(',text)
            self.assertNotIn('Set.copyOf(',text)
    def test_fifth_bounded_class_variant_is_accepted(self):
        d=json.loads((ROOT/module.ASSET).read_text()); r=copy.deepcopy(d['rules'][0]);r['key']='class_extra_promotion';r['requiredIds']=['close'];d['rules'].append(r);module.validate(d)
    def test_extension_cannot_make_automatic_close_a_payment(self):
        d=json.loads((ROOT/module.ASSET).read_text());r=copy.deepcopy(d['rules'][0]);r['key']='class_extra_promotion';r['targetId']='btn_pay_now';d['rules'].append(r)
        with self.assertRaises(ValueError):module.validate(d)
    def test_unknown_next_stage_is_rejected(self):
        d=json.loads((ROOT/module.ASSET).read_text());d['rules'][0]['nextStages']=['ANYWHERE']
        with self.assertRaises(ValueError):module.validate(d)
    def test_unbounded_retry_not_accepted(self):
        d=json.loads((ROOT/module.ASSET).read_text());d['rules'][0]['maxActions']=999
        with self.assertRaises(ValueError):module.validate(d)
