import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.view.accessibility.*;
import org.adguardian.app.classapp.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.recording.*;
import org.adguardian.app.runtime.*;
import java.nio.file.*;

public final class AuditB712Tests {
 static final String P=ClassAdProfile.PACKAGE;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 public static void main(String[]args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("disabled non-action CLASS promotion anchors must not hide an enabled close control",()->{
   var service=new FlowsB77Tests.Service();service.root=FlowsB77Tests.root(P,P+":id/dialog_ad");
   for(String id:new String[]{"close","tv_confirm","btn_pay_now"}) {
    var n=FlowsB77Tests.n(P+":id/"+id,null,"android.widget.TextView",600,300,100,70,true);
    if(!id.equals("close"))n.enabled=false;service.root.add(n);
   }
   try(var index=AccessibilityNodeIndex.build(service.root)){
    var rule=ClassAdRules.load(service).match(ClassAdProfile.MAIN,index);
    check(rule!=null&&rule.key.equals("class_native_promotion"),"enabled flag of a context anchor suppressed an actual close rule");
   }
  });
  FlowsB77Tests.run("known main course header certifies home when custom timetable node is not exposed",()->{
   var root=FinalizationB711Tests.home();root.children.removeIf(n->(P+":id/timetableView").equals(n.id));
   try(var index=AccessibilityNodeIndex.build(root)){
    var page=FlowPage.capture(P,ClassAdProfile.MAIN,1013,index);
    check(page!=null&&page.isCertifiedClassHome(),"end-of-recording waits forever on a custom node unavailable on this page");
   }
  });
  FlowsB77Tests.run("global accessibility off with retained component is not shown as authorized",()->{
   var c=RecoveryB711Tests.setup();c.getContentResolver().settings.put(Settings.Secure.ACCESSIBILITY_ENABLED,"0");
   var state=AccessibilityState.read(c);
   check(state.known&&!state.authorized,"retained component hid the explicitly disabled global switch");
  });
  FlowsB77Tests.run("record-and-back must not inject when the draft cannot be written",()->{
   RegressionB710Tests.clean();var f=new TeachingB77Tests.Fixture();
   try{
    f.start();f.pick();f.move("endcard","关闭","host.example.Ad",10400);
    Files.write(RegressionB710Tests.drafts().toPath(),new byte[]{1,2,3});
    f.teacher.recordBack();Handler.advance(SystemClock.now);
    check(f.s.backActions==0,"Back was sent before failed persistence, losing the recorded operation");
   }finally{f.close();RegressionB710Tests.clean();}
  });
  FlowsB77Tests.run("Pangle ordinary fullscreen page must not be classified as rewarded only by package segment",()->{
   check(!AdSdkSignatures.isRewardedActivity(ClassAdProfile.VIDEO),"reward namespace disabled ordinary fullscreen matching");
   check(AdSdkSignatures.isRewardedActivity("com.bytedance.sdk.openadsdk.core.component.reward.activity.TTRewardVideoActivity"),"real reward video no longer protected");
  });
  FlowsB77Tests.run("repeated unchanged overlay sync must not postpone handoff forever",()->{
   var c=new Context();var windows=new OverlayB711Tests.Windows();c.services.put(Context.WINDOW_SERVICE,windows);
   c.getContentResolver().settings.put("overlay_allowed","1");
   var overlay=new org.adguardian.app.service.ProtectionOverlay(c);long start=SystemClock.now;
   overlay.sync(false);overlay.sync(true);Handler.advance(start+600);overlay.sync(true);Handler.advance(start+1100);
   check(windows.views.isEmpty(),"unchanged state reset the one-second handoff deadline");overlay.close();
  });
  FlowsB77Tests.run("a failed draft marker cannot hide the fact that the official flow was committed",()->{
   RegressionB710Tests.clean();var f=new TeachingB77Tests.Fixture();
   try{f.start();f.pick();f.move("home",null,"host.example.Main",10400);
    Files.write(RegressionB710Tests.drafts().toPath(),new byte[]{1,2,3});f.save();
    check(f.replay.store().all().size()==1,"formal flow not persisted");
    check(f.teacher.status().contains("草稿状态未更新"),"draft marker failure hidden behind unconditional success");
   }finally{f.close();RegressionB710Tests.clean();}
  });
  FlowsB77Tests.run("CLASS capture to known Main header promotes a real file-backed flow without custom canvas ID",()->{
   RegressionB710Tests.clean();var f=new TeachingB77Tests.Fixture();
   try{f.pkg=P;f.activity=ClassAdProfile.SPLASH;f.s.pm.packageVersion=1013;
    f.s.root=FlowsB77Tests.root(P,P+":id/fl_ad_container");
    f.s.root.add(FlowsB77Tests.n(P+":id/fl_place_holder_container",null,"android.view.View",0,200,1000,1500,false));
    f.s.root.add(FlowsB77Tests.n(P+":id/tv_skip","跳过","android.widget.TextView",940,70,100,60,true));
    f.start();f.pick();f.s.root=FinalizationB711Tests.home();f.s.root.children.removeIf(n->(P+":id/timetableView").equals(n.id));f.activity=ClassAdProfile.MAIN;
    Handler.advance(10400);f.observe();Handler.advance(10800);f.observe();Handler.advance(11200);for(int i=0;i<4;i++)Handler.advance(SystemClock.now+200);
    check(f.replay.store().all().size()==1,"actual capture and completion pipeline did not commit: "+f.teacher.status());
    check(new RecordingDraftStore(f.s).all().get(0).state==RecordingDraft.ENABLED,"captured lesson not promoted");
   }finally{f.close();RegressionB710Tests.clean();}
  });
  FlowsB77Tests.run("three home headers cannot override a visible splash container or real SDK ad activity",()->{
   var root=FinalizationB711Tests.home();root.children.removeIf(n->(P+":id/timetableView").equals(n.id));
   root.add(FlowsB77Tests.n(P+":id/fl_ad_container",null,"android.view.View",0,400,1000,1500,false));
   root.add(FlowsB77Tests.n(P+":id/fl_place_holder_container",null,"android.view.View",0,400,1000,1500,false));
   for(String activity:new String[]{ClassAdProfile.SPLASH,ClassAdProfile.VIDEO})try(var index=AccessibilityNodeIndex.build(root)){
    check(!FlowPage.capture(P,activity,1013,index).isCertifiedClassHome(),"weak home alternative certified a still-advertisement page");
   }
  });
  System.out.println("B7.12 audit regression cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("B7.12 audit regressions");
 }
}
