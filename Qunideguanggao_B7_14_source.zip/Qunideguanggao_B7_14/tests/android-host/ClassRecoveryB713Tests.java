import android.content.*;import android.content.res.*;import android.os.*;import java.io.*;import java.nio.file.*;import java.util.*;
import org.adguardian.app.classapp.*;import org.adguardian.app.engine.*;import org.adguardian.app.flow.*;import org.adguardian.app.runtime.*;import org.adguardian.app.service.*;

public final class ClassRecoveryB713Tests {
 static void check(boolean value,String why){if(!value)throw new AssertionError(why);}
 static Context asset(String text){return new Context(){public AssetManager getAssets(){return new AssetManager(){public InputStream open(String p)throws IOException{return new ByteArrayInputStream(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));}};}};}
 static String extension()throws Exception{
   String text=Files.readString(Path.of(System.getProperty("test.assets"),ClassAdRules.ASSET));
   String extra="{\"key\":\"class_extra_promotion\",\"name\":\"已有推广模板的更窄变体\",\"category\":\"POPUP\",\"activities\":[],\"allIds\":[\"close\",\"tv_confirm\",\"btn_pay_now\"],\"targetId\":\"close\",\"matchCloseText\":false,\"evidence\":\"test-only stricter known popup template\",\"stage\":\"NATIVE_PROMOTION\",\"nextStages\":[\"HOST_HOME\"],\"requiredIds\":[\"close\"],\"excludedIds\":[],\"maxActions\":2,\"timeoutMs\":15000},";
   return text.replaceFirst("\\\"rules\\\"\\s*:\\s*\\[",java.util.regex.Matcher.quoteReplacement("\"rules\": ["+extra));
 }
 public static void main(String[]args)throws Exception{
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("B713 periodic health checks never remove system authorization even when enhancement is granted",()->{
   var c=RecoveryB711Tests.setup();RecoveryB711Tests.consent(c,true);Object r=RecoveryB711Tests.make(c);String before=c.getContentResolver().settings.get(RecoveryB711Tests.KEY);
   try{RecoveryB711Tests.request(r,false);check(before.equals(c.getContentResolver().settings.get(RecoveryB711Tests.KEY)),"routine check removed own component");}finally{RecoveryB711Tests.close(r);}
  });
  FlowsB77Tests.run("B713 explicit granted repair remains available and checks actual connection",()->{
   var c=RecoveryB711Tests.setup();RecoveryB711Tests.consent(c,true);Object r=RecoveryB711Tests.make(c);
   try{RecoveryB711Tests.request(r,true);check(!RecoveryB711Tests.self(c),"explicit repair missing");Handler.advance(14000);check(RecoveryB711Tests.self(c)&&!AccessibilityState.read(c).connected,"repair did not restore or forged live connection");}finally{RecoveryB711Tests.close(r);}
  });
  FlowsB77Tests.run("B713 connected initialization failure has a bounded retry budget and preserves consent",()->{
   var s=new AdAccessibilityService();s.services.put(Context.WINDOW_SERVICE,new RegressionB76Tests.Windows());RegressionB76Tests.authorize(s);s.failServiceInfo=true;
   var connect=AdAccessibilityService.class.getDeclaredMethod("onServiceConnected");connect.setAccessible(true);connect.invoke(s);Handler.advance(SystemClock.now);
   var r=new AccessibilityRecovery(s,new Handler(Looper.getMainLooper()));
   try{for(int i=0;i<8;i++){r.request(false);Handler.advance(SystemClock.now+130000);}
    var field=AdAccessibilityService.class.getDeclaredField("healthInitAttempts");field.setAccessible(true);check(field.getInt(s)==3,"unbounded initialization retries");
    check(AccessibilityState.read(s).authorized,"initialization failure revoked consent");s.failServiceInfo=false;AdAccessibilityService.retryInitialization();Handler.advance(SystemClock.now+1000);check(AccessibilityState.read(s).running(),"explicit retry could not recover after automatic budget");
   }finally{r.close();Handler.advance(SystemClock.now);s.onDestroy();Handler.advance(SystemClock.now+1000);}
  });
  FlowsB77Tests.run("B713 a fifth constrained CLASS rule does not disable the existing four",()->{
   var rules=ClassAdRules.load(asset(extension()));check(rules.rules.size()==5,"hard-coded rule count rejected valid extension");
  });
  FlowsB77Tests.run("B713 CLASS extensions cannot replace a close target with a payment target",()->{
   check(ClassAdRules.load(asset(extension().replaceFirst("\\\"targetId\\\":\\\"close\\\"","\"targetId\":\"btn_pay_now\""))).rules.isEmpty(),"payment was accepted as an extension action");
  });
  FlowsB77Tests.run("B713 three headers on an actual fullscreen SDK activity are not home",()->{
   var r=FinalizationB711Tests.home();r.children.removeIf(n->(ClassAdProfile.PACKAGE+":id/timetableView").equals(n.id));
   check(!FinalizationB711Tests.snapshot(r,ClassAdProfile.VIDEO).isCertifiedClassHome(),"real fullscreen erased by home background");
  });
  FlowsB77Tests.run("B713 CLASS missing targets keep a specific stage diagnostic rather than a fake success",()->{
   var s=new FlowsB77Tests.Service();s.getPackageManager().packageVersion=1013;s.root=ClassAdapterB77Tests.root();
   var engine=new RuleEngine(s,new Handler(Looper.getMainLooper()),()->{},()->ClassAdProfile.PACKAGE);
   try{engine.handle(ClassAdProfile.PACKAGE,ClassAdProfile.VIDEO,32,s.root);
    String diag=RuntimeDiagnostics.read(s);check(diag.contains("SDK_FULLSCREEN")&&diag.contains("NO_CLOSE"),"no stage-specific missing-target evidence");}
   finally{engine.close();}
  });
  System.out.println("B7.13 CLASS and recovery passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("CLASS recovery regressions");
 }
}
