import android.content.*;
import android.graphics.Rect;
import android.os.*;
import android.view.accessibility.*;
import java.util.*;
import org.adguardian.app.classapp.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.settings.PreferenceStore;

/** Runs real app code with adversarial Binder callbacks, not an Android device. */
public final class LogicB714Tests {
    static void check(boolean v,String why){if(!v)throw new AssertionError(why);}
    static class FailedClick extends AccessibilityNodeInfo {
        Runnable after;
        FailedClick(String pkg,String id,String text,Runnable after){
            this.pkg=pkg;this.id=id;this.text=text;this.name="android.widget.TextView";
            this.bounds=new Rect(940,70,1040,130);this.clickable=true;this.after=after;
        }
        @Override public boolean performAction(int action){clicks++;if(after!=null)after.run();return false;}
    }
    static class CallbackService extends FlowsB77Tests.Service {
        Runnable duringRead;
        @Override public AccessibilityNodeInfo getRootInActiveWindow(){
            if(duringRead!=null){Runnable run=duringRead;duringRead=null;run.run();}
            return root;
        }
    }
    static FlowPage classPage(AccessibilityNodeInfo root,String activity){return FinalizationB711Tests.snapshot(root,activity);}
    static AccessibilityNodeInfo splash(){
        var r=FlowsB77Tests.root(ClassAdProfile.PACKAGE,ClassAdProfile.PACKAGE+":id/fl_ad_container");
        r.add(FlowsB77Tests.n(ClassAdProfile.PACKAGE+":id/fl_place_holder_container",null,"android.view.View",0,200,1000,1500,false));
        r.add(FlowsB77Tests.n(ClassAdProfile.PACKAGE+":id/tv_skip","跳过","android.widget.TextView",940,70,100,60,true));return r;
    }
    static FlowJournal classJournal(){
        var r=splash();FlowPage p=classPage(r,ClassAdProfile.SPLASH);var j=new FlowJournal(AdType.STARTUP);
        check(p!=null&&j.beginClick(p,p.pick(980,100)),"fixture could not capture splash");return j;
    }
    public static void main(String[] args)throws Exception {
        FlowsB77Tests.pass=FlowsB77Tests.fail=0;
        FlowsB77Tests.run("B714 CLASS MainActivity name without home evidence must not enable a flow",()->{
            var j=classJournal();var root=FlowsB77Tests.root(ClassAdProfile.PACKAGE,ClassAdProfile.PACKAGE+":id/another_panel");
            root.add(FlowsB77Tests.n(ClassAdProfile.PACKAGE+":id/another_content",null,"android.view.View",0,300,900,800,false));
            var page=classPage(root,ClassAdProfile.MAIN);check(page!=null&&!page.isCertifiedClassHome(),"fixture accidentally certified home");
            j.observe(page,10300);j.observe(page,10600);check(j.stepCount()==1,"fixture did not confirm first step");
            check(!j.finishProblem().isEmpty(),"recording accepted end that CLASS replay will never accept");
        });
        FlowsB77Tests.run("B714 actual CLASS home still enables the confirmed lesson",()->{
            var j=classJournal();var h=classPage(FinalizationB711Tests.home(),ClassAdProfile.MAIN);
            j.observe(h,10300);j.observe(h,10600);check(j.finishProblem().isEmpty()&&j.finish("good-home","课表").steps.size()==1,"real home rejected");
        });
        FlowsB77Tests.run("B714 flow native click failure after foreground change cannot fall back to gesture",()->{
            var s=new FlowsB77Tests.Service();String[] fg={"host.example"};
            var e=new FlowReplayEngine(s,new Handler(Looper.getMainLooper()),()->fg[0],()->{});e.store().add(ResearchB713Tests.recorded());
            s.root=FlowsB77Tests.page("video","跳过");var n=new FailedClick(fg[0],"host.example:id/close","跳过",()->fg[0]="other.example");
            s.root.children.remove(1);s.root.add(n);
            try{FlowsB77Tests.handle(e,s,"host.example.Ad");check(n.clicks==1&&s.gestures==0&&!e.isActive(),"stale flow injected gesture in next app");}finally{e.close();}
        });
        FlowsB77Tests.run("B714 disabling the active category during failed click prevents gesture fallback",()->{
            var s=new FlowsB77Tests.Service();var e=new FlowReplayEngine(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});e.store().add(ResearchB713Tests.recorded());
            s.root=FlowsB77Tests.page("video","跳过");var n=new FailedClick("host.example","host.example:id/close","跳过",()->PreferenceStore.setTypeEnabled(s,AdType.POPUP,false));
            s.root.children.remove(1);s.root.add(n);
            try{FlowsB77Tests.handle(e,s,"host.example.Ad");check(s.gestures==0&&!e.isActive(),"disabled category still injected input");}finally{e.close();}
        });
        FlowsB77Tests.run("B714 same-window failed click still has its allowed gesture fallback",()->{
            var s=new FlowsB77Tests.Service();var e=new FlowReplayEngine(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});e.store().add(ResearchB713Tests.recorded());
            s.root=FlowsB77Tests.page("video","跳过");s.root.children.remove(1);s.root.add(new FailedClick("host.example","host.example:id/close","跳过",null));
            try{FlowsB77Tests.handle(e,s,"host.example.Ad");check(s.gestures==1&&e.isActive(),"valid fallback removed");}finally{e.close();}
        });
        FlowsB77Tests.run("B714 CLASS failed native click cannot inject a gesture after app switch",()->{
            var s=new ClassAdapterB77Tests.Service();s.getPackageManager().packageVersion=1013;String[] fg={ClassAdProfile.PACKAGE};
            var h=new Handler(Looper.getMainLooper());var v=new ActionVerifier(s,h,()->fg[0],()->{});
            var e=new ClassAdEngine(s,h,()->fg[0],()->{},v);s.root=ClassAdapterB77Tests.root();
            var n=new FailedClick(fg[0],fg[0]+":id/tv_skip","跳过",()->fg[0]="other.example");s.root.add(n);
            try(var i=AccessibilityNodeIndex.build(s.root)){e.handle(ClassAdProfile.PACKAGE,ClassAdProfile.SPLASH,i);}
            check(n.clicks==1&&s.gestures==0&&!e.isPending(),"CLASS stale fallback touched next app");e.close();v.cancel();
        });
        FlowsB77Tests.run("B714 cancelled CLASS attempt cannot recreate a pending gesture",()->{
            var s=new ClassAdapterB77Tests.Service();s.getPackageManager().packageVersion=1013;var h=new Handler(Looper.getMainLooper());
            var v=new ActionVerifier(s,h,()->ClassAdProfile.PACKAGE,()->{});var e=new ClassAdEngine(s,h,()->ClassAdProfile.PACKAGE,()->{},v);
            s.root=ClassAdapterB77Tests.root();s.root.add(new FailedClick(ClassAdProfile.PACKAGE,ClassAdProfile.PACKAGE+":id/tv_skip","跳过",e::cancelPending));
            try(var i=AccessibilityNodeIndex.build(s.root)){e.handle(ClassAdProfile.PACKAGE,ClassAdProfile.SPLASH,i);}
            check(s.gestures==0&&!e.isPending(),"cancelled CLASS action recreated pending state");e.close();v.cancel();
        });
        FlowsB77Tests.run("B714 old result callback cannot clear a replacement verification ticket",()->{
            var s=new CallbackService();s.root=FlowsB77Tests.page("video","跳过");var h=new Handler(Looper.getMainLooper());
            var verifier=new ActionVerifier(s,h,()->"host.example",()->{});ActionVerifier.Ticket first;
            try(var i=AccessibilityNodeIndex.build(s.root)){first=verifier.capture("host.example","old","click",s.root.children.get(1),i,null);}
            verifier.accepted(first);s.root=FlowsB77Tests.page("home",null);Handler.advance(10150);
            s.duringRead=()->{
                verifier.cancel();s.root=FlowsB77Tests.page("replacement","关闭");
                try(var i=AccessibilityNodeIndex.build(s.root)){
                    var second=verifier.capture("host.example","new","click",s.root.children.get(1),i,null);verifier.accepted(second);
                }
                s.root=FlowsB77Tests.page("home",null);
            };
            Handler.advance(10350);
            check(verifier.isPending(),"old read cleared the new pending ticket");verifier.cancel();
        });
        FlowsB77Tests.run("B714 scope change during result lookup cannot record completion",()->{
            var s=new CallbackService();String[] fg={"host.example"};int[] rescans={0};s.root=FlowsB77Tests.page("video","跳过");
            var verifier=new ActionVerifier(s,new Handler(Looper.getMainLooper()),()->fg[0],()->rescans[0]++);
            try(var i=AccessibilityNodeIndex.build(s.root)){verifier.accepted(verifier.capture(fg[0],"old","click",s.root.children.get(1),i,null));}
            s.root=FlowsB77Tests.page("home",null);Handler.advance(10150);s.duringRead=()->fg[0]="other.example";Handler.advance(10350);
            check(rescans[0]==0&&!verifier.isPending(),"result was finalized after foreground changed");verifier.cancel();
        });
        System.out.println("B7.14 logical regressions passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
        if(FlowsB77Tests.fail>0)throw new AssertionError("B714 logical regressions "+FlowsB77Tests.fail);
    }
}
