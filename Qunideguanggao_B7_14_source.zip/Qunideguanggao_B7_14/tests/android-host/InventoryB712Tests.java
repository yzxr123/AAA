import android.content.*;import android.content.pm.*;import java.nio.file.*;import java.util.function.*;
public final class InventoryB712Tests {
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 static String scan(Context c,BooleanSupplier stop)throws Exception{
  Class<?> type;try{type=Class.forName("org.adguardian.app.sdk.InstalledSdkInventory");}catch(ClassNotFoundException e){throw new AssertionError("Installed app inventory integration missing");}
  return (String)type.getMethod("scan",Context.class,BooleanSupplier.class,Consumer.class).invoke(null,c,stop,(Consumer<String>)(x)->{});
 }
 static ApplicationInfo app(String pkg,String path){var a=new ApplicationInfo();a.packageName=pkg;a.sourceDir=path;return a;}
 public static void main(String[]args)throws Exception{
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("installed user application scanner includes split APK and excludes own and system packages",()->{
   Path p=SdkB712Tests.folder();var c=new Context();var base=SdkB712Tests.apk(p,"base.apk","classes.dex",SdkB712Tests.dex(new String[]{"Lhost/A;"},new int[]{0}));
   var split=SdkB712Tests.apk(p,"split.apk","classes2.dex",SdkB712Tests.dex(new String[]{"Lcom/qq/e/ads/A;"},new int[]{0}));
   var target=app("host.example",base.toString());target.splitSourceDirs=new String[]{split.toString()};c.pm.installed.add(target);
   var system=app("system.example",base.toString());system.flags=ApplicationInfo.FLAG_SYSTEM;c.pm.installed.add(system);c.pm.installed.add(app(c.getPackageName(),base.toString()));
   String report=scan(c,()->false);check(report.contains("腾讯优量汇")&&report.contains("host.example"),"real split SDK not reported");check(!report.contains("system.example")&&!report.contains(c.getPackageName()),"irrelevant apps included");
  });
  FlowsB77Tests.run("unreadable installed archive is reported as incomplete not no ads",()->{
   var c=new Context();c.pm.installed.add(app("broken.example","/no/such.apk"));String report=scan(c,()->false);check(report.contains("无法完整检查"),"unreadable data hidden");
  });
  FlowsB77Tests.run("SDK inventory cancellation stops before reading applications",()->{
   var c=new Context();c.pm.installed.add(app("cancel.example","/no/such.apk"));String report=scan(c,()->true);check(report.contains("已停止"),"cancel ignored");check(!report.contains("cancel.example"),"cancelled app still inspected");
  });
  FlowsB77Tests.run("concurrent inventory requests do not start a second disk scan",()->{
   Path p=SdkB712Tests.folder();var c=new Context();var base=SdkB712Tests.apk(p,"base.apk","classes.dex",SdkB712Tests.dex(new String[]{"Lhost/A;"},new int[]{0}));c.pm.installed.add(app("host.example",base.toString()));
   String[] nested={""};org.adguardian.app.sdk.InstalledSdkInventory.scan(c,()->false,x->{nested[0]=org.adguardian.app.sdk.InstalledSdkInventory.scan(c,()->false,y->{});});
   check(nested[0].contains("已经在进行"),"a concurrent scan was not rejected");
  });
  FlowsB77Tests.run("one-click enable refreshes the visible SDK switch as well as its stored preference",()->{
   var activity=new org.adguardian.app.MainActivity();org.adguardian.app.settings.PreferenceStore.setSdkEnabled(activity,false);
   var create=activity.getClass().getDeclaredMethod("buildContent");create.setAccessible(true);create.invoke(activity);
   org.adguardian.app.settings.PreferenceStore.enableAllAds(activity);
   var sync=activity.getClass().getDeclaredMethod("syncSwitches");sync.setAccessible(true);sync.invoke(activity);
   var field=activity.getClass().getDeclaredField("sdkSwitch");field.setAccessible(true);
   check(((android.widget.Switch)field.get(activity)).isChecked(),"SDK enabled preference is not reflected in UI");
  });
  System.out.println("B7.12 inventory tests passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);if(FlowsB77Tests.fail>0)throw new AssertionError("Inventory integration regressions");
 }
}
