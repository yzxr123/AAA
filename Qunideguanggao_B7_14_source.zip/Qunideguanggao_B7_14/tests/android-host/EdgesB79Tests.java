import android.app.AlertDialog;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import java.lang.reflect.*;
import java.util.*;
import org.adguardian.app.classapp.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.settings.PreferenceStore;

public class EdgesB79Tests {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static AccessibilityNodeInfo home(){
  var r=FlowsB77Tests.root(ClassAdProfile.PACKAGE,null);
  for(String id:List.of("navigation_bar","tv_today_date","tv_weeks","timetableView"))r.add(FlowsB77Tests.n(ClassAdProfile.PACKAGE+":id/"+id,null,"android.view.View",0,400,1080,1000,false));return r;
 }
 public static void main(String[] args)throws Exception{
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("CLASS terminal can be recognized by verified home and course layout anchors without Activity event",()->{
   try(var i=AccessibilityNodeIndex.build(home())){var p=FlowPage.capture(ClassAdProfile.PACKAGE,"",1013,i);check(p!=null&&p.guard.activity.equals(ClassAdProfile.MAIN)&&!p.knownClassAd,"CLASS completion still blocked despite its exact home layout");}
  });
  FlowsB77Tests.run("CLASS partial home layout cannot be used as a completed timetable",()->{
   var r=home();r.children.remove(2);
   try(var i=AccessibilityNodeIndex.build(r)){var p=FlowPage.capture(ClassAdProfile.PACKAGE,"",1013,i);check(p==null||!p.guard.activity.equals(ClassAdProfile.MAIN),"partial page falsely inferred as completed home");}
  });
  FlowsB77Tests.run("page learned without Activity can finish replay after known Activity metadata recovers",()->{
   var s=new FlowsB77Tests.Service();var h=new Handler(Looper.getMainLooper());s.root=FlowsB77Tests.page("video","跳过");FlowPage first,terminal;
   try(var i=AccessibilityNodeIndex.build(s.root)){first=FlowPage.capture("host.example","",1,i);}
   try(var i=AccessibilityNodeIndex.build(FlowsB77Tests.page("home",null))){terminal=FlowPage.capture("host.example","",1,i);}
   var e=new FlowReplayEngine(s,h,()->"host.example",()->{});e.store().add(new LearnedFlow("missing-meta","host.example","test",1,AdType.POPUP,true,List.of(new FlowStep(first.guard,first.targets.get(0),false,30000)),terminal.guard));
   try(var i=AccessibilityNodeIndex.build(s.root)){check(e.handle("host.example","host.example.Ad",i),"first guarded step did not start");}
   s.root=FlowsB77Tests.page("home",null);SystemClock.now=10400;try(var i=AccessibilityNodeIndex.build(s.root)){e.handle("host.example","host.example.Main",i);}
   SystemClock.now=10800;try(var i=AccessibilityNodeIndex.build(s.root)){e.handle("host.example","host.example.Main",i);}
   check(e.completedCount()==1,"raw Activity equality cancelled an otherwise exact recovered guard");e.close();
  });
  FlowsB77Tests.run("a next-page snapshot captured by result polling is available to a delayed second click",()->{
   var f=new TeachingB77Tests.Fixture();f.start();f.click();
   f.s.root=FlowsB77Tests.page("endcard","关闭");Handler.advance(10200);
   f.teacher.clicked(RegressionB79Tests.click(f.pkg,f.s.root.children.get(1),10220,null));Handler.advance(10220);
   f.move("home",null,"host.example.Main",10700);f.save();
   check(f.replay.store().all().size()==1&&f.replay.store().all().get(0).steps.size()==2,"poll-only next page absent from pre-click history");f.close();
  });
  FlowsB77Tests.run("a quiet explicit lesson samples then stops rather than requiring endless window events",()->{
   var s=new FlowsB77Tests.Service();var h=new Handler(Looper.getMainLooper());var e=new FlowReplayEngine(s,h,()->"host.example",()->{});s.services.put(android.content.Context.WINDOW_SERVICE,new RegressionB76Tests.Windows());int[] scans={0};
   var t=new FlowTeachingController(s,h,()->"host.example",()->"host.example.Ad",e,()->scans[0]++);t.start(AdType.POPUP);Handler.advance(10000);int start=scans[0];Handler.advance(10400);check(scans[0]>start,"quiet page was never resampled");
   t.stop();int stopped=scans[0];Handler.advance(11500);check(scans[0]==stopped,"passive sampling continued after explicit lesson stopped");e.close();
  });
  FlowsB77Tests.run("two indistinguishable labels in the taught page cannot be selected from null event source",()->{
   var f=new TeachingB77Tests.Fixture();f.s.root.add(FlowsB77Tests.n("host.example:id/second_skip","跳过","android.widget.TextView",40,70,100,60,true));f.start();
   f.teacher.clicked(RegressionB79Tests.click(f.pkg,null,10000,"跳过"));Handler.advance(10000);f.move("home",null,"host.example.Main",10400);f.save();check(f.replay.store().all().isEmpty(),"ambiguous label created a replay rule");f.close();
  });
  FlowsB77Tests.run("APK-derived promotion rule is loaded through real RuleEngine and obeys its switch",()->{
   var s=new FlowsB77Tests.Service();s.getPackageManager().packageVersion=1013;s.root=ClassAdapterB77Tests.root();var close=ClassAdapterB77Tests.close(ClassAdProfile.PACKAGE+":id/close",null);s.root.add(close);
   for(String id:List.of("tv_confirm","btn_pay_now"))s.root.add(FlowsB77Tests.n(ClassAdProfile.PACKAGE+":id/"+id,null,"android.widget.TextView",100,800,600,80,true));
   PreferenceStore.setGkdEnabled(s,false);PreferenceStore.setLiTiaotiaoEnabled(s,false);PreferenceStore.setLearnedEnabled(s,false);PreferenceStore.setClassAdapterEnabled(s,false);
   var e=new RuleEngine(s,new Handler(Looper.getMainLooper()),()->{},()->ClassAdProfile.PACKAGE);check(!e.handle(ClassAdProfile.PACKAGE,"",32,s.root)&&close.clicks==0,"disabled CLASS still clicked");
   PreferenceStore.setClassAdapterEnabled(s,true);check(e.handle(ClassAdProfile.PACKAGE,"",32,s.root)&&close.clicks==1,"new runtime asset not reachable from pipeline");e.close();
  });
  FlowsB77Tests.run("user can inspect the actually parsed builtin CLASS rule asset from the home screen",()->{
   var a=new org.adguardian.app.MainActivity();Method build=a.getClass().getDeclaredMethod("buildContent");build.setAccessible(true);View content=(View)build.invoke(a);
   View button=RegressionB76Tests.button(content,"查看 CLASS 内置规则");check(button!=null,"no builtin rule viewer");button.performClick();
   check(AlertDialog.lastMessage.contains("4 组")&&AlertDialog.lastMessage.contains("tv_confirm")&&AlertDialog.lastMessage.contains("1013"),"viewer did not read real rule asset");
  });
  FlowsB77Tests.run("learned flow management exposes recorded ordered steps rather than only delete and enable",()->{
   var a=new org.adguardian.app.MainActivity();var f=FlowsB77Tests.flow();Method edit=a.getClass().getDeclaredMethod("editLearnedFlow",LearnedFlow.class);edit.setAccessible(true);edit.invoke(a,f);
   check(Arrays.asList(AlertDialog.lastItems).contains("查看记录步骤"),"recorded data has no readable management entry");
   int i=Arrays.asList(AlertDialog.lastItems).indexOf("查看记录步骤");AlertDialog.lastListener.onClick(null,i);
   check(AlertDialog.lastMessage.contains("第 1 步")&&AlertDialog.lastMessage.contains("第 2 步")&&AlertDialog.lastMessage.contains("结束条件"),"missing ordered capture details");
  });
  System.out.println("B7.9 integration and data visibility cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("B7.9 edges");
 }
}
