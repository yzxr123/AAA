import android.content.*;
import android.app.*;
import android.os.*;
import java.util.*;
import java.lang.reflect.*;
import java.nio.file.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.recording.*;

/** Real record/teaching operations; only Android platform is doubled. */
public final class ReviewAndSafetyB713Tests {
 static void check(boolean v,String why){if(!v)throw new AssertionError(why);}
 static RecordingDraft reviewDraft(String key){var f=FlowsB77Tests.flow();return new RecordingDraft(key,f.packageName,f.appName,1,f.type,false,f.steps,2,RecordingDraft.NEEDS_REVIEW,System.currentTimeMillis());}
 static Object method(Object o,String n,Class<?>[] types,Object...args)throws Exception{return o.getClass().getMethod(n,types).invoke(o,args);}
 public static void main(String[]args)throws Exception{
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("B713 review resolves one explicitly identified unknown event but never enables execution",()->{
   var s=new RecordingDraftStore(new Context());s.put(reviewDraft("review"));
   method(s,"dismissIssue",new Class<?>[]{String.class,String.class},"review","legacy-review");
   var d=s.all().get(0);check(d.state==RecordingDraft.CAPTURED&&d.confirmed==2,"review cannot leave permanent taint");
   check(new FlowStore(new Context()).all().isEmpty(),"review incorrectly bypassed final validation");check(d.steps.get(0).guard.signature.equals(reviewDraft("x").steps.get(0).guard.signature),"review rewrote old locator");
  });
  FlowsB77Tests.run("B713 prefix repair preserves original suffix and forks only the confirmed prefix",()->{
   var s=new RecordingDraftStore(new Context());s.put(reviewDraft("original"));s.dismissIssue("original","legacy-review");
   var fork=(RecordingDraft)method(s,"forkConfirmedPrefix",new Class<?>[]{String.class,int.class},"original",1);
   check(!fork.key.equals("original")&&fork.steps.size()==1&&fork.confirmed==1&&fork.state==RecordingDraft.CAPTURED,"bad prefix");
   check(s.all().size()==2&&s.all().stream().anyMatch(d->d.key.equals("original")&&d.steps.size()==2),"old suffix evidence destroyed");
   check(new FlowStore(new Context()).all().isEmpty(),"prefix repair enabled a truncated macro");
  });
  FlowsB77Tests.run("B713 resumable prefix requires new recorded step rather than finishing immediately",()->{
   var f=new TeachingB77Tests.Fixture();var store=new RecordingDraftStore(f.s);store.put(reviewDraft("full"));store.dismissIssue("full","legacy-review");
   var fork=(RecordingDraft)method(store,"forkConfirmedPrefix",new Class<?>[]{String.class,int.class},"full",1);
   method(f.teacher,"resumeDraftForRecording",new Class<?>[]{String.class},fork.key);Handler.advance(10000);
   f.move("home",null,"host.example.Main",10400);f.save();check(f.replay.store().all().isEmpty(),"prefix auto-enabled before replacement step");
   f.activity="host.example.Ad";f.s.root=FlowsB77Tests.page("endcard","关闭");f.observe();f.pick();f.move("home",null,"host.example.Main",11500);f.save();
   check(f.replay.store().all().size()==1&&f.replay.store().all().get(0).steps.size()==2,"only replacing suffix cannot complete");f.close();
  });
  FlowsB77Tests.run("B713 unknown normal click is written as reviewable evidence with its step index",()->{
   var f=new TeachingB77Tests.Fixture();f.start();f.click();f.move("home",null,"host.example.Main",10400);
   f.teacher.clicked(RegressionB79Tests.click(f.pkg,null,SystemClock.now,null));Handler.advance(SystemClock.now);f.teacher.stop();
   var d=new RecordingDraftStore(f.s).all().get(0);Object issues=d.getClass().getField("issues").get(d);check(((List<?>)issues).size()==1,"unknown event has no persisted review record");
   Object issue=((List<?>)issues).get(0);check(issue.getClass().getField("afterStep").getInt(issue)==1,"missing review location");f.close();
  });
  FlowsB77Tests.run("B713 record UI exposes explicit per-issue review and suffix repair",()->{
   var a=new org.adguardian.app.MainActivity();var d=reviewDraft("ui");Method m=a.getClass().getDeclaredMethod("editRecordingDraft",RecordingDraft.class);m.setAccessible(true);m.invoke(a,d);
   check(Arrays.asList(AlertDialog.lastItems).contains("审查未识别操作")&&Arrays.asList(AlertDialog.lastItems).contains("补录或重录指定步骤"),"review actions not connected to real UI");
  });
  FlowsB77Tests.run("B713 first typed rule write preserves exact pre-upgrade active bytes",()->{
   var c=new Context();var backup=new java.io.File(c.getFilesDir(),"learned-ad-flows.bin.before-b713");backup.delete();var s=new FlowStore(c);s.add(FlowsB77Tests.flow());
   var original=Files.readAllBytes(new java.io.File(c.getFilesDir(),"learned-ad-flows.bin").toPath());s.add(ResearchB713Tests.recorded());
   check(backup.isFile()&&Arrays.equals(original,Files.readAllBytes(backup.toPath())),"no rollback copy before new condition writes");
   check(new FlowStore(c).all().size()==2,"legacy rule disappeared on upgrade");backup.delete();
  });
  FlowsB77Tests.run("B713 typed condition survives real disk reload and never stores screen body",()->{
   var c=new Context();var flow=ResearchB713Tests.recorded();new FlowStore(c).add(flow);var now=new FlowStore(c).all().get(0);
   check(now.steps.get(0).guard.signature.startsWith("v3:")&&now.steps.get(0).guard.signature.equals(flow.steps.get(0).guard.signature),"typed data not persisted");
   check(!new String(Files.readAllBytes(new java.io.File(c.getFilesDir(),"learned-ad-flows.bin").toPath()),java.nio.charset.StandardCharsets.UTF_8).contains("normal body"),"raw body in record");
  });
  FlowsB77Tests.run("B713 malformed typed guard cannot be accepted as a valid condition",()->{
   for(String s:List.of("v3:","v3:not valid!","v3:AA","v3:AAAA"))check(!new FlowGuard("host.example.Ad",s,.45f).valid(),"malformed condition accepted");
  });
  System.out.println("B7.13 review and persistence passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("review and persistence regressions");
 }
}
