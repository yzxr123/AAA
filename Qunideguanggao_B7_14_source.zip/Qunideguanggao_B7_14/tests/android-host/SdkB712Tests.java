import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.zip.*;

public final class SdkB712Tests {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static Object scan(List<File> apks,File cache,BooleanSupplier stop)throws Exception {
  Class<?> scanner;try{scanner=Class.forName("org.adguardian.app.sdk.DexSdkScanner");}
  catch(ClassNotFoundException absent){throw new AssertionError("No installed APK SDK definition scanner is implemented");}
  return scanner.getMethod("scan",List.class,File.class,BooleanSupplier.class).invoke(null,apks,cache,stop);
 }
 static Object field(Object r,String name)throws Exception{return r.getClass().getField(name).get(r);}
 static byte[] dex(String[] names,int[] definitions)throws Exception {
  int strings=112,types=strings+names.length*4,defs=types+names.length*4,data=defs+definitions.length*32;
  ByteArrayOutputStream content=new ByteArrayOutputStream();int[] offsets=new int[names.length];
  for(int i=0;i<names.length;i++){offsets[i]=data+content.size();int len=names[i].length();do{int b=len&127;len>>>=7;content.write(b|(len>0?128:0));}while(len>0);content.write(names[i].getBytes("UTF-8"));content.write(0);}
  ByteBuffer b=ByteBuffer.allocate(data+content.size()).order(ByteOrder.LITTLE_ENDIAN);b.put("dex\n039\0".getBytes("US-ASCII"));b.putInt(32,b.capacity());b.putInt(36,112);b.putInt(40,0x12345678);
  b.putInt(56,names.length);b.putInt(60,strings);b.putInt(64,names.length);b.putInt(68,types);b.putInt(96,definitions.length);b.putInt(100,definitions.length==0?0:defs);
  b.putInt(104,content.size());b.putInt(108,data);
  for(int i=0;i<names.length;i++){b.putInt(strings+i*4,offsets[i]);b.putInt(types+i*4,i);}
  for(int i=0;i<definitions.length;i++)b.putInt(defs+i*32,definitions[i]);b.position(data);b.put(content.toByteArray());return b.array();
 }
 static File apk(Path folder,String file,String entry,byte[] data)throws Exception{
  File f=folder.resolve(file).toFile();try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(f))){z.putNextEntry(new ZipEntry(entry));z.write(data);z.closeEntry();}return f;
 }
 static Path folder()throws Exception{return Files.createTempDirectory("sdk-regression-");}
 public static void main(String[]args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("SDK scan finds a defined Pangle class without executing APK code",()->{
   Path p=folder();File cache=Files.createDirectory(p.resolve("cache")).toFile();Object r=scan(List.of(apk(p,"base.apk","classes.dex",dex(new String[]{"Lcom/bytedance/sdk/openadsdk/TTAdSdk;"},new int[]{0}))),cache,()->false);
   check(((Set<?>)field(r,"sdkIds")).contains("pangle"),"Pangle definition missed");check(field(r,"status").equals("COMPLETE"),"supported DEX not complete");check(cache.list().length==0,"temporary DEX retained");
  });
  FlowsB77Tests.run("SDK-looking strings and type references alone do not establish embedded SDK",()->{
   Path p=folder();Object r=scan(List.of(apk(p,"base.apk","classes.dex",dex(new String[]{"Lhost/app/Screen;","Lcom/bytedance/sdk/openadsdk/TTAdSdk;"},new int[]{0}))),p.toFile(),()->false);
   check(((Set<?>)field(r,"sdkIds")).isEmpty(),"reference misreported as embedded implementation");
  });
  FlowsB77Tests.run("SDK scan includes split APK definitions and respects namespace boundaries",()->{
   Path p=folder();Object r=scan(List.of(apk(p,"base.apk","classes.dex",dex(new String[]{"Lcom/bytedance/sdk/openadsdkfake/Fake;"},new int[]{0})),apk(p,"split.apk","classes2.dex",dex(new String[]{"Lcom/qq/e/ads/ADActivity;"},new int[]{0}))),p.toFile(),()->false);
   check(field(r,"sdkIds").equals(Set.of("gdt")),"split or package-boundary handling wrong");
  });
  FlowsB77Tests.run("unsupported DEX version is partial not a false no-SDK success",()->{
   Path p=folder();byte[] d=dex(new String[]{"Lhost/app/A;"},new int[]{0});d[6]='1';Object r=scan(List.of(apk(p,"base.apk","classes.dex",d)),p.toFile(),()->false);
   check(field(r,"status").equals("PARTIAL"),"unknown DEX presented as fully inspected");
  });
  FlowsB77Tests.run("malformed table offsets do not allocate unbounded memory or report complete",()->{
   Path p=folder();byte[] d=dex(new String[]{"Lhost/app/A;"},new int[]{0});ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN).putInt(56,Integer.MAX_VALUE);
   Object r=scan(List.of(apk(p,"base.apk","classes.dex",d)),p.toFile(),()->false);check(!field(r,"status").equals("COMPLETE"),"malformed input accepted");
  });
  FlowsB77Tests.run("cancelled SDK scan returns cancelled and does not create cache artifacts",()->{
   Path p=folder();File cache=Files.createDirectory(p.resolve("cache")).toFile();Object r=scan(List.of(apk(p,"base.apk","classes.dex",dex(new String[]{"Lhost/app/A;"},new int[]{0}))),cache,()->true);
   check(field(r,"status").equals("CANCELLED"),"cancel ignored");check(cache.list().length==0,"cancel leaked data");
  });
  String original=System.getProperty("test.classApk");
  if(original!=null&&new File(original).isFile()&&FlowsB77Tests.fail==0){
   Path p=folder();Object r=scan(List.of(new File(original)),p.toFile(),()->false);
   check(((Set<?>)field(r,"sdkIds")).contains("pangle"),"uploaded CLASS APK Pangle not found");
   System.out.println("REAL CLASS APK sdkIds="+field(r,"sdkIds")+" definedClasses="+field(r,"definedClasses")+" dexFiles="+field(r,"dexFiles")+" status="+field(r,"status"));
  }
  System.out.println("B7.12 SDK definition tests passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);if(FlowsB77Tests.fail>0)throw new AssertionError("SDK tests failed");
 }
}
