import android.content.*;import android.os.*;import java.io.*;import java.nio.file.*;import java.util.*;
import org.adguardian.app.flow.*;import org.adguardian.app.recording.*;import org.adguardian.app.engine.*;

public final class BoundaryB713Tests {
 static void check(boolean b,String why){if(!b)throw new AssertionError(why);}
 static void writeLegacy(File file,RecordingDraft d)throws Exception{
  try(DataOutputStream out=new DataOutputStream(new FileOutputStream(file))){out.writeInt(0x41524431);out.writeInt(1);out.writeUTF(d.key);out.writeUTF(d.packageName);out.writeUTF(d.appName);out.writeLong(d.version);out.writeInt(d.type.ordinal());out.writeBoolean(d.single);out.writeInt(d.confirmed);out.writeInt(d.state);out.writeLong(d.updatedAt);out.writeInt(d.steps.size());
   for(var s:d.steps){out.writeUTF(s.guard.activity);out.writeUTF(s.guard.signature);out.writeFloat(s.guard.aspect);out.writeBoolean(s.back);out.writeLong(s.timeoutMs);if(!s.back){var t=s.target;out.writeUTF(t.id);out.writeUTF(t.name);out.writeUTF(t.label);out.writeFloat(t.x);out.writeFloat(t.y);out.writeFloat(t.width);out.writeFloat(t.height);}}
  }
 }
 public static void main(String[]args)throws Exception{
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("B713 real legacy draft binary migrates with exact prior bytes and no fabricated target context",()->{
   var c=new Context();File file=new File(c.getFilesDir(),"ad-recording-drafts.bin"),backup=new File(file+".before-b713");backup.delete();var d=ReviewAndSafetyB713Tests.reviewDraft("old");writeLegacy(file,d);byte[] bytes=Files.readAllBytes(file.toPath());
   var s=new RecordingDraftStore(c);var old=s.all().get(0);check(old.issues.size()==1&&old.issues.get(0).reason==RecordingIssue.LEGACY,"legacy missing flag misrepresented");
   s.dismissIssue("old","legacy-review");var migrated=s.all().get(0);check(Arrays.equals(bytes,Files.readAllBytes(backup.toPath())),"legacy rollback bytes lost");check(migrated.steps.get(0).guard.signature.equals(d.steps.get(0).guard.signature),"old page hash invented into new context");backup.delete();
  });
  FlowsB77Tests.run("B713 another SDK ad stage cannot become a learned successful terminal",()->{
   var a=FlowsB77Tests.page("video","跳过");var j=new FlowJournal(AdType.POPUP);String activity="com.bytedance.sdk.openadsdk.core.component.reward.activity.TTFullScreenVideoActivity";
   j.beginClick(FlowsB77Tests.snap(a,activity),FlowsB77Tests.target(a));var b=FlowsB77Tests.snap(FlowsB77Tests.page("endcard",null),activity);j.observe(b,10300);j.observe(b,10600);
   check(j.stepCount()==1,"setup stage not observed");check(!j.finishProblem().isEmpty(),"known SDK ad accepted as host end");
  });
  FlowsB77Tests.run("B713 target guard cannot be stored as a terminal condition",()->{
   var f=ResearchB713Tests.recorded();var bad=new LearnedFlow("bad",f.packageName,f.appName,f.versionCode,f.type,true,f.steps,f.steps.get(0).guard);
   try{new FlowStore(new Context()).add(bad);throw new AssertionError("target condition stored as end condition");}catch(IOException expected){}
  });
  FlowsB77Tests.run("B713 persisted target and context must refer to exactly the same recorded control",()->{
   var f=ResearchB713Tests.recorded();var step=f.steps.get(0);var t=step.target;var changed=new NodeTarget(t.id,t.name,t.label,t.x+.02f,t.y,t.width,t.height);
   check(!new FlowStep(step.guard,changed,false,30000).valid(),"condition target and serialized target disagree");
  });
  FlowsB77Tests.run("B713 matching is directional but equality of guard objects is structural and symmetric",()->{
   var root=FlowsB77Tests.page("home",null);var page=FlowsB77Tests.snap(root,"host.example.Main");FlowGuard expected=page.terminalGuard();
   check(expected.matches(page.guard),"recorded terminal condition did not match observed home");check(expected.equals(page.guard)==page.guard.equals(expected),"equals changed depending on comparison direction");
  });
  FlowsB77Tests.run("B713 unreviewed issue cannot be silently written as enabled",()->{
   var d=ReviewAndSafetyB713Tests.reviewDraft("unsafe");var bad=new RecordingDraft(d.key,d.packageName,d.appName,d.version,d.type,false,d.steps,d.confirmed,RecordingDraft.ENABLED,d.updatedAt,d.issues);
   try{new RecordingDraftStore(new Context()).put(bad);throw new AssertionError("unreviewed capture activated");}catch(IOException expected){}
  });
  FlowsB77Tests.run("B713 corrupt draft cannot be overwritten by review or repair",()->{
   var c=new Context();File file=new File(c.getFilesDir(),"ad-recording-drafts.bin");byte[] data={3,9,8,0};Files.write(file.toPath(),data);var s=new RecordingDraftStore(c);
   try{s.dismissIssue("x","x");throw new AssertionError("review read corrupt archive");}catch(IOException expected){}
   try{s.forkConfirmedPrefix("x",1);throw new AssertionError("repair read corrupt archive");}catch(IOException expected){}
   check(Arrays.equals(data,Files.readAllBytes(file.toPath())),"corrupt evidence lost");file.delete();
  });
  FlowsB77Tests.run("B713 unconfirmed suffix cannot be retained by repair",()->{
   var c=new Context();var s=new RecordingDraftStore(c);var d=ReviewAndSafetyB713Tests.reviewDraft("two");s.put(new RecordingDraft(d.key,d.packageName,d.appName,1,d.type,false,d.steps,1,RecordingDraft.CAPTURED,d.updatedAt));
   try{s.forkConfirmedPrefix("two",2);throw new AssertionError("unverified suffix retained");}catch(IOException expected){}
  });
  FlowsB77Tests.run("B713 body refresh cannot finish an active replay with original target still visible",()->{
   var s=new FlowsB77Tests.Service();var e=new FlowReplayEngine(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});e.store().add(ResearchB713Tests.recorded());s.root=FlowsB77Tests.page("video","跳过");FlowsB77Tests.handle(e,s,"host.example.Ad");
   s.root=ResearchB713Tests.withBodyId();Handler.advance(10400);FlowsB77Tests.handle(e,s,"host.example.Ad");Handler.advance(10700);FlowsB77Tests.handle(e,s,"host.example.Ad");check(e.completedCount()==0,"body refresh completed replay");e.close();
  });
  FlowsB77Tests.run("B713 suffix repair cannot silently discard unresolved evidence inside the kept prefix",()->{
   var c=new Context();var store=new RecordingDraftStore(c);var d=ReviewAndSafetyB713Tests.reviewDraft("prefix-issue");
   var issue=new RecordingIssue("earlier",0,RecordingIssue.UNLOCATED_CLICK,false);
   store.put(new RecordingDraft(d.key,d.packageName,d.appName,d.version,d.type,false,d.steps,d.confirmed,RecordingDraft.NEEDS_REVIEW,d.updatedAt,List.of(issue)));
   try{store.forkConfirmedPrefix(d.key,1);throw new AssertionError("unreviewed prefix was silently trusted");}catch(IOException expected){}
   check(store.all().size()==1,"rejected repair changed the archive");
  });
  FlowsB77Tests.run("B713 old unlocated review flags cannot be presumed to belong only to a discarded suffix",()->{
   var c=new Context();var store=new RecordingDraftStore(c);var d=ReviewAndSafetyB713Tests.reviewDraft("legacy-location");
   var issue=new RecordingIssue("legacy-review",d.confirmed,RecordingIssue.LEGACY,false);
   store.put(new RecordingDraft(d.key,d.packageName,d.appName,d.version,d.type,false,d.steps,d.confirmed,RecordingDraft.NEEDS_REVIEW,d.updatedAt,List.of(issue)));
   try{store.forkConfirmedPrefix(d.key,1);throw new AssertionError("unknown legacy review location guessed");}catch(IOException expected){}
  });
  System.out.println("B7.13 final boundary passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);if(FlowsB77Tests.fail>0)throw new AssertionError("B713 boundary regressions");
 }
}
