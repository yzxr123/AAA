import android.content.*;
import android.os.*;
import android.view.accessibility.*;
import java.util.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.classapp.*;
import org.adguardian.app.recording.*;
import org.adguardian.app.runtime.*;
import org.adguardian.app.service.*;

/** Paired research counterexamples against production classes. Android interfaces are doubles. */
public final class ResearchB713Tests {
 static void check(boolean value,String why){if(!value)throw new AssertionError(why);}
 static AccessibilityNodeInfo withBodyId(){var r=FlowsB77Tests.page("video","跳过");r.add(FlowsB77Tests.n("host.example:id/subtitle","ad text","android.widget.TextView",40,1900,800,220,false));return r;}
 static LearnedFlow recorded() {
  var r=FlowsB77Tests.page("video","跳过");var j=new FlowJournal(AdType.POPUP);var p=FlowsB77Tests.snap(r,"host.example.Ad");
  check(j.beginClick(p,FlowsB77Tests.target(r)),"setup");var h=FlowsB77Tests.snap(FlowsB77Tests.page("home",null),"host.example.Main");j.observe(h,10300);j.observe(h,10600);return j.finish("recorded","test");
 }
 public static void main(String[] args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("B713 unchanged close plus new passive ID cannot confirm a step",()->{
   var r=FlowsB77Tests.page("video","跳过");var j=new FlowJournal(AdType.POPUP);j.beginClick(FlowsB77Tests.snap(r,"host.example.Ad"),FlowsB77Tests.target(r));
   var changed=FlowsB77Tests.snap(withBodyId(),"host.example.Ad");j.observe(changed,10300);j.observe(changed,10600);
   check(j.stepCount()==0&&j.pending(),"passive body ID falsely confirmed dismissal");check(!j.finishProblem().isEmpty(),"unfinished step accepted as terminal");
  });
  FlowsB77Tests.run("B713 recorded target replays when only unrelated ID is added",()->{
   var s=new FlowsB77Tests.Service();var e=new FlowReplayEngine(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});e.store().add(recorded());s.root=withBodyId();
   try{check(FlowsB77Tests.handle(e,s,"host.example.Ad"),"whole-page fingerprint prevented replay");check(s.root.children.get(1).clicks==1,"unchanged close not clicked");}finally{e.close();}
  });
  FlowsB77Tests.run("B713 terminal additions do not block an already closed recorded flow",()->{
   var s=new FlowsB77Tests.Service();var e=new FlowReplayEngine(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});e.store().add(recorded());s.root=FlowsB77Tests.page("video","跳过");FlowsB77Tests.handle(e,s,"host.example.Ad");
   s.root=FlowsB77Tests.page("home",null);s.root.add(FlowsB77Tests.n("host.example:id/home_tip","normal body","android.widget.TextView",40,1900,800,220,false));
   Handler.advance(10300);FlowsB77Tests.handle(e,s,"host.example.Main");Handler.advance(10500);FlowsB77Tests.handle(e,s,"host.example.Main");
   check(e.completedCount()==1&&!e.isActive(),"terminal whole-page hash blocked success");e.close();
  });
  FlowsB77Tests.run("B713 same ID in a different actual parent still records a second stage",()->{
   var a=FlowsB77Tests.page("video","关闭");var b=FlowsB77Tests.page("endcard","关闭");var j=new FlowJournal(AdType.POPUP);j.beginClick(FlowsB77Tests.snap(a,"host.example.Ad"),FlowsB77Tests.target(a));j.observe(FlowsB77Tests.snap(b,"host.example.Ad"),10300);j.observe(FlowsB77Tests.snap(b,"host.example.Ad"),10500);
   check(j.stepCount()==1,"actual next stage with reused close ID rejected");
  });
  FlowsB77Tests.run("B713 connected failed engine retries without secure-settings grant or opt-in",()->{
   var s=new AdAccessibilityService();s.services.put(Context.WINDOW_SERVICE,new RegressionB76Tests.Windows());s.root=FlowsB77Tests.page("video","跳过");RegressionB76Tests.authorize(s);s.failServiceInfo=true;
   var connect=AdAccessibilityService.class.getDeclaredMethod("onServiceConnected");connect.setAccessible(true);connect.invoke(s);Handler.advance(SystemClock.now);s.failServiceInfo=false;
   var recovery=new AccessibilityRecovery(s,new Handler(Looper.getMainLooper()));
   try {recovery.request(false);Handler.advance(SystemClock.now+31000);check(AccessibilityState.read(s).running(),"ordinary health check never rebuilt connected failed runtime");}
   finally{recovery.close();Handler.advance(SystemClock.now);s.onDestroy();Handler.advance(SystemClock.now+1000);}
  });
  FlowsB77Tests.run("B713 CLASS three home controls can disprove stale Splash without self-drawn timetable",()->{
   var r=FinalizationB711Tests.home();r.children.removeIf(n->(ClassAdProfile.PACKAGE+":id/timetableView").equals(n.id));var p=FinalizationB711Tests.snapshot(r,ClassAdProfile.SPLASH);
   check(p!=null&&p.isCertifiedClassHome()&&!p.knownClassAd,"stale Splash requires a non-exposed self-drawn node");
  });
  System.out.println("B7.13 research regressions passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("research regressions "+FlowsB77Tests.fail);
 }
}
