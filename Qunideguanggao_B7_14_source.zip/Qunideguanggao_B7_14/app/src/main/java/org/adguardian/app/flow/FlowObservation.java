package org.adguardian.app.flow;

import java.util.*;
import org.adguardian.app.engine.NodeTarget;

/** Immutable metadata captured in one bounded traversal. Never holds Android nodes or body text. */
final class FlowObservation {
    static final class Item {
        final NodeTarget target;
        final String lineage;
        Item(NodeTarget target,String lineage){this.target=target;this.lineage=lineage;}
    }
    final String pkg,rootName,rootId,stage;
    final long version;
    final Set<String> anchors;
    final List<String> terminalAnchors;
    final List<Item> visible,enabled;
    final boolean classHome,ad;
    FlowObservation(String pkg,long version,String rootName,String rootId,String stage,Set<String> anchors,
                    List<String> terminalAnchors,List<Item> visible,List<Item> enabled,boolean classHome,boolean ad) {
        this.pkg=pkg;this.version=version;this.rootName=rootName;this.rootId=rootId;this.stage=stage;
        this.anchors=Collections.unmodifiableSet(new HashSet<>(anchors));
        this.terminalAnchors=Collections.unmodifiableList(new ArrayList<>(terminalAnchors));this.visible=Collections.unmodifiableList(new ArrayList<>(visible));this.enabled=Collections.unmodifiableList(new ArrayList<>(enabled));
        this.classHome=classHome;this.ad=ad;
    }
    Item item(NodeTarget target){
        Item result=null;
        for(Item item:enabled)if(sameDescriptor(target,item.target,true)) {
            if(result!=null && !result.lineage.equals(item.lineage))return null;result=item;
        }
        return result;
    }
    static boolean exactDescriptor(NodeTarget a,NodeTarget b) {
        return a!=null&&b!=null&&a.id.equals(b.id)&&a.name.equals(b.name)&&a.label.equals(b.label)
            &&Float.compare(a.x,b.x)==0&&Float.compare(a.y,b.y)==0&&Float.compare(a.width,b.width)==0&&Float.compare(a.height,b.height)==0;
    }
    static boolean sameDescriptor(NodeTarget expected,NodeTarget actual,boolean position) {
        if(expected==null||actual==null||!expected.id.equals(actual.id)||!expected.name.equals(actual.name)
                ||!expected.label.equals(actual.label))return false;
        // ID/text do not disappear merely because the status/navigation bars change the viewport.
        if(!position && (!expected.id.isEmpty()||!expected.label.isEmpty()))return true;
        return Math.abs(expected.x-actual.x)<=.065f&&Math.abs(expected.y-actual.y)<=.075f
                &&Math.abs(expected.width-actual.width)<=.07f&&Math.abs(expected.height-actual.height)<=.07f;
    }
}
