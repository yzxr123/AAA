package org.adguardian.app.sdk;

import android.content.Context;
import android.content.pm.*;
import java.io.File;
import java.util.*;
import java.util.function.*;

/** Explicit, offline inventory. Not called by accessibility events or by app startup. */
public final class InstalledSdkInventory {
    private static final java.util.concurrent.atomic.AtomicBoolean RUNNING=new java.util.concurrent.atomic.AtomicBoolean();
    private InstalledSdkInventory() {}
    public static String scan(Context context,BooleanSupplier stop,Consumer<String> progress){
        if(!RUNNING.compareAndSet(false,true))return "广告 SDK 检查已经在进行 请等待当前检查结束";
        try{return scanOnce(context,stop,progress);}finally{RUNNING.set(false);}
    }
    private static String scanOnce(Context context,BooleanSupplier stop,Consumer<String> progress){
        if(stopped(stop))return "已停止检查";
        File cache=new File(context.getCacheDir(),"sdk-inspection");
        if(!cache.isDirectory()&&!cache.mkdirs())return "检查缓存暂时无法创建 不影响已有广告规则";
        // A process killed during a scan cannot execute finally. Reclaim only our own temporary files.
        File[] abandoned=cache.listFiles();if(abandoned!=null)for(File file:abandoned)
            if(file.getName().startsWith("sdk-inspect-")&&file.getName().endsWith(".dex"))file.delete();
        PackageManager pm=context.getPackageManager();List<ApplicationInfo> apps=new ArrayList<>();
        try{
            List<ApplicationInfo> visible=pm.getInstalledApplications(0);
            if(visible==null)return "系统暂时无法提供应用列表";
            for(ApplicationInfo app:visible)if(app!=null&&app.packageName!=null&&!app.packageName.equals(context.getPackageName())
                    &&(app.flags&ApplicationInfo.FLAG_SYSTEM)==0)apps.add(app);
        }catch(RuntimeException denied){return "系统暂时无法提供应用列表";}
        apps.sort(Comparator.comparing(a->a.packageName));
        StringBuilder report=new StringBuilder();int inspected=0,withSdk=0,incomplete=0;
        boolean limited=apps.size()>2048;
        for(ApplicationInfo app:apps){
            if(stopped(stop)||inspected>=2048)break;
            String label=app.packageName;try{CharSequence name=pm.getApplicationLabel(app);if(name!=null)label=name.toString();}catch(RuntimeException ignored){}
            if(label.length()>256)label=label.substring(0,256);
            List<File> paths=new ArrayList<>();paths.add(app.sourceDir==null?null:new File(app.sourceDir));
            if(app.splitSourceDirs!=null)for(String path:app.splitSourceDirs)paths.add(path==null?null:new File(path));
            DexSdkScanner.Report found=DexSdkScanner.scan(paths,cache,stop);
            if("CANCELLED".equals(found.status))break;
            inspected++;report.append(label).append('\n').append(app.packageName).append('\n');
            if(!found.sdkIds.isEmpty()){
                withSdk++;StringJoiner names=new StringJoiner("  ");for(String id:found.sdkIds)names.add(AdSdkCatalog.name(id));
                report.append("包含 ").append(names).append('\n');
            }else if("COMPLETE".equals(found.status))report.append("未发现已知广告 SDK 的类定义\n");
            if(!"COMPLETE".equals(found.status)){incomplete++;report.append("无法完整检查 可能是受限文件 加壳或暂不支持的格式\n");}
            report.append('\n');if(progress!=null)progress.accept("已检查 "+inspected+" / "+apps.size()+" 个应用");
        }
        String heading=stopped(stop)?"已停止检查 保留本次已完成的结果":"本次检查完成";
        return heading+"\n已检查 "+inspected+" 个应用\n发现已知 SDK "+withSdk+" 个  无法完整检查 "+incomplete+" 个\n"
            +(limited?"应用数量超过单次检查上限 列表未完全检查\n":"")
            +"\n仅检查当前用户中系统允许读取的第三方安装包 不读取应用私有数据\n"
            +"SDK 存在不代表当前正在播放广告 也不代表已经关闭\n"
            +"加壳 下载的插件 原生实现或改名混淆可能无法识别 未发现不等于没有广告\n"
            +"自动关闭仍需匹配当前页面和真实关闭控件 不修改其他应用代码 不改变系统音量\n\n"+report;
    }
    private static boolean stopped(BooleanSupplier stop){return Thread.currentThread().isInterrupted()||stop!=null&&stop.getAsBoolean();}
}
