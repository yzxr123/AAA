package org.adguardian.app.sdk;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.zip.*;

/** Read-only standard DEX definition inspection. Never loads foreign classes or private app data. */
public final class DexSdkScanner {
    private static final long DEX_LIMIT=128L*1024*1024, TOTAL_LIMIT=384L*1024*1024;
    private static final java.util.regex.Pattern DEX_ENTRY=java.util.regex.Pattern.compile("classes(?:[2-9]|[1-9][0-9]+)?\\.dex");
    private static final int STRING_LIMIT=400_000, TYPE_LIMIT=65_536, DEX_COUNT_LIMIT=32;
    public static final class Report {
        public final Set<String> sdkIds;
        public final String status;
        public final int definedClasses, dexFiles;
        Report(Set<String> ids,String status,int classes,int files){
            sdkIds=Collections.unmodifiableSet(new LinkedHashSet<>(ids));this.status=status;
            definedClasses=classes;dexFiles=files;
        }
    }
    private static final class Stopped extends IOException {}
    private DexSdkScanner() {}
    public static Report scan(List<File> archives,File cache,BooleanSupplier stop) {
        Set<String> ids=new LinkedHashSet<>();int definitions=0,dexFiles=0;boolean partial=false;long copied=0;
        if(archives==null||archives.isEmpty()||archives.size()>32)return new Report(ids,"UNREADABLE",0,0);
        try {
            if(!cache.isDirectory()&&!cache.mkdirs())return new Report(ids,"UNREADABLE",0,0);
            for(File archive:archives){
                cancelled(stop);
                if(archive==null){partial=true;continue;}
                try(ZipFile zip=new ZipFile(archive)){
                    Enumeration<? extends ZipEntry> entries=zip.entries();int entryCount=0;
                    while(entries.hasMoreElements()){
                        cancelled(stop);ZipEntry entry=entries.nextElement();
                        if(++entryCount>100_000){partial=true;break;}
                        if(entry.isDirectory()||!DEX_ENTRY.matcher(entry.getName()).matches())continue;
                        if(dexFiles>=DEX_COUNT_LIMIT||entry.getSize()>DEX_LIMIT||copied>=TOTAL_LIMIT){partial=true;break;}
                        dexFiles++;
                        File temp=File.createTempFile("sdk-inspect-",".dex",cache);
                        try{
                            try(InputStream in=zip.getInputStream(entry);OutputStream out=new BufferedOutputStream(new FileOutputStream(temp))){
                                byte[] buffer=new byte[64*1024];long count=0;int n;
                                while((n=in.read(buffer))!=-1){
                                    cancelled(stop);count+=n;copied+=n;
                                    if(count>DEX_LIMIT||copied>TOTAL_LIMIT)throw new IOException("Inspection size limit");
                                    out.write(buffer,0,n);
                                }
                            }
                            try(RandomAccessFile dex=new RandomAccessFile(temp,"r")){
                                DefinitionResult result=definitions(dex,stop);
                                definitions+=result.count;ids.addAll(result.ids);partial|=result.packed;
                            }
                        }catch(Stopped e){throw e;}
                        catch(IOException|RuntimeException invalid){partial=true;}
                        finally{if(!temp.delete())temp.deleteOnExit();}
                    }
                }catch(Stopped e){throw e;}
                catch(IOException|RuntimeException unreadable){partial=true;}
            }
        }catch(Stopped stopped){return new Report(ids,"CANCELLED",definitions,dexFiles);}
        catch(RuntimeException unavailable){return new Report(ids,"UNREADABLE",definitions,dexFiles);}
        return new Report(ids,partial||dexFiles==0?"PARTIAL":"COMPLETE",definitions,dexFiles);
    }
    private static final class DefinitionResult {
        int count;boolean packed;final Set<String> ids=new LinkedHashSet<>();
    }
    private static DefinitionResult definitions(RandomAccessFile f,BooleanSupplier stop)throws IOException{
        if(f.length()<112||f.length()>DEX_LIMIT)throw new IOException("Invalid DEX length");
        byte[] magic=new byte[8];f.readFully(magic);
        String version=new String(magic,4,3,StandardCharsets.US_ASCII);
        if(magic[0]!='d'||magic[1]!='e'||magic[2]!='x'||magic[3]!='\n'||magic[7]!=0
            ||!Arrays.asList("035","037","038","039","040").contains(version))throw new IOException("Unsupported DEX");
        if(u32(f,32)!=f.length()||u32(f,36)!=112||u32(f,40)!=0x12345678L)throw new IOException("Invalid DEX header");
        int ns=table(f,56,60,4,STRING_LIMIT),nt=table(f,64,68,4,TYPE_LIMIT),nc=table(f,96,100,32,TYPE_LIMIT);
        long stringOff=u32(f,60),typeOff=u32(f,68),classOff=u32(f,100);
        // Only descriptors named by class_defs count. A reference or arbitrary string is not a definition.
        TreeSet<Long> descriptors=new TreeSet<>();
        for(int i=0;i<nc;i++){
            if((i&127)==0)cancelled(stop);
            long type=u32(f,classOff+(long)i*32);if(type>=nt)throw new IOException("Invalid type index");
            long sid=u32(f,typeOff+type*4);if(sid>=ns)throw new IOException("Invalid string index");
            long offset=u32(f,stringOff+sid*4);if(offset<112||offset>=f.length())throw new IOException("Invalid descriptor offset");
            descriptors.add(offset);
        }
        DefinitionResult result=new DefinitionResult();
        for(long offset:descriptors){
            cancelled(stop);String name=descriptor(f,offset);String id=AdSdkCatalog.identify(name);
            if(id!=null)result.ids.add(id);result.packed|=AdSdkCatalog.isPacked(name);result.count++;
        }
        return result;
    }
    private static int table(RandomAccessFile f,int countAt,int offsetAt,int stride,int max)throws IOException{
        long count=u32(f,countAt),offset=u32(f,offsetAt);
        if(count>max||count>0&&(offset<112||(offset&3)!=0||offset+count*stride>f.length()))throw new IOException("Invalid table bounds");
        return (int)count;
    }
    private static long u32(RandomAccessFile f,long offset)throws IOException{
        if(offset<0||offset+4>f.length())throw new EOFException();f.seek(offset);
        return Integer.toUnsignedLong(Integer.reverseBytes(f.readInt()));
    }
    private static String descriptor(RandomAccessFile f,long offset)throws IOException{
        f.seek(offset);int shift=0;long chars=0;int b;
        do{if(shift>=35)throw new IOException("Invalid ULEB");b=f.readUnsignedByte();chars|=(long)(b&127)<<shift;shift+=7;}while((b&128)!=0);
        if(chars>4096)throw new IOException("Descriptor length limit");
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        for(int i=0;i<12_288;i++){b=f.readUnsignedByte();if(b==0)return out.toString("UTF-8");out.write(b);}
        throw new IOException("Unterminated descriptor");
    }
    private static void cancelled(BooleanSupplier stop)throws Stopped{
        if(Thread.currentThread().isInterrupted()||stop!=null&&stop.getAsBoolean())throw new Stopped();
    }
}
