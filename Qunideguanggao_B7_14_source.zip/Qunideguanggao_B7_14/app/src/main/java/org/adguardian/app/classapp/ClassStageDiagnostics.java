package org.adguardian.app.classapp;

/** Only rule names, stage identifiers and enums. Never saves screen content or node handles. */
public final class ClassStageDiagnostics {
    private static volatile String last="CLASS 尚未检测";
    private ClassStageDiagnostics() { }
    public static void record(String stage,String key,String result){last="CLASS 阶段 "+stage+" 规则 "+key+" 结果 "+result;}
    public static String read(){return last;}
}
