package org.adguardian.app.recording;

import android.content.Context;
import android.util.AtomicFile;
import java.io.*;
import java.util.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;

/** Read-modify-write is serialized across instances. A failed verification cannot erase the captured lesson. */
public final class RecordingDraftStore {
    private static final int MAGIC=0x41524432, LEGACY_MAGIC=0x41524431, MAX_RECORDS=64, MAX_BYTES=1048576;
    private static final Object LOCK=new Object();
    private final AtomicFile file;
    public RecordingDraftStore(Context context) {
        file=new AtomicFile(new File(context.getFilesDir(),"ad-recording-drafts.bin"));
    }
    public List<RecordingDraft> all() throws IOException {synchronized(LOCK){return read();}}
    public void put(RecordingDraft draft) throws IOException {
        validate(draft);
        synchronized(LOCK) {
            ArrayList<RecordingDraft> next=new ArrayList<>(read());
            next.removeIf(item->item.key.equals(draft.key));
            if(next.size()>=MAX_RECORDS)throw new IOException("recording archive is full");
            next.add(draft);write(next);
        }
    }
    /** Explicit user annotation only. It never writes an active flow or changes captured actions. */
    public void dismissIssue(String key,String issueKey)throws IOException {
        synchronized(LOCK) {
            ArrayList<RecordingDraft> records=new ArrayList<>(read());int position=find(records,key);RecordingDraft old=records.get(position);
            if(old.state==RecordingDraft.ENABLED)throw new IOException("active recording cannot be reviewed");
            ArrayList<RecordingIssue> next=new ArrayList<>();boolean found=false,pending=false;
            for(RecordingIssue issue:old.issues){if(issue.key.equals(issueKey)){issue=issue.dismissed();found=true;}next.add(issue);pending|=!issue.dismissed;}
            if(!found)throw new IOException("review event not found");
            records.set(position,new RecordingDraft(old.key,old.packageName,old.appName,old.version,old.type,old.single,old.steps,old.confirmed,
                    pending?RecordingDraft.NEEDS_REVIEW:RecordingDraft.CAPTURED,System.currentTimeMillis(),next));
            write(records);
        }
    }
    /** Suffix repair is a new draft; the original recording and any active flow are untouched. */
    public RecordingDraft forkConfirmedPrefix(String key,int keep)throws IOException {
        synchronized(LOCK) {
            ArrayList<RecordingDraft> records=new ArrayList<>(read());RecordingDraft old=records.get(find(records,key));
            if(keep<1||keep>old.confirmed||keep>=FlowJournal.MAX_STEPS)throw new IOException("invalid confirmed prefix");
            for(RecordingIssue issue:old.issues)if(!issue.dismissed&&(issue.reason==RecordingIssue.LEGACY||issue.afterStep<keep))
                throw new IOException("review retained prefix first");
            if(records.size()>=MAX_RECORDS)throw new IOException("recording archive is full");
            RecordingDraft next=new RecordingDraft(UUID.randomUUID().toString(),old.packageName,old.appName,old.version,old.type,false,
                    old.steps.subList(0,keep),keep,RecordingDraft.CAPTURED,System.currentTimeMillis(),List.of());
            records.add(next);write(records);return next;
        }
    }
    private static int find(List<RecordingDraft> values,String key)throws IOException {
        for(int i=0;i<values.size();i++)if(values.get(i).key.equals(key))return i;
        throw new IOException("recording not found");
    }
    public void remove(String key)throws IOException {
        synchronized(LOCK){ArrayList<RecordingDraft> next=new ArrayList<>(read());next.removeIf(item->item.key.equals(key));write(next);}
    }
    public void clear()throws IOException {synchronized(LOCK){write(List.of());}}
    private List<RecordingDraft> read() throws IOException {
        if(!file.getBaseFile().exists() && !new File(file.getBaseFile()+".bak").exists())return List.of();
        try(DataInputStream in=new DataInputStream(file.openRead())) {
            int format=in.readInt();
            if(file.getBaseFile().length()>MAX_BYTES || (format!=MAGIC&&format!=LEGACY_MAGIC))throw new IOException("invalid recording archive");
            int count=in.readInt();if(count<0||count>MAX_RECORDS)throw new IOException("recording count");
            ArrayList<RecordingDraft> records=new ArrayList<>();Set<String> keys=new HashSet<>();
            for(int i=0;i<count;i++) {
                String key=field(in),pkg=field(in),name=field(in);long version=in.readLong();int type=in.readInt();
                boolean single=in.readBoolean();int confirmed=in.readInt(),state=in.readInt();long updated=in.readLong();
                int size=in.readInt();if(size<1||size>FlowJournal.MAX_STEPS||type<0||type>=AdType.values().length)throw new IOException("invalid recording");
                ArrayList<FlowStep> steps=new ArrayList<>();
                for(int j=0;j<size;j++) {
                    FlowGuard guard=new FlowGuard(field(in),conditionField(in),in.readFloat());
                    boolean back=in.readBoolean();long wait=in.readLong();
                    NodeTarget target=back?null:new NodeTarget(field(in),field(in),field(in),in.readFloat(),in.readFloat(),in.readFloat(),in.readFloat());
                    steps.add(new FlowStep(guard,target,back,wait));
                }
                ArrayList<RecordingIssue> issues=new ArrayList<>();
                if(format==MAGIC){int issueCount=in.readInt();if(issueCount<0||issueCount>16)throw new IOException("review issue limit");
                    for(int j=0;j<issueCount;j++)issues.add(new RecordingIssue(field(in),in.readInt(),in.readInt(),in.readBoolean()));
                }else if(state==RecordingDraft.NEEDS_REVIEW)issues.add(new RecordingIssue("legacy-review",confirmed,RecordingIssue.LEGACY,false));
                RecordingDraft value=new RecordingDraft(key,pkg,name,version,AdType.values()[type],single,steps,confirmed,state,updated,issues);
                validate(value);if(!keys.add(key))throw new IOException("duplicate recording");records.add(value);
            }
            if(in.read()!=-1)throw new IOException("trailing recording data");
            return Collections.unmodifiableList(records);
        }catch(RuntimeException invalid){throw new IOException("recording archive unreadable",invalid);}
    }
    private void write(List<RecordingDraft> values)throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(MAGIC);out.writeInt(values.size());
        for(RecordingDraft d:values) {
            validate(d);out.writeUTF(d.key);out.writeUTF(d.packageName);out.writeUTF(d.appName);out.writeLong(d.version);
            out.writeInt(d.type.ordinal());out.writeBoolean(d.single);out.writeInt(d.confirmed);out.writeInt(d.state);out.writeLong(d.updatedAt);out.writeInt(d.steps.size());
            for(FlowStep s:d.steps) {
                out.writeUTF(s.guard.activity);out.writeUTF(s.guard.signature);out.writeFloat(s.guard.aspect);
                out.writeBoolean(s.back);out.writeLong(s.timeoutMs);
                if(!s.back){NodeTarget t=s.target;out.writeUTF(t.id);out.writeUTF(t.name);out.writeUTF(t.label);out.writeFloat(t.x);out.writeFloat(t.y);out.writeFloat(t.width);out.writeFloat(t.height);}
            }
            out.writeInt(d.issues.size());for(RecordingIssue issue:d.issues){out.writeUTF(issue.key);out.writeInt(issue.afterStep);out.writeInt(issue.reason);out.writeBoolean(issue.dismissed);}
        }
        out.flush();if(bytes.size()>MAX_BYTES)throw new IOException("recording archive too large");
        byte[] expected=bytes.toByteArray();RecordBackup.preserve(file);FileOutputStream stream=file.startWrite();
        try {
            stream.write(expected);stream.getFD().sync();file.finishWrite(stream);
            // AtomicFile.finishWrite returns void. Never announce persistence without checking actual bytes.
            try(InputStream verify=file.openRead()) {
                int position=0;byte[] buffer=new byte[4096];int size;
                while((size=verify.read(buffer))!=-1) {
                    if(position+size>expected.length)throw new IOException("recording readback length");
                    for(int i=0;i<size;i++)if(buffer[i]!=expected[position+i])throw new IOException("recording readback mismatch");
                    position+=size;
                }
                if(position!=expected.length)throw new IOException("recording readback truncated");
            }
        }catch(IOException|RuntimeException error){file.failWrite(stream);throw new IOException("recording write failed",error);}
    }
    private static String conditionField(DataInputStream in)throws IOException{String s=in.readUTF();if(s.length()>8192)throw new IOException("condition limit");return s;}
    private static String field(DataInputStream in)throws IOException{String value=in.readUTF();if(value.length()>512)throw new IOException("recording field too long");return value;}
    private static void validate(RecordingDraft d)throws IOException {
        if(d==null||d.type==null||d.version<0||d.updatedAt<0||d.confirmed<0||d.confirmed>d.steps.size()
                ||d.state<0||d.state>2||d.steps.isEmpty()||d.steps.size()>FlowJournal.MAX_STEPS||(d.single&&d.steps.size()!=1))throw new IOException("invalid recording metadata");
        for(String value:new String[]{d.key,d.packageName,d.appName})if(value==null||value.isEmpty()||value.length()>512)throw new IOException("invalid recording field");
        for(FlowStep s:d.steps) {
            if(s==null||!s.valid())throw new IOException("invalid recording step");
            if(!s.back){
                for(String value:new String[]{s.target.id,s.target.name,s.target.label})if(value==null||value.length()>512)throw new IOException("invalid recording target");
                if(!s.target.label.isEmpty()&&!AdCloseText.isClose(s.target.label))throw new IOException("arbitrary recording text");
            }
        }
        if(d.issues.size()>16)throw new IOException("review issue limit");
        Set<String> issueKeys=new HashSet<>();boolean unresolved=false;
        for(RecordingIssue issue:d.issues){if(issue==null||!issue.valid(d.steps.size())||!issueKeys.add(issue.key))throw new IOException("invalid review issue");unresolved|=!issue.dismissed;}
        if(unresolved&&d.state!=RecordingDraft.NEEDS_REVIEW)throw new IOException("unreviewed event marked ready");
        if(d.steps.get(0).back)throw new IOException("first recorded step cannot be Back");
        if(d.state==RecordingDraft.ENABLED&&d.confirmed!=d.steps.size())throw new IOException("unverified recording marked enabled");
    }
}
