package org.adguardian.app.runtime;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.Settings;
import java.util.ArrayList;
import org.adguardian.app.settings.PreferenceStore;

/**
 * Optional, explicitly authorized recovery following GKD's remove/wait/add/recheck sequence.
 * No grant is attempted here. The default mode never writes secure settings.
 * Only our own temporary removal is rolled back; other services are always reread and retained.
 */
public final class AccessibilityRecovery implements AutoCloseable {
    public static final String PERMISSION="android.permission.WRITE_SECURE_SETTINGS";
    private static final String PREFS="accessibility_recovery", ENABLED="consented", PENDING="restore_own_component";
    private static final Object LOCK=new Object();
    private static AccessibilityRecovery active;
    private static volatile String lastStatus="增强重连尚未开启";
    private final Context context;
    private final Handler worker;
    private volatile boolean closed;
    private boolean removed;
    private long lastAttempt=-120000,nextRollbackAt,epoch;
    public AccessibilityRecovery(Context context,Handler handler){this.context=context.getApplicationContext();worker=new Handler(handler.getLooper());}
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    public static boolean enabled(Context c){return prefs(c).getBoolean(ENABLED,false);}
    public static void setEnabled(Context c,boolean value){prefs(c).edit().putBoolean(ENABLED,value).apply();AccessibilityState.changed();}
    public static boolean granted(Context c){try{return c.checkSelfPermission(PERMISSION)==PackageManager.PERMISSION_GRANTED;}catch(RuntimeException e){return false;}}
    public static String status(){return lastStatus;}
    public static String grantCommand(Context c){return "adb shell pm grant "+c.getPackageName()+" "+PERMISSION;}
    public static boolean restoring(Context c){
        synchronized(LOCK){if(active!=null&&active.context.getPackageName().equals(c.getPackageName()))return true;}
        return granted(c)&&prefs(c).getBoolean(PENDING,false);
    }
    private boolean requested(){return enabled(context)&&PreferenceStore.isMasterEnabled(context)&&PreferenceStore.isKeepAliveEnabled(context);}
    private String read(){return Settings.Secure.getString(context.getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);}
    private boolean contains(String value){return AccessibilityState.containsComponent(value,context.getPackageName(),AccessibilityState.SERVICE_NAME);}
    private String own(){return new ComponentName(context.getPackageName(),AccessibilityState.SERVICE_NAME).flattenToString();}
    private String withoutOwn(String value){
        ArrayList<String> parts=new ArrayList<>();for(String part:value.split(":"))if(!part.trim().isEmpty()&&!contains(part.trim()))parts.add(part.trim());
        return String.join(":",parts);
    }
    private void write(String value){
        if(!Settings.Secure.putString(context.getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,value))throw new IllegalStateException("secure write denied");
    }
    private void pending(boolean value){if(!prefs(context).edit().putBoolean(PENDING,value).commit())throw new IllegalStateException("recovery marker not persisted");}
    private void note(String message){lastStatus=message;RuntimeHealth.event(context,message);AccessibilityState.changed();}
    public void request(boolean explicit){worker.post(()->attempt(explicit));}
    private void attempt(boolean explicit){
        if(closed)return;
        synchronized(LOCK){if(active!=null)return;}
        // Finish ONLY a transaction this app started, even if the user subsequently paused ads.
        if(prefs(context).getBoolean(PENDING,false)&&granted(context)) {
            if(SystemClock.uptimeMillis()<nextRollbackAt)return;
            synchronized(LOCK){if(active!=null&&active!=this)return;active=this;}
            removed=true;rollback();return;
        }
        AccessibilityState.Snapshot state=AccessibilityState.read(context);
        if(state.connected) {
            if(state.failed&&state.authorized&&state.enabled)org.adguardian.app.service.AdAccessibilityService.requestHealthInitialization();
            return;
        }
        if(!requested())return;
        // Normal health monitoring never creates a new remove/wait/add transaction.
        // A previously journaled interrupted removal is still restored above.
        if(!explicit) {
            lastStatus=state.authorized?"授权仍在但辅助服务未连接 可在应用内确认修复 不会定时撤销授权":"辅助功能未连接 请核对系统开关";
            return;
        }
        if(!granted(context)){if(explicit)note("增强重连需要额外系统授权 当前没有修改辅助功能设置");return;}
        if(AccessibilityState.read(context).connected)return;
        long now=SystemClock.uptimeMillis();if(now-lastAttempt<(explicit?5000:120000))return;
        synchronized(LOCK){if(active!=null)return;active=this;}
        long token=++epoch;lastAttempt=now;
        try {
            String names=read();if(names==null){finish("系统启用列表暂不可读 没有更改任何服务");return;}
            boolean globalOff="0".equals(Settings.Secure.getString(context.getContentResolver(),Settings.Secure.ACCESSIBILITY_ENABLED));
            if((!contains(names)||globalOff)&&!explicit){finish("系统辅助功能开关已关闭 请由用户确认恢复 不自动重新授权");return;}
            if(contains(names)) {
                // Crash recovery marker must reach disk BEFORE temporarily removing our component.
                pending(true);removed=true;write(withoutOwn(names));
                note("正在重新连接辅助功能 保留其他辅助服务");
                worker.postDelayed(()->restoreAndVerify(token,explicit),1000);
            } else restoreAndVerify(token,explicit);
        }catch(RuntimeException error){RuntimeHealth.failure(context,"增强重连请求失败",error);rollback();}
    }
    private void restoreAndVerify(long token,boolean explicit){
        if(token!=epoch)return;
        if(closed||!requested()){rollback();return;}
        try {
            addOwn(explicit);removed=false;pending(false);
            // A successful settings write is NOT proof of a system connection.
            worker.postDelayed(()->{
                if(token!=epoch)return;
                AccessibilityState.Snapshot state=AccessibilityState.read(context);
                finish(state.running()?"辅助功能已重新连接并开始保护":state.connected?"系统已重新连接 正在准备规则":"系统尚未重新连接 请检查自启动和受限设置");
            },2000);
        }catch(RuntimeException error){RuntimeHealth.failure(context,"系统重连未完成",error);rollback();}
    }
    private void addOwn(boolean enableGlobal){
        if(!granted(context))throw new IllegalStateException("grant revoked");
        String fresh=read();if(fresh==null)throw new IllegalStateException("unknown enabled list");
        if(!contains(fresh))write(fresh.trim().isEmpty()?own():fresh+":"+own());
        if(enableGlobal && "0".equals(Settings.Secure.getString(context.getContentResolver(),Settings.Secure.ACCESSIBILITY_ENABLED))) {
            if(!Settings.Secure.putInt(context.getContentResolver(),Settings.Secure.ACCESSIBILITY_ENABLED,1))throw new IllegalStateException("global switch denied");
        }
        String actual=read();if(actual==null||!contains(actual))throw new IllegalStateException("component readback failed");
    }
    private void rollback(){
        if(removed||prefs(context).getBoolean(PENDING,false)) {
            try{addOwn(false);pending(false);removed=false;finish("已恢复重连前的授权配置 请核对实际连接状态");}
            catch(RuntimeException e){nextRollbackAt=SystemClock.uptimeMillis()+120000;RuntimeHealth.failure(context,"原授权配置待恢复",e);finish("恢复授权配置受系统限制 请进入辅助功能设置核对");}
        } else finish("系统未完成增强重连 原配置没有主动清空");
    }
    private void finish(String message){
        epoch++;worker.removeCallbacksAndMessages(null);
        synchronized(LOCK){if(active==this)active=null;}
        note(message);
    }
    @Override public void close(){
        closed=true;
        worker.post(()->{
            synchronized(LOCK){if(active!=null&&active!=this){epoch++;worker.removeCallbacksAndMessages(null);return;}}
            if(removed||prefs(context).getBoolean(PENDING,false))rollback();
            else {synchronized(LOCK){if(active==this)active=null;}epoch++;worker.removeCallbacksAndMessages(null);}
        });
    }
}
