package org.adguardian.app.flow;

import android.accessibilityservice.*;
import android.graphics.*;
import android.os.*;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;
import java.util.function.Supplier;
import org.adguardian.app.engine.*;
import org.adguardian.app.settings.PreferenceStore;
import org.adguardian.app.log.UserEventLog;

/** Finite, page-checked replay. A completed input is never considered a completed advertising flow. */
public final class FlowReplayEngine {
    private final AccessibilityService service;
    private final Handler worker;
    private final Supplier<String> foreground;
    private final Runnable scan;
    private final FlowStore store;
    private final LinkedHashMap<String,Long> blocked=new LinkedHashMap<>();
    private volatile LearnedFlow current;
    private final org.adguardian.app.runtime.PackageVersionLookup versions=new org.adguardian.app.runtime.PackageVersionLookup();
    private long version=-1,epoch,stepStarted,started,stableAt,deadline;
    private volatile long lastAction;
    private int position,completed,sessionRotation=-1;
    private boolean inFlight,accepted;
    private FlowGuard stable;
    private FlowPage actionPage;
    private String unexpectedActivity="";
    private long unexpectedAt;
    public FlowReplayEngine(AccessibilityService service,Handler worker,Supplier<String> foreground,Runnable scan) {
        this.service=service;this.worker=new Handler(worker.getLooper());this.foreground=foreground;this.scan=scan;store=new FlowStore(service);
    }
    public FlowStore store(){return store;}
    public boolean isActive(){return current!=null;}
    public int completedCount(){return completed;}
    public long lastAction(){return lastAction;}
    public long nextWakeUp(){return current==null?-1:250;}
    public void onPackageChanged(){cancel();versions.clear();}
    public void cancel(){if(current!=null)block(current.key);clear();}
    public void close(){cancel();}
    private void clear(){epoch++;current=null;inFlight=false;accepted=false;stable=null;actionPage=null;unexpectedActivity="";worker.removeCallbacksAndMessages(null);}
    private void block(String key){blocked.put(key,SystemClock.uptimeMillis()+8000);if(blocked.size()>64)blocked.remove(blocked.keySet().iterator().next());}
    private boolean enabled(){return PreferenceStore.isMasterEnabled(service) && PreferenceStore.isLearnedEnabled(service);}
    public boolean handle(String pkg,String activity,AccessibilityNodeIndex index) {
        if(!enabled() || !pkg.equals(foreground.get())){cancel();return false;}
        if(current!=null && (!current.packageName.equals(pkg) || !store.isEnabled(current.key) || !PreferenceStore.isTypeEnabled(service,current.type))){cancel();return false;}
        if(current==null && !store.hasPackage(pkg))return false;
        long now=SystemClock.uptimeMillis();
        if(current!=null && (now>=deadline || now-started>120000)){cancel();return false;}
        version=versions.read(service,pkg);
        if(version<0)return false;
        index.startQueryBudget(45L);
        try {
            FlowPage page=FlowPage.capture(pkg,activity,version,index,org.adguardian.app.runtime.DisplayRotation.read(service));
            if(page==null){stable=null;return isActive();}
            if(current!=null && sessionRotation>=0 && page.displayRotation()>=0 && sessionRotation!=page.displayRotation()){cancel();return false;}
            if(current==null) {
                for(LearnedFlow f:store.all()) {
                    if(!f.enabled || !f.packageName.equals(pkg) || f.versionCode!=version || !PreferenceStore.isTypeEnabled(service,f.type)
                            || blocked.getOrDefault(f.key,0L)>now || !f.steps.get(0).guard.matches(page.guard))continue;
                    AccessibilityNodeInfo target=FlowPage.resolve(f.steps.get(0),index);
                    if(target==null)continue;
                    current=f;sessionRotation=page.displayRotation();position=0;started=now;return execute(page,index,target);
                }
                return false;
            }
            if(current.versionCode!=version){cancel();return false;}
            if(inFlight || !accepted)return true;
            FlowStep last=current.steps.get(position);
            FlowGuard expected=position+1<current.steps.size()?current.steps.get(position+1).guard:current.terminal;
            boolean unchanged=!FlowTransition.changed(actionPage,page,last);
            if(unchanged && now-stepStarted>=2500){cancel();return false;}
            if(!page.guard.activity.equals(last.guard.activity) && !page.guard.activity.equals(expected.activity)
                    && !last.guard.matches(page.guard) && !expected.matches(page.guard)) {
                if(unexpectedActivity.equals(page.guard.activity) && now-unexpectedAt>=180){cancel();return false;}
                unexpectedActivity=page.guard.activity;unexpectedAt=now;stable=null;return true;
            }
            unexpectedActivity="";
            if(!expected.matches(page.guard) || unchanged){stable=null;return true;}
            if(position+1<current.steps.size()) {
                FlowStep next=current.steps.get(position+1);
                if(!next.back && FlowPage.resolve(next,index)==null){stable=null;return true;}
            }
            if(stable==null || !stable.matches(page.guard)){stable=position+1<current.steps.size()?page.stageGuard():page.terminalGuard();stableAt=now;return true;}
            if(now-stableAt<120)return true;
            if(position+1>=current.steps.size()) {
                if(page.isKnownAdPage() || (page.pkg.equals("cn.luyiyuntech.stt")&&!page.isCertifiedClassHome())){stable=null;return true;}
                completed++;clear();
                UserEventLog.record(service,"已按学习流程关闭广告 并确认回到目标页面");scan.run();return true;
            }
            position++;stable=null;accepted=false;
            FlowStep next=current.steps.get(position);
            return execute(page,index,next.back?null:FlowPage.resolve(next,index));
        }catch(AccessibilityNodeIndex.QueryLimit exhausted){stable=null;return isActive();}
        catch(RuntimeException unavailable){if(current!=null)cancel();return false;}
        finally{index.clearQueryBudget();}
    }
    private boolean operationAllowed(LearnedFlow expected,long token) {
        return expected!=null && current==expected && token==epoch && enabled()
                && expected.packageName.equals(foreground.get())
                && PreferenceStore.isTypeEnabled(service,expected.type) && store.isEnabled(expected.key);
    }
    private boolean stopStaleOperation(LearnedFlow expected,long token) {
        if(operationAllowed(expected,token))return false;
        // A cancelled old invocation must not cancel a newer flow occupying this engine.
        if(current==expected && token==epoch)cancel();
        return true;
    }
    private boolean execute(FlowPage page,AccessibilityNodeIndex index,AccessibilityNodeInfo node) {
        if(current==null || !enabled() || !current.packageName.equals(foreground.get())){cancel();return false;}
        LearnedFlow operation=current;
        FlowStep step=operation.steps.get(position);
        if(!step.guard.matches(page.guard)){cancel();return false;}
        actionPage=page;long token=++epoch;stepStarted=SystemClock.uptimeMillis();deadline=Math.min(started+120000,stepStarted+step.timeoutMs);
        worker.removeCallbacksAndMessages(null);
        worker.postAtTime(()->{if(token==epoch && current!=null){cancel();scan.run();}},deadline);
        boolean result=false;
        // Mark before Binder can deliver the resulting click event back on the main thread.
        lastAction=SystemClock.uptimeMillis();
        if(step.back) {
            if(page.guard.activity.startsWith("@window:")){cancel();return false;}
            if(page.pkg.equals("cn.luyiyuntech.stt") && page.guard.activity.equals("com.common.tang.activity.MainActivity")){cancel();return false;}
            if(stopStaleOperation(operation,token))return false;
            result=service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
        } else {
            AccessibilityNodeInfo clickable=FlowSafety.clickTarget(node,index);
            if(clickable==null){cancel();return false;}
            boolean nativeClickable=clickable.isClickable();
            if(stopStaleOperation(operation,token))return false;
            if(nativeClickable)result=clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            if(stopStaleOperation(operation,token))return false;
            if(!result) {
                Rect b=FlowSafety.bounds(clickable);Path path=new Path();path.moveTo(b.exactCenterX(),b.exactCenterY());
                GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,45)).build();
                if(stopStaleOperation(operation,token))return false;
                inFlight=true;
                result=service.dispatchGesture(gesture,new AccessibilityService.GestureResultCallback(){
                    @Override public void onCompleted(GestureDescription g){if(token!=epoch || current==null)return;inFlight=false;if(stopStaleOperation(operation,token))return;accepted=true;scan.run();}
                    @Override public void onCancelled(GestureDescription g){if(token!=epoch || current==null)return;cancel();scan.run();}
                },worker);
                if(result)worker.postDelayed(()->{if(token==epoch && inFlight){cancel();scan.run();}},1500);
            }
        }
        if(stopStaleOperation(operation,token))return false;
        if(!result){cancel();return false;}
        lastAction=SystemClock.uptimeMillis();if(!inFlight)accepted=true;
        worker.postDelayed(()->{if(token==epoch && current!=null)scan.run();},180);
        return true;
    }
}
