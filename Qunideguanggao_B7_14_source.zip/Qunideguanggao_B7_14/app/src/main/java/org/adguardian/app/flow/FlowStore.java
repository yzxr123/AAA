package org.adguardian.app.flow;

import android.content.Context;
import android.util.AtomicFile;
import java.io.*;
import java.util.*;
import org.adguardian.app.engine.*;

/** Separate format and file: old single-button lessons are never rewritten or discarded here. */
public final class FlowStore {
    private static final int MAGIC=0x51464c31,MAX_FLOWS=64,MAX_BYTES=262144;
    private static final Object FILE_LOCK=new Object();
    private static long revision;
    private long loadedRevision;
    private final AtomicFile file;
    private List<LearnedFlow> flows=List.of();
    private boolean readable=true;
    public FlowStore(Context c) {
        file=new AtomicFile(new File(c.getFilesDir(),"learned-ad-flows.bin"));
        synchronized(FILE_LOCK){load();}
    }
    private void load() {
        flows=List.of();readable=true;loadedRevision=revision;
        if(!file.getBaseFile().exists() && !new File(file.getBaseFile()+".bak").exists())return;
        try(DataInputStream in=new DataInputStream(file.openRead())) {
            if(file.getBaseFile().length()>MAX_BYTES || in.readInt()!=MAGIC)throw new IOException("invalid flow file");
            int count=in.readInt();if(count<0 || count>MAX_FLOWS)throw new IOException("flow count");
            ArrayList<LearnedFlow> copy=new ArrayList<>();HashSet<String> keys=new HashSet<>();
            for(int i=0;i<count;i++) {
                String key=field(in),pkg=field(in),name=field(in);long version=in.readLong();int type=in.readInt();boolean enabled=in.readBoolean();
                if(type<0 || type>=AdType.values().length)throw new IOException("category");
                int size=in.readInt();if(size<1 || size>FlowJournal.MAX_STEPS)throw new IOException("step count");
                ArrayList<FlowStep> steps=new ArrayList<>();
                for(int j=0;j<size;j++) {
                    FlowGuard guard=guard(in);boolean back=in.readBoolean();long wait=in.readLong();
                    NodeTarget target=back?null:new NodeTarget(field(in),field(in),field(in),in.readFloat(),in.readFloat(),in.readFloat(),in.readFloat());
                    steps.add(new FlowStep(guard,target,back,wait));
                }
                LearnedFlow flow=new LearnedFlow(key,pkg,name,version,AdType.values()[type],enabled,steps,guard(in));
                validate(flow);if(!keys.add(key))throw new IOException("duplicate flow");copy.add(flow);
            }
            if(in.read()!=-1)throw new IOException("trailing flow data");flows=Collections.unmodifiableList(copy);
        }catch(IOException | RuntimeException e){readable=false;}
    }
    private void refresh(){if(loadedRevision!=revision)load();}
    public boolean isReadable(){synchronized(FILE_LOCK){refresh();return readable;}}
    public List<LearnedFlow> all(){synchronized(FILE_LOCK){refresh();return flows;}}
    public boolean hasPackage(String pkg){for(LearnedFlow f:all())if(f.enabled&&f.packageName.equals(pkg))return true;return false;}
    public boolean isEnabled(String key){for(LearnedFlow f:all())if(f.key.equals(key))return f.enabled;return false;}
    public void add(LearnedFlow flow)throws IOException {
        synchronized(FILE_LOCK){load();
        if(!readable)throw new IOException("unreadable flow file");validate(flow);ArrayList<LearnedFlow> next=new ArrayList<>(flows);
        next.removeIf(f->f.key.equals(flow.key));if(next.size()>=MAX_FLOWS)throw new IOException("flow limit");next.add(flow);save(next);}
    }
    public void setEnabled(String key,boolean value)throws IOException {
        synchronized(FILE_LOCK){load();
        if(!readable)throw new IOException("unreadable flow file");ArrayList<LearnedFlow> next=new ArrayList<>();
        for(LearnedFlow f:flows)next.add(f.key.equals(key)?f.withEnabled(value):f);save(next);}
    }
    public void remove(String key)throws IOException {
        synchronized(FILE_LOCK){load();
        if(!readable)throw new IOException("unreadable flow file");ArrayList<LearnedFlow> next=new ArrayList<>(flows);next.removeIf(f->f.key.equals(key));save(next);}
    }
    public void clear()throws IOException {synchronized(FILE_LOCK){save(List.of());readable=true;}}
    private void save(List<LearnedFlow> next)throws IOException {
        for(LearnedFlow flow:next)validate(flow);
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(MAGIC);out.writeInt(next.size());
        for(LearnedFlow f:next) {
            out.writeUTF(f.key);out.writeUTF(f.packageName);out.writeUTF(f.appName);out.writeLong(f.versionCode);out.writeInt(f.type.ordinal());out.writeBoolean(f.enabled);out.writeInt(f.steps.size());
            for(FlowStep s:f.steps){writeGuard(out,s.guard);out.writeBoolean(s.back);out.writeLong(s.timeoutMs);if(!s.back){NodeTarget t=s.target;out.writeUTF(t.id);out.writeUTF(t.name);out.writeUTF(t.label);out.writeFloat(t.x);out.writeFloat(t.y);out.writeFloat(t.width);out.writeFloat(t.height);}}
            writeGuard(out,f.terminal);
        }
        out.flush();if(bytes.size()>MAX_BYTES)throw new IOException("flow file limit");
        if(next.stream().anyMatch(f->f.terminal.signature.startsWith("v3:")||f.steps.stream().anyMatch(s->s.guard.signature.startsWith("v3:"))))
            org.adguardian.app.recording.RecordBackup.preserve(file);
        FileOutputStream stream=file.startWrite();try{byte[] expected=bytes.toByteArray();stream.write(expected);stream.getFD().sync();file.finishWrite(stream);
            try(InputStream verify=file.openRead()){
                byte[] buffer=new byte[4096];int offset=0,count;
                while((count=verify.read(buffer))!=-1){if(offset+count>expected.length)throw new IOException("flow readback length");
                    for(int i=0;i<count;i++)if(buffer[i]!=expected[offset+i])throw new IOException("flow readback mismatch");offset+=count;}
                if(offset!=expected.length)throw new IOException("flow write truncated");}
            revision++;loadedRevision=revision;flows=Collections.unmodifiableList(new ArrayList<>(next));}
        catch(IOException | RuntimeException error){file.failWrite(stream);throw new IOException("flow write failed",error);}
    }
    private static void validate(LearnedFlow f)throws IOException {
        if(f==null || f.type==null || f.terminal==null || !f.terminal.valid() || f.versionCode<0 || f.steps.isEmpty() || f.steps.size()>FlowJournal.MAX_STEPS)throw new IOException("invalid flow");
        if(f.terminal.condition!=null&&f.terminal.condition.kind!=FlowCondition.END&&f.terminal.condition.kind!=FlowCondition.CLASS_HOME)throw new IOException("invalid terminal kind");
        for(String s:new String[]{f.key,f.packageName,f.appName})if(s==null || s.isEmpty() || s.length()>512)throw new IOException("invalid field");
        if(f.steps.get(0)==null || f.steps.get(0).back)throw new IOException("cannot begin with back");
        for(int i=0;i<f.steps.size();i++) {
            FlowStep s=f.steps.get(i);if(s==null || !s.valid())throw new IOException("invalid step");
            // Each stage has its own window guard. A fullscreen ad and its inset home have different aspects.
            if(s.back && s.guard.matches(i+1<f.steps.size()?f.steps.get(i+1).guard:f.terminal))throw new IOException("unverified back");
            if(!s.back)for(String text:new String[]{s.target.id,s.target.name,s.target.label})if(text==null || text.length()>512)throw new IOException("invalid target field");
            if(!s.back && !s.target.label.isEmpty() && !AdCloseText.isClose(s.target.label))throw new IOException("arbitrary label");
        }
    }
    private static String field(DataInputStream in)throws IOException{String s=in.readUTF();if(s.length()>512)throw new IOException("field length");return s;}
    private static FlowGuard guard(DataInputStream in)throws IOException{return new FlowGuard(field(in),conditionField(in),in.readFloat());}
    private static String conditionField(DataInputStream in)throws IOException{String s=in.readUTF();if(s.length()>8192)throw new IOException("condition limit");return s;}
    private static void writeGuard(DataOutputStream out,FlowGuard g)throws IOException{out.writeUTF(g.activity);out.writeUTF(g.signature);out.writeFloat(g.aspect);}
}
