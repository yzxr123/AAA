package org.adguardian.app.sdk;

/** Signatures identify SDK implementation namespaces, not ads currently on screen. */
public final class AdSdkCatalog {
    private static final String[][] ROWS = {
        {"pangle", "穿山甲 Pangle", "Lcom/bytedance/sdk/openadsdk/"},
        {"gdt", "腾讯优量汇", "Lcom/qq/e/ads/", "Lcom/qq/e/comm/"},
        {"baidu", "百度广告", "Lcom/baidu/mobads/", "Lcom/baidu/mobads/sdk/"},
        {"kuaishou", "快手广告", "Lcom/kwad/sdk/", "Lcom/ksad/"},
        {"googleads", "Google 移动广告", "Lcom/google/android/gms/ads/"},
        {"unity", "Unity Ads", "Lcom/unity3d/ads/", "Lcom/unity3d/services/ads/"},
        {"applovin", "AppLovin", "Lcom/applovin/"},
        {"mintegral", "Mintegral", "Lcom/mbridge/msdk/", "Lcom/mintegral/msdk/"},
        {"sigmob", "Sigmob", "Lcom/sigmob/"},
        {"inmobi", "InMobi", "Lcom/inmobi/"},
        {"vungle", "Vungle", "Lcom/vungle/"},
        {"huaweiads", "华为广告", "Lcom/huawei/openalliance/ad/"},
        {"topon", "TopOn 聚合", "Lcom/anythink/"},
        {"tradplus", "TradPlus 聚合", "Lcom/tradplus/ads/"}
    };
    private AdSdkCatalog() {}
    public static String identify(String descriptor) {
        if (descriptor == null || !descriptor.endsWith(";")) return null;
        for (String[] row : ROWS) for (int i=2;i<row.length;i++)
            if (descriptor.startsWith(row[i])) return row[0];
        return null;
    }
    public static String name(String id) {
        for(String[] row:ROWS)if(row[0].equals(id))return row[1];
        return id;
    }
    public static boolean isPacked(String descriptor) {
        return descriptor.startsWith("Lcom/tencent/StubShell/")
            || descriptor.equals("Lcom/stub/StubApp;") || descriptor.startsWith("Lcom/qihoo/util/");
    }
}
