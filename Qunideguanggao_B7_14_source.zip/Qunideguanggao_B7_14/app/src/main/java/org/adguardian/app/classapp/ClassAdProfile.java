package org.adguardian.app.classapp;

/** Verified from the supplied Class 6.2.1013 APK. Runtime accessibility templates are still checked. */
public final class ClassAdProfile {
    public static final String PACKAGE="cn.luyiyuntech.stt";
    public static final long VERSION=1013;
    public static final String SPLASH="com.common.tang.activity.SplashActivity";
    public static final String MAIN="com.common.tang.activity.MainActivity";
    public static final String VIDEO="com.bytedance.sdk.openadsdk.core.component.reward.activity.TTFullScreenVideoActivity";
    public static final String LANDSCAPE="com.bytedance.sdk.openadsdk.core.component.reward.activity.TTFullScreenVideoLandscapeActivity";
    public static final java.util.List<String> HOME_IDS=java.util.List.of("navigation_bar","tv_today_date","tv_weeks","timetableView");
    public static boolean hasHomeLayout(java.util.Set<String> ids) {
        for(String id:HOME_IDS)if(!ids.contains(PACKAGE+":id/"+id))return false;return true;
    }
    /** Composite home header evidence. Callers must also exclude ad containers and real SDK windows. */
    public static final java.util.List<String> MAIN_HEADER_IDS=java.util.Arrays.asList("navigation_bar","tv_today_date","tv_weeks");
    public static boolean hasHomeLayoutForActivity(java.util.Set<String> ids,String activity) {
        if(hasHomeLayout(ids))return true;
        if(activity!=null&&!activity.isEmpty()&&!MAIN.equals(activity)&&!SPLASH.equals(activity))return false;
        if(!ids.contains(PACKAGE+":id/navigation_bar"))return false;
        return ids.contains(PACKAGE+":id/tv_today_date") && ids.contains(PACKAGE+":id/tv_weeks");
    }
    private ClassAdProfile() { }
    public static boolean isAdActivity(String activity){return SPLASH.equals(activity) || VIDEO.equals(activity) || LANDSCAPE.equals(activity);}
}
