package org.adguardian.app.flow;
import org.adguardian.app.engine.NodeTarget;
public final class FlowStep {
    public final FlowGuard guard;
    public final NodeTarget target;
    public final boolean back;
    public final long timeoutMs;
    public FlowStep(FlowGuard guard,NodeTarget target,boolean back,long timeoutMs) {
        this.guard=guard;this.target=target;this.back=back;this.timeoutMs=timeoutMs;
    }
    public boolean valid() {return guard!=null && guard.valid() && timeoutMs>=1000 && timeoutMs<=60000
            && (back?target==null:FlowSafety.safeTarget(target))
            && (guard.condition==null || (back?guard.condition.kind==FlowCondition.STAGE:
                guard.condition.kind==FlowCondition.TARGET&&FlowObservation.exactDescriptor(guard.condition.target,target)));}
}
