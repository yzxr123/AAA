package org.adguardian.app.recording;

/** No input text or screenshot: just where an unlocated event needs the user's review. */
public final class RecordingIssue {
    public static final int LEGACY=0, UNLOCATED_CLICK=1, NO_PRIOR_PAGE=2, UNOBSERVED_TRANSITION=3, LIMIT=4;
    public final String key;
    public final int afterStep, reason;
    public final boolean dismissed;
    public RecordingIssue(String key,int afterStep,int reason,boolean dismissed){this.key=key;this.afterStep=afterStep;this.reason=reason;this.dismissed=dismissed;}
    public RecordingIssue dismissed(){return new RecordingIssue(key,afterStep,reason,true);}
    public String describe(){
        String[] labels={"旧记录只有待审查标记 没有更详细的事件数据","一次点击没有关联到唯一关闭目标","这次点击前的页面没有读到","步骤之间缺少可验证的页面变化","已达到本次记录的步骤上限"};
        return "第 "+afterStep+" 步之后  "+labels[reason]+(dismissed?"  已由你标注为无关操作":"  等待你审查");
    }
    public boolean valid(int count){return key!=null&&!key.isEmpty()&&key.length()<=80&&afterStep>=0&&afterStep<=count&&reason>=0&&reason<=4;}
}
