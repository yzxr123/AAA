package org.adguardian.app.recording;

import android.util.AtomicFile;
import java.io.*;
import java.nio.file.*;
import java.util.Arrays;

/** One bounded exact pre-upgrade copy. Never used automatically as a newer schema. */
public final class RecordBackup {
    private RecordBackup() { }
    public static void preserve(AtomicFile original)throws IOException {
        File base=original.getBaseFile();
        File backup=new File(base+".before-b713");
        if(backup.exists() || (!base.exists()&&!new File(base+".bak").exists()))return;
        byte[] old;
        try(InputStream in=original.openRead();ByteArrayOutputStream bytes=new ByteArrayOutputStream()) {
            byte[] buffer=new byte[4096];int count;
            while((count=in.read(buffer))!=-1){if(bytes.size()+count>1048576)throw new IOException("legacy record backup too large");bytes.write(buffer,0,count);}old=bytes.toByteArray();
        }
        AtomicFile copy=new AtomicFile(backup);FileOutputStream out=copy.startWrite();
        try {
            out.write(old);out.getFD().sync();copy.finishWrite(out);
            byte[] actual=Files.readAllBytes(backup.toPath());
            if(!Arrays.equals(old,actual))throw new IOException("backup readback failed");
        }catch(IOException|RuntimeException e){copy.failWrite(out);throw new IOException("record backup not completed",e);}
    }
}
