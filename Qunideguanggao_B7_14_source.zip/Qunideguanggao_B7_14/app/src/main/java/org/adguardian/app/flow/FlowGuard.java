package org.adguardian.app.flow;

import java.util.Objects;

/** A screen precondition. It contains structural metadata, never page text or screenshots. */
public final class FlowGuard {
    public final String activity, signature;
    private final String legacySignature;
    final FlowCondition condition;
    FlowObservation observation;
    public final float aspect;
    public FlowGuard(String activity,String signature,float aspect) {
        this(activity,signature,aspect,"");
    }
    public FlowGuard(String activity,String signature,float aspect,String legacySignature) {
        this.activity=activity;this.signature=signature;this.aspect=aspect;this.legacySignature=legacySignature;
        condition=FlowCondition.decode(signature);
    }
    public boolean valid() {
        return activity!=null && !activity.isEmpty() && activity.length()<=512
                && signature!=null && (signature.matches("f[12]:[0-9a-f]{64}") || condition!=null)
                && Float.isFinite(aspect) && aspect>.15f && aspect<6f;
    }
    public boolean matches(FlowGuard other) {
        if(other==null||!valid()||!other.valid()||!sameActivity(other))return false;
        if(condition!=null) {
            if(condition.kind!=FlowCondition.CLASS_HOME && Math.abs(aspect-other.aspect)>=.025f)return false;
            return other.observation!=null?condition.matches(other.observation):signature.equals(other.signature);
        }
        return (signature.equals(other.signature) || signature.equals(other.legacySignature) || legacySignature.equals(other.signature)) && Math.abs(aspect-other.aspect)<.025f;
    }
    private boolean sameActivity(FlowGuard other) {
        if(activity.equals(other.activity))return true;
        // A structurally equal captured window can survive a missing Activity event, never two differing known Activities.
        return ((signature.startsWith("f2:") && other.signature.startsWith("f2:")) || (condition!=null&&condition.kind==FlowCondition.TARGET))
                && (activity.startsWith("@window:") || other.activity.startsWith("@window:"));
    }
    @Override public boolean equals(Object o) {return o instanceof FlowGuard g && Objects.equals(activity,g.activity)
            && Objects.equals(signature,g.signature) && Float.compare(aspect,g.aspect)==0;}
    @Override public int hashCode() {return Objects.hash(activity,signature,aspect);}
}
