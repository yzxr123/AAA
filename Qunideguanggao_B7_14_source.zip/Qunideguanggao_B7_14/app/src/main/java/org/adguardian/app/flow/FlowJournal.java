package org.adguardian.app.flow;

import java.util.*;
import org.adguardian.app.engine.*;

/** Worker-confined teaching state. An observation never writes a rule; finish() needs explicit UI confirmation. */
public final class FlowJournal {
    public static final int MAX_STEPS=8;
    private final AdType type;
    private final ArrayList<FlowStep> steps=new ArrayList<>();
    private FlowStep pending;
    private FlowPage before,latest;
    private FlowGuard stable;
    private long firstStable;
    private String pkg="";
    private long version=-1;
    private float sessionAspect;
    private int sessionRotation=-1;
    private boolean cancelled;
    public FlowJournal(AdType type){this.type=type;}
    public int stepCount(){return steps.size();}
    public java.util.List<FlowStep> capturedSteps(){
        java.util.ArrayList<FlowStep> copy=new java.util.ArrayList<>(steps);
        if(pending!=null)copy.add(pending);
        return java.util.Collections.unmodifiableList(copy);
    }
    public String targetPackage(){return pkg;}
    public long targetVersion(){return version;}
    public boolean pending(){return pending!=null;}
    public boolean cancelled(){return cancelled;}
    public FlowStep pendingStep(){return pending;}
    public boolean beginClick(FlowPage page,NodeTarget target) {
        if(page==null || page.find(target)==null || !FlowSafety.safeTarget(target))return false;
        return begin(page,new FlowStep(page.targetGuard(target),target,false,30000));
    }
    public boolean beginBack(FlowPage page) {
        if(steps.isEmpty() || page==null || page.guard.activity.startsWith("@window:"))return false;
        // A timetable home page is an exit path, not an advertisement return step.
        if(page.pkg.equals("cn.luyiyuntech.stt") && page.guard.activity.equals("com.common.tang.activity.MainActivity"))return false;
        return begin(page,new FlowStep(page.stageGuard(),null,true,30000));
    }
    private boolean begin(FlowPage page,FlowStep step) {
        if(cancelled || pending!=null || steps.size()>=MAX_STEPS || !step.valid())return false;
        if(pkg.isEmpty()){pkg=page.pkg;version=page.version;sessionAspect=page.guard.aspect;sessionRotation=page.displayRotation();}
        if(!pkg.equals(page.pkg) || version!=page.version || (latest!=null && !latest.sameScope(page)))return false;
        before=page;latest=page;pending=step;stable=null;firstStable=0;return true;
    }
    /** A distinct explicit click on the observed next page supplies a second piece of transition evidence. */
    public boolean advanceBeforeClick(FlowPage page,NodeTarget target,long eventTime) {
        if(cancelled || pending==null || pending.back || before==null || !before.sameScope(page)
                || page.find(target)==null || !FlowTransition.changed(before,page,pending)
                || (stable==null || !stable.matches(page.guard)) || eventTime<firstStable)return false;
        steps.add(pending);pending=null;before=null;stable=null;firstStable=0;return true;
    }
    public void discardPending(){pending=null;before=null;stable=null;firstStable=0;}
    public void cancel(){cancelled=true;pending=null;latest=null;stable=null;}
    public void observe(FlowPage page,long now) {
        if(cancelled)return;
        if(page==null){stable=null;return;}
        if(!pkg.isEmpty() && (!pkg.equals(page.pkg) || version!=page.version || !org.adguardian.app.runtime.DisplayRotation.compatible(sessionRotation,page.displayRotation(),sessionAspect,page.guard.aspect))){cancel();return;}
        latest=page;
        if(pending==null)return;
        boolean changed=FlowTransition.changed(before,page,pending);
        if(!changed){stable=null;return;}
        if(stable==null || !stable.matches(page.guard)){stable=page.stageGuard();firstStable=now;return;}
        if(now-firstStable<120)return;
        steps.add(pending);pending=null;before=null;stable=null;
    }
    public static FlowJournal restore(org.adguardian.app.recording.RecordingDraft draft) {
        if(draft==null || draft.state!=org.adguardian.app.recording.RecordingDraft.CAPTURED
                || draft.steps.isEmpty() || draft.confirmed!=draft.steps.size())
            throw new IllegalStateException("只有全部步骤已确认且没有漏步的草稿可以继续校验");
        FlowJournal journal=new FlowJournal(draft.type);
        journal.pkg=draft.packageName;journal.version=draft.version;
        journal.sessionAspect=draft.steps.get(0).guard.aspect;
        for(FlowStep step:draft.steps) {
            if(!step.valid())throw new IllegalStateException("草稿中的步骤不完整");
            journal.steps.add(step);
        }
        return journal;
    }
    public String finishProblem() {
        if(cancelled)return "应用或屏幕方向已经变化 请回到原应用后继续校验";
        if(pending!=null)return "第 "+(steps.size()+1)+" 步尚未确认关闭 不能跳过这一层";
        if(steps.isEmpty())return "没有已确认的关闭步骤";
        if(latest==null)return "没有读到结束页面 请留在广告关闭后的页面";
        FlowStep last=steps.get(steps.size()-1);
        if(FlowTransition.targetPresent(last,latest))
            return "最后一步的原广告目标仍在 需要先关闭广告";
        if(latest.isKnownAdPage())return "当前仍是已知广告页面 请关闭剩余广告后校验";
        if(pkg.equals("cn.luyiyuntech.stt")) {
            if(latest.knownClassAd)return "当前仍识别为课表广告页 请关闭剩余广告后校验";
            if(!latest.isCertifiedClassHome())
                return "尚未确认回到课表首页 请打开课表主页后校验";
        }
        return "";
    }
    public LearnedFlow finish(String key,String appName) {
        String problem=finishProblem();if(!problem.isEmpty())throw new IllegalStateException(problem);
        return new LearnedFlow(key,pkg,appName,version,type,true,steps,latest.terminalGuard());
    }
}
