package org.adguardian.app.flow;

import org.adguardian.app.engine.NodeTarget;
import org.adguardian.app.learning.LearnedRule;

/** User-requested details from existing sanitized records, never a fresh screen/body capture. */
public final class LearningDetails {
    private LearningDetails() { }
    private static String page(String activity){return activity.startsWith("@window:")?"按窗口结构确认":activity;}
    private static void target(StringBuilder out,NodeTarget t) {
        if(!t.label.isEmpty())out.append("按钮文字 ").append(t.label).append('\n');
        if(!t.id.isEmpty())out.append("控件标识 ").append(t.id).append('\n');
        out.append("控件类型 ").append(t.name).append('\n');
        out.append("相对位置 横向 ").append(Math.round(t.x*100)).append("% 纵向 ").append(Math.round(t.y*100)).append("%\n");
        out.append("每次重新查找唯一控件 不直接重放这个位置\n");
    }
    public static String describe(LearnedFlow flow) {
        StringBuilder out=new StringBuilder(flow.appName).append("\n应用 ").append(flow.packageName)
                .append("\n适配版本码 ").append(flow.versionCode).append("\n已记录 ").append(flow.steps.size()).append(" 步\n");
        for(int i=0;i<flow.steps.size();i++) {
            FlowStep step=flow.steps.get(i);
            out.append("\n第 ").append(i+1).append(" 步 ").append(step.back?"返回":"点击关闭控件").append('\n')
                    .append("页面 ").append(page(step.guard.activity)).append('\n');
            if(!step.back)target(out,step.target);
            out.append(step.guard.signature.startsWith("v3:")?"定位条件 目标与附近控件 不要求正文完全相同\n":"定位条件 旧版精确页面 可通过重录该步骤升级\n");
        }
        return out.append("\n结束条件\n").append(page(flow.terminal.activity)).append("\n结束页条件必须满足并连续确认两次 不以正文刷新当作关闭成功\n不保存广告正文 课表内容 截图或输入文字").toString();
    }
    public static String describe(org.adguardian.app.recording.RecordingDraft record) {
        StringBuilder out=new StringBuilder(record.appName).append("\n应用 ").append(record.packageName)
            .append("\n适配版本码 ").append(record.version).append("\n捕获 ").append(record.steps.size())
            .append(" 步  已确认 ").append(record.confirmed).append(" 步\n").append(record.stateText()).append('\n');
        for(int i=0;i<record.steps.size();i++){
            FlowStep s=record.steps.get(i);out.append("\n第 ").append(i+1).append(" 步 ").append(s.back?"返回":"点击关闭控件")
                .append(i<record.confirmed?"  阶段已确认\n":"  等待阶段确认\n").append("页面 ").append(page(s.guard.activity)).append('\n');
            if(!s.back)target(out,s.target);
        }
        if(!record.issues.isEmpty()){
            out.append("\n待审查操作与处理记录\n");for(var issue:record.issues)out.append(issue.describe()).append('\n');
            out.append("仅在确认是无关操作后才标注忽略 真正缺少的广告关闭必须补录\n");
        }
        if(record.state==org.adguardian.app.recording.RecordingDraft.CAPTURED && record.confirmed==record.steps.size())
            out.append("\n步骤已确认 但还没有生成可执行流程\n返回上一页选择 继续校验并启用 可使用这份记录核对结束页面 不用重复录制");
        return out.append("\n未完成或漏步草稿不会直接用于自动点击\n已完成教学的当前开关请到已学习规则或流程中查看\n不包含广告正文 课表内容 输入文字或截图").toString();
    }
    public static String describe(LearnedRule rule) {
        StringBuilder out=new StringBuilder(rule.appName).append("\n应用 ").append(rule.packageName)
                .append("\n适配版本码 ").append(rule.versionCode).append("\n页面 ").append(page(rule.activityName)).append('\n');
        target(out,rule.target);
        return out.append("页面结构条件 ").append(rule.pageGuard.isEmpty()?"旧规则使用现场广告证据":"已保存")
                .append("\n点击后仍需确认原目标消失").toString();
    }
}
