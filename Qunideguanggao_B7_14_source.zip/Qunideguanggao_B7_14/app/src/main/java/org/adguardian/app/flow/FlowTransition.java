package org.adguardian.app.flow;

/** A page hash change is only a reason to observe again, never evidence that an ad was dismissed. */
final class FlowTransition {
    private FlowTransition() { }
    static boolean changed(FlowPage before,FlowPage after,FlowStep step) {
        if(before==null||after==null||!before.sameScope(after))return false;
        if(step.back) {
            if(!before.guard.activity.equals(after.guard.activity)
                    &&!before.guard.activity.startsWith("@window:")&&!after.guard.activity.startsWith("@window:"))return true;
            FlowObservation a=before.guard.observation,b=after.guard.observation;
            return a!=null&&b!=null&&(!a.stage.equals(b.stage)||(!a.rootId.isEmpty()&&!b.rootId.isEmpty()&&!a.rootId.equals(b.rootId)));
        }
        if(after.sameLayoutAfterResize(before,step.target))return false;
        FlowCondition condition=step.guard.condition;
        if(condition==null)condition=FlowCondition.target(before,step.target).condition;
        if(condition!=null&&condition.kind==FlowCondition.TARGET)return !condition.present(after.guard.observation);
        return !after.has(step.target);
    }
    static boolean targetPresent(FlowStep step,FlowPage page) {
        if(step.back)return step.guard.matches(page.guard);
        return step.guard.condition!=null&&step.guard.condition.kind==FlowCondition.TARGET
                ?step.guard.condition.present(page.guard.observation):page.has(step.target);
    }
}
