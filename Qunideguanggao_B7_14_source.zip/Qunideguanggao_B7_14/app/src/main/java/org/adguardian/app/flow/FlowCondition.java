package org.adguardian.app.flow;

import java.io.*;
import java.util.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.classapp.ClassAdProfile;

/** Versioned conditions. TARGET locates a control; END observes a host page. Neither proves an action succeeded. */
final class FlowCondition {
    static final int TARGET=1, END=2, CLASS_HOME=3, STAGE=4;
    static final int MAX_ENCODED=8192;
    final int kind;
    final String rootName,lineage,stage;
    final List<String> required;
    final NodeTarget target;
    FlowCondition(int kind,String rootName,String lineage,String stage,List<String> required,NodeTarget target) {
        this.kind=kind;this.rootName=rootName;this.lineage=lineage;this.stage=stage;
        this.required=Collections.unmodifiableList(new ArrayList<>(required));this.target=target;
    }
    static FlowGuard target(FlowPage page,NodeTarget selected) {
        FlowObservation o=page.guard.observation;
        FlowObservation.Item item=o==null?null:o.item(selected);
        if(item==null)return page.guard;
        // Weak anonymous non-ad pages keep the historical exact guard, not a silently broadened hash.
        if(selected.id.isEmpty()&&selected.label.isEmpty()&&!o.ad)return page.guard;
        FlowCondition c=new FlowCondition(TARGET,o.rootName,item.lineage,o.stage,List.of(),selected);
        return guard(page,c);
    }
    static FlowGuard terminal(FlowPage page) {
        FlowObservation o=page.guard.observation;
        if(o==null)return page.guard;
        if(o.classHome)return guard(page,new FlowCondition(CLASS_HOME,o.rootName,"","CLASS_HOME",ClassAdProfile.MAIN_HEADER_IDS,null));
        if(o.terminalAnchors.isEmpty()||page.guard.activity.startsWith("@window:"))return page.guard;
        return guard(page,new FlowCondition(END,o.rootName,"",o.stage,o.terminalAnchors,null));
    }
    static FlowGuard stage(FlowPage page) {
        FlowObservation o=page.guard.observation;
        if(o==null||o.terminalAnchors.isEmpty())return page.guard;
        return guard(page,new FlowCondition(STAGE,o.rootName,"",o.stage,o.terminalAnchors,null));
    }
    private static FlowGuard guard(FlowPage page,FlowCondition condition) {
        return new FlowGuard(page.guard.activity,condition.encode(),page.guard.aspect);
    }
    boolean matches(FlowObservation o) {
        if(o==null||!rootName.equals(o.rootName))return false;
        if(kind==TARGET){
            if(!stage.equals(o.stage))return false;
            int matches=0;
            for(FlowObservation.Item item:o.enabled)if(lineage.equals(item.lineage)&&FlowObservation.sameDescriptor(target,item.target,true))matches++;
            return matches==1;
        }
        if(kind==CLASS_HOME)return o.classHome&&ClassAdProfile.PACKAGE.equals(o.pkg)&&o.version==ClassAdProfile.VERSION&&!o.ad;
        if(kind==END && o.ad)return false;
        return stage.equals(o.stage)&&o.anchors.containsAll(required);
    }
    boolean present(FlowObservation o) {
        if(kind!=TARGET||o==null)return false;
        for(FlowObservation.Item item:o.visible)
            if(lineage.equals(item.lineage)&&FlowObservation.sameDescriptor(target,item.target,false))return true;
        return false;
    }
    boolean accepts(NodeTarget value,String actualLineage) {
        return kind==TARGET&&lineage.equals(actualLineage)&&FlowObservation.sameDescriptor(target,value,true);
    }
    boolean valid() {
        if(kind<TARGET||kind>STAGE||rootName==null||rootName.isEmpty()||rootName.length()>512
                ||lineage==null||lineage.length()>2300||stage==null||stage.length()>512||required.size()>8)return false;
        Set<String> seen=new HashSet<>();
        for(String s:required)if(s==null||s.isEmpty()||s.length()>512||!seen.add(s))return false;
        if(kind==TARGET)return target!=null&&FlowSafety.safeTarget(target)&&!lineage.isEmpty()
                && target.id.length()<=512&&target.name.length()<=512&&target.label.length()<=80
                &&(target.label.isEmpty()||AdCloseText.isClose(target.label))&&required.isEmpty();
        if(target!=null||!lineage.isEmpty()||required.isEmpty())return false;
        return kind!=CLASS_HOME||required.equals(ClassAdProfile.MAIN_HEADER_IDS);
    }
    String encode() {
        if(!valid())throw new IllegalArgumentException("invalid typed flow condition");
        try {
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
            out.writeByte(kind);out.writeUTF(rootName);out.writeUTF(lineage);out.writeUTF(stage);out.writeByte(required.size());
            for(String s:required)out.writeUTF(s);
            if(kind==TARGET){out.writeUTF(target.id);out.writeUTF(target.name);out.writeUTF(target.label);
                out.writeFloat(target.x);out.writeFloat(target.y);out.writeFloat(target.width);out.writeFloat(target.height);}
            out.flush();String result="v3:"+Base64.getUrlEncoder().withoutPadding().encodeToString(bytes.toByteArray());
            if(result.length()>MAX_ENCODED)throw new IllegalArgumentException("flow condition too large");return result;
        }catch(IOException impossible){throw new IllegalStateException(impossible);}
    }
    static FlowCondition decode(String encoded) {
        if(encoded==null||!encoded.startsWith("v3:")||encoded.length()>MAX_ENCODED)return null;
        try(DataInputStream in=new DataInputStream(new ByteArrayInputStream(Base64.getUrlDecoder().decode(encoded.substring(3))))) {
            int kind=in.readUnsignedByte();String root=field(in,512),lineage=field(in,2300),stage=field(in,512);
            int count=in.readUnsignedByte();if(count>8)return null;ArrayList<String> anchors=new ArrayList<>();
            for(int i=0;i<count;i++)anchors.add(field(in,512));
            NodeTarget target=kind==TARGET?new NodeTarget(field(in,512),field(in,512),field(in,80),in.readFloat(),in.readFloat(),in.readFloat(),in.readFloat()):null;
            FlowCondition c=new FlowCondition(kind,root,lineage,stage,anchors,target);return in.read()==-1&&c.valid()?c:null;
        }catch(IOException|RuntimeException invalid){return null;}
    }
    private static String field(DataInputStream in,int max)throws IOException {
        String s=in.readUTF();if(s.length()>max)throw new IOException("field limit");return s;
    }
}
