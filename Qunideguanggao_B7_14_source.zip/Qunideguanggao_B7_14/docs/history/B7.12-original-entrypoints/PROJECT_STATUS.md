# 去你的广告 B7.12 项目状态

基线 B7.11 完整源码
versionCode 32
versionName 0.7.12-b7.12

已修复可复现的CLASS上下文禁用条件 终点自绘控件依赖 录制Back写入顺序 草稿状态写入误报
已修复全局权限关闭被组件条目掩盖 覆盖层交接被重复同步无限延期
SDK识别增加只读DEX类定义检测 支持标准035至040 041明确标记未完整检查
实际上传CLASS APK由新检测器读取3份DEX 20911个类定义 检测到pangle
实际SDK报告不代表当前广告在运行 不代表已禁用SDK
新SDK当前页面辅助模块接入RuleEngine 默认开启独立开关 支持唯一有文字关闭目标 不猜匿名图标
所有原学习记录格式保留 不改成默认启用草稿
CLASS原四组动作不变 有意新增已确认MainActivity的终点替代条件
本轮新增QUERY_ALL_PACKAGES仅用于用户手动离线盘点 No INTERNET permission

最终完整主机测试以 VERIFICATION.txt 为准
没有APK编译或手机实测 未证明用户真实后台终止与每种广告模板已解决
