#!/usr/bin/env python3
"""Validate the local CLASS rule asset consumed by ClassAdRules at runtime."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
ASSET = 'app/src/main/assets/class/cn.luyiyuntech.stt_1013.json'
PACKAGE = 'cn.luyiyuntech.stt'
PREFIX = 'com.bytedance.sdk.openadsdk.core.component.reward.activity.'
EXPECTED = {
    'class_native_promotion': ('POPUP', [], ['close', 'tv_confirm', 'btn_pay_now'], 'close', False),
    'class_native_interaction': ('POPUP', [], ['fhad_rl_content', 'fhad_iv_delete'], 'fhad_iv_delete', False),
    'class_splash': ('STARTUP', ['com.common.tang.activity.SplashActivity'], ['fl_ad_container', 'fl_place_holder_container'], 'tv_skip', True),
    'class_sdk_fullscreen': ('POPUP', [PREFIX+'TTFullScreenVideoActivity', PREFIX+'TTFullScreenVideoLandscapeActivity'], [], '', True),
}
HOME = ['navigation_bar', 'tv_today_date', 'tv_weeks', 'timetableView']


def validate(data: dict) -> None:
    if data.get('schema') != 2 or data.get('package') != PACKAGE or data.get('versionCode') != 1013:
        raise ValueError('CLASS package/version/schema differ from the uploaded APK')
    if data.get('apkSha256') != '9a64abc67f1ca5cfa55c644140af47caa5d8995da996c49e0a786a0bd8765638':
        raise ValueError('CLASS evidence APK hash mismatch')
    rules = data.get('rules')
    if not isinstance(rules, list) or not len(EXPECTED) <= len(rules) <= 32:
        raise ValueError('Incomplete CLASS rules')
    seen = set()
    for rule in rules:
        key = rule.get('key')
        if not isinstance(key,str) or not key.startswith('class_') or key in seen:
            raise ValueError('Unknown or duplicate CLASS rule')
        seen.add(key)
        values = tuple(rule.get(k) for k in ('category', 'activities', 'allIds', 'targetId', 'matchCloseText'))
        expected = EXPECTED.get(key)
        if expected is None:
            for template in EXPECTED.values():
                if values == template: expected = template; break
        if expected is None or values != expected or type(rule.get('matchCloseText')) is not bool:
            raise ValueError('CLASS rule lost its APK-derived match/action guard: '+key)
        if not isinstance(rule.get('name'), str) or not rule['name'] or not rule.get('evidence'):
            raise ValueError('CLASS human name or evidence absent')
        stages={'SPLASH','SDK_FULLSCREEN','NATIVE_PROMOTION','NATIVE_INTERACTION','HOST_HOME'}
        family={'close':'NATIVE_PROMOTION','fhad_iv_delete':'NATIVE_INTERACTION','tv_skip':'SPLASH','':'SDK_FULLSCREEN'}
        if rule.get('stage') != family[rule['targetId']]: raise ValueError('Wrong action stage')
        for field in ('requiredIds','excludedIds','nextStages'):
            value=rule.get(field)
            if not isinstance(value,list) or len(value)>16 or len(set(value))!=len(value) or not all(isinstance(s,str) and s for s in value): raise ValueError('Invalid '+field)
        if not rule['nextStages'] or not set(rule['nextStages']).issubset(stages): raise ValueError('Unknown next stage')
        import re
        if not all(re.fullmatch('[a-zA-Z][a-zA-Z0-9_]*',s) and len(s)<=120 for s in rule['requiredIds']+rule['excludedIds']): raise ValueError('Invalid extra anchor')
        if type(rule.get('maxActions')) is not int or not 1<=rule['maxActions']<=8 or type(rule.get('timeoutMs')) is not int or not 1000<=rule['timeoutMs']<=60000: raise ValueError('Unbounded rule')
    if not set(EXPECTED).issubset(seen): raise ValueError('Missing base action family')
    terminal = data.get('terminal', {})
    if terminal.get('stage')!='HOST_HOME' or terminal.get('headerAllIds')!=HOME[:3]: raise ValueError('Invalid home stage')
    if terminal.get('confirmedMainAllIds') != HOME[:3]:
        raise ValueError('CLASS known Main alternative lost exact course header anchors')
    if terminal.get('activity') != 'com.common.tang.activity.MainActivity' or terminal.get('allIds') != HOME:
        raise ValueError('CLASS terminal must use the actual home and course layout guards')


def main() -> None:
    data = json.loads((ROOT/ASSET).read_text(encoding='utf-8'))
    validate(data)
    print('CLASS local runtime asset verified: package cn.luyiyuntech.stt version 1013 / bounded phase groups / guarded timetable terminal')

if __name__ == '__main__':
    main()
