# 去你的广告 B7.4

先阅读根目录 AGENTS.md PROJECT_STATUS.md README.md
架构见 references/ARCHITECTURE.md
规则见 references/RULES.md
构建见 references/BUILD.md

保持 Android 单 APK 本地识别 默认全开且独立开关
李跳跳原始文件不改写
GKD 必须使用真实 Selector 运行应用广告订阅
只有广告组参与 不能增加非广告自动点击
不得将桥接实现叫做完整 GKD 原版服务

OCR 为最后一层 必须保持关闭后停止新增工作
GPU 缩小后才读回软件像素 不创建全分辨率 ARGB 副本
原生调用安全结束后释放 不能声称瞬时强杀
所有扫描和规则加载在工作线程
用户交互和日志只显示必要用户语言

通过真实行为回归后再交付
没有 SDK 或设备结果必须如实标注
每次完整 ZIP 加独立工作流文件
