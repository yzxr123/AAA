# B7.4 核对记录

用户给定 gkd-main 的纯 Selector 源码及 A11yContext ResolvedRule AppRule GlobalRule GkdAction 等参考文件
原始 selector 38 文件保存在 third_party
不把外层加固壳当作李跳跳 SDK

Android Bitmap 硬件图像不能直接交给普通软件 Canvas
AOSP Bitmap.createBitmap 对硬件源存在软件复制路径 因此只 createScaledBitmap 不足以证明降低全屏副本峰值
本版选择 HardwareRenderer RenderNode ImageReader 小尺寸 GPU 输出后再 copy RGB565
公开 API 存在与宿主签名编译不构成实际 GPU 成功证据

代码设计中的时间上限与图像像素上限是参数
不是实测 CPU RAM 开屏延迟或99%广告覆盖率
SDK构建与手机回归必须分别记录
