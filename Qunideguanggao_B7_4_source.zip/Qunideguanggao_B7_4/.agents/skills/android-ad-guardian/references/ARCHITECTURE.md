# B7.4 架构

AdAccessibilityService 主线程收集最新窗口状态 合并事件
独立 HandlerThread 初始化 RuleEngine 并加载规则
同一线程拥有 LTT 状态 GKD RuleSession 节点索引以及动作完成回调

LiTiaotiaoRuleEngine 优先
GkdSubscriptionEngine 使用 GkdRuleRepository 前台应用分片 加 gkd-core 真实 Selector
GkdAssistEngine 只是沿用旧版结构辅助 不是官方 GKD 引擎
OCR 只有规则没有处理或等待动作时才能介入

GkdNodeAdapter 使用每轮 AccessibilityNodeIndex
索引懒读取 原生 ID 和文本 FastQuery 命中后不先扫描整树
原始根节点由调用方回收 索引只回收拥有的子节点
不得把旧索引或旧窗口节点用于下一轮动作查询

OCR takeScreenshot 系统回调后交给 OCR 单工作线程
HardwareRenderer RenderNode ImageReader 建立小尺寸目标
读取缩小图为 RGB565 后逐块 Tesseract
结果回规则线程 验证前台应用 当前根节点和会话令牌
延迟动作 手势回调和截图都必须防止跨会话结果使用

当前保留上一版后台权限入口和系统管理无障碍服务
没有实现强行停止后的自启动绕过
