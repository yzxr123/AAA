# 去你的广告开发约束

当前版本 B7.4

保留安卓单 APK 本地处理 无 INTERNET 权限 名称去你的广告
用户功能默认开启并可独立关闭 OCR 开关必须取消后续截图和任务
不得把 APK 50 MiB 上限说成运行内存上限

优先使用李跳跳原始规则 再使用真实 GKD Selector 和广告订阅 最后才是结构辅助和可选 OCR
李跳跳 assets/ltt 三份文件不得改写或精简
GKD 当前快照仅四类广告组 753 应用 1334 组 2445 规则 2600 选择器
不得丢弃排除条件 阶段依赖 原始启停值 时序或坐标
不得为扩大计数而加入权限 自动签到 更新等非广告自动操作

GKD 源码原件在 third_party/gkd-selector
生成副本在 gkd-core/src/main/kotlin/li/gkd/selector
只能通过 tools/prepare_gkd_selector.py 生成 不手改副本后声称原始源码
本项目 RuleSession 是桥接实现 不是 GKD 完整 App

无障碍规则加载与执行都留在单个工作线程
节点索引按事件存活 关闭后不可继续查询
异步手势必须核对会话代号和前台应用
禁止 typeAllMask 禁止 OCR 永久轮询 禁止主线程持有规则扫描锁
不能使用软件 Canvas 绘制硬件 Bitmap
不能用 createScaledBitmap 替代 GPU 缩图后再声称没有全屏软件副本

每次修改先增加行为回归测试
运行 python3 tools/run_host_tests.py 或其 --gradle 模式
SDK 编译未实际完成时必须明确 未做设备测试不得声称百分比覆盖率或毫秒和 RAM 实测
用户日志不含包名 选择器 View ID 规则编号或堆栈

完整交付包含源码 ZIP 和单独 build-apk-B7.4.yml
当前工作流支持仓库根目录直接上传完整源码 ZIP
清理只能删除确认的旧模块 不得以旧白名单删除新源码
