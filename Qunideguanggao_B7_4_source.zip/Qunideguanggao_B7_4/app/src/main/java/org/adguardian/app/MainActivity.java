package org.adguardian.app;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.PowerManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.adguardian.app.engine.AdType;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.service.AdAccessibilityService;
import org.adguardian.app.settings.PreferenceStore;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class MainActivity extends android.app.Activity {
    private TextView permissionStatus;
    private TextView eventLogView;
    private TextView backgroundStatus;
    private Switch protectionSwitch;
    private Switch liTiaotiaoSwitch;
    private Switch gkdSwitch;
    private Switch ocrSwitch;
    private Switch keepAliveSwitch;
    private final Map<AdType, Switch> typeSwitches = new EnumMap<>(AdType.class);
    private boolean changingSwitches;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildContent());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionStatus();
        refreshEventLog();
        syncSwitches();
        updateBackgroundStatus();
    }

    private ScrollView buildContent() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        root.addView(text("去你的广告", 28, true));
        TextView subtitle = text("规则优先处理广告 需要时再使用 OCR", 15, false);
        subtitle.setTextColor(Color.rgb(85, 85, 85));
        root.addView(subtitle, marginTop(dp(4)));

        permissionStatus = text("", 15, true);
        root.addView(permissionStatus, marginTop(dp(22)));

        Button enableAll = new Button(this);
        enableAll.setText("一键开启全部广告屏蔽");
        enableAll.setAllCaps(false);
        enableAll.setTextSize(17);
        enableAll.setOnClickListener(v -> enableEverything());
        root.addView(enableAll, marginTop(dp(12)));

        Button permission = new Button(this);
        permission.setText("允许辅助功能权限");
        permission.setAllCaps(false);
        permission.setOnClickListener(v -> openAccessibilitySettings());
        root.addView(permission, marginTop(dp(8)));

        backgroundStatus = text("", 13, false);
        backgroundStatus.setTextColor(Color.rgb(95, 95, 95));
        root.addView(backgroundStatus, marginTop(dp(8)));

        Button backgroundPermission = new Button(this);
        backgroundPermission.setText("允许后台持续运行");
        backgroundPermission.setAllCaps(false);
        backgroundPermission.setOnClickListener(v -> requestBackgroundPermission());
        root.addView(backgroundPermission, marginTop(dp(6)));

        root.addView(sectionTitle("运行方式"), marginTop(dp(20)));
        keepAliveSwitch = optionSwitch("后台静默运行", PreferenceStore.isKeepAliveEnabled(this));
        keepAliveSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setKeepAliveEnabled(this, enabled);
            AdAccessibilityService.notifySettingsChanged();
        });
        root.addView(keepAliveSwitch, marginTop(dp(2)));

        TextView keepAliveHint = text("关闭应用界面后继续保持广告屏蔽 默认开启", 13, false);
        keepAliveHint.setTextColor(Color.rgb(95, 95, 95));
        root.addView(keepAliveHint, marginTop(dp(4)));

        root.addView(sectionTitle("总开关"), marginTop(dp(20)));
        protectionSwitch = optionSwitch("广告屏蔽", PreferenceStore.isMasterEnabled(this));
        protectionSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setMasterEnabled(this, enabled);
            AdAccessibilityService.notifySettingsChanged();
        });
        root.addView(protectionSwitch, marginTop(dp(4)));

        root.addView(sectionTitle("识别方式"), marginTop(dp(20)));
        liTiaotiaoSwitch = optionSwitch("李跳跳规则", PreferenceStore.isLiTiaotiaoEnabled(this));
        liTiaotiaoSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setLiTiaotiaoEnabled(this, enabled);
            AdAccessibilityService.notifySettingsChanged();
        });
        root.addView(liTiaotiaoSwitch, marginTop(dp(2)));

        gkdSwitch = optionSwitch("GKD 广告规则", PreferenceStore.isGkdEnabled(this));
        gkdSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setGkdEnabled(this, enabled);
            AdAccessibilityService.notifySettingsChanged();
        });
        root.addView(gkdSwitch, marginTop(dp(2)));

        ocrSwitch = optionSwitch("OCR 视觉识别", PreferenceStore.isOcrEnabled(this));
        ocrSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setOcrEnabled(this, enabled);
            AdAccessibilityService.notifySettingsChanged();
        });
        root.addView(ocrSwitch, marginTop(dp(2)));

        TextView ocrHint = text("OCR 默认开启 仅在规则没有处理成功时工作 关闭后不再发起截图 正在处理的识别结束后释放资源", 13, false);
        ocrHint.setTextColor(Color.rgb(95, 95, 95));
        root.addView(ocrHint, marginTop(dp(4)));

        root.addView(sectionTitle("广告类型"), marginTop(dp(20)));
        for (AdType type : AdType.values()) {
            Switch typeSwitch = optionSwitch(type.displayName(), PreferenceStore.isTypeEnabled(this, type));
            typeSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
                if (changingSwitches) return;
                PreferenceStore.setTypeEnabled(this, type, enabled);
                AdAccessibilityService.notifySettingsChanged();
            });
            typeSwitches.put(type, typeSwitch);
            root.addView(typeSwitch, marginTop(dp(2)));
        }

        TextView privacy = text("所有识别均在本机完成", 13, false);
        privacy.setTextColor(Color.rgb(95, 95, 95));
        root.addView(privacy, marginTop(dp(12)));

        TextView recordTitle = sectionTitle("拦截记录");
        root.addView(recordTitle, marginTop(dp(24)));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(buttons, marginTop(dp(8)));

        Button refresh = smallButton("刷新");
        refresh.setOnClickListener(v -> refreshEventLog());
        buttons.addView(refresh, weightedButtonParams());

        Button copy = smallButton("复制");
        copy.setOnClickListener(v -> copyEventLog());
        buttons.addView(copy, weightedButtonParams());

        Button clear = smallButton("清空");
        clear.setOnClickListener(v -> {
            UserEventLog.clear(this);
            refreshEventLog();
        });
        buttons.addView(clear, weightedButtonParams());

        eventLogView = text("暂无拦截记录", 12, false);
        eventLogView.setTextIsSelectable(true);
        eventLogView.setTextColor(Color.rgb(35, 35, 35));
        eventLogView.setBackgroundColor(Color.rgb(242, 242, 242));
        eventLogView.setPadding(dp(10), dp(10), dp(10), dp(10));
        eventLogView.setMinHeight(dp(130));
        root.addView(eventLogView, marginTop(dp(8)));
        return scroll;
    }

    private void enableEverything() {
        PreferenceStore.enableAllAds(this);
        syncSwitches();
        AdAccessibilityService.notifySettingsChanged();
        if (!isServiceEnabled()) {
            Toast.makeText(this, "请允许辅助功能权限", Toast.LENGTH_SHORT).show();
            openAccessibilitySettings();
        } else {
            Toast.makeText(this, "全部广告屏蔽已开启", Toast.LENGTH_SHORT).show();
        }
    }

    private void syncSwitches() {
        changingSwitches = true;
        if (protectionSwitch != null) protectionSwitch.setChecked(PreferenceStore.isMasterEnabled(this));
        if (liTiaotiaoSwitch != null) liTiaotiaoSwitch.setChecked(PreferenceStore.isLiTiaotiaoEnabled(this));
        if (gkdSwitch != null) gkdSwitch.setChecked(PreferenceStore.isGkdEnabled(this));
        if (ocrSwitch != null) ocrSwitch.setChecked(PreferenceStore.isOcrEnabled(this));
        if (keepAliveSwitch != null) keepAliveSwitch.setChecked(PreferenceStore.isKeepAliveEnabled(this));
        for (Map.Entry<AdType, Switch> entry : typeSwitches.entrySet()) {
            entry.getValue().setChecked(PreferenceStore.isTypeEnabled(this, entry.getKey()));
        }
        changingSwitches = false;
    }

    private void openAccessibilitySettings() {
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    private void requestBackgroundPermission() {
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager != null && powerManager.isIgnoringBatteryOptimizations(getPackageName())) {
            Toast.makeText(this, "后台持续运行 已允许", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private void updateBackgroundStatus() {
        if (backgroundStatus == null) return;
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean allowed = powerManager != null && powerManager.isIgnoringBatteryOptimizations(getPackageName());
        backgroundStatus.setText(allowed ? "后台运行权限 已允许" : "后台运行权限 建议允许");
        backgroundStatus.setTextColor(allowed ? Color.rgb(20, 120, 60) : Color.rgb(160, 90, 30));
    }

    private void updatePermissionStatus() {
        if (permissionStatus == null) return;
        if (isServiceEnabled()) {
            permissionStatus.setText("辅助功能权限 已允许");
            permissionStatus.setTextColor(Color.rgb(20, 120, 60));
        } else {
            permissionStatus.setText("辅助功能权限 未允许");
            permissionStatus.setTextColor(Color.rgb(160, 50, 50));
        }
    }

    private boolean isServiceEnabled() {
        AccessibilityManager manager = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        List<AccessibilityServiceInfo> enabled = manager.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        );
        for (AccessibilityServiceInfo info : enabled) {
            if (info.getResolveInfo() == null || info.getResolveInfo().serviceInfo == null) continue;
            String packageName = info.getResolveInfo().serviceInfo.packageName;
            String serviceName = info.getResolveInfo().serviceInfo.name;
            if (getPackageName().equals(packageName)
                    && AdAccessibilityService.class.getName().equals(serviceName)) return true;
        }
        return false;
    }

    private void refreshEventLog() {
        if (eventLogView != null) eventLogView.setText(UserEventLog.read(this));
    }

    private void copyEventLog() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null) {
            Toast.makeText(this, "无法复制", Toast.LENGTH_SHORT).show();
            return;
        }
        clipboard.setPrimaryClip(ClipData.newPlainText("去你的广告", UserEventLog.read(this)));
        Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show();
    }

    private Switch optionSwitch(String value, boolean checked) {
        Switch view = new Switch(this);
        view.setText(value);
        view.setTextSize(16);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setChecked(checked);
        view.setPadding(0, dp(7), 0, dp(7));
        return view;
    }

    private TextView sectionTitle(String value) {
        return text(value, 16, true);
    }

    private Button smallButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextSize(13);
        button.setMinWidth(0);
        return button;
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1.0f
        );
        params.leftMargin = dp(2);
        params.rightMargin = dp(2);
        return params;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(Color.rgb(20, 20, 20));
        if (bold) view.setTypeface(view.getTypeface(), Typeface.BOLD);
        return view;
    }

    private LinearLayout.LayoutParams marginTop(int top) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.topMargin = top;
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
