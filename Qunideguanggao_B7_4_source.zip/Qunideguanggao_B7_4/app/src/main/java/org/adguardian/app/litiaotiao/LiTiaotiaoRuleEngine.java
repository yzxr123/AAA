package org.adguardian.app.litiaotiao;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import java.util.function.Supplier;
import java.util.function.BooleanSupplier;
import org.adguardian.app.settings.PreferenceStore;
import org.adguardian.app.engine.AdType;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;

import org.adguardian.app.engine.AccessibilityNodeIndex;
import org.adguardian.app.log.UserEventLog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LiTiaotiaoRuleEngine {
    private static final List<String> DEFAULT_KEYWORDS = Arrays.asList(
            "count_down", "countdown", "跳过", "skip", "跳過"
    );
    private static final Pattern COORDINATE = Pattern.compile("x\\s*:\\s*(\\d+)\\s*y\\s*:\\s*(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern BOUNDS_ACTION = Pattern.compile("\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)(?:\\s*,\\s*[01])?\\s*");
    private static final long SAME_ACTION_GUARD_MS = 360L;
    private static final long SEARCH_INTERVAL_MS = 220L;

    private final AccessibilityService service;
    private final LiTiaotiaoRuleRepository repository;
    private final Handler handler;
    private final Supplier<String> foreground;
    private BooleanSupplier externalActionPending = () -> false;
    private volatile boolean pendingAction;
    private final Map<String, Integer> successCounts = new HashMap<>();
    private final Map<String, Long> lastAttempts = new HashMap<>();
    private final Set<String> delayedPending = new HashSet<>();

    private String packageName = "";
    private long generation;
    private boolean startupDone;
    private boolean searchBurstPending;
    private volatile long lastAutomatedActionUptime;

    public LiTiaotiaoRuleEngine(AccessibilityService service, Handler worker, Supplier<String> foreground) {
        this.service = service;
        this.handler = new Handler(worker.getLooper());
        this.foreground = foreground;
        this.repository = new LiTiaotiaoRuleRepository(service.getApplicationContext());
    }

    public void setExternalActionPending(BooleanSupplier predicate) { externalActionPending=predicate; }

    public boolean hasPendingAction() { return pendingAction; }

    public void cancelPending() {
        generation++;
        handler.removeCallbacksAndMessages(null);
        delayedPending.clear();
        pendingAction=false;
        searchBurstPending=false;
    }

    private boolean mayAct(String currentPackage) {
        return PreferenceStore.isMasterEnabled(service)
                && PreferenceStore.isLiTiaotiaoEnabled(service)
                && currentPackage.equals(foreground.get()) && !externalActionPending.getAsBoolean();
    }

    public int packageCount() {
        return repository.packageCount();
    }

    public int ruleCount() {
        return repository.ruleCount();
    }

    public long lastAutomatedActionUptime() {
        return lastAutomatedActionUptime;
    }

    public void onPackageEntered(String currentPackage) {
        String next = currentPackage == null ? "" : currentPackage;
        if (next.equals(packageName)) return;
        cancelPending();
        packageName = next;
        startupDone = false;
        searchBurstPending = false;
        successCounts.clear();
        lastAttempts.clear();
        delayedPending.clear();
    }

    public boolean handle(String currentPackage, AccessibilityNodeInfo root, AccessibilityNodeIndex index) {
        if (currentPackage == null || currentPackage.isEmpty() || root == null || index == null || !mayAct(currentPackage)) return false;
        if (!currentPackage.equals(packageName)) onPackageEntered(currentPackage);
        LiTiaotiaoRuleBundle bundle = repository.forPackage(currentPackage);
        if (bundle != null && !bundle.lttService) return false;
        boolean handled = handleInternal(currentPackage, root, index, bundle, true);
        return handled;
    }

    private boolean handleInternal(
            String currentPackage,
            AccessibilityNodeInfo root,
            AccessibilityNodeIndex index,
            LiTiaotiaoRuleBundle bundle,
            boolean allowSearchBurst
    ) {
        if (PreferenceStore.isTypeEnabled(service,AdType.STARTUP) && !startupDone && handleStartupKeywords(currentPackage, index, bundle)) {
            return true;
        }
        boolean popupEnabled=PreferenceStore.isTypeEnabled(service,AdType.POPUP);
        boolean popupHandled = popupEnabled && handlePopupRules(currentPackage, index, bundle);
        if (popupHandled) return true;
        if (popupEnabled && allowSearchBurst && bundle != null && bundle.searchTimesPopup > 1 && !bundle.popupRules.isEmpty()) {
            scheduleSearchBurst(currentPackage, bundle.searchTimesPopup - 1);
        }
        return false;
    }

    private boolean handleStartupKeywords(
            String currentPackage,
            AccessibilityNodeIndex index,
            LiTiaotiaoRuleBundle bundle
    ) {
        List<String> keywords = new ArrayList<>();
        int clickWay = 0;
        int delay = 0;
        if (bundle != null) {
            clickWay = bundle.clickWay;
            delay = bundle.delayMs;
            if (bundle.keywordsSpecified) {
                keywords.addAll(bundle.keywords);
            } else {
                keywords.addAll(DEFAULT_KEYWORDS);
                keywords.addAll(bundle.keywordsAppend);
            }
        } else {
            keywords.addAll(DEFAULT_KEYWORDS);
        }
        if (keywords.isEmpty()) return false;
        AccessibilityNodeInfo target = index.findKeyword(keywords);
        if (target == null) return false;
        if (delay > 0) {
            scheduleStartupDelay(currentPackage, keywords, clickWay, delay);
            return false;
        }
        if (performNodeClick(target, clickWay == 1, index.rootBounds())) {
            startupDone = true;
            markAction();
            UserEventLog.record(service, "广告已自动跳过");
            return true;
        }
        return false;
    }

    private boolean handlePopupRules(
            String currentPackage,
            AccessibilityNodeIndex index,
            LiTiaotiaoRuleBundle bundle
    ) {
        if (bundle == null || bundle.popupRules.isEmpty()) return false;
        long now = SystemClock.uptimeMillis();
        boolean sawUniteState = false;
        for (int i = 0; i < bundle.popupRules.size(); i++) {
            LiTiaotiaoRule rule = bundle.popupRules.get(i);
            int limit = rule.times == null ? bundle.times : Math.max(0, rule.times);
            String key = currentPackage + '|' + i;
            if (limit > 0 && successCounts.getOrDefault(key, 0) >= limit) continue;
            AccessibilityNodeInfo evidence = index.findPrimaryNode(rule.id);
            if (evidence == null) continue;
            if (limit == 0) {
                sawUniteState = true;
                continue;
            }
            Long last = lastAttempts.get(key);
            if (last != null && now - last < SAME_ACTION_GUARD_MS) continue;
            lastAttempts.put(key, now);
            int delay = rule.delayPopupMs == null ? bundle.delayPopupMs : Math.max(0, rule.delayPopupMs);
            if (delay > 0) {
                schedulePopupDelay(currentPackage, key, rule, bundle.clickWayPopup == 1, delay);
                if (!bundle.unitePopupRules) return false;
                continue;
            }
            if (performPopupAction(rule, bundle.clickWayPopup == 1, index)) {
                successCounts.put(key, successCounts.getOrDefault(key, 0) + 1);
                markAction();
                UserEventLog.record(service, "弹窗已自动处理");
                if (!bundle.unitePopupRules) return true;
                sawUniteState = true;
            }
        }
        return sawUniteState && bundle.unitePopupRules && lastAutomatedActionUptime + 120L >= SystemClock.uptimeMillis();
    }

    private boolean performPopupAction(
            LiTiaotiaoRule rule,
            boolean forceGesture,
            AccessibilityNodeIndex index
    ) {
        if ("GLOBAL_ACTION_BACK".equals(rule.action)) {
            return service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
        }
        Matcher coordinates = COORDINATE.matcher(rule.action);
        if (coordinates.find()) {
            float x = Float.parseFloat(coordinates.group(1));
            float y = Float.parseFloat(coordinates.group(2));
            return dispatchTap(x, y);
        }
        Matcher boundsAction = BOUNDS_ACTION.matcher(rule.action);
        if (boundsAction.matches()) {
            float left = Float.parseFloat(boundsAction.group(1));
            float top = Float.parseFloat(boundsAction.group(2));
            float right = Float.parseFloat(boundsAction.group(3));
            float bottom = Float.parseFloat(boundsAction.group(4));
            if (right <= left || bottom <= top) return false;
            return dispatchTap((left + right) * 0.5f, (top + bottom) * 0.5f);
        }
        AccessibilityNodeInfo target = index.findActionNode(rule.action);
        if (target == null && equivalent(rule.id, rule.action)) {
            target = index.findPrimaryNode(rule.id);
        }
        return target != null && performNodeClick(target, forceGesture, index.rootBounds());
    }

    private void scheduleStartupDelay(
            String currentPackage,
            List<String> keywords,
            int clickWay,
            int delayMs
    ) {
        String key = currentPackage + "|startup";
        if (!delayedPending.add(key)) return;
        pendingAction=true;
        long token = generation;
        handler.postDelayed(() -> {
            delayedPending.remove(key);
            pendingAction=!delayedPending.isEmpty();
            if (token != generation || !currentPackage.equals(packageName) || startupDone
                    || !mayAct(currentPackage) || !PreferenceStore.isTypeEnabled(service,AdType.STARTUP)) return;
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            try {
                if (!ownsPackage(root, currentPackage)) return;
                try (AccessibilityNodeIndex index = AccessibilityNodeIndex.build(root)) {
                    AccessibilityNodeInfo target = index.findKeyword(keywords);
                    if (target != null && performNodeClick(target, clickWay == 1, index.rootBounds())) {
                        startupDone = true;
                        markAction();
                        UserEventLog.record(service, "广告已自动跳过");
                    }
                }
            } finally { if(root!=null)root.recycle(); }
        }, delayMs);
    }

    private void schedulePopupDelay(
            String currentPackage,
            String key,
            LiTiaotiaoRule rule,
            boolean forceGesture,
            int delayMs
    ) {
        if (!delayedPending.add(key)) return;
        pendingAction=true;
        long token = generation;
        handler.postDelayed(() -> {
            delayedPending.remove(key);
            pendingAction=!delayedPending.isEmpty();
            if (token != generation || !currentPackage.equals(packageName) || !mayAct(currentPackage)
                    || !PreferenceStore.isTypeEnabled(service,AdType.POPUP)) return;
            AccessibilityNodeInfo root = service.getRootInActiveWindow();
            try {
                if (!ownsPackage(root, currentPackage)) return;
                try (AccessibilityNodeIndex index = AccessibilityNodeIndex.build(root)) {
                    if (!index.expressionExists(rule.id)) return;
                    if (performPopupAction(rule, forceGesture, index)) {
                        successCounts.put(key, successCounts.getOrDefault(key, 0) + 1);
                        markAction();
                        UserEventLog.record(service, "弹窗已自动处理");
                    }
                }
            } finally { if(root!=null)root.recycle(); }
        }, delayMs);
    }

    private void scheduleSearchBurst(String currentPackage, int extraSearches) {
        if (extraSearches <= 0 || searchBurstPending) return;
        searchBurstPending = true;
        long token = generation;
        for (int i = 1; i <= extraSearches; i++) {
            final boolean last = i == extraSearches;
            handler.postDelayed(() -> {
                if (last) searchBurstPending = false;
                if (token != generation || !currentPackage.equals(packageName) || !mayAct(currentPackage)
                    || !PreferenceStore.isTypeEnabled(service,AdType.POPUP)) return;
                AccessibilityNodeInfo root = service.getRootInActiveWindow();
                try {
                    if (!ownsPackage(root, currentPackage)) return;
                    try (AccessibilityNodeIndex index = AccessibilityNodeIndex.build(root)) {
                        LiTiaotiaoRuleBundle bundle = repository.forPackage(currentPackage);
                        if (bundle != null && bundle.lttService) {
                            handleInternal(currentPackage, root, index, bundle, false);
                        }
                    }
                } finally { if(root!=null)root.recycle(); }
            }, SEARCH_INTERVAL_MS * i);
        }
    }

    private boolean performNodeClick(AccessibilityNodeInfo target, boolean forceGesture, Rect rootBounds) {
        if (!forceGesture) {
            AccessibilityNodeInfo clickable = clickableAncestor(target);
            if (clickable != null && clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        }
        Rect rect = new Rect();
        target.getBoundsInScreen(rect);
        if (rect.width() <= 0 || rect.height() <= 0) return false;
        if (rootBounds.width() > 0 && rootBounds.height() > 0 && !Rect.intersects(rootBounds, rect)) return false;
        return dispatchTap(rect.exactCenterX(), rect.exactCenterY());
    }

    private AccessibilityNodeInfo clickableAncestor(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; current != null && i < 8; i++) {
            if (current.isClickable() && current.isEnabled()) return current;
            current = current.getParent();
        }
        return null;
    }

    private boolean dispatchTap(float x, float y) {
        if (x < 0 || y < 0) return false;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0L, 45L))
                .build();
        return service.dispatchGesture(gesture, null, null);
    }

    private void markAction() {
        lastAutomatedActionUptime = SystemClock.uptimeMillis();
    }

    private static boolean equivalent(String left, String right) {
        if (left == null || right == null) return false;
        return stripOperator(left).equals(stripOperator(right));
    }

    private static String stripOperator(String value) {
        String result = value.trim();
        if (result.startsWith("|")) result = result.substring(1).trim();
        if (result.startsWith("=") || result.startsWith("+") || result.startsWith("-")) result = result.substring(1);
        return result.trim();
    }

    private static boolean ownsPackage(AccessibilityNodeInfo root, String expected) {
        return root != null && root.getPackageName() != null && expected.equals(root.getPackageName().toString());
    }
}
