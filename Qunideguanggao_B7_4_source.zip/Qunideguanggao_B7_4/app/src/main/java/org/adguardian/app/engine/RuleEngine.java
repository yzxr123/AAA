package org.adguardian.app.engine;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.function.Supplier;
import org.adguardian.app.gkd.GkdSubscriptionEngine;
import org.adguardian.app.litiaotiao.LiTiaotiaoRuleEngine;
import org.adguardian.app.settings.PreferenceStore;

public final class RuleEngine {
    private final AccessibilityService service;
    private final LiTiaotiaoRuleEngine liTiaotiao;
    private final GkdAssistEngine assist;
    private final GkdSubscriptionEngine subscription;
    private volatile long assistAction;
    private volatile boolean externalAction;
    private volatile long externalActionTime;
    private long externalGeneration;
    private String currentPackage="";

    public RuleEngine(AccessibilityService service, Handler worker,
                      Runnable requestScan,Supplier<String> foreground) {
        this.service=service;
        liTiaotiao=new LiTiaotiaoRuleEngine(service,worker,foreground);
        assist=new GkdAssistEngine(service);
        subscription=new GkdSubscriptionEngine(service,worker,requestScan,foreground);
        liTiaotiao.setExternalActionPending(() -> externalAction || subscription.isGesturePending());
    }
    public void onPackageEntered(String packageName) {
        if(packageName.equals(currentPackage))return;
        currentPackage=packageName;
        liTiaotiao.onPackageEntered(packageName);
        subscription.onPackageEntered(packageName);
        assist.onPackageEntered(packageName);
    }
    public int liTiaotiaoPackageCount() { return liTiaotiao.packageCount(); }
    public int liTiaotiaoRuleCount() { return liTiaotiao.ruleCount(); }
    public long lastAutomatedActionUptime() {
        return Math.max(Math.max(assistAction,externalActionTime),Math.max(liTiaotiao.lastAutomatedActionUptime(),subscription.lastAutomatedActionUptime()));
    }
    public boolean beginExternalAction() {
        if(externalAction || isWaitingForRules())return false;
        long last=lastAutomatedActionUptime();
        if(last>0 && SystemClock.uptimeMillis()-last<900L)return false;
        externalAction=true;
        externalGeneration++;
        externalActionTime=SystemClock.uptimeMillis();
        return true;
    }
    public long externalActionToken() { return externalGeneration; }
    public void endExternalAction() { externalAction=false; }
    public void endExternalAction(long token) { if(token==externalGeneration)externalAction=false; }
    public boolean isWaitingForRules() { return liTiaotiao.hasPendingAction() || subscription.isWaiting(); }
    public long nextWakeUp() { return subscription.nextWakeUp(); }
    public void onSettingsChanged() { liTiaotiao.cancelPending();subscription.reset(); }
    public void close() { liTiaotiao.cancelPending();subscription.close(); }

    public boolean handle(String packageName,String activityName,int eventType,AccessibilityNodeInfo root) {
        if(root==null || packageName==null || packageName.isEmpty()
                || !PreferenceStore.isMasterEnabled(service))return false;
        onPackageEntered(packageName);
        if(externalAction)return true;
        if(subscription.isWaiting() && subscription.nextWakeUp()<0)return true;
        long last=lastAutomatedActionUptime();
        if(last>0 && SystemClock.uptimeMillis()-last<100L)return true;
        try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)) {
            if(PreferenceStore.isLiTiaotiaoEnabled(service)
                    && liTiaotiao.handle(packageName,root,index))return true;
            if(liTiaotiao.hasPendingAction())return true;
            if(!PreferenceStore.isGkdEnabled(service))return false;
            if(subscription.handle(packageName,activityName,index))return true;
            boolean handled=assist.handle(packageName,activityName,eventType,index);
            assistAction=assist.lastAutomatedActionUptime();
            return handled;
        }
    }
}
