package org.adguardian.app.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.lang.ref.WeakReference;
import java.util.LinkedHashMap;
import org.adguardian.app.engine.PackagePolicy;
import org.adguardian.app.engine.RuleEngine;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.ocr.OcrFallbackController;
import org.adguardian.app.settings.PreferenceStore;

public final class AdAccessibilityService extends AccessibilityService {
    private static final long HOT_CONTENT_DEBOUNCE_MS=55L;
    private static final long IDLE_CONTENT_DEBOUNCE_MS=140L;
    private static WeakReference<AdAccessibilityService> activeService=new WeakReference<>(null);
    private final Handler mainHandler=new Handler(Looper.getMainLooper());
    private final Object scanLock=new Object();
    private final LinkedHashMap<String,Boolean> activityCache=new LinkedHashMap<>(32,0.75f,true);
    private final Runnable retryScan=this::requestCurrentScan;
    private volatile RuleEngine ruleEngine;
    private PackagePolicy packagePolicy;
    private OcrFallbackController ocrController;
    private AccessibilityKeepAliveOverlay keepAliveOverlay;
    private HandlerThread scanThread;
    private Handler scanHandler;
    private ScanRequest pendingScan;
    private boolean drainScheduled;
    private volatile boolean destroyed;
    private volatile String foregroundPackage="";
    private volatile String eventClass="";
    private volatile int foregroundWindow=-1;
    private String workerPackage="";
    private String activityName="";
    private long lastContentRequest;
    private long lastUserClick;
    private long enteredAt;
    private long retryAt=Long.MAX_VALUE;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        destroyed=false;
        activeService=new WeakReference<>(this);
        keepAliveOverlay=new AccessibilityKeepAliveOverlay(this);
        updateKeepAlive();
        AccessibilityServiceInfo info=getServiceInfo();
        if(info==null)info=new AccessibilityServiceInfo();
        info.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                |AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED|AccessibilityEvent.TYPE_WINDOWS_CHANGED
                |AccessibilityEvent.TYPE_VIEW_SCROLLED|AccessibilityEvent.TYPE_VIEW_CLICKED;
        info.feedbackType=AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout=60L;
        info.flags=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                |AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                |AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.packageNames=null;
        setServiceInfo(info);
        scanThread=new HandlerThread("AdRuleScan",Process.THREAD_PRIORITY_BACKGROUND);
        scanThread.start();
        scanHandler=new Handler(scanThread.getLooper());
        scanHandler.post(() -> {
            PackagePolicy policy=new PackagePolicy(this);
            RuleEngine engine=new RuleEngine(this,scanHandler,this::requestCurrentScan,() -> foregroundPackage);
            if(destroyed) { engine.close();return; }
            ruleEngine=engine;
            mainHandler.post(() -> {
                if(destroyed)return;
                packagePolicy=policy;
                ocrController=new OcrFallbackController(this,engine,scanHandler,() -> foregroundPackage);
                if(engine.liTiaotiaoPackageCount()==0)UserEventLog.error(this,"广告规则加载失败 请重新安装");
                scanHandler.post(this::requestCurrentScan);
            });
        });
    }

    public static void notifySettingsChanged() {
        AdAccessibilityService current=activeService.get();
        if(current==null)return;
        current.mainHandler.post(() -> {
            if(current.destroyed)return;
            if(current.ocrController!=null)current.ocrController.onSettingsChanged();
            current.updateKeepAlive();
            Handler worker=current.scanHandler;
            if(worker!=null)worker.post(() -> {
                if(current.ruleEngine!=null)current.ruleEngine.onSettingsChanged();
                current.cancelRetry();
                current.requestCurrentScan();
            });
        });
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(destroyed || event==null || ruleEngine==null || packagePolicy==null || ocrController==null)return;
        if(!PreferenceStore.isMasterEnabled(this))return;
        long now=SystemClock.uptimeMillis();
        int type=event.getEventType();
        if(type==AccessibilityEvent.TYPE_VIEW_CLICKED) {
            if(!ocrController.isLikelyAutomatedClick(now)) {
                lastUserClick=now;
                ocrController.noteUserInteraction();
            }
            return;
        }
        boolean state=type==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        boolean windows=type==AccessibilityEvent.TYPE_WINDOWS_CHANGED;
        boolean content=type==AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        boolean scroll=type==AccessibilityEvent.TYPE_VIEW_SCROLLED;
        if(!state && !windows && !content && !scroll)return;
        ocrController.noteUiEvent();
        String pkg=event.getPackageName()==null?foregroundPackage:event.getPackageName().toString();
        if(pkg.isEmpty())return;
        boolean changed=!pkg.equals(foregroundPackage);
        boolean windowChanged=state || (windows && foregroundWindow!=event.getWindowId());
        if(changed && !foregroundPackage.isEmpty() && packagePolicy.allow(pkg)
                && ocrController.shouldUndoCrossAppJump(foregroundPackage,pkg,now,lastUserClick)) {
            if(performGlobalAction(GLOBAL_ACTION_BACK)) {
                UserEventLog.record(this,"已阻止广告跳转");
                return;
            }
        }
        if(changed) {
            foregroundPackage=pkg;
            eventClass="";
            enteredAt=now;
            lastContentRequest=0;
            ocrController.endSession();
            if(packagePolicy.allow(pkg))ocrController.beginSession(pkg,"");
        }
        if(state && event.getClassName()!=null)eventClass=event.getClassName().toString();
        foregroundWindow=event.getWindowId();
        if(!packagePolicy.allow(pkg)) {
            if(changed)enqueue(new ScanRequest(pkg,"",type,false));
            return;
        }
        if(content && !changed) {
            long lastAction=ruleEngine.lastAutomatedActionUptime();
            boolean hot=now-enteredAt<5000L || (lastAction>0 && now-lastAction<3000L);
            long debounce=hot?HOT_CONTENT_DEBOUNCE_MS:IDLE_CONTENT_DEBOUNCE_MS;
            if(now-lastContentRequest<debounce)return;
            lastContentRequest=now;
        }
        enqueue(new ScanRequest(pkg,eventClass,type,windowChanged && !changed));
    }

    private void enqueue(ScanRequest request) {
        Handler worker=scanHandler;
        if(worker==null || destroyed)return;
        synchronized(scanLock) {
            if(pendingScan!=null && pendingScan.packageName.equals(request.packageName)) {
                request=new ScanRequest(request.packageName,request.className,request.type,
                        request.popupProbe || pendingScan.popupProbe);
            }
            pendingScan=request;
            if(drainScheduled)return;
            drainScheduled=true;
        }
        worker.post(this::drainOne);
    }

    private void drainOne() {
        ScanRequest request;
        synchronized(scanLock) { request=pendingScan;pendingScan=null; }
        try {
            if(request!=null && !destroyed && ruleEngine!=null && PreferenceStore.isMasterEnabled(this))scan(request);
        } catch(RuntimeException error) {
            UserEventLog.error(this,"广告保护暂时遇到问题");
        } finally {
            synchronized(scanLock) {
                if(pendingScan==null || destroyed) { drainScheduled=false;return; }
            }
            Handler worker=scanHandler;
            if(worker!=null)worker.post(this::drainOne);
        }
    }

    private void scan(ScanRequest request) {
        if(!request.packageName.equals(foregroundPackage))return;
        if(!request.packageName.equals(workerPackage)) {
            cancelRetry();
            workerPackage=request.packageName;
            activityName="";
            ruleEngine.onPackageEntered(workerPackage);
        }
        if(packagePolicy==null || !packagePolicy.allow(workerPackage))return;
        if(!request.className.isEmpty() && isActivity(workerPackage,request.className))activityName=request.className;
        AccessibilityNodeInfo root=getRootInActiveWindow();
        try {
            if(root==null || root.getPackageName()==null || !workerPackage.contentEquals(root.getPackageName()))return;
            String app=workerPackage;
            String activity=activityName;
            boolean handled=ruleEngine.handle(app,activity,request.type,root);
            scheduleRetry(ruleEngine.nextWakeUp());
            mainHandler.post(() -> {
                if(destroyed || !app.equals(foregroundPackage) || ocrController==null)return;
                ocrController.updateActivity(activity);
                if(handled)ocrController.endSession();
                else if(request.popupProbe)ocrController.beginPopupProbe(app,activity);
            });
        } finally { if(root!=null)root.recycle(); }
    }

    private boolean isActivity(String pkg,String name) {
        String key=pkg+"/"+name;
        Boolean cached=activityCache.get(key);
        if(cached!=null)return cached;
        boolean found;
        try {
            getPackageManager().getActivityInfo(new ComponentName(pkg,name),0);
            found=true;
        } catch(PackageManager.NameNotFoundException error) { found=false; }
        activityCache.put(key,found);
        if(activityCache.size()>128)activityCache.remove(activityCache.keySet().iterator().next());
        return found;
    }

    private void scheduleRetry(long delay) {
        if(delay<0) { cancelRetry();return; }
        long due=SystemClock.uptimeMillis()+Math.max(60L,delay);
        if(retryAt<=due)return;
        scanHandler.removeCallbacks(retryScan);
        retryAt=due;
        scanHandler.postAtTime(retryScan,due);
    }
    private void cancelRetry() {
        retryAt=Long.MAX_VALUE;
        if(scanHandler!=null)scanHandler.removeCallbacks(retryScan);
    }
    private void requestCurrentScan() {
        cancelRetry();
        if(destroyed || !PreferenceStore.isMasterEnabled(this))return;
        if(foregroundPackage.isEmpty()) {
            AccessibilityNodeInfo root=getRootInActiveWindow();
            try { if(root!=null && root.getPackageName()!=null)foregroundPackage=root.getPackageName().toString(); }
            finally { if(root!=null)root.recycle(); }
        }
        if(!foregroundPackage.isEmpty())enqueue(new ScanRequest(foregroundPackage,eventClass,
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,false));
    }
    private void updateKeepAlive() {
        if(keepAliveOverlay==null)return;
        if(PreferenceStore.isMasterEnabled(this) && PreferenceStore.isKeepAliveEnabled(this))keepAliveOverlay.attach();
        else keepAliveOverlay.detach();
    }
    @Override public void onTaskRemoved(Intent rootIntent) { updateKeepAlive();super.onTaskRemoved(rootIntent); }
    @Override public void onInterrupt() { if(ocrController!=null)ocrController.endSession(); }
    @Override public void onDestroy() {
        destroyed=true;
        if(ocrController!=null)ocrController.stop();
        if(keepAliveOverlay!=null)keepAliveOverlay.detach();
        mainHandler.removeCallbacksAndMessages(null);
        if(scanHandler!=null) {
            HandlerThread thread=scanThread;
            scanHandler.post(() -> { cancelRetry();if(ruleEngine!=null)ruleEngine.close();thread.quitSafely(); });
        }
        synchronized(scanLock) { pendingScan=null; }
        if(activeService.get()==this)activeService.clear();
        super.onDestroy();
    }
    private static final class ScanRequest {
        final String packageName;
        final String className;
        final int type;
        final boolean popupProbe;
        ScanRequest(String pkg,String name,int type,boolean popupProbe) {
            this.packageName=pkg;
            this.className=name;
            this.type=type;
            this.popupProbe=popupProbe;
        }
    }
}
