# 去你的广告 B7.7

Read .agents/skills/android-ad-guardian/SKILL.md and docs/B7.7-implementation.md before changes
Android phone application One offline APK No INTERNET permission No update subsystem
Keep app identity signing key original LTT bytes bundled GKD source and subscription unchanged
Do not require root Shizuku a companion app or WRITE_SECURE_SETTINGS
Never invoke onServiceConnected to pretend a framework rebind

## Preserved lifecycle

Authorization has known enabled known disabled unknown states
An unavailable settings read plus an empty manager list is not revocation
Retained positive authorization is only background retention policy not proof of a live service
Separate framework connection engine readiness and foreground guard status
User master/background off and explicit revocation must be honored
No hidden activities restart loops wake locks silent audio or claims of defeating OEM force stop
See docs/B7.6-audit.md for the inherited changes and limitations

## CLASS profile

Exact package cn.luyiyuntech.stt and versionCode 1013 only
Use only APK-evidenced Activities and actual resource IDs
tv_skip can be GONE Never click its historic position
TTFullScreenVideoActivity is ordinary fullscreen even though its namespace includes reward
Do not fold TTRewardVideoActivity or ordinary timetable pages into targeted closing
No generic Back No fabricated SDK IDs No blind corner tapping
Recheck each stage A completed input or missing first button is not proof the entire ad is over
Use bounded parents not the whole ad container
Class profile has a default-on separate switch

## Learning and replay

Primary multi-step implementation is flow/ FlowTeachingController FlowJournal FlowReplayEngine FlowStore
Single-button learning/ and its data must stay compatible
Explicit teaching only max180seconds max8steps No passive daily input recording
Pause other automation and OCR during either teaching mode
Capture immutable pre-action data and read event source at event intake
Explicit node selection does not inject a click Explicit Record and Back does inject one after guards
No first-step Back No Back on CLASS MainActivity
Commit a stage after two observations of target disappearance or a stable changed stage structure
Unchanged disabled visible targets are not disappearance
Unknown roots missing recorded steps incomplete traversals and unverified final pages cannot be success
Store only package version Activity structural digest safe target descriptor and expected terminal guard
No arbitrary content text screenshots passwords or coordinate-only macros
Replay must start at step1 and freshly resolve every target No mid-flow guessing
Exact package version guard and orientation unique target user switches apply to each action
A no-effect unchanged step yields after2500ms Step transition deadline30s total120s
Known unrelated Activities and user intervention cancel replay
Legacy learned-ad-rules.bin is untouched New flow file is separate atomic bounded and validated

## Runtime

Verified learned flow then legacy learned rule then CLASS profile then original LTT then real GKD subscription then constrained assistance then optional OCR
An active flow owns the action pipeline and blocks OCR Lower engines do not race its actions
Keep node caches event coalescing off-main query work delayed512pxRGB565OCR and all old switches
Use generation/foreground checks after expensive reads before injecting input
Diagnostic exceptions do not create fake permission or successful ads

## Delivery

Run tools/run_host_tests.py with all Python Kotlin and Java API-double tests
An API-double compilation is not Android SDK compilation or a real phone result
Deliver full Qunideguanggao_B7_7_source.zip and standalone build-apk-B7.7.yml
Inline workflow source preparation must accept renamed intact ZIPs nested folders and isolate old checkout files
Do not make users upload individual source files
