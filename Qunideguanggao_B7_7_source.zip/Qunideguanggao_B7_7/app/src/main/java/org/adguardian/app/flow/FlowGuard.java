package org.adguardian.app.flow;

import java.util.Objects;

/** A screen precondition. It contains structural metadata, never page text or screenshots. */
public final class FlowGuard {
    public final String activity, signature;
    public final float aspect;
    public FlowGuard(String activity,String signature,float aspect) {
        this.activity=activity;this.signature=signature;this.aspect=aspect;
    }
    public boolean valid() {
        return activity!=null && !activity.isEmpty() && activity.length()<=512
                && signature!=null && signature.matches("f1:[0-9a-f]{64}")
                && Float.isFinite(aspect) && aspect>.15f && aspect<6f;
    }
    public boolean matches(FlowGuard other) {
        return other!=null && valid() && other.valid() && activity.equals(other.activity)
                && signature.equals(other.signature) && Math.abs(aspect-other.aspect)<.025f;
    }
    @Override public boolean equals(Object o) {return o instanceof FlowGuard g && matches(g);}
    @Override public int hashCode() {return Objects.hash(activity,signature);}
}
