package org.adguardian.app.classapp;

import android.accessibilityservice.*;
import android.graphics.*;
import android.os.*;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;
import java.util.function.Supplier;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.FlowSafety;
import org.adguardian.app.settings.PreferenceStore;

/** Targeted UI adapter, not SDK hooking. No generic Back and no undocumented/fabricated resource IDs. */
public final class ClassAdEngine {
    private final AccessibilityService service;
    private final Handler worker;
    private final Supplier<String> foreground;
    private final Runnable scan;
    private final ActionVerifier verifier;
    private String checkedPackage="",scope="";
    private long version=-1,entered,epoch,pausedUntil;
    private volatile long lastAction;
    private int actions;
    private boolean scoped;
    private volatile boolean pending;
    public ClassAdEngine(AccessibilityService s,Handler h,Supplier<String> foreground,Runnable scan,ActionVerifier verifier) {
        service=s;worker=new Handler(h.getLooper());this.foreground=foreground;this.scan=scan;this.verifier=verifier;
    }
    public long lastAction(){return lastAction;}
    public boolean isPending(){return pending;}
    public long nextWakeUp(){long age=SystemClock.uptimeMillis()-entered;return !scoped || age>=60000 || actions>=8?-1:age<2000?380:age<8000?600:900;}
    public void cancelPending(){epoch++;pending=false;worker.removeCallbacksAndMessages(null);}
    public void onUserInteraction(){cancelPending();pausedUntil=SystemClock.uptimeMillis()+1200;}
    public void onPackageChanged(){cancelPending();checkedPackage="";scope="";scoped=false;pausedUntil=0;}
    public void close(){onPackageChanged();}
    public boolean handle(String pkg,String activity,AccessibilityNodeIndex index) {
        if(!ClassAdProfile.PACKAGE.equals(pkg) || !pkg.equals(foreground.get()) || !PreferenceStore.isMasterEnabled(service)
                || !PreferenceStore.isClassAdapterEnabled(service)){cancelPending();scoped=false;return false;}
        if(!pkg.equals(checkedPackage)) {
            checkedPackage=pkg;version=-1;
            try{version=service.getPackageManager().getPackageInfo(pkg,0).getLongVersionCode();}
            catch(android.content.pm.PackageManager.NameNotFoundException | RuntimeException unavailable){return false;}
        }
        if(version!=ClassAdProfile.VERSION){scoped=false;return false;}
        index.startQueryBudget(35L);
        try {
            boolean adActivity=ClassAdProfile.isAdActivity(activity);
            boolean nativePopup=ClassAdProfile.MAIN.equals(activity) && visibleId(index,"fhad_rl_content")!=null;
            if(!adActivity && !nativePopup){cancelPending();scope="";scoped=false;return false;}
            boolean splash=ClassAdProfile.SPLASH.equals(activity);
            if(!PreferenceStore.isTypeEnabled(service,splash?AdType.STARTUP:AdType.POPUP)){scoped=false;cancelPending();return false;}
            String nextScope=activity+"|"+index.root().getWindowId()+"|"+nativePopup;
            if(!nextScope.equals(scope)){cancelPending();scope=nextScope;entered=SystemClock.uptimeMillis();actions=0;}
            scoped=true;
            if(pending || verifier.isPending())return true;
            long now=SystemClock.uptimeMillis();if(now<pausedUntil || now-lastAction<180 || actions>=8)return false;
            if(FlowSafety.forbiddenScreen(index))return false;
            AccessibilityNodeInfo leaf=nativePopup?visibleId(index,"fhad_iv_delete"):splash?visibleId(index,"tv_skip"):null;
            if(leaf==null && adActivity) {
                LinkedHashMap<AccessibilityNodeInfo,AccessibilityNodeInfo> candidates=new LinkedHashMap<>();
                for(AccessibilityNodeInfo n:index.nodes()) {
                    if(!n.isEnabled() || !n.isVisibleToUser() || n.isEditable() || n.isPassword())continue;
                    String text=NodeTarget.string(n.getText()),desc=NodeTarget.string(n.getContentDescription());
                    if(!AdCloseText.isClose(text) && !AdCloseText.isClose(desc))continue;
                    NodeTarget target=NodeTarget.captureSelected(n,index.rootBounds());
                    if(!FlowSafety.safeTarget(target))continue;
                    AccessibilityNodeInfo click=FlowSafety.clickTarget(n,index);
                    if(click!=null)candidates.putIfAbsent(click,n);
                }
                if(candidates.size()!=1 || index.isTraversalIncomplete())return false;
                leaf=candidates.values().iterator().next();
            }
            if(leaf==null)return false;
            AccessibilityNodeInfo click=FlowSafety.clickTarget(leaf,index);if(click==null)return false;
            NodeTarget descriptor=NodeTarget.captureSelected(leaf,index.rootBounds());
            String key="class:"+activity+":"+descriptor.id+":"+AdCloseText.normalize(descriptor.label)+":"+Math.round(descriptor.x*20)+":"+Math.round(descriptor.y*20);
            if(!verifier.allowed(pkg,key,index.root().getWindowId()))return false;
            ActionVerifier.Ticket ticket=verifier.capture(pkg,key,"click",leaf,index,null);if(ticket==null)return false;
            if(!pkg.equals(foreground.get()) || !PreferenceStore.isMasterEnabled(service)
                    || !PreferenceStore.isClassAdapterEnabled(service)
                    || !PreferenceStore.isTypeEnabled(service,splash?AdType.STARTUP:AdType.POPUP))return false;
            lastAction=now;
            boolean accepted=click.isClickable() && click.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            if(accepted){lastAction=now;actions++;verifier.accepted(ticket);return true;}
            Rect b=FlowSafety.bounds(click);Path path=new Path();path.moveTo(b.exactCenterX(),b.exactCenterY());
            long token=++epoch;pending=true;
            GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,45)).build();
            try {
                accepted=service.dispatchGesture(gesture,new AccessibilityService.GestureResultCallback(){
                    @Override public void onCompleted(GestureDescription g){if(token!=epoch)return;pending=false;if(pkg.equals(foreground.get()) && PreferenceStore.isMasterEnabled(service) && PreferenceStore.isClassAdapterEnabled(service) && PreferenceStore.isTypeEnabled(service,splash?AdType.STARTUP:AdType.POPUP)){verifier.accepted(ticket);scan.run();}}
                    @Override public void onCancelled(GestureDescription g){if(token!=epoch)return;pending=false;verifier.rejected(ticket);scan.run();}
                },worker);
            }catch(RuntimeException error){accepted=false;}
            if(!accepted){pending=false;verifier.rejected(ticket);return false;}
            lastAction=now;actions++;
            worker.postDelayed(()->{if(token==epoch && pending){pending=false;epoch++;verifier.rejected(ticket);scan.run();}},1500);
            return true;
        }catch(AccessibilityNodeIndex.QueryLimit unavailable){return false;}
        finally{index.clearQueryBudget();}
    }
    private static AccessibilityNodeInfo visibleId(AccessibilityNodeIndex index,String suffix) {
        AccessibilityNodeInfo chosen=null;
        for(AccessibilityNodeInfo n:index.fastQuery(index.root(),"id",ClassAdProfile.PACKAGE+":id/"+suffix)) {
            if(!n.isVisibleToUser() || !n.isEnabled())continue;
            Rect b=FlowSafety.bounds(n);if(b.width()<=0 || b.height()<=0)continue;
            if(chosen!=null)return null;chosen=n;
        }
        return chosen;
    }
}
