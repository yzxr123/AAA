package org.adguardian.app.learning;

import android.graphics.Rect;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.adguardian.app.engine.AccessibilityNodeIndex;
import org.adguardian.app.engine.NodeTarget;

/** Immutable pre-click metadata. Never retains AccessibilityNodeInfo or user text. */
final class LearningPage {
    final String pkg,activity,guard;
    final Rect bounds;
    final long capturedAt;
    final boolean adContext;
    final List<NodeTarget> targets;

    private LearningPage(String pkg,String activity,String guard,Rect bounds,boolean ad,List<NodeTarget> targets) {
        this.pkg=pkg;this.activity=activity;this.guard=guard;this.bounds=new Rect(bounds);
        this.adContext=ad;this.targets=Collections.unmodifiableList(targets);capturedAt=SystemClock.uptimeMillis();
    }
    static LearningPage capture(String pkg,String activity,AccessibilityNodeIndex index) {
        String scope=activity.isEmpty()?"@window:"+NodeTarget.string(index.root().getClassName()):activity;
        String proof=signature(index);
        ArrayList<NodeTarget> controls=new ArrayList<>();
        int count=0;
        for(AccessibilityNodeInfo n:index.nodes()) {
            if(++count>128)break;
            if(!n.isEnabled() || !n.isVisibleToUser())continue;
            NodeTarget t=NodeTarget.captureSelected(n,index.rootBounds());
            if(t!=null && t.isSafeLearningTarget())controls.add(t.forLearning());
        }
        return new LearningPage(pkg,scope,proof,index.rootBounds(),LearnedRule.hasAdContext(index),controls);
    }
    static String signature(AccessibilityNodeIndex index) {
        return index.memoizedFingerprint("learned-page-v1",()->computeSignature(index));
    }
    private static String computeSignature(AccessibilityNodeIndex index) {
        // Fingerprint stable structural identifiers, never advertisement copy, countdowns or input values.
        java.util.SortedSet<String> anchors=new java.util.TreeSet<>();int count=0;
        for(AccessibilityNodeInfo n:index.nodes()) {
            if(++count>128)return "";
            if(!n.isVisibleToUser())continue;
            String id=NodeTarget.string(n.getViewIdResourceName());
            if(!id.isEmpty())anchors.add(id+"|"+NodeTarget.string(n.getClassName()));
        }
        if(anchors.size()<2 || index.isTraversalIncomplete())return "";
        StringBuilder data=new StringBuilder("page-v1\n").append(NodeTarget.string(index.root().getClassName())).append('\n');
        for(String anchor:anchors)data.append(anchor).append('\n');
        try {
            byte[] bytes=MessageDigest.getInstance("SHA-256").digest(data.toString().getBytes(StandardCharsets.UTF_8));
            StringBuilder hex=new StringBuilder("p1:");
            for(byte b:bytes)hex.append(String.format(java.util.Locale.ROOT,"%02x",b & 255));
            return hex.toString();
        } catch(NoSuchAlgorithmException impossible) {throw new IllegalStateException(impossible);}
    }
    NodeTarget find(NodeTarget source) {
        if(source==null)return null;
        NodeTarget result=null;
        for(NodeTarget t:targets) {
            if(!source.id.equals(t.id) || !source.name.equals(t.name)
                    || Math.abs(source.x-t.x)>.025f || Math.abs(source.y-t.y)>.025f)continue;
            if(!source.id.isEmpty() || (!source.label.isEmpty() && NodeTarget.normalizeClose(source.label).equals(t.label))) {
                if(result!=null)return null;result=t;
            }
        }
        return result;
    }
    NodeTarget pick(float screenX,float screenY) {
        float x=(screenX-bounds.left)/bounds.width(),y=(screenY-bounds.top)/bounds.height();
        NodeTarget best=null;float area=Float.MAX_VALUE;boolean ambiguous=false;
        for(NodeTarget t:targets) {
            if(Math.abs(x-t.x)>t.width/2 || Math.abs(y-t.y)>t.height/2)continue;
            float a=t.width*t.height;
            if(a<area-.00001f){best=t;area=a;ambiguous=false;}
            else if(Math.abs(a-area)<.00001f){
                if(best!=null && best.id.isEmpty() && !t.id.isEmpty()){best=t;ambiguous=false;}
                else if(best==null || !best.id.equals(t.id))ambiguous=true;
            }
        }
        return ambiguous?null:best;
    }
}
