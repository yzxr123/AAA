package org.adguardian.app.flow;

import android.content.Context;
import android.util.AtomicFile;
import java.io.*;
import java.util.*;
import org.adguardian.app.engine.*;

/** Separate format and file: old single-button lessons are never rewritten or discarded here. */
public final class FlowStore {
    private static final int MAGIC=0x51464c31,MAX_FLOWS=64,MAX_BYTES=262144;
    private final AtomicFile file;
    private List<LearnedFlow> flows=List.of();
    private boolean readable=true;
    public FlowStore(Context c) {
        file=new AtomicFile(new File(c.getFilesDir(),"learned-ad-flows.bin"));
        if(!file.getBaseFile().exists() && !new File(file.getBaseFile()+".bak").exists())return;
        try(DataInputStream in=new DataInputStream(file.openRead())) {
            if(file.getBaseFile().length()>MAX_BYTES || in.readInt()!=MAGIC)throw new IOException("invalid flow file");
            int count=in.readInt();if(count<0 || count>MAX_FLOWS)throw new IOException("flow count");
            ArrayList<LearnedFlow> copy=new ArrayList<>();HashSet<String> keys=new HashSet<>();
            for(int i=0;i<count;i++) {
                String key=field(in),pkg=field(in),name=field(in);long version=in.readLong();int type=in.readInt();boolean enabled=in.readBoolean();
                if(type<0 || type>=AdType.values().length)throw new IOException("category");
                int size=in.readInt();if(size<1 || size>FlowJournal.MAX_STEPS)throw new IOException("step count");
                ArrayList<FlowStep> steps=new ArrayList<>();
                for(int j=0;j<size;j++) {
                    FlowGuard guard=guard(in);boolean back=in.readBoolean();long wait=in.readLong();
                    NodeTarget target=back?null:new NodeTarget(field(in),field(in),field(in),in.readFloat(),in.readFloat(),in.readFloat(),in.readFloat());
                    steps.add(new FlowStep(guard,target,back,wait));
                }
                LearnedFlow flow=new LearnedFlow(key,pkg,name,version,AdType.values()[type],enabled,steps,guard(in));
                validate(flow);if(!keys.add(key))throw new IOException("duplicate flow");copy.add(flow);
            }
            if(in.read()!=-1)throw new IOException("trailing flow data");flows=Collections.unmodifiableList(copy);
        }catch(IOException e){readable=false;}
    }
    public boolean isReadable(){return readable;}
    public List<LearnedFlow> all(){return flows;}
    public boolean hasPackage(String pkg){for(LearnedFlow f:flows)if(f.enabled&&f.packageName.equals(pkg))return true;return false;}
    public boolean isEnabled(String key){for(LearnedFlow f:flows)if(f.key.equals(key))return f.enabled;return false;}
    public void add(LearnedFlow flow)throws IOException {
        if(!readable)throw new IOException("unreadable flow file");validate(flow);ArrayList<LearnedFlow> next=new ArrayList<>(flows);
        next.removeIf(f->f.key.equals(flow.key));if(next.size()>=MAX_FLOWS)throw new IOException("flow limit");next.add(flow);save(next);
    }
    public void setEnabled(String key,boolean value)throws IOException {
        if(!readable)throw new IOException("unreadable flow file");ArrayList<LearnedFlow> next=new ArrayList<>();
        for(LearnedFlow f:flows)next.add(f.key.equals(key)?f.withEnabled(value):f);save(next);
    }
    public void remove(String key)throws IOException {
        if(!readable)throw new IOException("unreadable flow file");ArrayList<LearnedFlow> next=new ArrayList<>(flows);next.removeIf(f->f.key.equals(key));save(next);
    }
    public void clear()throws IOException {save(List.of());readable=true;}
    private void save(List<LearnedFlow> next)throws IOException {
        for(LearnedFlow flow:next)validate(flow);
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(MAGIC);out.writeInt(next.size());
        for(LearnedFlow f:next) {
            out.writeUTF(f.key);out.writeUTF(f.packageName);out.writeUTF(f.appName);out.writeLong(f.versionCode);out.writeInt(f.type.ordinal());out.writeBoolean(f.enabled);out.writeInt(f.steps.size());
            for(FlowStep s:f.steps){writeGuard(out,s.guard);out.writeBoolean(s.back);out.writeLong(s.timeoutMs);if(!s.back){NodeTarget t=s.target;out.writeUTF(t.id);out.writeUTF(t.name);out.writeUTF(t.label);out.writeFloat(t.x);out.writeFloat(t.y);out.writeFloat(t.width);out.writeFloat(t.height);}}
            writeGuard(out,f.terminal);
        }
        out.flush();if(bytes.size()>MAX_BYTES)throw new IOException("flow file limit");
        FileOutputStream stream=file.startWrite();try{stream.write(bytes.toByteArray());file.finishWrite(stream);flows=Collections.unmodifiableList(new ArrayList<>(next));}
        catch(IOException error){file.failWrite(stream);throw error;}
    }
    private static void validate(LearnedFlow f)throws IOException {
        if(f==null || f.type==null || f.terminal==null || !f.terminal.valid() || f.versionCode<0 || f.steps.isEmpty() || f.steps.size()>FlowJournal.MAX_STEPS)throw new IOException("invalid flow");
        for(String s:new String[]{f.key,f.packageName,f.appName})if(s==null || s.isEmpty() || s.length()>512)throw new IOException("invalid field");
        if(f.steps.get(0)==null || f.steps.get(0).back)throw new IOException("cannot begin with back");
        for(int i=0;i<f.steps.size();i++) {
            FlowStep s=f.steps.get(i);if(s==null || !s.valid())throw new IOException("invalid step");
            if(Math.abs(s.guard.aspect-f.terminal.aspect)>.025f)throw new IOException("orientation changed");
            if(s.back && s.guard.matches(i+1<f.steps.size()?f.steps.get(i+1).guard:f.terminal))throw new IOException("unverified back");
            if(!s.back)for(String text:new String[]{s.target.id,s.target.name,s.target.label})if(text==null || text.length()>512)throw new IOException("invalid target field");
            if(!s.back && !s.target.label.isEmpty() && !AdCloseText.isClose(s.target.label))throw new IOException("arbitrary label");
        }
    }
    private static String field(DataInputStream in)throws IOException{String s=in.readUTF();if(s.length()>512)throw new IOException("field length");return s;}
    private static FlowGuard guard(DataInputStream in)throws IOException{return new FlowGuard(field(in),field(in),in.readFloat());}
    private static void writeGuard(DataOutputStream out,FlowGuard g)throws IOException{out.writeUTF(g.activity);out.writeUTF(g.signature);out.writeFloat(g.aspect);}
}
