package org.adguardian.app.classapp;

/** Verified from the supplied Class 6.2.1013 APK. Runtime accessibility templates are still checked. */
public final class ClassAdProfile {
    public static final String PACKAGE="cn.luyiyuntech.stt";
    public static final long VERSION=1013;
    public static final String SPLASH="com.common.tang.activity.SplashActivity";
    public static final String MAIN="com.common.tang.activity.MainActivity";
    public static final String VIDEO="com.bytedance.sdk.openadsdk.core.component.reward.activity.TTFullScreenVideoActivity";
    public static final String LANDSCAPE="com.bytedance.sdk.openadsdk.core.component.reward.activity.TTFullScreenVideoLandscapeActivity";
    private ClassAdProfile() { }
    public static boolean isAdActivity(String activity){return SPLASH.equals(activity) || VIDEO.equals(activity) || LANDSCAPE.equals(activity);}
}
