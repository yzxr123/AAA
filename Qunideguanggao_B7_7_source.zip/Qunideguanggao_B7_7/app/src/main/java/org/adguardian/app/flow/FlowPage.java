package org.adguardian.app.flow;

import android.graphics.Rect;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.adguardian.app.engine.*;

/** Frozen pre-action view metadata. No Android nodes or arbitrary labels survive capture. */
public final class FlowPage {
    public final String pkg;
    public final long version, capturedAt;
    public final FlowGuard guard;
    public final boolean knownClassAd;
    public final Rect bounds;
    public final List<NodeTarget> targets;
    private final List<NodeTarget> visibleTargets;
    private FlowPage(String pkg,long version,FlowGuard guard,Rect bounds,List<NodeTarget> targets,List<NodeTarget> visibleTargets,boolean knownClassAd) {
        this.pkg=pkg;this.version=version;this.guard=guard;this.knownClassAd=knownClassAd;this.bounds=new Rect(bounds);
        this.targets=Collections.unmodifiableList(new ArrayList<>(targets));
        this.visibleTargets=Collections.unmodifiableList(new ArrayList<>(visibleTargets));capturedAt=SystemClock.uptimeMillis();
    }
    public static FlowPage capture(String pkg,String activity,long version,AccessibilityNodeIndex index) {
        if(pkg==null || pkg.isEmpty() || activity==null || activity.isEmpty() || version<0)return null;
        if(!pkg.equals(NodeTarget.string(index.root().getPackageName())))return null;
        Rect screen=index.rootBounds();if(screen.width()<=0 || screen.height()<=0)return null;
        StringBuilder topology=new StringBuilder("flow-page-v1\n");
        boolean classPopupBody=false,classPopupClose=false;
        ArrayList<NodeTarget> controls=new ArrayList<>(),present=new ArrayList<>();int count=0,ids=0;
        for(AccessibilityNodeInfo n:index.nodes()) {
            if(++count>256)return null;
            if(!n.isVisibleToUser())continue;
            if(n.isPassword() || FlowSafety.protectedLabel(n.getText()) || FlowSafety.protectedLabel(n.getContentDescription()))return null;
            String id=NodeTarget.string(n.getViewIdResourceName()),name=NodeTarget.string(n.getClassName());
            if(!id.isEmpty())ids++;
            if(id.equals("cn.luyiyuntech.stt:id/fhad_rl_content"))classPopupBody=true;
            if(id.equals("cn.luyiyuntech.stt:id/fhad_iv_delete"))classPopupClose=true;
            Rect b=FlowSafety.bounds(n);
            topology.append(index.cachedDepth(n)).append('|').append(index.cachedIndex(n)).append('|')
                    .append(name).append('|').append(id).append('|').append(n.isClickable()).append('|')
                    .append(n.isScrollable()).append('|').append(n.isEditable()).append('|')
                    .append(Math.round((b.exactCenterX()-screen.left)*16/screen.width())).append(',')
                    .append(Math.round((b.exactCenterY()-screen.top)*16/screen.height())).append(',')
                    .append(Math.round(b.width()*16f/screen.width())).append(',')
                    .append(Math.round(b.height()*16f/screen.height())).append('\n');
            NodeTarget target=NodeTarget.captureSelected(n,screen);
            if(FlowSafety.safeTarget(target)){
                present.add(target.forLearning());
                if(n.isEnabled())controls.add(target.forLearning());
            }
        }
        if(index.isTraversalIncomplete() || count<2 || (ids<2 && count<4))return null;
        String fingerprint;
        try {
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(topology.toString().getBytes(StandardCharsets.UTF_8));
            StringBuilder hex=new StringBuilder("f1:");for(byte b:digest)hex.append(String.format(Locale.ROOT,"%02x",b & 255));fingerprint=hex.toString();
        }catch(java.security.NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}
        return new FlowPage(pkg,version,new FlowGuard(activity,fingerprint,(float)screen.width()/screen.height()),screen,controls,present,
                pkg.equals(org.adguardian.app.classapp.ClassAdProfile.PACKAGE)
                && (org.adguardian.app.classapp.ClassAdProfile.isAdActivity(activity) || (classPopupBody && classPopupClose)));
    }
    public boolean sameScope(FlowPage other) {
        return other!=null && pkg.equals(other.pkg) && version==other.version
                && Math.abs(guard.aspect-other.guard.aspect)<.025f;
    }
    public NodeTarget find(NodeTarget wanted) {
        if(wanted==null)return null;NodeTarget match=null;
        for(NodeTarget t:targets)if(sameTarget(wanted,t)) {if(match!=null)return null;match=t;}
        return match;
    }
    public boolean has(NodeTarget wanted) {
        if(wanted==null)return false;
        for(NodeTarget t:visibleTargets)if(sameTarget(wanted,t))return true;
        return false;
    }
    private static boolean sameTarget(NodeTarget a,NodeTarget b) {
        return a.id.equals(b.id) && a.name.equals(b.name) && a.label.equals(b.label)
                && Math.abs(a.x-b.x)<.04f && Math.abs(a.y-b.y)<.04f
                && Math.abs(a.width-b.width)<.04f && Math.abs(a.height-b.height)<.04f;
    }
    public NodeTarget pick(float x,float y) {
        float nx=(x-bounds.left)/bounds.width(),ny=(y-bounds.top)/bounds.height();NodeTarget best=null;float area=2;
        boolean ambiguous=false;
        for(NodeTarget t:targets) {
            if(Math.abs(t.x-nx)>t.width/2 || Math.abs(t.y-ny)>t.height/2)continue;
            float a=t.width*t.height;
            if(a<area-.00001f){best=t;area=a;ambiguous=false;}
            else if(Math.abs(a-area)<.00001f) {
                boolean better=best!=null && best.label.isEmpty() && !t.label.isEmpty();
                if(better){best=t;ambiguous=false;}else if(best!=null && !sameTarget(best,t) && best.label.isEmpty()==t.label.isEmpty())ambiguous=true;
            }
        }
        return ambiguous?null:best;
    }
    public static AccessibilityNodeInfo resolve(NodeTarget target,AccessibilityNodeIndex index) {
        if(!FlowSafety.safeTarget(target))return null;AccessibilityNodeInfo result=null;
        for(AccessibilityNodeInfo n:target.candidates(index))if(n.isEnabled() && target.matches(n,index.rootBounds(),true)) {
            if(result!=null)return null;result=n;
        }
        if(index.isTraversalIncomplete())return null;
        return result;
    }
}
