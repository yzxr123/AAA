package org.adguardian.app.flow;

import android.accessibilityservice.*;
import android.os.*;
import android.view.accessibility.*;
import java.io.IOException;
import java.util.UUID;
import java.util.function.Supplier;
import org.adguardian.app.engine.*;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.runtime.RootAccess;
import org.adguardian.app.settings.PreferenceStore;

/** Explicit multi-step teaching. No passive user tracking and no screenshots. */
public final class FlowTeachingController {
    private final AccessibilityService service;
    private final Handler worker,main=new Handler(Looper.getMainLooper());
    private final Supplier<String> foreground,activity;
    private final FlowReplayEngine engine;
    private final Runnable scan;
    private final FlowTeachingOverlay overlay;
    private volatile boolean active,saving,tainted,attempted,committed;
    private volatile long generation;
    private volatile FlowPage page;
    private volatile String status="尚未开始流程学习";
    private FlowJournal journal;
    private AdType type;
    private long oldTimeout=-1;
    private String versionPackage="";
    private long version=-1;
    private boolean polling;
    private final Object commitLock=new Object();
    public FlowTeachingController(AccessibilityService service,Handler handler,Supplier<String> foreground,Supplier<String> activity,FlowReplayEngine engine,Runnable scan) {
        this.service=service;worker=new Handler(handler.getLooper());this.foreground=foreground;this.activity=activity;this.engine=engine;this.scan=scan;overlay=new FlowTeachingOverlay(service,this::selectAt);
    }
    public boolean isActive(){return active;}
    public boolean isCategoryEnabled(){return type==null || PreferenceStore.isTypeEnabled(service,type);}
    public String status(){return status;}
    public boolean hasSession(){return attempted;}
    public void start(AdType type) {
        stop();this.type=type;tainted=false;committed=false;attempted=true;journal=new FlowJournal(type);page=null;versionPackage="";active=true;saving=false;long token=++generation;
        try{AccessibilityServiceInfo info=service.getServiceInfo();if(info!=null){oldTimeout=info.notificationTimeout;info.notificationTimeout=0;service.setServiceInfo(info);}}catch(RuntimeException ignored){}
        if(!overlay.show(this::beginPick,this::recordBack,this::finish,()->start(type),this::stop)){stop();status="无法显示流程学习提示";UserEventLog.error(service,status);return;}
        hint(token,"流程学习中 请打开广告 依次关闭每一层 没收到按钮时使用 选取下一步",false);
        main.postDelayed(()->{if(valid(token)){stop();status="流程学习已超时 没有保存本次操作";UserEventLog.record(service,status);}},180000);
        worker.post(scan);
    }
    private boolean valid(long token){return active && token==generation;}
    public void observe(String pkg,String pageActivity,AccessibilityNodeIndex index) {
        if(!active || saving || service.getPackageName().equals(pkg))return;
        long token=generation;
        try {
            FlowPage observed=capture(pkg,pageActivity,index);
            if(!valid(token))return;
            page=observed;int old=journal.stepCount();journal.observe(observed,SystemClock.uptimeMillis());
            if(journal.cancelled()){abort(token,"应用或屏幕方向已经变化 本次流程未保存");return;}
            if(journal.stepCount()>old)hint(token,"已确认第 "+journal.stepCount()+" 步 请继续关闭下一层 回到目标页面后点 完成并保存",true);
        }catch(RuntimeException unavailable){page=null;journal.observe(null,SystemClock.uptimeMillis());}
    }
    private FlowPage capture(String pkg,String pageActivity,AccessibilityNodeIndex index) {
        if(!pkg.equals(versionPackage)) {
            versionPackage=pkg;version=-1;
            try{version=service.getPackageManager().getPackageInfo(pkg,0).getLongVersionCode();}
            catch(android.content.pm.PackageManager.NameNotFoundException | RuntimeException unavailable){return null;}
        }
        index.startQueryBudget(40);
        try{return FlowPage.capture(pkg,pageActivity,version,index);}finally{index.clearQueryBudget();}
    }
    public void clicked(AccessibilityEvent event) {
        if(!active || saving || event==null)return;
        FlowPage before=page;String pkg=NodeTarget.string(event.getPackageName());long token=generation;
        if(service.getPackageName().equals(pkg))return;
        if(before==null || !before.pkg.equals(pkg) || SystemClock.uptimeMillis()-before.capturedAt>15000){markMissingStep(token,pkg);hint(token,"未取得操作前页面 请重新打开广告并点 选取下一步",false);return;}
        AccessibilityNodeInfo node=null;NodeTarget selected=null;
        try {
            node=event.getSource();
            for(int depth=0;node!=null && depth<4;depth++) {
                NodeTarget t=NodeTarget.captureSelected(node,before.bounds);
                if(t!=null){selected=before.find(t.forLearning());if(selected!=null)break;}
                AccessibilityNodeInfo parent=node.getParent();node.recycle();node=parent;
            }
        }catch(RuntimeException unavailable){}
        finally{if(node!=null)node.recycle();}
        if(selected==null){markMissingStep(token,pkg);worker.post(() -> {if(valid(token) && !journal.pending() && !tainted)hint(token,"未读取到这个关闭按钮 请用 选取下一步 先选再关",false);});return;}
        NodeTarget target=selected;worker.post(()->recordClick(token,before,target));
    }
    private void markMissingStep(long token,String pkg) {
        worker.post(() -> {
            if(valid(token) && !saving && !journal.pending() && journal.stepCount()>0 && pkg.equals(journal.targetPackage())) {
                tainted=true;
                hint(token,"刚才有一步未能记录 不能保存残缺流程 请重录并先选取关闭按钮",false);
            }
        });
    }
    private void recordClick(long token,FlowPage before,NodeTarget target) {
        if(!valid(token) || saving || !before.pkg.equals(foreground.get()))return;
        if(tainted){hint(token,"本次有漏记步骤 请重录 不会把残缺流程保存",false);return;}
        if(journal.pending())return;
        if(journal.stepCount()>=FlowJournal.MAX_STEPS){tainted=true;hint(token,"本次超过八步 未保存残缺流程 请取消",false);return;}
        if(!journal.beginClick(before,target)){hint(token,"这一步缺少唯一安全目标 或已达到八步 请重试或完成",journal.stepCount()>0);return;}
        hint(token,"第 "+(journal.stepCount()+1)+" 步按钮已记录 请手动关闭 当前界面确实变化后才会确认",false);poll(token);
    }
    private void beginPick() {
        if(!active || saving)return;
        long token=generation;
        worker.post(()->{if(!valid(token))return;if(journal.pending()){hint(token,"请先完成当前这一步 仍未关闭时可重录 不会跳过未完成步骤",false);return;}
            main.post(()->{if(valid(token)){overlay.select();hint(token,"轻点关闭按钮位置 这次只选取 然后请手动关闭",false);}});
        });
    }
    public void selectAt(float x,float y) {
        long token=generation;
        worker.post(()->{
            if(!valid(token) || saving || journal.pending())return;
            FlowPage fresh=fresh();if(fresh==null){hint(token,"无法读取完整广告页面 不会记录空白位置或整张画布",false);return;}
            NodeTarget target=fresh.pick(x,y);if(target==null){hint(token,"这里没有唯一可读取的小型关闭控件",false);return;}
            page=fresh;recordClick(token,fresh,target);
        });
    }
    public void recordBack() {
        long token=generation;
        worker.post(()->{
            if(!valid(token) || saving || journal.pending())return;
            if(tainted || journal.stepCount()>=FlowJournal.MAX_STEPS){tainted=true;hint(token,"本次步骤不完整或超过八步 请重录或取消",false);return;}
            FlowPage before=fresh();
            if(!valid(token) || saving || !PreferenceStore.isMasterEnabled(service) || !PreferenceStore.isLearnedEnabled(service) || !isCategoryEnabled())return;
            if(before==null || !before.pkg.equals(foreground.get()))return;
            if(!journal.beginBack(before)){hint(token,"返回需要先完成至少一个关闭步骤 不能在课表首页记录退出",journal.stepCount()>0);return;}
            boolean accepted=false;try{accepted=service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);}catch(RuntimeException unavailable){}
            if(!accepted){journal.discardPending();hint(token,"系统未执行返回 没有增加这一步",journal.stepCount()>0);return;}
            hint(token,"返回已记录 等待页面变化 如果没有变化请重录 不会假装成功",false);poll(token);
        });
    }
    private FlowPage fresh() {
        String pkg=foreground.get();if(pkg==null || pkg.isEmpty() || pkg.equals(service.getPackageName()))return null;
        AccessibilityNodeInfo root=RootAccess.readFor(service,pkg);
        try{if(root==null)return null;try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)){return capture(pkg,activity.get(),index);}}
        catch(RuntimeException unavailable){return null;}finally{if(root!=null)root.recycle();}
    }
    private void poll(long token) {
        if(polling)return;polling=true;
        worker.postDelayed(new Runnable(){public void run(){
            if(!valid(token) || saving || !journal.pending()){polling=false;return;}
            FlowPage observed=fresh();int old=journal.stepCount();
            if(observed!=null)page=observed;
            journal.observe(observed,SystemClock.uptimeMillis());
            if(journal.cancelled()){polling=false;abort(token,"已离开目标应用 本次流程未保存");return;}
            if(journal.stepCount()>old){polling=false;hint(token,"已确认第 "+journal.stepCount()+" 步 可继续关闭下一层 或完成并保存",true);scan.run();return;}
            worker.postDelayed(this,220);
        }},180);
    }
    public void finish() {
        if(!active || saving)return;long token=generation;
        if(tainted){hint(token,"本次有漏记步骤 请重录 不能保存为完整流程",false);return;}
        saving=true;
        hint(token,"正在复核结束页面",false);worker.post(()->verifyFinish(token,null));
    }
    private void verifyFinish(long token,FlowPage first) {
        if(!valid(token))return;
        if(tainted){saving=false;hint(token,"本次有漏记步骤 请重录",false);return;}
        if(!PreferenceStore.isMasterEnabled(service) || !PreferenceStore.isLearnedEnabled(service) || !PreferenceStore.isTypeEnabled(service,type)){saving=false;abort(token,"开关已关闭 本次流程未保存");return;}
        FlowPage now=fresh();
        if(now==null){saving=false;hint(token,"结束页面暂时无法读取 请留在目标页面后再保存",true);return;}
        journal.observe(now,SystemClock.uptimeMillis());
        if(first==null){worker.postDelayed(()->verifyFinish(token,now),180);return;}
        if(!first.sameScope(now) || !first.guard.matches(now.guard)){saving=false;hint(token,"页面仍在变化 请关闭剩余广告后再保存",true);return;}
        try {
            String label=service.getPackageManager().getApplicationLabel(service.getPackageManager().getApplicationInfo(now.pkg,0)).toString();
            LearnedFlow flow=journal.finish(UUID.randomUUID().toString(),label);
            synchronized(commitLock){if(!valid(token) || tainted)return;engine.store().add(flow);committed=true;}
            main.post(()->{if(valid(token)){stop();status="已保存 "+flow.steps.size()+" 步关闭流程 下次按相同页面条件执行";UserEventLog.record(service,status);}});
        }catch(IllegalStateException unfinished){saving=false;hint(token,"当前步骤尚未确认 或仍在广告页面 请完成关闭后再保存",true);poll(token);}
        catch(IOException | android.content.pm.PackageManager.NameNotFoundException | RuntimeException error){saving=false;hint(token,"流程保存失败 原有规则未改变",true);}
    }
    private void hint(long token,String value,boolean finish){if(!valid(token))return;status=value;main.post(()->{if(valid(token))overlay.text(value,finish&&!saving&&!tainted);});}
    private void abort(long token,String text){main.post(()->{if(valid(token)){stop();status=text;UserEventLog.warning(service,text);}});}
    public void stop() {
        boolean was;
        synchronized(commitLock){was=active;active=false;generation++;saving=false;page=null;polling=false;}
        worker.removeCallbacksAndMessages(null);main.removeCallbacksAndMessages(null);overlay.close();
        if(oldTimeout>=0)try{AccessibilityServiceInfo info=service.getServiceInfo();if(info!=null){info.notificationTimeout=oldTimeout;service.setServiceInfo(info);}}catch(RuntimeException ignored){}
        oldTimeout=-1;if(was){status=committed?"本次关闭流程已保存":"流程学习已结束 本次操作未保存";scan.run();}
    }
}
