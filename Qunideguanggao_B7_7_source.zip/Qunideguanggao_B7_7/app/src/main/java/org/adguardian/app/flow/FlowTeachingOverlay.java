package org.adguardian.app.flow;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.*;
import android.widget.*;

/** Main-thread owned overlay. Selection consumes only the explicit teaching tap. */
final class FlowTeachingOverlay {
    interface Selection {void at(float x,float y);}
    private final AccessibilityService service;
    private final Selection selection;
    private WindowManager windows;
    private LinearLayout panel;
    private TextView message;
    private Button finish;
    private View picker;
    private boolean top;
    FlowTeachingOverlay(AccessibilityService service,Selection selection){this.service=service;this.selection=selection;}
    boolean show(Runnable pick,Runnable back,Runnable save,Runnable retry,Runnable cancel) {
        windows=(WindowManager)service.getSystemService(Context.WINDOW_SERVICE);if(windows==null)return false;
        panel=new LinearLayout(service);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(8,8,8,8);panel.setBackgroundColor(Color.rgb(248,248,248));
        message=new TextView(service);message.setTextColor(Color.BLACK);message.setTextSize(14);panel.addView(message);
        LinearLayout row=row();button(row,"选取下一步",pick);button(row,"记录并返回",back);finish=button(row,"完成并保存",save);
        LinearLayout more=row();button(more,"移动提示条",()->{top=!top;try{windows.updateViewLayout(panel,params());}catch(RuntimeException ignored){}});button(more,"重录",retry);button(more,"取消",cancel);
        try{windows.addView(panel,params());return true;}catch(RuntimeException unavailable){close();return false;}
    }
    private LinearLayout row(){LinearLayout row=new LinearLayout(service);row.setOrientation(LinearLayout.HORIZONTAL);panel.addView(row);return row;}
    private Button button(LinearLayout row,String text,Runnable action){Button b=new Button(service);b.setText(text);b.setAllCaps(false);b.setOnClickListener(v->action.run());row.addView(b,new LinearLayout.LayoutParams(0,WindowManager.LayoutParams.WRAP_CONTENT,1f));return b;}
    private WindowManager.LayoutParams params(){WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);p.gravity=(top?Gravity.TOP:Gravity.BOTTOM)|Gravity.CENTER_HORIZONTAL;return p;}
    void text(String value,boolean canFinish){if(message!=null)message.setText(value);if(finish!=null)finish.setEnabled(canFinish);}
    void select() {
        removePicker();if(windows==null)return;
        View v=new View(service);v.setBackgroundColor(0x18000000);
        v.setOnTouchListener((view,event)->{
            if(event.getAction()==MotionEvent.ACTION_UP){float x=event.getRawX(),y=event.getRawY();removePicker();selection.at(x,y);view.performClick();}
            else if(event.getAction()==MotionEvent.ACTION_CANCEL)removePicker();return true;
        });
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.START;
        try{windows.addView(v,p);picker=v;}catch(RuntimeException unavailable){text("无法显示选取层 可以手动点击有文字的关闭按钮",false);}
    }
    private void removePicker(){if(picker!=null && windows!=null)try{windows.removeView(picker);}catch(RuntimeException ignored){}picker=null;}
    void close(){removePicker();if(panel!=null && windows!=null)try{windows.removeView(panel);}catch(RuntimeException ignored){}panel=null;message=null;finish=null;}
}
