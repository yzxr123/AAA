package org.adguardian.app.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.lang.ref.WeakReference;
import java.util.LinkedHashMap;
import java.util.function.Consumer;
import org.adguardian.app.runtime.AccessibilityState;
import org.adguardian.app.runtime.RootAccess;
import org.adguardian.app.runtime.RuntimeHealth;
import org.adguardian.app.learning.LearningController;
import org.adguardian.app.learning.LearnedRuleStore;
import org.adguardian.app.flow.FlowTeachingController;
import org.adguardian.app.flow.FlowStore;
import org.adguardian.app.engine.AccessibilityNodeIndex;
import org.adguardian.app.engine.AdType;
import org.adguardian.app.engine.PackagePolicy;
import org.adguardian.app.engine.RuleEngine;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.ocr.OcrFallbackController;
import org.adguardian.app.settings.PreferenceStore;

public final class AdAccessibilityService extends AccessibilityService {
    private static final long HOT_CONTENT_DEBOUNCE_MS=55L;
    private static final long IDLE_CONTENT_DEBOUNCE_MS=140L;
    private static volatile String lastObservedPackage="";
    private static volatile String lastObservedActivity="";
    public static String[] lastObservedPage() {return new String[]{lastObservedPackage,lastObservedActivity};}
    private static volatile WeakReference<AdAccessibilityService> activeService=new WeakReference<>(null);
    private final Handler mainHandler=new Handler(Looper.getMainLooper());
    private final Handler initializationResults=new Handler(Looper.getMainLooper());
    private boolean initializing;
    private final Object scanLock=new Object();
    private final LinkedHashMap<String,Boolean> activityCache=new LinkedHashMap<>(32,0.75f,true);
    private final Runnable retryScan=this::requestCurrentScan;
    private volatile RuleEngine ruleEngine;
    private PackagePolicy packagePolicy;
    private OcrFallbackController ocrController;
    private AccessibilityKeepAliveOverlay keepAliveOverlay;
    private volatile LearningController learning;
    private volatile FlowTeachingController flowLearning;
    private boolean connected;
    private volatile long connectionGeneration;
    private HandlerThread scanThread;
    private Handler scanHandler;
    private ScanRequest pendingScan;
    private boolean drainScheduled;
    private volatile boolean destroyed;
    private volatile String foregroundPackage="";
    private volatile String eventClass="";
    private volatile int foregroundWindow=-1;
    private String workerPackage="";
    private volatile String activityName="";
    private long lastContentRequest;
    private long lastUserClick;
    private long enteredAt;
    private long retryAt=Long.MAX_VALUE;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        if(connected)return;
        connected=true;destroyed=false;
        AccessibilityState.connected(this);
        RuntimeHealth.event(this,"系统已连接辅助功能服务");
        activeService=new WeakReference<>(this);
        keepAliveOverlay=new AccessibilityKeepAliveOverlay(this);
        updateKeepAlive();
        ProtectionService.sync(this);
        initializeRuntime();
    }
    private void initializeRuntime() {
        if(destroyed || !connected || initializing)return;
        initializing=true;
        final long token=++connectionGeneration;
        AccessibilityState.preparing(this);
        RuntimeHealth.event(this,"开始初始化规则引擎");
        try {
            AccessibilityServiceInfo info=getServiceInfo();
            if(info==null)info=new AccessibilityServiceInfo();
            info.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    |AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED|AccessibilityEvent.TYPE_WINDOWS_CHANGED
                    |AccessibilityEvent.TYPE_VIEW_SCROLLED|AccessibilityEvent.TYPE_VIEW_CLICKED;
            info.feedbackType=AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.notificationTimeout=60L;
            info.flags=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                    |AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                    |AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            info.packageNames=null;setServiceInfo(info);
            scanThread=new HandlerThread("AdRuleScan",Process.THREAD_PRIORITY_BACKGROUND);
            scanThread.start();scanHandler=new Handler(scanThread.getLooper());
            Handler worker=scanHandler;
            worker.post(() -> {
                try {
                    PackagePolicy policy=new PackagePolicy(this);
                    RuleEngine engine=new RuleEngine(this,worker,this::requestCurrentScan,() -> foregroundPackage);
                    // This completion is not removed by UI/task teardown. A stale result must close its engine.
                    initializationResults.post(() -> {
                        if(destroyed || token!=connectionGeneration || !connected) {engine.close();return;}
                        try {
                            ruleEngine=engine;packagePolicy=policy;
                            ocrController=new OcrFallbackController(this,engine,worker,() -> foregroundPackage);
                            learning=new LearningController(this,worker,() -> foregroundPackage,engine.learned(),
                                    () -> worker.post(this::requestCurrentScan));
                            flowLearning=new FlowTeachingController(this,worker,() -> foregroundPackage,
                                    () -> activityName,engine.flows(),() -> worker.post(this::requestCurrentScan));
                            initializing=false;AccessibilityState.initialized(this,true);
                            RuntimeHealth.event(this,"规则引擎已就绪");
                            ProtectionService.sync(this);worker.post(this::requestCurrentScan);
                        } catch(RuntimeException error) {initializationFailed(token,error);}
                    });
                } catch(RuntimeException error) {initializationResults.post(() -> initializationFailed(token,error));}
            });
        } catch(RuntimeException error) {initializationFailed(token,error);}
    }
    private void initializationFailed(long token,RuntimeException error) {
        if(destroyed || token!=connectionGeneration || !connected)return;
        initializing=false;AccessibilityState.initialized(this,false);
        RuntimeHealth.failure(this,"规则初始化失败",error);
        UserEventLog.error(this,"广告保护初始化失败 权限仍然保留 请点检查并恢复服务");
    }

    public static String learningStatus() {
        AdAccessibilityService current=activeService.get();
        if(current==null)return "学习服务尚未连接";
        if(current.flowLearning!=null && current.flowLearning.isActive())return current.flowLearning.status();
        if(current.learning!=null && current.learning.isActive())return current.learning.status();
        if(current.flowLearning!=null && current.flowLearning.hasSession())return current.flowLearning.status();
        return current.learning!=null?current.learning.status():"尚未开始学习";
    }
    public static boolean beginLearning(AdType type) {
        AdAccessibilityService current=activeService.get();
        if(current==null || current.destroyed || current.learning==null || !AccessibilityState.read(current).running())return false;
        PreferenceStore.setLearnedEnabled(current,true);
        if(current.flowLearning!=null)current.flowLearning.stop();
        current.ocrController.endSession();
        current.learning.start(type);
        current.scanHandler.post(() -> {if(current.destroyed || current.ruleEngine==null)return;current.ruleEngine.onSettingsChanged();current.cancelRetry();current.requestCurrentScan();});
        return current.learning.isActive();
    }
    private boolean teachingActive() {
        return (flowLearning!=null && flowLearning.isActive()) || (learning!=null && learning.isActive());
    }
    public static boolean beginFlowLearning(AdType type) {
        AdAccessibilityService current=activeService.get();
        if(current==null || current.destroyed || current.flowLearning==null || !AccessibilityState.read(current).running())return false;
        PreferenceStore.setLearnedEnabled(current,true);
        if(current.learning!=null)current.learning.stop();
        current.ocrController.endSession();
        current.flowLearning.start(type);
        current.scanHandler.post(() -> {
            if(current.destroyed || current.ruleEngine==null)return;
            current.ruleEngine.onSettingsChanged();current.cancelRetry();current.requestCurrentScan();
        });
        return current.flowLearning.isActive();
    }
    public static void withLearnedFlows(Consumer<FlowStore> action,Runnable completed) {
        AdAccessibilityService current=activeService.get();
        if(current==null || current.destroyed || current.ruleEngine==null){completed.run();return;}
        current.scanHandler.post(() -> {
            if(current.destroyed || current.ruleEngine==null){current.mainHandler.post(completed);return;}
            try{action.accept(current.ruleEngine.flows().store());}
            catch(RuntimeException error){RuntimeHealth.failure(current,"关闭流程管理失败",error);}
            finally{current.mainHandler.post(completed);}
        });
    }
    public static void withLearnedRules(Consumer<LearnedRuleStore> action,Runnable completed) {
        AdAccessibilityService current=activeService.get();
        if(current==null || current.destroyed || current.ruleEngine==null) {completed.run();return;}
        current.scanHandler.post(() -> {
            if(current.destroyed || current.ruleEngine==null) {current.mainHandler.post(completed);return;}
            try {action.accept(current.ruleEngine.learned().store());}
            catch(RuntimeException error) {RuntimeHealth.failure(current,"学习规则管理失败",error);}
            finally {current.mainHandler.post(completed);}
        });
    }
    public static void retryInitialization() {
        AdAccessibilityService current=activeService.get();
        if(current==null || current.destroyed)return;
        current.mainHandler.post(() -> {
            AccessibilityState.Snapshot state=AccessibilityState.read(current);
            if(!state.failed)return;
            current.disposeRuntime();
            current.initializeRuntime();
        });
    }

    public static void notifySettingsChanged() {
        AdAccessibilityService current=activeService.get();
        if(current==null) {AccessibilityState.changed();return;}
        current.mainHandler.post(() -> {
            if(current.destroyed)return;
            if(current.ocrController!=null)current.ocrController.onSettingsChanged();
            current.updateKeepAlive();
            ProtectionService.sync(current);
            AccessibilityState.changed();
            if(current.learning!=null && (!PreferenceStore.isMasterEnabled(current) || !PreferenceStore.isLearnedEnabled(current)))current.learning.stop();
            if(current.flowLearning!=null && (!PreferenceStore.isMasterEnabled(current)
                    || !PreferenceStore.isLearnedEnabled(current) || !current.flowLearning.isCategoryEnabled()))current.flowLearning.stop();
            Handler worker=current.scanHandler;
            if(worker!=null)worker.post(() -> {
                if(current.ruleEngine!=null)current.ruleEngine.onSettingsChanged();
                current.cancelRetry();
                current.requestCurrentScan();
            });
        });
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        try {handleAccessibilityEvent(event);}
        catch(RuntimeException error) {RuntimeHealth.failure(this,"辅助事件处理失败",error);}
    }
    private void handleAccessibilityEvent(AccessibilityEvent event) {
        if(destroyed || event==null || ruleEngine==null || packagePolicy==null || ocrController==null)return;
        if(!PreferenceStore.isMasterEnabled(this))return;
        long now=SystemClock.uptimeMillis();
        int type=event.getEventType();
        if(type==AccessibilityEvent.TYPE_VIEW_CLICKED) {
            if(flowLearning!=null && flowLearning.isActive()){flowLearning.clicked(event);return;}
            if(learning!=null && learning.isActive()) {learning.clicked(event);return;}
            if(event.getPackageName()!=null && getPackageName().contentEquals(event.getPackageName()))return;
            if(!ocrController.isLikelyAutomatedClick(now)) {
                lastUserClick=now;
                ocrController.noteUserInteraction();
                scanHandler.post(() -> {if(ruleEngine!=null)ruleEngine.onUserInteraction();});
            }
            return;
        }
        boolean state=type==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        boolean windows=type==AccessibilityEvent.TYPE_WINDOWS_CHANGED;
        boolean content=type==AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
        boolean scroll=type==AccessibilityEvent.TYPE_VIEW_SCROLLED;
        if(!state && !windows && !content && !scroll)return;
        ocrController.noteUiEvent();
        String pkg=event.getPackageName()==null?foregroundPackage:event.getPackageName().toString();
        if(pkg.isEmpty())return;
        if(!state && !pkg.equals(foregroundPackage)) {
            requestReconcile();return;
        }
        if(getPackageName().equals(pkg)) {
            if(state && "org.adguardian.app.MainActivity".contentEquals(event.getClassName()==null?"":event.getClassName())) {
                foregroundPackage=pkg;eventClass="";ocrController.endSession();
                enqueue(new ScanRequest(pkg,"",type,false));
            }
            return;
        }
        boolean changed=!pkg.equals(foregroundPackage);
        boolean windowChanged=state || (windows && foregroundWindow!=event.getWindowId());
        if(changed && !foregroundPackage.isEmpty() && packagePolicy.allow(pkg)
                && !teachingActive()
                && ocrController.shouldUndoCrossAppJump(foregroundPackage,pkg,now,lastUserClick)) {
            ocrController.consumeJumpRisk();
            if(performGlobalAction(GLOBAL_ACTION_BACK)) {
                UserEventLog.record(this,"已尝试返回广告跳转 请确认是否回到原应用");
                mainHandler.postDelayed(this::requestReconcile,250L);
                return;
            }
        }
        if(changed) {
            foregroundPackage=pkg;
            eventClass="";
            enteredAt=now;
            lastContentRequest=0;
            ocrController.endSession();
            if(packagePolicy.allow(pkg) && !teachingActive())ocrController.beginSession(pkg,"");
        }
        if(state && event.getClassName()!=null)eventClass=event.getClassName().toString();
        foregroundWindow=event.getWindowId();
        if(!packagePolicy.allow(pkg)) {
            if(changed)enqueue(new ScanRequest(pkg,"",type,false));
            return;
        }
        if(content && !changed) {
            long lastAction=ruleEngine.lastAutomatedActionUptime();
            boolean hot=now-enteredAt<5000L || (lastAction>0 && now-lastAction<3000L);
            long debounce=hot?HOT_CONTENT_DEBOUNCE_MS:IDLE_CONTENT_DEBOUNCE_MS;
            if(now-lastContentRequest<debounce)return;
            lastContentRequest=now;
        }
        enqueue(new ScanRequest(pkg,eventClass,type,windowChanged && !changed));
    }

    private void enqueue(ScanRequest request) {
        Handler worker=scanHandler;
        if(worker==null || destroyed)return;
        synchronized(scanLock) {
            if(pendingScan!=null && pendingScan.packageName.equals(request.packageName)) {
                request=new ScanRequest(request.packageName,request.className,request.type,
                        request.popupProbe || pendingScan.popupProbe);
            }
            pendingScan=request;
            if(drainScheduled)return;
            drainScheduled=true;
        }
        worker.post(this::drainOne);
    }

    private void drainOne() {
        ScanRequest request;
        synchronized(scanLock) { request=pendingScan;pendingScan=null; }
        try {
            if(request!=null && !destroyed && ruleEngine!=null && PreferenceStore.isMasterEnabled(this))scan(request);
        } catch(RuntimeException error) {
            RuntimeHealth.failure(this,"广告规则扫描失败",error);
            UserEventLog.error(this,"广告保护暂时遇到问题");
        } finally {
            synchronized(scanLock) {
                if(pendingScan==null || destroyed) { drainScheduled=false;return; }
            }
            Handler worker=scanHandler;
            if(worker!=null)worker.post(this::drainOne);
        }
    }

    private void scan(ScanRequest request) {
        if(!request.packageName.equals(foregroundPackage))return;
        if(!request.packageName.equals(workerPackage)) {
            cancelRetry();
            workerPackage=request.packageName;
            activityName="";
            ruleEngine.onPackageEntered(workerPackage);
        }
        if(packagePolicy==null || !packagePolicy.allow(workerPackage))return;
        if(!request.className.isEmpty() && isActivity(workerPackage,request.className))activityName=request.className;
        AccessibilityNodeInfo root=RootAccess.readFor(this,workerPackage);
        try {
            if(root==null || root.getPackageName()==null || !workerPackage.contentEquals(root.getPackageName()))return;
            String app=workerPackage;
            String activity=activityName;
            lastObservedPackage=app;lastObservedActivity=activity;
            if(flowLearning!=null && flowLearning.isActive()) {
                try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)){flowLearning.observe(app,activity,index);}
                return;
            }
            if(learning!=null && learning.isActive()) {
                try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)) {learning.observe(app,activity,index);}
                return;
            }
            boolean handled=ruleEngine.handle(app,activity,request.type,root);
            scheduleRetry(ruleEngine.nextWakeUp());
            mainHandler.post(() -> {
                if(destroyed || !app.equals(foregroundPackage) || ocrController==null)return;
                ocrController.updateActivity(activity);
                if(handled)ocrController.endSession();
                else if(request.popupProbe)ocrController.beginPopupProbe(app,activity);
            });
        } finally { if(root!=null)root.recycle(); }
    }

    private void requestReconcile() {
        Handler worker=scanHandler;
        if(worker==null || destroyed)return;
        worker.post(() -> {
            if(destroyed)return;
            AccessibilityNodeInfo root=RootAccess.read(this);
            try {
                if(root==null || root.getPackageName()==null)return;
                String pkg=root.getPackageName().toString();
                if(getPackageName().equals(pkg) || pkg.equals(foregroundPackage))return;
                foregroundPackage=pkg;eventClass="";foregroundWindow=root.getWindowId();enteredAt=SystemClock.uptimeMillis();
                enqueue(new ScanRequest(pkg,"",AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,false));
            } finally {if(root!=null)root.recycle();}
        });
    }
    private boolean isActivity(String pkg,String name) {
        String key=pkg+"/"+name;
        Boolean cached=activityCache.get(key);
        if(cached!=null)return cached;
        boolean found;
        try {
            getPackageManager().getActivityInfo(new ComponentName(pkg,name),0);
            found=true;
        } catch(PackageManager.NameNotFoundException error) { found=false; }
        catch(RuntimeException unavailable) {return false;}
        activityCache.put(key,found);
        if(activityCache.size()>128)activityCache.remove(activityCache.keySet().iterator().next());
        return found;
    }

    private void scheduleRetry(long delay) {
        if(delay<0) { cancelRetry();return; }
        long due=SystemClock.uptimeMillis()+Math.max(60L,delay);
        if(retryAt<=due)return;
        scanHandler.removeCallbacks(retryScan);
        retryAt=due;
        scanHandler.postAtTime(retryScan,due);
    }
    private void cancelRetry() {
        retryAt=Long.MAX_VALUE;
        if(scanHandler!=null)scanHandler.removeCallbacks(retryScan);
    }
    private void requestCurrentScan() {
        cancelRetry();
        if(destroyed || !PreferenceStore.isMasterEnabled(this))return;
        if(foregroundPackage.isEmpty()) {
            AccessibilityNodeInfo root=RootAccess.read(this);
            try { if(root!=null && root.getPackageName()!=null)foregroundPackage=root.getPackageName().toString(); }
            finally { if(root!=null)root.recycle(); }
        }
        if(!foregroundPackage.isEmpty())enqueue(new ScanRequest(foregroundPackage,eventClass,
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,false));
    }
    private void updateKeepAlive() {
        if(keepAliveOverlay==null)return;
        if(PreferenceStore.isMasterEnabled(this) && PreferenceStore.isKeepAliveEnabled(this))keepAliveOverlay.attach();
        else keepAliveOverlay.detach();
    }
    @Override public void onTaskRemoved(Intent rootIntent) {
        RuntimeHealth.event(this,"最近任务被移除 服务未主动停止");updateKeepAlive();super.onTaskRemoved(rootIntent);
    }
    @Override public void onInterrupt() {
        if(ocrController!=null)ocrController.endSession();
        if(flowLearning!=null)flowLearning.stop();
        Handler worker=scanHandler;
        if(worker!=null)worker.post(() -> {if(ruleEngine!=null)ruleEngine.onUserInteraction();});
    }
    @Override public boolean onUnbind(Intent intent) {
        releaseConnection();
        return super.onUnbind(intent);
    }
    private void releaseConnection() {
        if(destroyed && !connected)return;
        destroyed=true;connected=false;
        RuntimeHealth.event(this,"辅助功能服务断开 系统授权另行核对");
        AccessibilityState.disconnected(this);
        disposeRuntime();
        if(keepAliveOverlay!=null)keepAliveOverlay.detach();keepAliveOverlay=null;
        if(activeService.get()==this)activeService.clear();
    }
    private void disposeRuntime() {
        connectionGeneration++;initializing=false;
        if(flowLearning!=null)flowLearning.stop();flowLearning=null;
        if(learning!=null)learning.stop();learning=null;
        if(ocrController!=null)ocrController.stop();ocrController=null;
        mainHandler.removeCallbacksAndMessages(null);
        Handler worker=scanHandler;HandlerThread thread=scanThread;RuleEngine engine=ruleEngine;
        ruleEngine=null;packagePolicy=null;scanHandler=null;scanThread=null;
        foregroundPackage="";workerPackage="";activityName="";eventClass="";activityCache.clear();
        retryAt=Long.MAX_VALUE;
        if(worker!=null) {
            worker.removeCallbacksAndMessages(null);
            worker.post(() -> {try {if(engine!=null)engine.close();}finally {if(thread!=null)thread.quitSafely();}});
        }
        synchronized(scanLock) {pendingScan=null;drainScheduled=false;}
    }
    @Override public void onDestroy() {
        releaseConnection();super.onDestroy();
    }
    private static final class ScanRequest {
        final String packageName;
        final String className;
        final int type;
        final boolean popupProbe;
        ScanRequest(String pkg,String name,int type,boolean popupProbe) {
            this.packageName=pkg;
            this.className=name;
            this.type=type;
            this.popupProbe=popupProbe;
        }
    }
}
