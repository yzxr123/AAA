import android.content.*;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.service.*;
import org.adguardian.app.settings.PreferenceStore;
public class ServiceFlowB77Tests {
 static void event(AdAccessibilityService s,int type,String activity,AccessibilityNodeInfo source,long now){
  SystemClock.now=now;AccessibilityEvent e=new AccessibilityEvent();e.type=type;e.pkg="host.example";e.name=activity;e.source=source;s.onAccessibilityEvent(e);Handler.advance(now);
 }
 static AdAccessibilityService create(RegressionB76Tests.Windows windows)throws Exception {
  AdAccessibilityService s=new AdAccessibilityService();s.services.put(Context.WINDOW_SERVICE,windows);s.root=FlowsB77Tests.page("video","跳过");
  PreferenceStore.setGkdEnabled(s,false);PreferenceStore.setLiTiaotiaoEnabled(s,false);PreferenceStore.setOcrEnabled(s,false);
  RegressionB76Tests.authorize(s);java.lang.reflect.Method connect=AdAccessibilityService.class.getDeclaredMethod("onServiceConnected");connect.setAccessible(true);connect.invoke(s);Handler.advance(10000);
  event(s,32,"host.example.Ad",null,10100);return s;
 }
 public static void main(String[] args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("real service intake records two stages and exposes saved flows through management",()->{
   RegressionB76Tests.Windows windows=new RegressionB76Tests.Windows();AdAccessibilityService s=create(windows);
   FlowsB77Tests.check(AdAccessibilityService.beginFlowLearning(AdType.POPUP),"service cannot begin flow teaching");Handler.advance(10200);
   event(s,1,"android.widget.TextView",s.root.children.get(1),10300);
   s.root=FlowsB77Tests.page("endcard","关闭");event(s,32,"host.example.Ad",null,10400);Handler.advance(10650);
   event(s,1,"android.widget.TextView",s.root.children.get(1),10700);
   s.root=FlowsB77Tests.page("home",null);event(s,32,"host.example.Main",null,10800);Handler.advance(11050);
   View finish=RegressionB76Tests.button(windows.panel,"完成并保存");FlowsB77Tests.check(finish!=null&&finish.isEnabled(),"service did not confirm second step: "+AdAccessibilityService.learningStatus());
   finish.performClick();Handler.advance(11100);Handler.advance(11400);
   final int[] count={0};AdAccessibilityService.withLearnedFlows(store->{FlowsB77Tests.check(store.all().size()==1,"no managed lesson");count[0]=store.all().get(0).steps.size();},()->{});Handler.advance(11450);
   FlowsB77Tests.check(count[0]==2,"service persisted a single-button instead of two-step flow");s.onDestroy();Handler.advance(11500);
  });
  FlowsB77Tests.run("service interruption stops active teaching and removes its controls",()->{
   RegressionB76Tests.Windows windows=new RegressionB76Tests.Windows();AdAccessibilityService s=create(windows);
   AdAccessibilityService.beginFlowLearning(AdType.POPUP);Handler.advance(10200);s.onInterrupt();Handler.advance(10300);
   FlowsB77Tests.check(RegressionB76Tests.button(windows.panel,"选取下一步")==null,"interrupt left active teaching control");
   FlowsB77Tests.check(new FlowStore(s).all().isEmpty(),"interrupt saved an incomplete recording");s.onDestroy();Handler.advance(10400);
  });
  System.out.println("B7.7 service flow cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);if(FlowsB77Tests.fail>0)throw new AssertionError("service flow regressions");
 }
}
