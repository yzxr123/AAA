#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID = '{http://schemas.android.com/apk/res/android}'

def require(condition, message):
    if not condition:
        raise SystemExit('ERROR: ' + message)

def text(name):
    return (ROOT/name).read_text(encoding='utf-8')

def main():
    for path in (ROOT/'app/src/main').rglob('*.xml'):
        ET.parse(path)
    manifest = ET.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot()
    permissions = {item.get(ANDROID+'name') for item in manifest.findall('uses-permission')}
    require('android.permission.INTERNET' not in permissions, 'Runtime INTERNET permission must remain absent')
    service = manifest.find('application/service')
    require(service is not None and service.get(ANDROID+'permission') == 'android.permission.BIND_ACCESSIBILITY_SERVICE', 'Missing system-bound accessibility service')
    require(service.get(ANDROID+'stopWithTask') == 'false', 'Closing UI task must not explicitly stop accessibility service')
    config = ET.parse(ROOT/'app/src/main/res/xml/accessibility_service_config.xml').getroot()
    require(config.get(ANDROID+'canPerformGestures') == 'true' and config.get(ANDROID+'canTakeScreenshot') == 'true', 'Missing optional action/screenshot capability')
    require('typeAllMask' not in config.get(ANDROID+'accessibilityEventTypes',''), 'Unbounded event subscription regressed')
    app_build = text('app/build.gradle')
    require("versionName '0.7.7-b7.7'" in app_build and 'versionCode 27' in app_build, 'Version mismatch')
    require("implementation project(':gkd-core')" in app_build, 'Real GKD selector module not linked into APK')
    require('minifyEnabled true' in app_build and 'shrinkResources true' in app_build, 'Release shrinking missing')
    require("abiFilters 'arm64-v8a'" in app_build, 'Unexpected ABI changes')
    require('Tesseract4Android:tesseract4android:4.9.0' in app_build, 'OCR dependency differs')
    require("id 'org.jetbrains.kotlin.jvm' version '2.3.10'" in text('build.gradle'), 'Kotlin CI toolchain differs')
    strings = ET.parse(ROOT/'app/src/main/res/values/strings.xml').getroot()
    require(next(x.text for x in strings if x.get('name')=='app_name') == '去你的广告', 'App display name mismatch')
    for folder in ('mipmap-mdpi','mipmap-hdpi','mipmap-xhdpi','mipmap-xxhdpi','mipmap-xxxhdpi'):
        require((ROOT/'app/src/main/res'/folder/'ic_launcher.png').is_file(), 'Launcher icon missing: '+folder)
    hashes = {
        'AllRules.json':'0623ae015e6868828f391e4f2f4fae3eec1f2d83e407e19dfc197b8d96d201f9',
        'BasicRules.json':'f905a2b066459d25ca89502536b27428940856b4e8df980d0f35a68ac88893ca',
        'ExtendedRules.json':'2cde4b84cbb7e3b38f82240d5cb1850337960480f2b857e6a1434e754cd89ce9',
    }
    for name,digest in hashes.items():
        require(hashlib.sha256((ROOT/'app/src/main/assets/ltt'/name).read_bytes()).hexdigest()==digest,'LiTiaotiao raw bytes changed: '+name)
    for script in ('build_gkd_bundle.py','prepare_gkd_selector.py'):
        subprocess.run([sys.executable,str(ROOT/'tools'/script),'--check'],cwd=ROOT,check=True)
    gkd=json.loads(text('app/src/main/assets/gkd/manifest.json'))
    require(tuple(gkd[k] for k in ('app_count','group_count','rule_count','selector_count'))==(753,1334,2445,2600),'GKD coverage unexpectedly changed')
    production='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'app/src/main/java').rglob('*.java'))
    for obsolete in ('com.google.mlkit','TextRecognition','YoloSkipDetector','LocalDnsVpnService','AdDomainBlocklist'):
        require(obsolete not in production,'obsolete runtime remains: '+obsolete)
    require(not (ROOT/'app/src/main/cpp/yolo_jni.cpp').exists(),'Obsolete YOLO native source remains')
    for name in ('gkd/GkdNodeAdapter.java','gkd/GkdRuleRepository.java','gkd/GkdSubscriptionEngine.java','ocr/HardwareScreenshotReducer.java'):
        require((ROOT/'app/src/main/java/org/adguardian/app'/name).is_file(),'Required runtime missing: '+name)
    workflow=text('.github/workflows/build-apk.yml')
    for required in ('Build 去你的广告 B7.7','Qunideguanggao-B7.7.apk',':gkd-core:verifyGkdRuntime',':gkd-core:verifyAndroidHost','assembleRelease','52428800','50 MiB','tools/clean_legacy_sources.py'):
        require(required in workflow,'Active workflow missing: '+required)
    require('B4.3' not in workflow and 'B7.3' not in workflow,'Old active workflow remains')
    require((ROOT/'dev-signing.jks').is_file(),'Stable development signing missing')
    model=ROOT/'app/src/main/assets/tessdata/chi_sim.traineddata'
    if model.exists():
        require(hashlib.sha256(model.read_bytes()).hexdigest()=='a5fcb6f0db1e1d6d8522f39db4e848f05984669172e584e8d76b6b3141e1f730','OCR model changed')
    services={item.get(ANDROID+'name'):item for item in manifest.findall('application/service')}
    guard=services.get('org.adguardian.app.service.ProtectionService')
    require(guard is not None and guard.get(ANDROID+'exported')=='false' and guard.get(ANDROID+'stopWithTask')=='false', 'Background protection must be a separate non-exported service')
    require(guard.get(ANDROID+'foregroundServiceType')=='specialUse','Missing foreground type')
    require({'android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_SPECIAL_USE','android.permission.RECEIVE_BOOT_COMPLETED'}<=permissions,'Missing foreground or boot declarations')
    require('Settings.Secure.putString' not in production and 'WRITE_SECURE_SETTINGS' not in permissions,'Do not force accessibility grants')
    for name in ('runtime/AccessibilityState.java','runtime/RootAccess.java','runtime/RuntimeHealth.java','learning/LearningPage.java','engine/ActionVerifier.java','learning/LearningController.java','learning/LearnedRuleEngine.java','learning/LearnedRuleStore.java'):
        require((ROOT/'app/src/main/java/org/adguardian/app'/name).is_file(),'Missing B7.7 implementation: '+name)
    require('RuntimeLearningB75Tests.main' in text('tests/android-host/BackendTests.java'),'New behavioral tests not included in CI')
    require('RegressionB76Tests.main' in text('tests/android-host/BackendTests.java'),'B7.6 regressions are not part of CI')
    require("exclude '**/MainActivity.java'" not in text('gkd-core/build.gradle'),'UI must compile in host API checks too')
    for name in ('flow/FlowTeachingController.java','flow/FlowReplayEngine.java','flow/FlowStore.java','classapp/ClassAdEngine.java','engine/AdCloseText.java'):
        require((ROOT/'app/src/main/java/org/adguardian/app'/name).is_file(),'Missing B7.7 implementation: '+name)
    for case in ('ClassTextB77Tests','ClassAdapterB77Tests','FlowsB77Tests','FlowEdgesB77Tests','TeachingB77Tests','IntegrationB77Tests','ServiceFlowB77Tests'):
        require(case+'.main' in text('tests/android-host/BackendTests.java'),'B7.7 case not included in CI: '+case)
    print('去你的广告 B7.7 project structure and source checks passed')
    print('GKD: 753 apps / 1334 advertisement groups / 2445 rules / 2600 selector expressions')
    print('Runtime INTERNET permission: none')
    print('APK ceiling: 50 MiB (not a RAM measurement)')

if __name__ == '__main__':
    main()
