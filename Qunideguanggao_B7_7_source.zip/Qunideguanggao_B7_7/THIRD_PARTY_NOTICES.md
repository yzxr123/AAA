# Third-party source inventory

## LiTiaotiao rule repository
User input LiTiaotiao-main.zip
Raw AllRules BasicRules ExtendedRules remain byte-identical in app/src/main/assets/ltt
Original repository license is retained in third_party/litiaotiao/LICENSE
No protected APK payload is embedded or loaded

## GKD selector and reference implementation
User input gkd-main.zip
Original selector sources and license remain in third_party/gkd-selector
Syntax-adapted JVM sources are generated in gkd-core
Original-to-generated SHA256 mapping is in gkd-core/source-manifest.json
Selected runtime files retained as reference in third_party/gkd-runtime-reference
RuleSession and Android lifecycle/action bridge are project-specific implementations

## GKD subscription
User input GKD_subscription-main.zip
Original JSON5 and upstream README retained in third_party/gkd_subscription
Frozen normalized JSON has verified semantic equivalence with original JSON5
Only four advertisement category groups are included in APK assets

## Tesseract
Tesseract4Android 4.9.0 remains a build dependency
chi_sim tessdata_fast is fetched at build time and checked against its frozen SHA256
No OCR telemetry or runtime download is enabled
