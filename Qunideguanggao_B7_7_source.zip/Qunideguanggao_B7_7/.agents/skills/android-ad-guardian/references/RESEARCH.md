# B7.7 研究依据

CLASS相关证据与方法在 docs/B7.7-implementation.md
本轮读取上传的 base(1).apk 而不是从公开下载站换一个版本
SHA256 9a64abc67f1ca5cfa55c644140af47caa5d8995da996c49e0a786a0bd8765638
三份DEX的校验通过 补充读取599个广告或业务相关方法的调用引用
没有把静态调用链等价成全部远程广告模板的真实运行

SDK onAdClose会转发业务onAdDismiss与onSkip
视频完成 跳过视频 与最终关闭不是同一事件
服务侧只能观察控件和页面 不可以声称直接收到了目标APK内部回调

官方API与GKD原始实现的参考地址在本轮实施报告
既有后台问题的GitHub依据继续保留于 docs/B7.6-audit.md
