import os
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest
import zipfile


ROOT = Path(__file__).resolve().parents[1]
REQUIRED = (
    'settings.gradle', 'build.gradle', 'gradle.properties', 'app/build.gradle',
    'app/src/main/AndroidManifest.xml', 'gkd-core/build.gradle', 'dev-signing.jks',
    'tools/clean_legacy_sources.py', 'tools/validate_project.py',
    'tools/build_gkd_bundle.py', 'tools/prepare_gkd_selector.py',
    'tools/fetch_ocr_data.py', 'app/src/main/assets/gkd/manifest.json',
    'app/src/main/assets/ltt/AllRules.json',
    'app/src/main/assets/ltt/BasicRules.json',
    'app/src/main/assets/ltt/ExtendedRules.json',
    'tests/test_subscription_bundle.py',
    'app/src/main/java/org/adguardian/app/flow/FlowTeachingController.java',
    'app/src/main/java/org/adguardian/app/flow/FlowReplayEngine.java',
    'app/src/main/java/org/adguardian/app/classapp/ClassAdEngine.java',
    'tests/android-host/TeachingB77Tests.java',
    'app/src/main/java/org/adguardian/app/runtime/ActivityTracker.java',
    'app/src/main/java/org/adguardian/app/runtime/PackageVersionLookup.java',
    'app/src/main/java/org/adguardian/app/runtime/ScanDiagnostics.java',
    'tests/android-host/RegressionB78Tests.java',
    'app/src/main/assets/class/cn.luyiyuntech.stt_1013.json',
    'app/src/main/java/org/adguardian/app/classapp/ClassAdRules.java',
    'app/src/main/java/org/adguardian/app/flow/TeachingHistory.java',
    'tools/validate_class_rules.py',
    'tests/android-host/RegressionB79Tests.java',
    'app/src/main/java/org/adguardian/app/recording/RecordingDraft.java',
    'app/src/main/java/org/adguardian/app/recording/RecordingDraftStore.java',
    'app/src/main/java/org/adguardian/app/recording/RecordingSession.java',
    'app/src/main/java/org/adguardian/app/runtime/DisplayRotation.java',
    'tests/android-host/RegressionB710Tests.java',
    'tests/android-host/RecordingB710Tests.java',
    'tests/android-host/FinalB710Tests.java',
    'app/src/main/java/org/adguardian/app/runtime/AccessibilityRecovery.java',
    'app/src/main/java/org/adguardian/app/service/ProtectionOverlay.java',
    'tests/android-host/FinalizationB711Tests.java',
    'tests/android-host/RecoveryB711Tests.java',
    'tests/android-host/OverlayB711Tests.java',
    'tests/android-host/ReviewB711Tests.java',
    'tests/android-host/ClassCompletionB711Tests.java',
    'tests/android-host/RecoveryBoundaryB711Tests.java',
    'app/src/main/java/org/adguardian/app/sdk/AdSdkCatalog.java',
    'app/src/main/java/org/adguardian/app/sdk/DexSdkScanner.java',
    'app/src/main/java/org/adguardian/app/sdk/InstalledSdkInventory.java',
    'app/src/main/java/org/adguardian/app/sdk/SdkAdEngine.java',
    'tests/android-host/AuditB712Tests.java',
    'tests/android-host/SdkB712Tests.java',
    'tests/android-host/SdkRuntimeB712Tests.java',
    'tests/android-host/InventoryB712Tests.java',
    'app/src/main/java/org/adguardian/app/flow/FlowObservation.java',
    'app/src/main/java/org/adguardian/app/flow/FlowCondition.java',
    'app/src/main/java/org/adguardian/app/flow/FlowTransition.java',
    'app/src/main/java/org/adguardian/app/recording/RecordingIssue.java',
    'app/src/main/java/org/adguardian/app/recording/RecordBackup.java',
    'app/src/main/java/org/adguardian/app/classapp/ClassStageDiagnostics.java',
    'tests/android-host/ResearchB713Tests.java',
    'tests/android-host/ReviewAndSafetyB713Tests.java',
    'tests/android-host/ClassRecoveryB713Tests.java',
    'tests/android-host/BoundaryB713Tests.java',
    'tests/test_b713_contract.py',
    'tools/report_lint.py',
    'tests/test_b714_lint.py',
    'tests/android-host/LogicB714Tests.java',
    'app/src/main/java/org/adguardian/app/engine/JumpGuard.java',
    'app/src/main/java/org/adguardian/app/ocr/OcrActionPolicy.java',
    'app/src/main/java/org/adguardian/app/ocr/OcrTextEvidence.java',
    'tests/android-host/DemoB715Tests.java',
    'tests/android-host/LearningUiB715Tests.java',
    'tests/android-host/RecordingCapacityB715Tests.java',

)


def fixture(version='0.7.15-b7.15', code=35):
    data = {name: b'fixture\n' for name in REQUIRED}
    data['app/build.gradle'] = (
        "android { defaultConfig {\n versionCode %d\n versionName '%s'\n} }\n"
        % (code, version)
    ).encode()
    data['tools/clean_legacy_sources.py'] = b"print('cleanup fixture ready')\n"
    data['.github/workflows/build-apk.yml'] = b'name: fixture\n'
    return data


def embedded_script():
    workflow = (ROOT / '.github/workflows/build-apk.yml').read_text(encoding='utf-8')
    after = workflow.split("<<'PYUPLOAD'", 1)[1].split('\n', 1)[1]
    lines = []
    for line in after.splitlines():
        if line.strip() == 'PYUPLOAD':
            break
        lines.append(line)
    return textwrap.dedent('\n'.join(lines))


class CiSourcePreparationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='b710-ci-test-')
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.repo = self.base / 'AAA' / 'AAA'
        self.repo.mkdir(parents=True)
        self.runner = self.base / 'runner'
        self.runner.mkdir()
        self.output = self.base / 'github-output'
        self.output.touch()
        self.workflow = self.repo / '.github/workflows/build-apk.yml'
        self.workflow.parent.mkdir(parents=True)
        self.workflow.write_text('name: active workflow\n', encoding='utf-8')

    def archive(self, name='Qunideguanggao_B7_15_source.zip', prefix='Qunideguanggao_B7_15/', data=None):
        path = self.repo / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as archive:
            for relative, content in (fixture() if data is None else data).items():
                archive.writestr(prefix + relative, content)
        return path

    def tree(self, folder, data=None):
        path = self.repo / folder
        for relative, content in (fixture() if data is None else data).items():
            target = path / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)
        return path

    def prepare(self, selected=''):
        env = dict(os.environ, GITHUB_WORKSPACE=str(self.repo), RUNNER_TEMP=str(self.runner),
                   GITHUB_OUTPUT=str(self.output), SOURCE_PATH=selected)
        return subprocess.run([sys.executable, '-c', embedded_script()], cwd=self.repo,
                              env=env, capture_output=True, text=True, timeout=15)

    def project(self):
        values = dict(line.split('=', 1) for line in self.output.read_text().splitlines() if '=' in line)
        return Path(values.get('project_dir', self.repo))

    def assert_ready(self, result):
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        for relative in REQUIRED:
            self.assertTrue((self.project() / relative).is_file(), 'missing ' + relative)
        cleanup = subprocess.run([sys.executable, 'tools/clean_legacy_sources.py'],
                                 cwd=self.project(), capture_output=True, text=True)
        self.assertEqual(cleanup.returncode, 0, cleanup.stderr)

    def test_canonical_zip(self):
        self.archive()
        self.assert_ready(self.prepare())

    def test_browser_numbered_filename(self):
        self.archive('Qunideguanggao_B7_15_source (1).zip')
        self.assert_ready(self.prepare())

    def test_zip_uploaded_inside_app_folder(self):
        self.archive('app/Qunideguanggao_B7_15_source.zip')
        self.assert_ready(self.prepare())

    def test_renamed_zip_and_renamed_top_folder(self):
        self.archive('files/去你的广告最新版.zip', prefix='download/project/')
        self.assert_ready(self.prepare())

    def test_zip_with_no_top_folder(self):
        self.archive(prefix='')
        self.assert_ready(self.prepare())

    def test_extracted_source_folder(self):
        self.tree('Qunideguanggao_B7_15')
        self.assert_ready(self.prepare())

    def test_source_at_repository_root(self):
        self.tree('.')
        self.assert_ready(self.prepare())

    def test_no_source_is_rejected_before_cleanup(self):
        result = self.prepare()
        self.assertNotEqual(result.returncode, 0, 'an empty source checkout must not report success')
        self.assertIn('B7.15', result.stdout + result.stderr)
        self.assertFalse(self.output.read_text().strip())

    def test_missing_cleanup_script_is_rejected_during_preparation(self):
        data = fixture()
        del data['tools/clean_legacy_sources.py']
        self.archive(data=data)
        result = self.prepare()
        self.assertNotEqual(result.returncode, 0, 'an incomplete ZIP must not proceed')
        self.assertIn('clean_legacy_sources.py', result.stdout + result.stderr)
        self.assertFalse(self.output.read_text().strip())

    def test_old_version_is_not_selected(self):
        self.archive('Qunideguanggao_B7_4_source.zip', data=fixture('0.7.4-b7.4', 24))
        result = self.prepare()
        self.assertNotEqual(result.returncode, 0, 'old source must not be mistaken for B7.15')
        self.assertFalse(self.output.read_text().strip())

    def test_old_zip_can_coexist_with_current_zip(self):
        self.archive('Qunideguanggao_B7_4_source.zip', data=fixture('0.7.4-b7.4', 24))
        self.archive('new/B7.15.zip')
        self.assert_ready(self.prepare())

    def test_exact_duplicate_download_is_not_ambiguous(self):
        path = self.archive()
        (self.repo / 'Qunideguanggao_B7_15_source (1).zip').write_bytes(path.read_bytes())
        self.assert_ready(self.prepare())

    def test_conflicting_current_archives_require_explicit_selection(self):
        self.archive()
        different = fixture()
        different['build.gradle'] += b'changed\n'
        self.archive('other.zip', data=different)
        result = self.prepare()
        self.assertNotEqual(result.returncode, 0, 'different copies must not be chosen silently')
        self.assertIn('source_path', result.stdout + result.stderr)
        self.assertFalse(self.output.read_text().strip())

    def test_explicit_path_selects_intended_archive(self):
        self.archive()
        different = fixture()
        different['build.gradle'] += b'changed\n'
        self.archive('other.zip', data=different)
        self.assert_ready(self.prepare('other.zip'))
        self.assertEqual((self.project() / 'build.gradle').read_bytes(), different['build.gradle'])

    def test_zip_cannot_write_outside_project(self):
        data = fixture()
        data['../escaped.txt'] = b'escape'
        self.archive(data=data)
        result = self.prepare()
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse((self.repo / 'escaped.txt').exists())
        self.assertFalse(self.output.read_text().strip())

    def test_zip_symlink_is_rejected(self):
        path = self.archive()
        with zipfile.ZipFile(path, 'a') as archive:
            entry = zipfile.ZipInfo('Qunideguanggao_B7_15/link')
            entry.create_system = 3
            entry.external_attr = 0o120777 << 16
            archive.writestr(entry, '../../elsewhere')
        result = self.prepare()
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(self.output.read_text().strip())

    def test_source_path_cannot_escape_checkout(self):
        outside = self.base / 'outside'
        outside.mkdir()
        result = self.prepare(str(outside))
        self.assertNotEqual(result.returncode, 0)

    def test_build_copy_is_isolated_and_preserves_checkout(self):
        self.archive()
        legacy = self.repo / 'app/src/main/java/org/adguardian/app/network/LocalDnsVpnService.java'
        legacy.parent.mkdir(parents=True, exist_ok=True)
        legacy.write_text('legacy', encoding='utf-8')
        self.assert_ready(self.prepare())
        self.assertNotEqual(self.project(), self.repo)
        self.assertFalse((self.project() / legacy.relative_to(self.repo)).exists())
        self.assertEqual(legacy.read_text(), 'legacy')
        self.assertEqual((self.project() / '.github/workflows/build-apk.yml').read_bytes(), self.workflow.read_bytes())


if __name__ == '__main__':
    unittest.main()
