import android.content.Context;
import java.io.File;
import java.util.List;
import org.adguardian.app.engine.AdType;
import org.adguardian.app.engine.NodeTarget;
import org.adguardian.app.flow.FlowGuard;
import org.adguardian.app.flow.FlowStep;
import org.adguardian.app.recording.RecordingDraft;
import org.adguardian.app.recording.RecordingDraftStore;
import org.adguardian.app.recording.RecordingSession;

public final class RecordingCapacityB715Tests {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    private static FlowStep step(){
        return new FlowStep(new FlowGuard("host.example.Ad","f1:"+"0".repeat(64),0.45f),
                new NodeTarget("host.example:id/close","android.widget.TextView","关闭",0.94f,0.05f,0.08f,0.03f),false,30000L);
    }
    private static RecordingDraft draft(String key){
        return new RecordingDraft(key,"host.example","测试",1L,AdType.POPUP,true,
                List.of(step()),0,RecordingDraft.CAPTURED,System.currentTimeMillis());
    }
    private static void clean(Context context){
        File file=new File(context.getFilesDir(),"ad-recording-drafts.bin");file.delete();new File(file+".new").delete();new File(file+".bak").delete();
    }
    public static void main(String[] args)throws Exception {
        Context context=new Context();clean(context);RecordingDraftStore store=new RecordingDraftStore(context);
        for(int i=0;i<64;i++)store.put(draft("draft-"+i));
        RecordingSession session=new RecordingSession(context,true,AdType.POPUP);
        check(!session.persist("host.example",1L,List.of(step()),0,RecordingDraft.CAPTURED),"full archive accepted another lesson");
        check(session.problem().contains("64") && session.problem().contains("清理"),"full archive did not explain how to continue learning: "+session.problem());
        check(store.all().size()==64,"capacity failure changed existing lessons");
        store.clear();
        check(session.persist("host.example",1L,List.of(step()),0,RecordingDraft.CAPTURED),"explicit cleanup did not allow learning to resume");
        clean(context);System.out.println("PASS B7.15 recording capacity recovery");
    }
}
