import android.content.*;
import android.graphics.Rect;
import android.os.*;
import android.view.accessibility.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.Files;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.service.*;
import org.adguardian.app.runtime.*;

public final class RegressionB710Tests {
  static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
  static File drafts(){return new File(new Context().getFilesDir(),"ad-recording-drafts.bin");}
  static void clean(){drafts().delete();new File(drafts()+".bak").delete();new File(drafts()+".new").delete();}
  static void call(Object o,String name)throws Exception{Method m=o.getClass().getDeclaredMethod(name);m.setAccessible(true);m.invoke(o);}
  static void authorize(Context c){c.getContentResolver().settings.put(android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,c.getPackageName()+"/"+AdAccessibilityService.class.getName());}
  public static void main(String[] args)throws Exception{
    FlowsB77Tests.pass=FlowsB77Tests.fail=0;
    FlowsB77Tests.run("portrait fullscreen ad to inset home is not a rotation and saves",()->{
      var f=new TeachingB77Tests.Fixture();f.start();f.pick();
      f.s.root=FlowsB77Tests.page("home",null);f.s.root.bounds=new Rect(0,96,1080,2180);f.activity="host.example.Main";
      Handler.advance(10400);f.observe();Handler.advance(10700);f.observe();f.save();
      check(f.replay.store().all().size()==1,"same portrait display rejected after status/navigation inset change: "+f.teacher.status());f.close();
    });
    FlowsB77Tests.run("FlowStore accepts validated stages with different window rectangles",()->{
      var flow=FlowsB77Tests.flow();var terminal=new FlowGuard(flow.terminal.activity,flow.terminal.signature,1080f/2084f);
      new FlowStore(new Context()).add(new LearnedFlow("insets",flow.packageName,flow.appName,flow.versionCode,flow.type,true,flow.steps,terminal));
      check(new FlowStore(new Context()).all().size()==1,"saved flow disappeared");
    });
    FlowsB77Tests.run("multi-step capture is durable before final-page verification",()->{
      clean();var f=new TeachingB77Tests.Fixture();f.start();f.pick();
      check(drafts().isFile()&&drafts().length()>0,"captured action only exists in RAM before finish");
      check(f.replay.store().all().isEmpty(),"draft was enabled as a verified flow");f.close();
    });
    FlowsB77Tests.run("stopping an unfinished lesson keeps its captured record on disk",()->{
      clean();var f=new TeachingB77Tests.Fixture();f.start();f.pick();f.teacher.stop();
      check(drafts().isFile()&&drafts().length()>0,"stop wiped captured action instead of retaining a draft");f.close();
    });
    FlowsB77Tests.run("single-button capture is also saved as a non-executable draft",()->{
      clean();var f=LearningB79Tests.fresh();f.start();f.learning.selectAt(990,110);Handler.advance(SystemClock.now);
      check(drafts().isFile()&&drafts().length()>0,"single-button candidate remains only in memory");
      check(f.engine.store().all().isEmpty(),"unverified candidate enabled");f.learning.stop();
    });
    FlowsB77Tests.run("two FlowStore writers do not overwrite each other's records",()->{
      FlowStore a=new FlowStore(new Context()),b=new FlowStore(new Context());LearnedFlow f=FlowsB77Tests.flow();
      a.add(f);b.add(new LearnedFlow("second",f.packageName,f.appName,f.versionCode,f.type,false,f.steps,f.terminal));
      check(new FlowStore(new Context()).all().size()==2,"stale store snapshot overwrote first writer");
    });
    FlowsB77Tests.run("removing recent task pauses status notification without touching authorization",()->{
      AdAccessibilityService s=new AdAccessibilityService();authorize(s);s.root=FlowsB77Tests.page("home",null);call(s,"onServiceConnected");Handler.advance(10000);
      Field requested=ProtectionService.class.getDeclaredField("requestedAt");requested.setAccessible(true);requested.set(null,0L);
      Field owner=ProtectionService.class.getDeclaredField("owner");owner.setAccessible(true);owner.set(null,null);
      int before=s.foregroundStarts;String permission=s.getContentResolver().settings.get(android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
      s.onTaskRemoved(new Intent("removed"));
      check(s.foregroundStarts==before,"task removal restarted the status notification");
      check(org.adguardian.app.settings.PreferenceStore.isTaskRemoved(s),"task removal did not pause the demo");
      check(permission.equals(s.getContentResolver().settings.get(android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)),"authorization was rewritten");s.onDestroy();
    });
    FlowsB77Tests.run("a platform stopService exception cannot crash protection reconciliation",()->{
      Context c=new Context(){@Override public boolean stopService(Intent i){throw new SecurityException("platform failure");}};
      org.adguardian.app.settings.PreferenceStore.setMasterEnabled(c,false);
      ProtectionService.sync(c);
    });
    System.out.println("B7.10 initial regressions passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
    if(FlowsB77Tests.fail>0)throw new AssertionError("B7.10 initial failures");
  }
}
