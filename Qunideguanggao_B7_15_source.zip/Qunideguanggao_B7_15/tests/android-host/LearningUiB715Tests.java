import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;
import org.adguardian.app.engine.ActionVerifier;
import org.adguardian.app.engine.AdType;
import org.adguardian.app.flow.FlowReplayEngine;
import org.adguardian.app.flow.FlowTeachingController;
import org.adguardian.app.learning.LearnedRuleEngine;
import org.adguardian.app.learning.LearningController;

/** Checks the teaching controls users actually see, not source-string presence. */
public final class LearningUiB715Tests {
    private static int passed;

    private static final class Service extends AccessibilityService {
        @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
        @Override public void onInterrupt() { }
    }

    private static final class Windows implements WindowManager {
        View panel;
        View picker;
        LayoutParams panelParams;

        @Override public void addView(View view,LayoutParams params) {
            if(params.height==ViewGroup.LayoutParams.MATCH_PARENT)picker=view;
            else {panel=view;panelParams=params;}
        }
        @Override public void removeView(View view) {
            if(view==picker)picker=null;
            if(view==panel)panel=null;
        }
        @Override public void updateViewLayout(View view,LayoutParams params) {
            if(view==panel)panelParams=params;
        }
    }

    private static void check(boolean value,String message) {if(!value)throw new AssertionError(message);}
    private static View find(View root,String text) {
        if(root instanceof TextView value && text.contentEquals(value.getText()))return root;
        if(root instanceof ViewGroup group)for(View child:group.children){View found=find(child,text);if(found!=null)return found;}
        return null;
    }
    private static void cancelPicker(Windows windows) {
        check(windows.picker!=null && windows.picker.touchListener!=null,"picker was not shown");
        MotionEvent cancel=new MotionEvent();cancel.action=MotionEvent.ACTION_CANCEL;
        windows.picker.touchListener.onTouch(windows.picker,cancel);
    }
    private static void run(String name,Runnable body) {
        Handler.tasks.clear();SystemClock.now=10000L;body.run();passed++;System.out.println("PASS "+name);
    }

    public static void main(String[] args) {
        run("flow teaching panel is compact collapsible and hidden while selecting",()->{
            Service service=new Service();Windows windows=new Windows();service.services.put(Context.WINDOW_SERVICE,windows);
            Handler worker=new Handler(Looper.getMainLooper());
            FlowReplayEngine replay=new FlowReplayEngine(service,worker,()->"host.example",()->{});
            FlowTeachingController teaching=new FlowTeachingController(service,worker,()->"host.example",()->"host.example.Ad",replay,()->{});
            try {
                teaching.start(AdType.POPUP);Handler.advance(10000L);
                check(windows.panel!=null,"flow panel missing");
                check(windows.panelParams.width>0 && windows.panelParams.width<service.getResources().getDisplayMetrics().widthPixels,"flow panel still covers full width");
                View collapse=find(windows.panel,"收起");check(collapse!=null,"flow panel cannot collapse");
                collapse.performClick();check(find(windows.panel,"展开")!=null,"flow panel did not collapse");
                find(windows.panel,"展开").performClick();
                View direct=find(windows.panel,"直接选取并关闭");check(direct!=null,"direct close is not the primary teaching action");
                direct.performClick();Handler.advance(SystemClock.now);
                check(windows.panel.getVisibility()==View.GONE,"flow panel still obscures the target picker");
                cancelPicker(windows);check(windows.panel.getVisibility()==View.VISIBLE,"flow panel was not restored after picker cancellation");
            } finally {teaching.stop();replay.close();}
        });

        run("single-button teaching panel is compact collapsible and restores after picker",()->{
            Service service=new Service();Windows windows=new Windows();service.services.put(Context.WINDOW_SERVICE,windows);
            Handler worker=new Handler(Looper.getMainLooper());
            LearnedRuleEngine engine=new LearnedRuleEngine(service,worker,new ActionVerifier(service,worker,()->"host.example",()->{}),()->"host.example");
            LearningController teaching=new LearningController(service,worker,()->"host.example",engine,()->{});
            try {
                teaching.start(AdType.POPUP);Handler.advance(10000L);
                check(windows.panel!=null,"single panel missing");
                check(windows.panelParams.width>0 && windows.panelParams.width<service.getResources().getDisplayMetrics().widthPixels,"single panel still covers full width");
                View collapse=find(windows.panel,"收起");check(collapse!=null,"single panel cannot collapse");
                collapse.performClick();check(find(windows.panel,"展开")!=null,"single panel did not collapse");
                find(windows.panel,"展开").performClick();
                View select=find(windows.panel,"选取按钮");check(select!=null,"single target picker missing");select.performClick();
                check(windows.panel.getVisibility()==View.GONE,"single panel still obscures the target picker");
                cancelPicker(windows);check(windows.panel.getVisibility()==View.VISIBLE,"single panel was not restored after picker cancellation");
            } finally {teaching.stop();}
        });

        System.out.println("B7.15 learning UI cases passed="+passed);
    }
}
