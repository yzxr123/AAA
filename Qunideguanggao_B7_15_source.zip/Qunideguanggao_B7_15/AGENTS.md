# 去你的广告 B7.15

Read PROJECT_STATUS.md and docs/B7.15-audit.md before changes
The active contract is this file Historical docs explain old behavior and must not override it

## Product and preservation

Android phone single APK package/signing identity unchanged minSdk30 compileSdk36 targetSdk36
No runtime INTERNET permission No mandatory PC companion root or Shizuku
Do not alter LTT original JSON GKD subscription selector sources native OCR implementation or old user switches
CLASS target cn.luyiyuntech.stt versionCode1013 Keep exact scope and real resource names
APK size ceiling50MiB is not a RAM measurement

## Learning contract

Only explicit teaching captures metadata max8steps180seconds
Keep original single-button recording file and entrypoint
Keep drafts separately from executable flows Capture and commit are different states
Every injected teaching action must persist and read back before execution
No raw body text screenshots passwords arbitrary touch tracking or naked coordinate playback

For newly taught complete flows use versioned typed conditions in FlowCondition
TARGET finds a unique current control plus bounded ancestor context
STAGE describes a bounded observed stage END and CLASS_HOME certify an end page
FlowTransition alone decides action evidence Whole-page hash difference is never sufficient
Passive body resource changes must neither destroy local target matching nor confirm a dismissal
Still-visible disabled target is not gone Window insets alone are not a completed step
Old f1/f2/p1 guard data retain old exact semantics Do not broaden an old hash without new teaching
Before first upgraded writes RecordBackup preserves original bytes in .before-b713
The backup is for deliberate rollback not automatic downgrade or corrupt-file concealment

Unmatched explicit teaching actions become review items with reason and afterStep
Only explicit user review can dismiss a non-ad action It does not enable the flow
Repair creates a new draft retaining a confirmed prefix Original draft and active flow survive
All steps from the repair boundary onward must be taught again Require at least one newly confirmed step
Keep application/version/rotation/user switch/window ownership checks around every action
Re-read the actual terminal twice before enabling Never enable on timeout or unknown tree

## CLASS

Schema2 has actual evidenced four base families and supports <=32 validated bounded variants
Do not equate schema extensibility with new dynamic ad template coverage
Stages requiredIds excludedIds nextStages timeoutMs maxActions are runtime-validated and consumed
Base payment/confirmation controls are evidence only not click targets
Three visible home header IDs may correct stale Splash metadata only with no visible ad scope or real SDK ad activity
No blind close image selection and no generic Back
Do not fake a named view ID for a SDK integer/drawable
A pure Canvas without an independent readable target is still a known boundary

## Background

Separate system authorization actual service binding initialization and foreground guard
Ordinary health checks may retry a connected failed runtime <=3 times with30s60s120s backoff and no WSS permission
Do not use remove/wait/add as periodic health checking
A new system-setting reconnect transaction requires explicit current user action plus actual granted WSS and opt-in
Rollback of our prior persisted interrupted removal is separate and preserved
Respect user revocation Keep notifications and user controls No permanent-survival claims

## Delivery and checks

Run python3 tools/run_host_tests.py for all Python Kotlin Java tests including B7.15 regressions
Host tests use Android API doubles They are not Android SDK compilation or device verification
CI assembles Release and keeps APK50MiB ceiling
Deliver full Qunideguanggao_B7_15_source.zip plus build-apk-B7.15.yml
Workflow must accept intact renamed/nested ZIPs distinguish old versions and isolate checkout leftovers
Never ask the user to individually upload hundreds of files

## B7.15 checks and callback ownership

QUERY_ALL_PACKAGES is intentional for the explicit local installed-app SDK inventory
Keep its element-only tools:ignore=QueryAllPackagesPermission explanation
Do not globally disable lint or baseline away unknown diagnostics
Emit XML TXT HTML and the complete raw log before enforcing the real lint outcome
Missing malformed or failed lint output must not be treated as zero errors
Warnings are exported individually; successful warnings-only runs may publish the APK

CLASS recording and replay require the same isCertifiedClassHome terminal proof
A known MainActivity name alone cannot enable a lesson that replay cannot finish
After any blocking node read or native action failure re-check foreground ownership
Re-check current flow/ticket generation and user controls before gesture fallback
Late old verification queries cannot clear a newer pending ticket or report success after scope change
Keep the valid same-window native-click-to-gesture fallback
