package org.adguardian.app.flow;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Main-thread owned compact overlay. Selection consumes only the explicit teaching tap. */
final class FlowTeachingOverlay {
    interface Selection {void at(float x,float y);}
    private final AccessibilityService service;
    private final Selection selection;
    private Selection execution;
    private boolean executePick;
    private WindowManager windows;
    private WindowManager.LayoutParams layout;
    private LinearLayout panel;
    private LinearLayout controls;
    private TextView summary;
    private TextView message;
    private Button finish;
    private Button collapse;
    private View picker;
    private int panelX;
    private int panelY;
    private float dragStartX;
    private float dragStartY;
    private int dragOriginX;
    private int dragOriginY;
    private int lastSteps;

    FlowTeachingOverlay(AccessibilityService service,Selection selection){this.service=service;this.selection=selection;}
    void execution(Selection value){execution=value;}

    boolean show(Runnable pick,Runnable execute,Runnable back,Runnable save,Runnable retry,Runnable cancel) {
        windows=(WindowManager)service.getSystemService(Context.WINDOW_SERVICE);if(windows==null)return false;
        panel=new LinearLayout(service);panel.setOrientation(LinearLayout.VERTICAL);
        int padding=dp(6);panel.setPadding(padding,padding,padding,padding);panel.setBackgroundColor(Color.rgb(248,248,248));

        LinearLayout header=new LinearLayout(service);header.setOrientation(LinearLayout.HORIZONTAL);panel.addView(header);
        summary=new TextView(service);summary.setText("流程学习 0/8");summary.setTextColor(Color.BLACK);summary.setTextSize(13);
        header.addView(summary,new LinearLayout.LayoutParams(0,WindowManager.LayoutParams.WRAP_CONTENT,1f));
        collapse=button(header,"收起",this::toggleExpanded);
        installDrag(summary);

        controls=new LinearLayout(service);controls.setOrientation(LinearLayout.VERTICAL);panel.addView(controls);
        message=new TextView(service);message.setTextColor(Color.BLACK);message.setTextSize(12);controls.addView(message);
        LinearLayout primary=row();
        button(primary,"直接选取并关闭",execute);
        button(primary,"选取下一步",pick);
        button(primary,"记录并返回",back);
        LinearLayout more=row();
        finish=button(more,"完成并保存",save);
        button(more,"重录",retry);
        button(more,"结束并保留",cancel);

        layout=params();
        try{windows.addView(panel,layout);return true;}catch(RuntimeException unavailable){close();return false;}
    }

    private LinearLayout row(){LinearLayout row=new LinearLayout(service);row.setOrientation(LinearLayout.HORIZONTAL);controls.addView(row);return row;}
    private Button button(LinearLayout row,String text,Runnable action){
        Button value=new Button(service);value.setText(text);value.setAllCaps(false);value.setTextSize(11);value.setMinWidth(0);value.setOnClickListener(v->action.run());
        row.addView(value,new LinearLayout.LayoutParams(0,WindowManager.LayoutParams.WRAP_CONTENT,1f));return value;
    }
    private WindowManager.LayoutParams params(){
        int screenWidth=service.getResources().getDisplayMetrics().widthPixels;
        int screenHeight=service.getResources().getDisplayMetrics().heightPixels;
        int width=Math.max(1,Math.min(Math.max(1,screenWidth-dp(24)),dp(360)));
        if(panelX==0)panelX=dp(12);
        if(panelY==0)panelY=Math.max(dp(12),screenHeight-dp(230));
        WindowManager.LayoutParams value=new WindowManager.LayoutParams(width,WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        value.gravity=Gravity.TOP|Gravity.START;value.x=panelX;value.y=panelY;return value;
    }
    private void installDrag(View handle) {
        handle.setOnTouchListener((view,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN){dragStartX=event.getRawX();dragStartY=event.getRawY();dragOriginX=panelX;dragOriginY=panelY;return true;}
            if(event.getAction()==MotionEvent.ACTION_MOVE && layout!=null){
                int screenWidth=service.getResources().getDisplayMetrics().widthPixels;
                int screenHeight=service.getResources().getDisplayMetrics().heightPixels;
                panelX=Math.max(0,Math.min(screenWidth-layout.width,dragOriginX+Math.round(event.getRawX()-dragStartX)));
                panelY=Math.max(0,Math.min(screenHeight-dp(48),dragOriginY+Math.round(event.getRawY()-dragStartY)));
                layout.x=panelX;layout.y=panelY;try{windows.updateViewLayout(panel,layout);}catch(RuntimeException ignored){}return true;
            }
            return event.getAction()==MotionEvent.ACTION_UP || event.getAction()==MotionEvent.ACTION_CANCEL;
        });
    }
    private void toggleExpanded() {
        if(controls==null || collapse==null)return;
        boolean expand=controls.getVisibility()!=View.VISIBLE;
        controls.setVisibility(expand?View.VISIBLE:View.GONE);collapse.setText(expand?"收起":"展开");
    }
    void text(String value,boolean canFinish){text(value,lastSteps,canFinish);}
    void text(String value,int steps,boolean canFinish){
        lastSteps=Math.max(0,Math.min(FlowJournal.MAX_STEPS,steps));
        if(summary!=null)summary.setText("流程学习 "+lastSteps+"/"+FlowJournal.MAX_STEPS);
        if(message!=null)message.setText(value);if(finish!=null)finish.setEnabled(canFinish);
    }
    void selectAndExecute(){executePick=true;showPicker();}
    void select(){executePick=false;showPicker();}
    private void showPicker() {
        removePicker();if(windows==null)return;
        if(panel!=null)panel.setVisibility(View.GONE);
        View value=new View(service);value.setBackgroundColor(0x18000000);
        value.setOnTouchListener((view,event)->{
            if(event.getAction()==MotionEvent.ACTION_UP){float x=event.getRawX(),y=event.getRawY();boolean act=executePick;removePicker();if(act&&execution!=null)execution.at(x,y);else selection.at(x,y);view.performClick();}
            else if(event.getAction()==MotionEvent.ACTION_CANCEL)removePicker();return true;
        });
        WindowManager.LayoutParams pickerParams=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);pickerParams.gravity=Gravity.TOP|Gravity.START;
        try{windows.addView(value,pickerParams);picker=value;}catch(RuntimeException unavailable){if(panel!=null)panel.setVisibility(View.VISIBLE);text("无法显示选取层 可以手动点击有文字的关闭按钮",false);}
    }
    private void removePicker(){
        if(picker!=null && windows!=null)try{windows.removeView(picker);}catch(RuntimeException ignored){}
        picker=null;if(panel!=null)panel.setVisibility(View.VISIBLE);
    }
    void close(){removePicker();if(panel!=null && windows!=null)try{windows.removeView(panel);}catch(RuntimeException ignored){}panel=null;controls=null;summary=null;message=null;finish=null;collapse=null;layout=null;}
    private int dp(int value){return Math.round(value*service.getResources().getDisplayMetrics().density);}
}
