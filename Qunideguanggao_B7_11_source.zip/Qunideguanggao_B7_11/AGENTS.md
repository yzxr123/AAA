# 去你的广告 B7.11

Read .agents/skills/android-ad-guardian/SKILL.md and docs/B7.11-audit.md before changes
Android phone application One offline APK No INTERNET permission No update subsystem
Keep app identity signing key original LTT bytes bundled GKD source and subscription unchanged
Do not require root Shizuku a companion app or WRITE_SECURE_SETTINGS for ordinary ad protection
Optional WRITE_SECURE_SETTINGS recovery requires explicit opt-in and an actual system grant; default off
Never invoke onServiceConnected to pretend a framework rebind

## Preserved lifecycle

Authorization has known enabled known disabled unknown states
An unavailable settings read plus an empty manager list is not revocation
Retained positive authorization is only background retention policy not proof of a live service
Separate framework connection engine readiness and foreground guard status
User master/background off and explicit revocation must be honored
No hidden activities restart loops wake locks silent audio or claims of defeating OEM force stop
See docs/B7.6-audit.md for the inherited changes and limitations

## CLASS profile

Exact package cn.luyiyuntech.stt and versionCode 1013 only
Use only APK-evidenced Activities and actual resource IDs
tv_skip can be GONE Never click its historic position
TTFullScreenVideoActivity is ordinary fullscreen even though its namespace includes reward
Do not fold TTRewardVideoActivity or ordinary timetable pages into targeted closing
No generic Back No fabricated SDK IDs No blind corner tapping
Recheck each stage A completed input or missing first button is not proof the entire ad is over
Use bounded parents not the whole ad container
Class profile has a default-on separate switch

## Learning and replay

Primary multi-step implementation is flow/ FlowTeachingController FlowJournal FlowReplayEngine FlowStore
Single-button learning/ and its data must stay compatible
Explicit teaching only max180seconds max8steps No passive daily input recording
Pause other automation and OCR during either teaching mode
Capture immutable pre-action data and read event source at event intake
Original select-only entry does not inject a click
Separate Select and Execute persists and revalidates a unique target before dispatch
Explicit Record and Back injects one after guards
No first-step Back No Back on CLASS MainActivity
Commit a stage after two observations of target disappearance or a stable changed stage structure
Unchanged disabled visible targets are not disappearance
Unknown roots missing recorded steps incomplete traversals and unverified final pages cannot be success
Store only package version Activity structural digest safe target descriptor and expected terminal guard
No arbitrary content text screenshots passwords or coordinate-only macros
Replay must start at step1 and freshly resolve every target No mid-flow guessing
Exact package version guard and orientation unique target user switches apply to each action
A no-effect unchanged step yields after2500ms Step transition deadline30s total120s
Known unrelated Activities and user intervention cancel replay
Legacy learned-ad-rules.bin is untouched New flow file is separate atomic bounded and validated

## Runtime

Verified learned flow then legacy learned rule then CLASS profile then original LTT then real GKD subscription then constrained assistance then optional OCR
An active flow owns the action pipeline and blocks OCR Lower engines do not race its actions
Keep node caches event coalescing off-main query work delayed512pxRGB565OCR and all old switches
Use generation/foreground checks after expensive reads before injecting input
Diagnostic exceptions do not create fake permission or successful ads

## Delivery

Run tools/run_host_tests.py with all Python Kotlin and Java API-double tests
An API-double compilation is not Android SDK compilation or a real phone result
Deliver full Qunideguanggao_B7_11_source.zip and standalone build-apk-B7.11.yml
Inline workflow source preparation must accept renamed intact ZIPs nested folders and isolate old checkout files
Do not make users upload individual source files

## Inherited B7.8 boundary fixes
Preserve validated Activity candidates through coalescing of Dialog/View state events
Retry negative Activity and package metadata lookups with bounded TTL not session-long false caches
Critical teaching selection action verification and active replay refresh native cached roots
Never select the expected background app behind a different topmost application
Flow f2 guards ignore passive anonymous marketing content but preserve safe controls resource IDs and version scope
f1 stored guards remain compatible using the original B7.7 structural digest for unchanged pages
Explicit teaching node capture is limited to1024 with160ms budget Ordinary scans keep480 and existing budgets
Explicit picker teardown may retry120ms then300ms only within unchanged session app Activity orientation
ScanDiagnostics stores one enum-only record per subsystem in RAM No raw text screenshots coordinates or node handles
Full host command includes RegressionB78Tests Do not present API-double success as phone success
No device exit logs were supplied Background rebind remains unverified and must not be described as fixed


## B7.9 recording and actual CLASS assets
ClassAdEngine must load class/cn.luyiyuntech.stt_1013.json via ClassAdRules
Do not silently replace the four groups with guessed corner coordinates or report-only JSON
The new native promotion guard requires close AND tv_confirm AND btn_pay_now Only close is actionable
CLASS terminal fallback requires navigation_bar tv_today_date tv_weeks timetableView together
Native package version must equal1013 Unknown and other versions do not use these fixed parameters
Runtime asset and UI viewer are tested through the real RuleEngine and MainActivity

Both old single-button LearningController and FlowTeachingController use shared FlowPage metadata
TeachingHistory keeps max12 distinct pages for15seconds only during explicit teaching
Use getEventTime and event window to correlate the pre-click snapshot Never use only arrival-time page
Duplicate safe snapshots coalesce without losing the earlier pre-click page
A second explicit click can corroborate a previously observed changed stage before recording the next step
Do not count a missing second click as success Do not save a truncated sequence
Unknown Activity does not imply no nodes It requires at least2 distinct stable IDs and exact f2 structure
Known conflicting Activities never match A missing Activity never authorizes a recorded Back
A stale CLASS Splash activity may become MAIN only with all four actual home anchors and no visible native ad or known real SDK ad activity
Small picture and bounded clickable parent refer to one actual action region not duplicate candidates
The legacy128node capture path must not return Both paths allow up to1024 nodes within160ms cooperative budget
Null declared child means unavailable child not zero data or traversal-size overflow
Corrupt single-button or flow files must be reported unreadable and preserved Never show empty success
Management must display sanitized saved steps and targets Actual body text is never part of exported learning data
Original p1/f1 stored records remain supported without rewriting the user database

Run all Python Kotlin Java host tests including RegressionB79Tests LearningB79Tests EdgesB79Tests ReviewB79Tests
Regression evidence and selected fresh binary APK extracts are in docs
No device exists here No claim about all SDK dynamic templates or opaque Canvas learning


## B7.11 durable capture and offline management

Do not equate raw captured evidence with an executable learned rule
recording/RecordingDraftStore owns ad-recording-drafts.bin Separate from both active rule files
Each supported explicit capture is saved on worker and read back before claiming stored
Cancellation timeout disconnect and failed terminal verification retain written drafts
Drafts never enter RuleEngine or automatic replay
A fully confirmed CAPTURED draft can resume endpoint verification through the live service
Do not execute stored steps during continuation or enable incomplete/tainted drafts
A draft can still be viewed/deleted offline; active promotion requires real terminal verification
Manage local records using the private storage independent of service availability
Never call a successful completion callback if the requested data mutation did not execute
FlowStore and LearnedRuleStore serialize read-modify-write across instances in this single-process app
Refresh in-memory readers by revision Do not reread disk for every normal accessibility event
Do not add a separate Android process without replacing this locking strategy
AtomicFile does not itself provide writer locking Validate and read back bytes after finishWrite
Preserve old active file formats and corrupt originals Report errors without empty-list success
Capture stable display rotation separately from each root window's aspect ratio
A fullscreen ad and inset normal home can belong to the same orientation
Inset-only changes with the original target present are not a successful stage transition
onInterrupt interrupts feedback not consent or connection Do not cancel explicit teaching there
Unbind destroy user-off still stop capture Written drafts are not erased
Run RegressionB710Tests RecordingB710Tests FinalB710Tests through full BackendTests
Cross-JVM readback is a host filesystem check NOT a device/process-death or concurrent-multiprocess test
No measured OEM survival guarantee No claim that actual permission revocation was fixed


## B7.11 actual recording and source-backed background recovery

User sample proves one captured/confirmed/stored step but not executable promotion
Never tell the user that example means zero data was captured
FlowPage certifiedClassHome requires all four actual APK home IDs and absence of known ads
Stale Splash metadata cannot veto that composite home or make a normal home close button an ad target
Known SDK video Activity still wins; a home-like background does not erase actual visible ads
In explicit teaching only, fully confirmed CLASS steps plus certified home trigger existing two-fresh-read finalization
Other apps keep explicit finish; an Activity name alone cannot auto-promote
resumeDraft uses the same persisted draft key; FlowStore id recording-<draftKey> is idempotent
All transitions retain exact package/version/unique current target and user settings
Source-before-action selection is inspired by actual SoloPi CaseRecordManager and OperationStepExporter
Do not claim copying its whole application or Android private callback access

Only runtime/AccessibilityRecovery.java may write secure accessibility settings
It requires explicit consent plus actual WRITE_SECURE_SETTINGS grant, never adb exec/self-grant
Preserve OTHER enabled components by rereading the system list before restoring self
Persist own temporary-removal marker BEFORE removal; restore it on cancel/close/transaction interruption
GKD-derived sequence uses 1000ms remove/add separation and 2000ms real connection recheck
Never call onServiceConnected or disableSelf in product recovery; no fake running status
Automatic repair is only for configured-enabled disconnected self; a system-off state (including ACCESSIBILITY_ENABLED=0) needs explicit user confirmation
Rollback restores only the prior own component, never reverses a new user global-off choice
Status service keeps running during its own temporary removal and rolls back paused transactions
Shared ownership prevents multiple recovery workers from corrupting each other
Throttle automatic failure attempts and restoration failures to avoid observer loops
WRITE_SECURE_SETTINGS and SYSTEM_ALERT_WINDOW are optional manifest additions, not previously preserved bytes
ProtectionOverlay uses real overlay permission, noninteractive small view and delayed owner-aware handoff
No hidden activity/audio/wakelock or permanent survival claims
Periodic 30-second status checks are not UI traversal or screenshot polling
New tests: FinalizationB711Tests RecoveryB711Tests OverlayB711Tests ReviewB711Tests ClassCompletionB711Tests RecoveryBoundaryB711Tests
Run the complete host suite and actual intact-ZIP preparation before delivery
