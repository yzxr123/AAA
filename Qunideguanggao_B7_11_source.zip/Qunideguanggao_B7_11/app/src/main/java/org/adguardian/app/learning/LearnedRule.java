package org.adguardian.app.learning;

import android.view.accessibility.AccessibilityNodeInfo;
import org.adguardian.app.engine.AccessibilityNodeIndex;
import org.adguardian.app.engine.NodeTarget;
import org.adguardian.app.engine.AdType;

public final class LearnedRule {
    public final String key,packageName,appName,activityName,pageGuard;
    public final long versionCode;
    public final NodeTarget target;
    public final boolean enabled;
    public final AdType type;
    public LearnedRule(String key,String pkg,String appName,String activity,long version,NodeTarget target,boolean enabled) {
        this(key,pkg,appName,activity,version,target,enabled,AdType.POPUP);
    }
    public LearnedRule(String key,String pkg,String appName,String activity,long version,NodeTarget target,boolean enabled,AdType type) {
        this(key,pkg,appName,activity,version,target,enabled,type,"");
    }
    public LearnedRule(String key,String pkg,String appName,String activity,long version,NodeTarget target,boolean enabled,AdType type,String guard) {
        pageGuard=guard;
        this.type=type;
        this.key=key;packageName=pkg;this.appName=appName;activityName=activity;
        versionCode=version;this.target=target;this.enabled=enabled;
    }
    public LearnedRule withEnabled(boolean value) {
        return new LearnedRule(key,packageName,appName,activityName,versionCode,target,value,type,pageGuard);
    }
    public AccessibilityNodeInfo match(String pkg,String activity,long version,AccessibilityNodeIndex index) {
        if(!enabled || !packageName.equals(pkg) || activityName.isEmpty()
                || versionCode!=version)return null;
        if(pageGuard.startsWith("f2:")) {
            org.adguardian.app.flow.FlowPage current=org.adguardian.app.flow.FlowPage.capture(pkg,activity,version,index);
            if(current==null)return null;
            org.adguardian.app.flow.FlowGuard expected=new org.adguardian.app.flow.FlowGuard(activityName,pageGuard,current.guard.aspect);
            if(!expected.matches(current.guard))return null;
        }else {
            if(activityName.startsWith("@window:")) {
                if(pageGuard.isEmpty() || !activityName.substring(8).equals(NodeTarget.string(index.root().getClassName())))return null;
            }else if(!activityName.equals(activity))return null;
            if(!pageGuard.isEmpty()) {
                if(!pageGuard.equals(LearningPage.signature(index)))return null;
            }else if(!hasAdContext(index))return null;
        }
        AccessibilityNodeInfo matched=null;
        for(AccessibilityNodeInfo node:target.candidates(index)) {
            if(!node.isEnabled() || !target.matches(node,index.rootBounds(),true))continue;
            if(matched!=null)return null;
            matched=node;
        }
        return index.isTraversalIncomplete()?null:matched;
    }
    public static boolean hasAdContext(AccessibilityNodeIndex index) {
        if(index.hasAdSdkMarker())return true;
        for(AccessibilityNodeInfo node:index.nodes()) {
            String value=NodeTarget.string(node.getText());
            String desc=NodeTarget.string(node.getContentDescription());
            if(adLabel(value) || adLabel(desc))return true;
        }
        return false;
    }
    private static boolean adLabel(String text) {
        return text.equals("广告") || text.equals("推广") || text.equals("赞助")
                || text.equals("关闭广告") || text.equals("跳过广告") || text.equals("广告推广")
                || text.equalsIgnoreCase("Advertisement") || text.equalsIgnoreCase("Sponsored");
    }
}
