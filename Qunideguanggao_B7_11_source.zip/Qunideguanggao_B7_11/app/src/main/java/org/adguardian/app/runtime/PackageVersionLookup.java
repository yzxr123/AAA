package org.adguardian.app.runtime;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.SystemClock;

/** One foreground package; failures are negative-cached only briefly, never for the full session. */
public final class PackageVersionLookup {
    private String pkg="";
    private long value=-1,retryAt;
    public long read(Context context,String app) {
        long now=SystemClock.uptimeMillis();
        if(!pkg.equals(app)){pkg=app;value=-1;retryAt=0;}
        if(value>=0 || now<retryAt)return value;
        try {value=context.getPackageManager().getPackageInfo(app,0).getLongVersionCode();retryAt=0;}
        catch(PackageManager.NameNotFoundException | RuntimeException unavailable){value=-1;retryAt=now+750;}
        return value;
    }
    public void clear(){pkg="";value=-1;retryAt=0;}
}
