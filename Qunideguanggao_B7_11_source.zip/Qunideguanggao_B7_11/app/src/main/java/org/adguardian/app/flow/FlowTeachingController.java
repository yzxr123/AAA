package org.adguardian.app.flow;

import android.accessibilityservice.*;
import android.os.*;
import android.view.accessibility.*;
import java.io.IOException;
import java.util.UUID;
import java.util.function.Supplier;
import org.adguardian.app.engine.*;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.runtime.RootAccess;
import org.adguardian.app.settings.PreferenceStore;

/** Explicit multi-step teaching. No passive user tracking and no screenshots. */
public final class FlowTeachingController {
    private final AccessibilityService service;
    private final Handler worker,main=new Handler(Looper.getMainLooper());
    private final Supplier<String> foreground,activity;
    private final FlowReplayEngine engine;
    private final Runnable scan;
    private final FlowTeachingOverlay overlay;
    private volatile boolean active,saving,tainted,attempted,committed;
    private volatile long generation,selectionGeneration;
    private volatile FlowPage page;
    private final TeachingHistory history=new TeachingHistory();
    private volatile String status="尚未开始流程学习";
    private FlowJournal journal;
    private volatile org.adguardian.app.recording.RecordingSession recording;
    private AdType type;
    private long oldTimeout=-1;
    private final org.adguardian.app.runtime.PackageVersionLookup versions=new org.adguardian.app.runtime.PackageVersionLookup();
    private long version=-1;
    private boolean polling;
    private volatile boolean resumeOnly,loadingDraft;
    private volatile FlowPage injectedPage;
    private volatile NodeTarget injectedTarget;
    private volatile long injectedUntil;
    private final Object commitLock=new Object();
    public FlowTeachingController(AccessibilityService service,Handler handler,Supplier<String> foreground,Supplier<String> activity,FlowReplayEngine engine,Runnable scan) {
        this.service=service;worker=new Handler(handler.getLooper());this.foreground=foreground;this.activity=activity;this.engine=engine;this.scan=scan;overlay=new FlowTeachingOverlay(service,this::selectAt);overlay.execution(this::selectAndExecuteAt);
    }
    public boolean isActive(){return active||loadingDraft;}
    public boolean isCategoryEnabled(){return type==null || PreferenceStore.isTypeEnabled(service,type);}
    public String status(){return status;}
    public boolean hasSession(){return attempted;}
    public void start(AdType type) { startSession(type,null); }
    public void resumeDraft(String key) {
        stop();long request=generation;loadingDraft=true;
        worker.post(()->{
            try {
                org.adguardian.app.recording.RecordingDraft selected=null;
                for(var draft:new org.adguardian.app.recording.RecordingDraftStore(service).all())if(draft.key.equals(key))selected=draft;
                FlowJournal.restore(selected);
                final var restored=selected;
                main.post(()->{if(generation==request&&!active)startSession(restored.type,restored);});
            } catch(IOException|RuntimeException error) {
                main.post(()->{if(generation==request&&!active){loadingDraft=false;status="这份草稿尚有未确认或漏记步骤 不能直接启用 请查看捕获内容";UserEventLog.warning(service,status);scan.run();}});
            }
        });
    }
    private void startSession(AdType type,org.adguardian.app.recording.RecordingDraft restored) {
        stop();this.type=type;tainted=false;committed=false;attempted=true;resumeOnly=restored!=null;
        recording=new org.adguardian.app.recording.RecordingSession(service,restored!=null&&restored.single,type,restored);
        journal=restored==null?new FlowJournal(type):FlowJournal.restore(restored);
        page=null;history.clear();versions.clear();active=true;saving=false;injectedUntil=0;long token=++generation;
        try{AccessibilityServiceInfo info=service.getServiceInfo();if(info!=null){oldTimeout=info.notificationTimeout;info.notificationTimeout=0;service.setServiceInfo(info);}}catch(RuntimeException ignored){}
        if(!overlay.show(this::beginPick,this::beginExecutePick,this::recordBack,this::finish,()->start(type),this::stop)){stop();status="无法显示流程学习提示";UserEventLog.error(service,status);return;}
        hint(token,resumeOnly?"已载入 "+restored.confirmed+" 个已确认步骤 请打开广告关闭后的原应用页面 然后点 完成并保存"
                :"请逐层关闭广告 或点 选取并执行 CLASS 回到已识别主页后自动保存启用",resumeOnly);
        main.postDelayed(()->{if(valid(token)){stop();status=retainedText("流程学习已超时");UserEventLog.record(service,status);}},180000);
        worker.post(scan);
        // Only during the user's finite lesson. A quiet window still needs a pre-click capture.
        worker.postDelayed(new Runnable(){public void run(){
            if(!valid(token))return;
            if(!saving&&!journal.pending())scan.run();
            worker.postDelayed(this,650);
        }},350);
    }
    private boolean valid(long token){return active && token==generation;}
    public void observe(String pkg,String pageActivity,AccessibilityNodeIndex index) {
        if(!active || saving || service.getPackageName().equals(pkg))return;
        long token=generation;
        try {
            FlowPage observed=capture(pkg,pageActivity,index);
            if(!valid(token))return;
            page=observed;history.add(observed);int old=journal.stepCount();journal.observe(observed,SystemClock.uptimeMillis());
            if(journal.cancelled()){abort(token,"应用或屏幕方向已经变化 已停止校验");return;}
            if(journal.stepCount()>old){hint(token,persistCaptured()?"第 "+journal.stepCount()+" 步已确认并更新草稿 请继续关闭下一层 或完成并保存":recording.problem(),true);}
            else if(!journal.pending()&&!tainted) {
                if(observed==null)hint(token,org.adguardian.app.runtime.ScanDiagnostics.explain(org.adguardian.app.runtime.ScanDiagnostics.Area.PAGE),journal.stepCount()>0);
                else hint(token,"已读取 "+observed.nodeCount+" 个控件 可选目标 "+observed.targets.size()+" 个 已记录 "+journal.stepCount()+" 步 请关闭广告或选取下一步",journal.stepCount()>0);
            }
            autoFinishClass(token,observed);
        }catch(RuntimeException unavailable){page=null;journal.observe(null,SystemClock.uptimeMillis());}
    }
    private FlowPage capture(String pkg,String pageActivity,AccessibilityNodeIndex index) {
        version=versions.read(service,pkg);
        if(version<0){org.adguardian.app.runtime.ScanDiagnostics.record(org.adguardian.app.runtime.ScanDiagnostics.Area.PAGE,org.adguardian.app.runtime.ScanDiagnostics.Reason.VERSION_UNKNOWN,0,0);status="暂时未读到应用版本 正在等待重试";return null;}
        index.startQueryBudget(160);
        try{return FlowPage.capture(pkg,pageActivity,version,index,org.adguardian.app.runtime.DisplayRotation.read(service));}finally{index.clearQueryBudget();}
    }
    public void clicked(AccessibilityEvent event) {
        if(!active || saving || event==null || resumeOnly)return;
        String pkg=NodeTarget.string(event.getPackageName());long token=generation;
        if(service.getPackageName().equals(pkg))return;
        long eventTime=event.getEventTime()>0?event.getEventTime():SystemClock.uptimeMillis();
        if(eventTime>SystemClock.uptimeMillis()+100 || SystemClock.uptimeMillis()-eventTime>2000)return;
        FlowPage before=history.before(pkg,eventTime,event.getWindowId());
        if(before==null){markMissingStep(token,pkg,before);hint(token,"没有取得这次点击之前的页面 请先选取下一步",false);return;}
        AccessibilityNodeInfo node=null;NodeTarget selected=null;
        try {
            node=event.getSource();
            for(int depth=0;node!=null && depth<4;depth++) {
                NodeTarget t=NodeTarget.captureSelected(node,before.bounds);
                if(t!=null){selected=before.find(t.forLearning());if(selected!=null)break;}
                AccessibilityNodeInfo parent=node.getParent();node.recycle();node=parent;
            }
        }catch(RuntimeException unavailable){}
        finally{if(node!=null)node.recycle();}
        if(selected==null)selected=before.findCloseText(event.getText());
        if(selected==null){markMissingStep(token,pkg,before);worker.post(() -> {if(valid(token) && !journal.pending() && !tainted)hint(token,"未读取到这个关闭按钮 请用 选取下一步 先选再关",false);});return;}
        // Suppress only our own operation on its exact pre-action page. A fast manual second step is retained.
        if(SystemClock.uptimeMillis()<injectedUntil && injectedPage!=null && injectedTarget!=null
                && injectedPage.windowId==before.windowId && injectedPage.guard.matches(before.guard)
                && before.find(injectedTarget)==selected)return;
        NodeTarget target=selected;worker.post(()->recordClick(token,before,target,eventTime));
    }
    private void markMissingStep(long token,String pkg,FlowPage before) {
        worker.post(() -> {
            if(valid(token) && !saving && pkg.equals(journal.targetPackage()) && (journal.pending() || journal.stepCount()>0)) {
                // Only a duplicate on the same known pre-action page may be ignored.
                if(journal.pending() && before!=null && journal.pendingStep().guard.matches(before.guard))return;
                tainted=true;persistCaptured();
                hint(token,"前面的步骤草稿已保留 刚才有一步未读取到 未启用自动回放 请重录并先选取",true);
            }
        });
    }
    private void recordClick(long token,FlowPage before,NodeTarget target,long eventTime) {
        if(!valid(token) || saving || !before.pkg.equals(foreground.get()))return;
        if(tainted){hint(token,"前面的草稿已保留 本次有漏记步骤 暂不启用自动回放 请重新教学",false);return;}
        if(journal.pending()) {
            if(!journal.advanceBeforeClick(before,target,eventTime)) {
                if(!journal.pendingStep().guard.matches(before.guard)){tainted=true;persistCaptured();hint(token,"前面的草稿已保留 有一步缺少前后页面 请重新教学并先选取",true);}
                return;
            }
        }
        if(journal.stepCount()>=FlowJournal.MAX_STEPS){tainted=true;persistCaptured();hint(token,"前八步草稿已保留 已达到单次上限 请结束后重新教学",true);return;}
        if(!journal.beginClick(before,target)){hint(token,"这一步缺少唯一安全目标 或已达到八步 请重试或完成",journal.stepCount()>0);return;}
        if(persistCaptured())hint(token,"第 "+(journal.stepCount()+1)+" 步按钮已写入录制草稿 请手动关闭 结束校验通过后才自动启用",true);
        else hint(token,recording.problem(),true);
        poll(token);
    }
    private void beginPick() {
        if(!active || saving || resumeOnly)return;
        long token=generation;
        worker.post(()->{if(!valid(token))return;if(journal.pending()){hint(token,"请先完成当前这一步 仍未关闭时可重录 不会跳过未完成步骤",false);return;}
            main.post(()->{if(valid(token)){overlay.select();hint(token,"轻点关闭按钮位置 这次只选取 然后请手动关闭",false);}});
        });
    }
    public void selectAt(float x,float y) {
        long token=generation,selection=++selectionGeneration;
        String pkg=foreground.get(),pageActivity=activity.get();FlowPage before=page;
        worker.post(()->selectFresh(token,selection,pkg,pageActivity,before,x,y,0,false));
    }
    private void selectFresh(long token,long selection,String pkg,String pageActivity,FlowPage before,float x,float y,int attempt,boolean execute) {
        if(!valid(token) || selection!=selectionGeneration || saving || resumeOnly || journal.pending()
                || pkg==null || pkg.equals(service.getPackageName()) || !pkg.equals(foreground.get())
                || pageActivity==null || (!pageActivity.isEmpty()&&!pageActivity.equals(activity.get())))return;
        FlowPage fresh=fresh();
        // WindowManager removing the picking layer and accessibility cache invalidation are asynchronous.
        // Retry only this explicit selection, in the same app/page, for less than half a second.
        if(fresh==null) {
            if(attempt<2){worker.postDelayed(()->selectFresh(token,selection,pkg,pageActivity,before,x,y,attempt+1,execute),attempt==0?120:300);return;}
            hint(token,org.adguardian.app.runtime.ScanDiagnostics.explain(org.adguardian.app.runtime.ScanDiagnostics.Area.PAGE),false);return;
        }
        if(!valid(token) || selection!=selectionGeneration || !pkg.equals(foreground.get())
                || (!pageActivity.isEmpty()&&!pageActivity.equals(fresh.guard.activity)) || (before!=null && !fresh.sameScope(before)))return;
        NodeTarget target=fresh.pick(x,y);if(target==null){hint(token,"这里没有唯一可读取的小型关闭控件",false);return;}
        page=fresh;history.add(fresh);recordClick(token,fresh,target,SystemClock.uptimeMillis());
        if(execute && valid(token) && journal.pending() && recording.isStored()
                && recording.problem().isEmpty() && recording.count()==journal.capturedSteps().size())executeSelected(token,selection,fresh,target);
    }
    private void beginExecutePick() {
        if(!active || saving || resumeOnly)return;
        long token=generation;
        worker.post(()->{if(valid(token)&&!journal.pending())main.post(()->{
            if(valid(token)){overlay.selectAndExecute();hint(token,"轻点实际关闭按钮 先保存目标 再执行这次关闭",false);}
        });});
    }
    public void selectAndExecuteAt(float x,float y) {
        long token=generation,selection=++selectionGeneration;
        String pkg=foreground.get(),pageActivity=activity.get();FlowPage before=page;
        worker.post(()->selectFresh(token,selection,pkg,pageActivity,before,x,y,0,true));
    }
    private void executeSelected(long token,long selection,FlowPage captured,NodeTarget target) {
        AccessibilityNodeInfo root=RootAccess.readFreshFor(service,captured.pkg);
        try {
            if(root==null)throw new IllegalStateException("no fresh root");
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)) {
                FlowPage current=capture(captured.pkg,activity.get(),index);
                if(current==null || !current.sameScope(captured) || !captured.guard.matches(current.guard))
                    throw new IllegalStateException("page changed");
                AccessibilityNodeInfo node=FlowPage.resolve(target,index),action=FlowSafety.clickTarget(node,index);
                if(action==null || !valid(token) || selection!=selectionGeneration || !captured.pkg.equals(foreground.get())
                        || !PreferenceStore.isMasterEnabled(service) || !PreferenceStore.isLearnedEnabled(service) || !isCategoryEnabled())
                    throw new IllegalStateException("target changed");
                // Own injected click events are not extra manual steps.
                injectedPage=captured;injectedTarget=target;injectedUntil=SystemClock.uptimeMillis()+650;
                boolean accepted=action.isClickable()&&action.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                if(!accepted) {
                    android.graphics.Rect bounds=FlowSafety.bounds(action);android.graphics.Path path=new android.graphics.Path();
                    path.moveTo(bounds.exactCenterX(),bounds.exactCenterY());
                    GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,45)).build();
                    accepted=service.dispatchGesture(gesture,new AccessibilityService.GestureResultCallback(){
                        @Override public void onCompleted(GestureDescription g){if(valid(token)&&selection==selectionGeneration)poll(token);}
                        @Override public void onCancelled(GestureDescription g){if(valid(token)&&selection==selectionGeneration)hint(token,"这次点击被系统取消 草稿保留 未确认本步 可手动关闭后继续",true);}
                    },worker);
                }
                hint(token,accepted?"关闭动作已发送 目标已存草稿 正在核对实际页面变化":"系统没有接受点击 草稿保留 请手动关闭后继续",true);
            }
        } catch(RuntimeException error){if(valid(token))hint(token,"页面或控件已经变化 没有向新页面发送点击 草稿保留",true);}
        finally{if(root!=null)root.recycle();}
    }
    public void recordBack() {
        if(resumeOnly)return;
        long token=generation;
        worker.post(()->{
            if(!valid(token) || saving || journal.pending())return;
            if(tainted || journal.stepCount()>=FlowJournal.MAX_STEPS){tainted=true;hint(token,"本次步骤不完整或超过八步 请重录或取消",false);return;}
            FlowPage before=fresh();
            if(!valid(token) || saving || !PreferenceStore.isMasterEnabled(service) || !PreferenceStore.isLearnedEnabled(service) || !isCategoryEnabled())return;
            if(before==null || !before.pkg.equals(foreground.get()))return;
            if(!journal.beginBack(before)){hint(token,"返回需要先完成至少一个关闭步骤 不能在课表首页记录退出",journal.stepCount()>0);return;}
            boolean accepted=false;try{accepted=service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);}catch(RuntimeException unavailable){}
            if(!accepted){journal.discardPending();hint(token,"系统未执行返回 没有增加这一步",journal.stepCount()>0);return;}
            if(persistCaptured())hint(token,"返回步骤已写入草稿 等待页面变化",true);else hint(token,recording.problem(),true);poll(token);
        });
    }
    private FlowPage fresh() {
        String pkg=foreground.get();if(pkg==null || pkg.isEmpty() || pkg.equals(service.getPackageName()))return null;
        AccessibilityNodeInfo root=RootAccess.readFreshFor(service,pkg);
        try{if(root==null)return null;try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)){return capture(pkg,activity.get(),index);}}
        catch(RuntimeException unavailable){return null;}finally{if(root!=null)root.recycle();}
    }
    private void poll(long token) {
        if(polling)return;polling=true;
        worker.postDelayed(new Runnable(){public void run(){
            if(!valid(token) || saving || !journal.pending()){polling=false;return;}
            FlowPage observed=fresh();int old=journal.stepCount();
            if(observed!=null){page=observed;history.add(observed);}
            journal.observe(observed,SystemClock.uptimeMillis());
            if(journal.cancelled()){polling=false;abort(token,"已离开目标应用 已停止校验");return;}
            if(journal.stepCount()>old){polling=false;hint(token,persistCaptured()?"第 "+journal.stepCount()+" 步已确认并更新草稿 可继续下一层 或完成并保存":recording.problem(),true);scan.run();return;}
            worker.postDelayed(this,220);
        }},180);
    }
    private void autoFinishClass(long token,FlowPage observed) {
        if(observed==null || !observed.isCertifiedClassHome() || journal.pending() || journal.stepCount()==0
                || tainted || saving || !PreferenceStore.isClassAdapterEnabled(service))return;
        // Only the APK-confirmed composite home layout ends CLASS lessons automatically.
        // Other apps still need the user's explicit completion and two fresh page checks.
        main.post(()->{if(valid(token)&&!saving&&!tainted)finish();});
    }
    public void finish() {
        if(!active || saving)return;long token=generation;
        if(tainted){hint(token,"录制草稿已保留 有漏记步骤 暂不启用为完整流程 请重新教学",false);return;}
        saving=true;
        hint(token,"正在复核结束页面",false);worker.post(()->verifyFinish(token,null));
    }
    private void verifyFinish(long token,FlowPage first) {
        if(!valid(token))return;
        if(tainted){saving=false;hint(token,"本次有漏记步骤 请重录",false);return;}
        if(!PreferenceStore.isMasterEnabled(service) || !PreferenceStore.isLearnedEnabled(service) || !PreferenceStore.isTypeEnabled(service,type)){saving=false;abort(token,"开关已关闭 已停止校验");return;}
        FlowPage now=fresh();
        if(now==null){saving=false;hint(token,"步骤草稿已保留 结束页面暂时无法读取 请留在目标页面后再校验",true);return;}
        journal.observe(now,SystemClock.uptimeMillis());
        if(first==null){worker.postDelayed(()->verifyFinish(token,now),180);return;}
        if(!first.sameScope(now) || !first.guard.matches(now.guard)){saving=false;hint(token,"页面仍在变化 请关闭剩余广告后再保存",true);return;}
        try {
            String label=now.pkg;try{label=service.getPackageManager().getApplicationLabel(service.getPackageManager().getApplicationInfo(now.pkg,0)).toString();}catch(android.content.pm.PackageManager.NameNotFoundException unavailable){}
            LearnedFlow flow=journal.finish("recording-"+recording.key(),label);
            synchronized(commitLock){if(!valid(token) || tainted)return;engine.store().add(flow);committed=true;recording.mark(flow.steps.size(),org.adguardian.app.recording.RecordingDraft.ENABLED);}
            main.post(()->{if(valid(token)){stop();status="已保存 "+flow.steps.size()+" 步关闭流程 下次按相同页面条件执行";UserEventLog.record(service,status);}});
        }catch(IllegalStateException unfinished){saving=false;hint(token,"未启用原因  "+journal.finishProblem()+"  已保存步骤可在草稿中继续校验",true);poll(token);}
        catch(IOException | RuntimeException error){saving=false;hint(token,"自动规则写入失败 已捕获步骤仍在录制草稿 原有规则未改变",true);}
    }
    private void hint(long token,String value,boolean finish){if(!valid(token))return;status=value;main.post(()->{if(valid(token))overlay.text(value,(finish || (recording!=null&&recording.isStored()))&&!saving);});}
    private void abort(long token,String text){main.post(()->{if(valid(token)){stop();status=retainedText(text);UserEventLog.warning(service,status);}});}
    private boolean persistCaptured() {
        if(recording==null || journal==null || journal.capturedSteps().isEmpty())return false;
        return recording.persist(journal.targetPackage(),journal.targetVersion(),journal.capturedSteps(),
                journal.stepCount(),tainted?org.adguardian.app.recording.RecordingDraft.NEEDS_REVIEW:org.adguardian.app.recording.RecordingDraft.CAPTURED);
    }
    private String retainedText(String prefix) {
        return prefix+(recording!=null&&recording.isStored()?" 已捕获 "+recording.count()+" 步保存在录制草稿 未自动启用":" 尚未捕获到可保存的步骤");
    }
    public void stop() {
        boolean was;
        synchronized(commitLock){was=active;active=false;loadingDraft=false;injectedPage=null;injectedTarget=null;generation++;selectionGeneration++;saving=false;page=null;history.clear();polling=false;}
        worker.removeCallbacksAndMessages(null);main.removeCallbacksAndMessages(null);overlay.close();
        if(oldTimeout>=0)try{AccessibilityServiceInfo info=service.getServiceInfo();if(info!=null){info.notificationTimeout=oldTimeout;service.setServiceInfo(info);}}catch(RuntimeException ignored){}
        oldTimeout=-1;if(was){status=committed?"本次关闭流程已保存并启用":retainedText("流程学习已结束");scan.run();}
    }
}
