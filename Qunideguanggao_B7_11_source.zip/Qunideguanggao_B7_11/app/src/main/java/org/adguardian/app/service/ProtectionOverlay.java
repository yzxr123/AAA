package org.adguardian.app.service;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import org.adguardian.app.settings.PreferenceStore;

/** Main-thread status-service attachment, handed off only after the accessibility attachment exists. */
public final class ProtectionOverlay implements AutoCloseable {
    private final Context context;
    private final Handler main=new Handler(Looper.getMainLooper());
    private WindowManager windows;
    private View view;
    private boolean closed,replacement;
    private long epoch;
    public ProtectionOverlay(Context context){this.context=context;}
    public static boolean allowed(Context context){try{return Settings.canDrawOverlays(context);}catch(RuntimeException e){return false;}}
    public boolean isAttached(){return view!=null;}
    public void sync(boolean accessibilityAttached){
        if(closed)return;
        replacement=accessibilityAttached;long token=++epoch;main.removeCallbacksAndMessages(null);
        if(!PreferenceStore.isMasterEnabled(context)||!PreferenceStore.isKeepAliveEnabled(context)||!allowed(context)){detach();return;}
        if(accessibilityAttached){
            if(view!=null)main.postDelayed(()->{if(!closed&&replacement&&token==epoch)detach();},1000);
            return;
        }
        if(view!=null)return;
        try{
            windows=(WindowManager)context.getSystemService(Context.WINDOW_SERVICE);if(windows==null)return;
            View next=new View(context);next.setAlpha(0.01f);
            WindowManager.LayoutParams p=new WindowManager.LayoutParams(1,1,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
            p.gravity=Gravity.TOP|Gravity.START;p.packageName=context.getPackageName();windows.addView(next,p);view=next;
        }catch(RuntimeException error){org.adguardian.app.runtime.RuntimeHealth.failure(context,"后台覆盖层未建立",error);}
    }
    private void detach(){View old=view;view=null;if(old!=null&&windows!=null)try{windows.removeView(old);}catch(RuntimeException ignored){}}
    @Override public void close(){closed=true;epoch++;main.removeCallbacksAndMessages(null);detach();}
}
