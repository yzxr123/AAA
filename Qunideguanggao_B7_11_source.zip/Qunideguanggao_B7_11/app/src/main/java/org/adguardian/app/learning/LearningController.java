package org.adguardian.app.learning;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.IOException;
import java.util.UUID;
import java.util.function.Supplier;
import org.adguardian.app.engine.AccessibilityNodeIndex;
import org.adguardian.app.engine.AdType;
import org.adguardian.app.engine.NodeTarget;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.runtime.RootAccess;
import org.adguardian.app.settings.PreferenceStore;

public final class LearningController {
    private final AccessibilityService service;
    private final Handler worker;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Supplier<String> foreground;
    private final LearnedRuleEngine engine;
    private final Runnable resume;
    private volatile boolean active;
    private volatile long generation;
    private volatile LearnedRule candidate;
    private volatile LearningPage page;
    private volatile String lastStatus="尚未开始学习";
    private volatile boolean saving;
    private volatile long selectionGeneration;
    private final org.adguardian.app.flow.TeachingHistory history=new org.adguardian.app.flow.TeachingHistory();
    private final org.adguardian.app.runtime.PackageVersionLookup versions=new org.adguardian.app.runtime.PackageVersionLookup();
    private volatile org.adguardian.app.recording.RecordingSession recording;
    private AdType type=AdType.POPUP;
    private WindowManager windows;
    private LinearLayout panel;
    private View picker;
    private TextView message;
    private Button save;
    private boolean panelAtTop;
    private long oldNotificationTimeout=-1;

    public LearningController(AccessibilityService service,Handler worker,Supplier<String> foreground,
                              LearnedRuleEngine engine,Runnable resume) {
        this.service=service;this.worker=new Handler(worker.getLooper());this.foreground=foreground;this.engine=engine;this.resume=resume;
    }
    public boolean isActive() {return active;}
    public String status() {return lastStatus;}
    public void start(AdType value) {
        stop();recording=new org.adguardian.app.recording.RecordingSession(service,true,value);active=true;type=value;page=null;history.clear();versions.clear();candidate=null;saving=false;long token=++generation;
        try {
            android.accessibilityservice.AccessibilityServiceInfo info=service.getServiceInfo();
            if(info!=null) {oldNotificationTimeout=info.notificationTimeout;info.notificationTimeout=0;service.setServiceInfo(info);}
        } catch(RuntimeException unavailable) { }
        if(!showPanel()) {stop();UserEventLog.error(service,"无法显示学习提示 请检查辅助功能服务状态");return;}
        hint(token,"学习中 请打开广告 可以直接手动关闭 读取不到按钮时先点 选取按钮");
        main.postDelayed(() -> {
            if(active && token==generation) {stop();lastStatus=recording!=null&&recording.isStored()?"本次学习超时 按钮草稿已保留 未启用自动规则":"本次学习超时 尚未捕获按钮";UserEventLog.record(service,lastStatus);}
        },90000L);
        resume.run();
        worker.postDelayed(new Runnable(){public void run(){
            if(!active || token!=generation)return;
            if(candidate==null&&!saving)resume.run();
            worker.postDelayed(this,650L);
        }},350L);
    }
    public void observe(String pkg,String activity,AccessibilityNodeIndex index) {
        if(!active || candidate!=null || service.getPackageName().equals(pkg))return;
        long token=generation;
        index.startQueryBudget(160L);
        try {
            long version=versions.read(service,pkg);
            if(version<0){hint(token,"暂时未读到应用版本 正在等待重试");return;}
            LearningPage captured=LearningPage.capture(pkg,activity,version,index);
            if(active && token==generation && candidate==null) {
                page=captured;
                if(captured!=null) {
                    history.add(captured.snapshot);
                    hint(token,"已读取 "+captured.snapshot.nodeCount+" 个控件 可选目标 "+captured.targets.size()+" 个 请关闭广告或选取按钮");
                }else hint(token,org.adguardian.app.runtime.ScanDiagnostics.explain(org.adguardian.app.runtime.ScanDiagnostics.Area.PAGE));
            }
        } catch(RuntimeException limit) {
            if(active && token==generation)page=null;
        } finally {index.clearQueryBudget();}
    }
    public void clicked(AccessibilityEvent value) {
        if(!active || candidate!=null || saving)return;
        String pkg=NodeTarget.string(value.getPackageName());
        if(pkg.isEmpty() || pkg.equals(service.getPackageName()))return;
        long now=SystemClock.uptimeMillis(),eventTime=value.getEventTime()>0?value.getEventTime():now;
        if(eventTime>now+100 || now-eventTime>2000)return;
        LearningPage before=LearningPage.from(history.before(pkg,eventTime,value.getWindowId()));
        long token=generation;
        if(before==null || !pkg.equals(before.pkg)) {
            hint(token,"页面信息尚未就绪 请重新打开广告后点 选取按钮");return;
        }
        // Resolve only this source now. Deferring getSource until after dismissal loses the node.
        AccessibilityNodeInfo node=null;
        NodeTarget found=null;
        try {
            node=value.getSource();
            for(int depth=0;node!=null && depth<4;depth++) {
                NodeTarget source=NodeTarget.captureSelected(node,before.bounds);
                if(org.adguardian.app.flow.FlowSafety.safeTarget(source)) {found=before.find(source);if(found!=null)break;}
                AccessibilityNodeInfo parent=node.getParent();node.recycle();node=parent;
            }
        } catch(RuntimeException unavailable) { }
        finally {if(node!=null)node.recycle();}
        if(found==null)found=before.snapshot.findCloseText(value.getText());
        if(found==null) {hint(token,"已读取页面 但没有唯一对应的关闭按钮 请重新打开广告并选取按钮 不会猜测位置");return;}
        NodeTarget target=found;
        worker.post(() -> prepare(token,before,target));
    }
    private void prepare(long token,LearningPage before,NodeTarget target) {
        if(!active || token!=generation || candidate!=null)return;
        if(!org.adguardian.app.flow.FlowSafety.safeTarget(target) || (!before.adContext && before.guard.isEmpty())
                || (target.id.isEmpty() && target.label.isEmpty() && before.guard.isEmpty())) {
            hint(token,"缺少可复用的页面和按钮特征 本次不会保存 请保持完整广告页面后再选取");return;
        }
        try {
            long version=before.snapshot.version;
            String app=before.pkg;try{app=service.getPackageManager().getApplicationLabel(service.getPackageManager().getApplicationInfo(before.pkg,0)).toString();}catch(PackageManager.NameNotFoundException unavailable){}
            if(!active || token!=generation)return;
            candidate=new LearnedRule(UUID.randomUUID().toString(),before.pkg,app,before.activity,
                    version,target.forLearning(),true,type,before.guard);
            boolean stored=recording.persist(before.pkg,version,java.util.List.of(new org.adguardian.app.flow.FlowStep(before.snapshot.guard,target.forLearning(),false,30000)),0,org.adguardian.app.recording.RecordingDraft.CAPTURED);
            hint(token,stored?"按钮已写入录制草稿 请手动关闭广告 然后点 保存 校验后才启用":recording.problem());
        } catch(RuntimeException unavailable) {hint(token,"无法读取目标应用版本 请重试");}
    }
    /** One explicit teaching tap selects a real node; it does not inject a click into the app. */
    public void selectAt(float screenX,float screenY) {
        if(!active || saving)return;
        long token=generation,selection=++selectionGeneration;
        LearningPage before=page;
        String expected=before==null?foreground.get():before.pkg;
        worker.post(() -> selectFresh(token,selection,expected,before,screenX,screenY,0));
    }
    private void selectFresh(long token,long selection,String expected,LearningPage before,float x,float y,int attempt) {
        if(!active || token!=generation || selection!=selectionGeneration || saving)return;
        if(expected==null || expected.isEmpty() || expected.equals(service.getPackageName()) || !expected.equals(foreground.get())) {
            hint(token,"请先打开需要学习的广告页面");return;
        }
        AccessibilityNodeInfo root=RootAccess.readFreshFor(service,expected);
        try {
            if(root==null) {
                if(attempt<2)worker.postDelayed(()->selectFresh(token,selection,expected,before,x,y,attempt+1),attempt==0?120L:300L);
                else hint(token,"系统暂时未提供广告窗口 没有保存新规则 请保持广告页面后重试");
                return;
            }
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)) {
                index.startQueryBudget(160L);
                long version=versions.read(service,expected);
                if(version<0){hint(token,"暂时未读到应用版本 请稍后重试");return;}
                LearningPage fresh=LearningPage.capture(expected,before==null?"":before.activity,version,index);
                if(fresh==null){hint(token,org.adguardian.app.runtime.ScanDiagnostics.explain(org.adguardian.app.runtime.ScanDiagnostics.Area.PAGE));return;}
                if(before!=null && (before.snapshot.version!=version || !before.snapshot.guard.matches(fresh.snapshot.guard))) {
                    hint(token,"页面已经变化 请重新选取当前广告的关闭按钮");return;
                }
                NodeTarget target=fresh.pick(x,y);
                if(target==null){hint(token,"已读取 "+fresh.snapshot.nodeCount+" 个控件 这个位置没有唯一关闭目标 不记录整张广告画布");return;}
                if(!active || token!=generation || selection!=selectionGeneration || !expected.equals(foreground.get()))return;
                page=fresh;history.add(fresh.snapshot);candidate=null;prepare(token,fresh,target);
            }
        }catch(RuntimeException unavailable){hint(token,"控件读取暂时失败 请重新选取");}
        finally{if(root!=null)root.recycle();}
    }
    private void beginPick() {
        if(!active || saving)return;
        candidate=null;save.setEnabled(false);
        hint(generation,"轻点广告关闭按钮的位置 这次只选取 然后请再手动关闭广告");
        removePicker();
        View selection=new View(service);selection.setBackgroundColor(0x18000000);
        selection.setOnTouchListener((view,event) -> {
            if(event.getAction()==MotionEvent.ACTION_UP) {
                float x=event.getRawX(),y=event.getRawY();removePicker();selectAt(x,y);view.performClick();
            } else if(event.getAction()==MotionEvent.ACTION_CANCEL)removePicker();
            return true;
        });
        WindowManager.LayoutParams params=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;
        try {windows.addView(selection,params);picker=selection;}
        catch(RuntimeException unavailable) {hint(generation,"无法显示选取层 请直接手动关闭或取消学习");}
    }
    private void removePicker() {
        if(picker!=null && windows!=null)try {windows.removeView(picker);}catch(RuntimeException unavailable) { }
        picker=null;
    }
    private void hint(long token,String text) {
        main.post(() -> {if(active && token==generation && message!=null) {
            lastStatus=text;message.setText(text);save.setEnabled(candidate!=null && !saving);
        }});
    }
    private WindowManager.LayoutParams panelParams() {
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        p.gravity=(panelAtTop?Gravity.TOP:Gravity.BOTTOM)|Gravity.CENTER_HORIZONTAL;return p;
    }
    private boolean showPanel() {
        windows=(WindowManager)service.getSystemService(Context.WINDOW_SERVICE);
        if(windows==null)return false;
        panel=new LinearLayout(service);panel.setOrientation(LinearLayout.VERTICAL);
        int p=Math.round(8*service.getResources().getDisplayMetrics().density);
        panel.setPadding(p,p,p,p);panel.setBackgroundColor(Color.rgb(248,248,248));
        message=new TextView(service);message.setTextColor(Color.BLACK);message.setTextSize(14);panel.addView(message);
        LinearLayout row=new LinearLayout(service);row.setOrientation(LinearLayout.HORIZONTAL);panel.addView(row);
        addButton(row,"选取按钮",this::beginPick);
        save=addButton(row,"保存",this::confirm);save.setEnabled(false);
        addButton(row,"重试",() -> start(type));
        LinearLayout more=new LinearLayout(service);more.setOrientation(LinearLayout.HORIZONTAL);panel.addView(more);
        addButton(more,"移动提示条",() -> {
            panelAtTop=!panelAtTop;
            try {windows.updateViewLayout(panel,panelParams());}catch(RuntimeException unavailable){hint(generation,"提示条暂时无法移动");}
        });
        addButton(more,"结束并保留记录",this::stop);
        try {windows.addView(panel,panelParams());return true;}
        catch(RuntimeException error) {panel=null;message=null;save=null;return false;}
    }
    private Button addButton(LinearLayout row,String text,Runnable click) {
        Button b=new Button(service);b.setText(text);b.setAllCaps(false);b.setOnClickListener(v->click.run());
        row.addView(b,new LinearLayout.LayoutParams(0,WindowManager.LayoutParams.WRAP_CONTENT,1f));return b;
    }
    private void confirm() {
        LearnedRule selected=candidate;
        if(!active || selected==null || saving)return;
        saving=true;save.setEnabled(false);long token=generation;
        worker.post(() -> confirmGone(token,selected,0));
    }
    private void confirmGone(long token,LearnedRule selected,int absent) {
        if(!active || token!=generation || selected!=candidate)return;
        if(!PreferenceStore.isLearnedEnabled(service) || !PreferenceStore.isMasterEnabled(service)
                || !selected.packageName.equals(foreground.get())) {
            saving=false;hint(token,"应用已经切换或学习规则已关闭 本次没有保存");return;
        }
        AccessibilityNodeInfo root=RootAccess.readFreshFor(service,selected.packageName);
        try {
            if(root==null) {saving=false;hint(token,"按钮草稿已保留 暂时无法确认关闭效果 请回到原应用后再校验");return;}
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)) {
                index.startQueryBudget(160L);
                for(AccessibilityNodeInfo n:selected.target.candidates(index)) {
                    if(selected.target.matches(n,index.rootBounds(),true)) {
                        saving=false;hint(token,"按钮草稿已保留 关闭效果未通过校验 请先手动关闭 再校验启用");return;
                    }
                }
                if(index.isTraversalIncomplete()) {saving=false;hint(token,"按钮草稿已保留 页面信息不完整 暂不启用自动规则");return;}
            }
            if(absent<1) {worker.postDelayed(()->confirmGone(token,selected,absent+1),180L);return;}
            if(!active || token!=generation)return;
            engine.store().add(selected);
            if(recording!=null)recording.mark(1,org.adguardian.app.recording.RecordingDraft.ENABLED);
            main.post(() -> {if(active && token==generation) {
                lastStatus="学习规则已保存 已确认原关闭控件消失";stop();UserEventLog.record(service,lastStatus);
            }});
        } catch(IOException error) {saving=false;hint(token,"自动规则写入失败 按钮录制草稿仍然保留 请检查存储空间");}
        catch(RuntimeException unavailable) {saving=false;hint(token,"页面读取暂时失败 本次没有保存 请重试");}
        finally {if(root!=null)root.recycle();}
    }
    public void stop() {
        boolean wasActive=active;active=false;generation++;selectionGeneration++;candidate=null;page=null;history.clear();saving=false;
        worker.removeCallbacksAndMessages(null);
        main.removeCallbacksAndMessages(null);removePicker();
        if(panel!=null && windows!=null)try {windows.removeView(panel);}catch(RuntimeException unavailable) { }
        panel=null;message=null;save=null;
        if(oldNotificationTimeout>=0)try {
            android.accessibilityservice.AccessibilityServiceInfo info=service.getServiceInfo();
            if(info!=null) {info.notificationTimeout=oldNotificationTimeout;service.setServiceInfo(info);}
        }catch(RuntimeException unavailable) { }
        oldNotificationTimeout=-1;
        if(wasActive)resume.run();
    }
}
