package org.adguardian.app.classapp;

import android.content.Context;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;
import org.adguardian.app.engine.*;

/** Local APK-derived rules. Loaded by the running engine, not documentation or a remote subscription. */
public final class ClassAdRules {
    public static final String ASSET="class/cn.luyiyuntech.stt_1013.json";
    public static final class Rule {
        public final String key,name,targetId;
        public final AdType type;
        public final List<String> activities,allIds;
        public final boolean matchCloseText;
        Rule(JSONObject o)throws JSONException {
            key=o.getString("key");name=o.getString("name");type=AdType.valueOf(o.getString("category"));
            targetId=o.getString("targetId");activities=strings(o.getJSONArray("activities"));allIds=strings(o.getJSONArray("allIds"));
            matchCloseText=Boolean.TRUE.equals(o.get("matchCloseText"));
            if(key.isEmpty() || name.isEmpty() || (activities.isEmpty() && allIds.size()<2)
                    || (!targetId.isEmpty() && !targetId.matches("[a-z][a-z0-9_]*")))throw new IllegalArgumentException("Invalid CLASS rule");
        }
        boolean scope(String activity,AccessibilityNodeIndex index) {
            if(activities.contains(activity))return true;
            if(allIds.isEmpty())return false;
            for(String id:allIds)if(visibleId(index,id)==null)return false;
            return true;
        }
    }
    public final List<Rule> rules;
    private ClassAdRules(List<Rule> rules){this.rules=Collections.unmodifiableList(rules);}
    private static List<String> strings(JSONArray a)throws JSONException {
        ArrayList<String> values=new ArrayList<>();for(int i=0;i<a.length();i++)values.add(a.getString(i));return Collections.unmodifiableList(values);
    }
    public static ClassAdRules load(Context context) {
        try(InputStream in=context.getAssets().open(ASSET)) {
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();byte[] chunk=new byte[4096];int n;
            while((n=in.read(chunk))!=-1){if(buffer.size()+n>65536)throw new IOException("CLASS rule size");buffer.write(chunk,0,n);}
            byte[] bytes=buffer.toByteArray();
            JSONObject root=new JSONObject(new String(bytes,StandardCharsets.UTF_8));
            if(root.getInt("schema")!=1 || !ClassAdProfile.PACKAGE.equals(root.getString("package"))
                    || root.getInt("versionCode")!=ClassAdProfile.VERSION)throw new IOException("CLASS scope");
            JSONObject terminal=root.getJSONObject("terminal");
            if(!ClassAdProfile.MAIN.equals(terminal.getString("activity")) || !ClassAdProfile.HOME_IDS.equals(strings(terminal.getJSONArray("allIds"))))throw new IOException("CLASS terminal guard");
            JSONArray source=root.getJSONArray("rules");ArrayList<Rule> rules=new ArrayList<>();Set<String> keys=new HashSet<>();
            for(int i=0;i<source.length();i++){Rule rule=new Rule(source.getJSONObject(i));if(!keys.add(rule.key))throw new IOException("Duplicate CLASS rule");rules.add(rule);}
            if(rules.size()!=4)throw new IOException("CLASS rule count");return new ClassAdRules(rules);
        } catch(IOException | JSONException | RuntimeException invalid){return new ClassAdRules(new ArrayList<>());}
    }
    public Rule match(String activity,AccessibilityNodeIndex index) {
        if(activity!=null && activity.contains("TTRewardVideo"))return null;
        for(Rule rule:rules) {
            // The same stale Splash metadata that blocked lesson completion must not make
            // an ordinary, positively identified home page eligible for ad-close actions.
            if(rule.type==AdType.STARTUP && ClassAdProfile.SPLASH.equals(activity) && visibleHome(index)
                    && (visibleId(index,"fl_ad_container")==null || visibleId(index,"fl_place_holder_container")==null))continue;
            if(rule.scope(activity,index))return rule;
        }
        return null;
    }
    private static boolean visibleHome(AccessibilityNodeIndex index) {
        for(String suffix:ClassAdProfile.HOME_IDS)if(visibleId(index,suffix)==null)return false;
        return !index.isTraversalIncomplete();
    }
    /** Some virtual providers cannot fast-query IDs although they expose named child nodes. */
    public static AccessibilityNodeInfo visibleId(AccessibilityNodeIndex index,String suffix) {
        if(suffix==null || suffix.isEmpty())return null;
        String id=ClassAdProfile.PACKAGE+":id/"+suffix;AccessibilityNodeInfo chosen=null;
        List<AccessibilityNodeInfo> fast=index.fastQuery(index.root(),"id",id);
        Iterable<AccessibilityNodeInfo> nodes=fast.isEmpty()?index.nodes():fast;
        for(AccessibilityNodeInfo n:nodes) {
            if(!id.equals(NodeTarget.string(n.getViewIdResourceName())) || !n.isVisibleToUser() || !n.isEnabled())continue;
            android.graphics.Rect b=new android.graphics.Rect();n.getBoundsInScreen(b);if(b.width()<=0||b.height()<=0)continue;
            if(chosen!=null && !chosen.equals(n))return null;chosen=n;
        }
        return index.isTraversalIncomplete()?null:chosen;
    }
    public static String describe(Context context) {
        ClassAdRules bundle=load(context);
        if(bundle.rules.isEmpty())return "CLASS 内置规则读取失败 原有广告规则不受影响";
        StringBuilder text=new StringBuilder("Class课程表 6.2.1013\n包名 ").append(ClassAdProfile.PACKAGE)
                .append("\n适配版本码 1013\n已加载 ").append(bundle.rules.size()).append(" 组内置规则\n");
        for(Rule rule:bundle.rules) {
            text.append("\n").append(rule.name).append("\n");
            if(!rule.activities.isEmpty())text.append("页面 ").append(String.join(" 或 ",rule.activities)).append('\n');
            if(!rule.allIds.isEmpty())text.append("联合控件 ").append(String.join(" 和 ",rule.allIds)).append('\n');
            if(!rule.targetId.isEmpty())text.append("关闭目标 ").append(rule.targetId).append('\n');
            if(rule.matchCloseText)text.append("补充识别 当前广告中的跳过或关闭按钮\n");
        }
        return text.append("\n返回课表的确认条件\n").append(String.join(" 和 ",ClassAdProfile.HOME_IDS)).append("\n只点击真实可见关闭入口 不点击购买下载 不使用盲目返回").toString();
    }
}
