package org.adguardian.app.engine;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.function.Supplier;
import org.adguardian.app.gkd.GkdSubscriptionEngine;
import org.adguardian.app.litiaotiao.LiTiaotiaoRuleEngine;
import org.adguardian.app.settings.PreferenceStore;
import org.adguardian.app.learning.LearnedRuleEngine;
import org.adguardian.app.flow.FlowReplayEngine;
import org.adguardian.app.classapp.ClassAdEngine;

public final class RuleEngine {
    private final AccessibilityService service;
    private final LiTiaotiaoRuleEngine liTiaotiao;
    private final GkdAssistEngine assist;
    private final GkdSubscriptionEngine subscription;
    private final ActionVerifier verifier;
    private final LearnedRuleEngine learned;
    private final FlowReplayEngine flows;
    private final ClassAdEngine classAdapter;
    private volatile long assistAction;
    private volatile boolean externalAction;
    private volatile long externalActionTime;
    private long externalGeneration;
    private String currentPackage="";

    public RuleEngine(AccessibilityService service, Handler worker,
                      Runnable requestScan,Supplier<String> foreground) {
        this.service=service;
        verifier=new ActionVerifier(service,worker,foreground,requestScan);
        learned=new LearnedRuleEngine(service,worker,verifier,foreground);
        flows=new FlowReplayEngine(service,worker,foreground,requestScan);
        classAdapter=new ClassAdEngine(service,worker,foreground,requestScan,verifier);
        liTiaotiao=new LiTiaotiaoRuleEngine(service,worker,foreground,verifier);
        assist=new GkdAssistEngine(service,worker,verifier);
        subscription=new GkdSubscriptionEngine(service,worker,requestScan,foreground,verifier);
        liTiaotiao.setExternalActionPending(() -> externalAction || flows.isActive() || classAdapter.isPending() || learned.isPending() || assist.isGesturePending() || subscription.isGesturePending() || verifier.isPending());
    }
    public void onPackageEntered(String packageName) {
        if(packageName.equals(currentPackage))return;
        cancelExternalAction();
        currentPackage=packageName;
        verifier.onPackageChanged();learned.onPackageChanged();assist.cancelPending();
        flows.onPackageChanged();classAdapter.onPackageChanged();
        liTiaotiao.onPackageEntered(packageName);
        subscription.onPackageEntered(packageName);
        assist.onPackageEntered(packageName);
    }
    public int liTiaotiaoPackageCount() { return liTiaotiao.packageCount(); }
    public int liTiaotiaoRuleCount() { return liTiaotiao.ruleCount(); }
    public long lastAutomatedActionUptime() {
        return Math.max(Math.max(Math.max(Math.max(Math.max(assistAction,externalActionTime),Math.max(flows.lastAction(),classAdapter.lastAction())),learned.lastAction()),verifier.lastAction()),Math.max(liTiaotiao.lastAutomatedActionUptime(),subscription.lastAutomatedActionUptime()));
    }
    public boolean beginExternalAction() {
        if(externalAction || isWaitingForRules())return false;
        long last=lastAutomatedActionUptime();
        if(last>0 && SystemClock.uptimeMillis()-last<900L)return false;
        externalAction=true;
        externalGeneration++;
        externalActionTime=SystemClock.uptimeMillis();
        return true;
    }
    public long externalActionToken() { return externalGeneration; }
    public void endExternalAction() { cancelExternalAction(); }
    private void cancelExternalAction() { externalAction=false;externalGeneration++; }
    public void endExternalAction(long token) { if(token==externalGeneration)externalAction=false; }
    public LearnedRuleEngine learned() {return learned;}
    public FlowReplayEngine flows() {return flows;}
    public ActionVerifier verifier() { return verifier; }
    public void onUserInteraction() { flows.cancel();classAdapter.onUserInteraction();cancelExternalAction();verifier.cancel();liTiaotiao.cancelPending();subscription.cancelPendingActions();learned.cancel();assist.cancelPending(); }
    public boolean isWaitingForRules() { return flows.isActive() || classAdapter.isPending() || verifier.isPending() || learned.isPending() || assist.isGesturePending() || liTiaotiao.hasPendingAction() || subscription.isWaiting(); }
    public long nextWakeUp() {
        if(flows.isActive())return flows.nextWakeUp();
        long normal=subscription.nextWakeUp(),specific=classAdapter.nextWakeUp();
        return normal<0?specific:specific<0?normal:Math.min(normal,specific);
    }
    public void onSettingsChanged() { flows.cancel();classAdapter.onPackageChanged();cancelExternalAction();verifier.cancel();learned.cancel();assist.cancelPending();liTiaotiao.cancelPending();subscription.reset(); }
    public void close() { flows.close();classAdapter.close();cancelExternalAction();verifier.cancel();learned.cancel();assist.cancelPending();liTiaotiao.cancelPending();subscription.close(); }

    public boolean handle(String packageName,String activityName,int eventType,AccessibilityNodeInfo root) {
        if(root==null || packageName==null || packageName.isEmpty()
                || !PreferenceStore.isMasterEnabled(service))return false;
        onPackageEntered(packageName);
        if(externalAction || verifier.isPending() || learned.isPending() || assist.isGesturePending() || classAdapter.isPending())return true;
        if(subscription.isWaiting() && subscription.nextWakeUp()<0)return true;
        long last=lastAutomatedActionUptime();
        if(last>0 && SystemClock.uptimeMillis()-last<100L)return true;
        try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)) {
            if(flows.handle(packageName,activityName,index)) {
                liTiaotiao.cancelPending();subscription.cancelPendingActions();assist.cancelPending();
                return true;
            }
            if(learned.handle(packageName,activityName,index))return true;
            if(classAdapter.handle(packageName,activityName,index))return true;
            if(PreferenceStore.isLiTiaotiaoEnabled(service)
                    && liTiaotiao.handle(packageName,root,index))return true;
            if(liTiaotiao.hasPendingAction())return true;
            if(!PreferenceStore.isGkdEnabled(service))return false;
            if(subscription.handle(packageName,activityName,index))return true;
            boolean handled=assist.handle(packageName,activityName,eventType,index);
            assistAction=assist.lastAutomatedActionUptime();
            return handled;
        }
    }
}
