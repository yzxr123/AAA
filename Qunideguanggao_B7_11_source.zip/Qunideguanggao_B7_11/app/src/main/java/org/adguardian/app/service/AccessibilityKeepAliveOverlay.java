package org.adguardian.app.service;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

public final class AccessibilityKeepAliveOverlay {
    private final AccessibilityService service;
    private WindowManager windowManager;
    private View overlayView;

    public AccessibilityKeepAliveOverlay(AccessibilityService service) {
        this.service = service;
    }

    public synchronized boolean attach() {
        if (overlayView != null) return true;
        try {
            windowManager = (WindowManager) service.getSystemService(Context.WINDOW_SERVICE);
            if (windowManager == null) return false;
            View view = new View(service);
            view.setAlpha(0.0f);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    1,
                    1,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.START | Gravity.TOP;
            params.x = 0;
            params.y = 0;
            params.packageName = service.getPackageName();
            windowManager.addView(view, params);
            overlayView = view;
            return true;
        } catch (RuntimeException ignored) {
            detach();
            return false;
        }
    }

    public synchronized void detach() {
        View view = overlayView;
        overlayView = null;
        if (view == null || windowManager == null) return;
        try {
            windowManager.removeView(view);
        } catch (RuntimeException ignored) {
        }
    }

    public synchronized boolean isAttached() {
        return overlayView != null;
    }
}
