package org.adguardian.app.flow;
import java.util.*;
import org.adguardian.app.engine.AdType;
public final class LearnedFlow {
    public final String key,packageName,appName;
    public final long versionCode;
    public final AdType type;
    public final boolean enabled;
    public final List<FlowStep> steps;
    public final FlowGuard terminal;
    public LearnedFlow(String key,String pkg,String name,long version,AdType type,boolean enabled,List<FlowStep> steps,FlowGuard terminal) {
        this.key=key;packageName=pkg;appName=name;versionCode=version;this.type=type;this.enabled=enabled;
        this.steps=steps==null?List.of():Collections.unmodifiableList(new ArrayList<>(steps));this.terminal=terminal;
    }
    public LearnedFlow withEnabled(boolean value){return new LearnedFlow(key,packageName,appName,versionCode,type,value,steps,terminal);}
}
