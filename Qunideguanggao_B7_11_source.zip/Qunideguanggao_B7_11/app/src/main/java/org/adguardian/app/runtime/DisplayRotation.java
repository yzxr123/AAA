package org.adguardian.app.runtime;

import android.content.Context;
import android.view.WindowManager;

/** Physical display rotation is not the aspect ratio of a dialog or an inset content window. */
public final class DisplayRotation {
    private DisplayRotation() { }
    @SuppressWarnings("deprecation")
    public static int read(Context context) {
        try {
            WindowManager manager=(WindowManager)context.getSystemService(Context.WINDOW_SERVICE);
            if(manager==null || manager.getDefaultDisplay()==null)return -1;
            int value=manager.getDefaultDisplay().getRotation();
            return value>=0 && value<=3?value:-1;
        } catch(RuntimeException unavailable) {return -1;}
    }
    public static boolean compatible(int a,int b,float fallbackA,float fallbackB) {
        if(a>=0 && b>=0)return a==b;
        // Unknown rotation: preserve the old landscape rejection, but do not call insets a rotation.
        return (fallbackA>1f)==(fallbackB>1f);
    }
}
