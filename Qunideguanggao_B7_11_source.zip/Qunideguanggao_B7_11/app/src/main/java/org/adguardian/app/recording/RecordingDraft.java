package org.adguardian.app.recording;

import java.util.*;
import org.adguardian.app.engine.AdType;
import org.adguardian.app.flow.FlowStep;

/** Captured evidence is separate from an executable rule. Drafts are never read by rule engines. */
public final class RecordingDraft {
    public static final int CAPTURED=0, NEEDS_REVIEW=1, ENABLED=2;
    public final String key, packageName, appName;
    public final long version, updatedAt;
    public final AdType type;
    public final boolean single;
    public final int confirmed, state;
    public final List<FlowStep> steps;
    public RecordingDraft(String key,String pkg,String app,long version,AdType type,boolean single,
                          List<FlowStep> steps,int confirmed,int state,long updatedAt) {
        this.key=key;packageName=pkg;appName=app;this.version=version;this.type=type;this.single=single;
        this.steps=Collections.unmodifiableList(new ArrayList<>(steps));this.confirmed=confirmed;
        this.state=state;this.updatedAt=updatedAt;
    }
    public String stateText(){return state==ENABLED?"本次教学已完成验证":state==NEEDS_REVIEW?"草稿已保存 需要重新核对步骤":"草稿已保存 等待结束校验";}
}
