package org.adguardian.app.learning;

import android.content.Context;
import android.util.AtomicFile;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.adguardian.app.engine.NodeTarget;
import org.adguardian.app.engine.AdType;

public final class LearnedRuleStore {
    private static final int MAGIC=0x51414432;
    private static final int OLD_MAGIC=0x51414431;
    public static final int MAX_RULES=64;
    private static final Object FILE_LOCK=new Object();
    private static long revision;
    private long loadedRevision;
    private final AtomicFile file;
    private List<LearnedRule> rules=new ArrayList<>();
    private boolean readable=true;
    public LearnedRuleStore(Context context) {
        file=new AtomicFile(new File(context.getFilesDir(),"learned-ad-rules.bin"));
        synchronized(FILE_LOCK){load();}
    }
    private void load() {
        rules=new ArrayList<>();readable=true;loadedRevision=revision;
        if(!file.getBaseFile().exists() && !new File(file.getBaseFile()+".bak").exists())return;
        try(DataInputStream in=new DataInputStream(file.openRead())) {
            int format=in.readInt();
            if(file.getBaseFile().length()>131072L || (format!=MAGIC && format!=OLD_MAGIC))throw new IOException("invalid rule data");
            int count=in.readInt();
            if(count<0 || count>MAX_RULES)throw new IOException("rule limit");
            ArrayList<LearnedRule> loaded=new ArrayList<>();
            for(int i=0;i<count;i++) {
                String key=field(in),pkg=field(in),name=field(in),activity=field(in);
                long version=in.readLong();boolean enabled=in.readBoolean();
                int type=in.readInt();if(type<0 || type>=AdType.values().length)throw new IOException("invalid type");
                NodeTarget target=new NodeTarget(field(in),field(in),field(in),in.readFloat(),in.readFloat(),in.readFloat(),in.readFloat());
                String guard=format==MAGIC?field(in):"";
                LearnedRule rule=new LearnedRule(key,pkg,name,activity,version,target,enabled,AdType.values()[type],guard);
                validate(rule);loaded.add(rule);
            }
            if(in.read()!=-1)throw new IOException("trailing rule data");
            rules=loaded;
        } catch(IOException | RuntimeException error) { readable=false; }
    }
    private void refresh(){if(loadedRevision!=revision)load();}
    public boolean isReadable() {synchronized(FILE_LOCK){refresh();return readable;}}
    public List<LearnedRule> all() {synchronized(FILE_LOCK){refresh();return Collections.unmodifiableList(rules);}}
    public boolean hasPackage(String pkg) {
        for(LearnedRule rule:all())if(rule.enabled && rule.packageName.equals(pkg))return true;
        return false;
    }
    public void add(LearnedRule rule) throws IOException {
        synchronized(FILE_LOCK){load();
        if(!readable)throw new IOException("local rules need repair");
        validate(rule);
        ArrayList<LearnedRule> next=new ArrayList<>(rules);
        next.removeIf(old -> old.packageName.equals(rule.packageName) && old.activityName.equals(rule.activityName)
                && old.target.id.equals(rule.target.id) && old.target.label.equals(rule.target.label)
                && Math.abs(old.target.x-rule.target.x)<0.025f && Math.abs(old.target.y-rule.target.y)<0.025f);
        if(next.size()>=MAX_RULES)throw new IOException("rule limit reached");
        next.add(rule);save(next);}
    }
    public void setEnabled(String key,boolean enabled) throws IOException {
        synchronized(FILE_LOCK){load();
        if(!readable)throw new IOException("unreadable rule file");
        ArrayList<LearnedRule> next=new ArrayList<>();
        for(LearnedRule rule:rules)next.add(rule.key.equals(key)?rule.withEnabled(enabled):rule);
        save(next);}
    }
    public void remove(String key) throws IOException {
        synchronized(FILE_LOCK){load();
        if(!readable)throw new IOException("unreadable rule file");
        ArrayList<LearnedRule> next=new ArrayList<>(rules);next.removeIf(rule -> rule.key.equals(key));save(next);}
    }
    public void clear() throws IOException {synchronized(FILE_LOCK){save(new ArrayList<>());readable=true;}}
    private void save(List<LearnedRule> next) throws IOException {
        for(LearnedRule rule:next)validate(rule);
        java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();
        DataOutputStream out=new DataOutputStream(bytes);out.writeInt(MAGIC);out.writeInt(next.size());
        for(LearnedRule rule:next) {
            out.writeUTF(rule.key);out.writeUTF(rule.packageName);out.writeUTF(rule.appName);out.writeUTF(rule.activityName);
            out.writeLong(rule.versionCode);out.writeBoolean(rule.enabled);out.writeInt(rule.type.ordinal());
            NodeTarget t=rule.target;out.writeUTF(t.id);out.writeUTF(t.name);out.writeUTF(t.label);
            out.writeFloat(t.x);out.writeFloat(t.y);out.writeFloat(t.width);out.writeFloat(t.height);out.writeUTF(rule.pageGuard);
        }
        out.flush();if(bytes.size()>131072L)throw new IOException("rule storage limit");
        FileOutputStream stream=file.startWrite();
        try {
            byte[] expected=bytes.toByteArray();stream.write(expected);stream.getFD().sync();file.finishWrite(stream);
            try(java.io.InputStream verify=file.openRead()) {
                byte[] buffer=new byte[4096];int offset=0,count;
                while((count=verify.read(buffer))!=-1){if(offset+count>expected.length)throw new IOException("rule readback length");
                    for(int i=0;i<count;i++)if(buffer[i]!=expected[offset+i])throw new IOException("rule readback mismatch");offset+=count;}
                if(offset!=expected.length)throw new IOException("rule readback truncated");
            }
            revision++;loadedRevision=revision;rules=new ArrayList<>(next);
        } catch(IOException | RuntimeException error) {file.failWrite(stream);throw new IOException("rule write failed",error);}
    }
    private static void validate(LearnedRule r)throws IOException {
        if(r==null || r.target==null || r.type==null)throw new IOException("missing target");
        for(String s:new String[]{r.key,r.packageName,r.appName,r.activityName,r.target.id,r.target.name,r.target.label,r.pageGuard})
            if(s==null || s.length()>512)throw new IOException("field limit");
        if(r.key.isEmpty() || r.packageName.isEmpty() || r.activityName.isEmpty() || r.versionCode<0
                || !finite(r.target) || !(r.pageGuard.startsWith("f2:")?org.adguardian.app.flow.FlowSafety.safeTarget(r.target):r.target.isSafeLearningTarget()))throw new IOException("invalid target");
        if(!r.pageGuard.isEmpty() && !r.pageGuard.matches("(?:p1|f2):[0-9a-f]{64}"))throw new IOException("invalid page signature");
        if((r.activityName.startsWith("@window:") || (r.target.id.isEmpty() && r.target.label.isEmpty()))
                && r.pageGuard.isEmpty())throw new IOException("unguarded structural target");
    }
    private static String field(DataInputStream in)throws IOException {
        String text=in.readUTF();if(text.length()>512)throw new IOException("field limit");return text;
    }
    private static boolean finite(NodeTarget t) {
        return Float.isFinite(t.x)&&Float.isFinite(t.y)&&Float.isFinite(t.width)&&Float.isFinite(t.height)
                && t.x>=0 && t.x<=1 && t.y>=0 && t.y<=1;
    }
}
