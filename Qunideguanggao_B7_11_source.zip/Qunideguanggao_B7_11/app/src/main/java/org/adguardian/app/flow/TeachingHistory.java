package org.adguardian.app.flow;

import java.util.ArrayDeque;
import java.util.Iterator;

/** Bounded immutable pre-action pages retained only while the user is explicitly teaching. */
public final class TeachingHistory {
    private static final class Entry {
        final FlowPage page;
        final long firstSeen;
        long lastSeen;
        Entry(FlowPage page){this.page=page;firstSeen=lastSeen=page.capturedAt;}
    }
    private final ArrayDeque<Entry> pages=new ArrayDeque<>();
    public synchronized void clear(){pages.clear();}
    public synchronized void add(FlowPage page) {
        if(page==null)return;
        if(!pages.isEmpty()&&!pages.getLast().page.pkg.equals(page.pkg))pages.clear();
        Entry last=pages.peekLast();
        // Coalesce identical safe metadata, not distinct stages. A content-event flood must not evict the pre-click stage.
        if(last!=null&&last.page.sameRecordingPage(page))last.lastSeen=page.capturedAt;
        else pages.addLast(new Entry(page));
        while(pages.size()>12 || (!pages.isEmpty()&&page.capturedAt-pages.getFirst().lastSeen>15000))pages.removeFirst();
    }
    public synchronized FlowPage before(String pkg,long eventTime,int windowId) {
        Iterator<Entry> it=pages.descendingIterator();
        while(it.hasNext()) {
            Entry entry=it.next();FlowPage page=entry.page;
            if(!page.pkg.equals(pkg) || entry.firstSeen>eventTime)continue;
            if(eventTime-entry.lastSeen>15000 || (windowId>=0&&page.windowId!=windowId))return null;
            return page;
        }
        return null;
    }
}
