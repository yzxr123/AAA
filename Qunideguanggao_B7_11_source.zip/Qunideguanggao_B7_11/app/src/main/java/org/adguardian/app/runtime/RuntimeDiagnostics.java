package org.adguardian.app.runtime;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.os.Build;
import android.os.PowerManager;
import android.os.Process;
import java.util.List;
import org.adguardian.app.service.ProtectionService;
import org.adguardian.app.service.AdAccessibilityService;
import android.content.pm.PackageManager;

public final class RuntimeDiagnostics {
    private RuntimeDiagnostics() { }
    public static String read(Context context) {
        AccessibilityState.Snapshot state=AccessibilityState.read(context);
        StringBuilder text=new StringBuilder("去你的广告 B7.11 运行状态\n");
        text.append("当前安装包 ").append(context.getPackageName()).append('\n');
        text.append("辅助服务组件 ").append(context.getPackageName()).append('/').append(AccessibilityState.SERVICE_NAME).append('\n');
        try {android.content.pm.PackageInfo own=context.getPackageManager().getPackageInfo(context.getPackageName(),0);
            text.append("实际安装版本 ").append(own.versionName).append(" 版本码 ").append(own.getLongVersionCode()).append('\n');
        } catch(PackageManager.NameNotFoundException | RuntimeException unavailable) { }
        text.append("授权信息来源 ").append(state.evidence).append('\n');
        if(!state.otherAuthorizedPackage.isEmpty())text.append("另一个已授权的安装版本 ").append(state.otherAuthorizedPackage).append('\n');
        text.append("最近学习状态 ").append(AdAccessibilityService.learningStatus()).append('\n');
        try {
            java.util.List<org.adguardian.app.recording.RecordingDraft> drafts=new org.adguardian.app.recording.RecordingDraftStore(context).all();
            int steps=0;for(org.adguardian.app.recording.RecordingDraft d:drafts)steps+=d.steps.size();
            text.append("磁盘录制记录 ").append(drafts.size()).append(" 份 已捕获 ").append(steps).append(" 步\n");
        }catch(java.io.IOException|RuntimeException error){text.append("磁盘录制记录无法读取 原文件保留\n");}
        org.adguardian.app.flow.FlowStore flows=new org.adguardian.app.flow.FlowStore(context);
        text.append("可回放流程文件 ").append(flows.isReadable()?String.valueOf(flows.all().size())+" 条":"无法读取").append('\n');
        text.append("CLASS定向识别 ").append(org.adguardian.app.settings.PreferenceStore.isClassAdapterEnabled(context)?"开启":"关闭").append('\n');
        text.append("已学习规则开关 ").append(org.adguardian.app.settings.PreferenceStore.isLearnedEnabled(context)?"开启":"关闭").append('\n');
        text.append("设备 ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        text.append("Android ").append(Build.VERSION.RELEASE).append(" API ").append(Build.VERSION.SDK_INT).append('\n');
        text.append(state.permissionText()).append('\n').append(state.runtimeText()).append('\n');
        text.append("常驻通知保护 ").append(ProtectionService.isRunning()?"已启动":"未启动").append('\n');
        text.append("增强重连开关 ").append(AccessibilityRecovery.enabled(context)).append(" 额外授权 ").append(AccessibilityRecovery.granted(context)).append('\n');
        text.append("增强重连最近结果 ").append(AccessibilityRecovery.status()).append('\n');
        text.append("独立覆盖层 ").append(ProtectionService.fallbackOverlayAttached()).append('\n');
        PowerManager power=(PowerManager)context.getSystemService(Context.POWER_SERVICE);
        text.append("电池优化豁免 ").append(power!=null && power.isIgnoringBatteryOptimizations(context.getPackageName())).append('\n');
        if(!ProtectionService.startProblem().isEmpty())text.append(ProtectionService.startProblem()).append('\n');
        ActivityManager manager=(ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
        if(manager!=null && Build.VERSION.SDK_INT>=30) {
            try {
                List<ApplicationExitInfo> exits=manager.getHistoricalProcessExitReasons(context.getPackageName(),0,3);
                for(ApplicationExitInfo exit:exits) {
                    if(exit.getPid()==Process.myPid())continue;
                    text.append("最近进程退出 时间 ").append(exit.getTimestamp()).append(" 系统原因 ")
                            .append(exit.getReason()).append(" 状态 ").append(exit.getStatus()).append('\n');
                }
            } catch(RuntimeException error) {text.append("系统没有提供进程退出记录\n");}
        }
        if(RootAccess.lastFailureUptime()>0)text.append("最近界面读取失败 设备开机后毫秒 ").append(RootAccess.lastFailureUptime()).append('\n');
        String[] page=AdAccessibilityService.lastObservedPage();
        if(!page[0].isEmpty()) {
            text.append("最近检测应用包名 ").append(page[0]).append('\n').append("最近检测页面 ").append(page[1]).append('\n');
            try {
                text.append("应用名称 ").append(context.getPackageManager().getApplicationLabel(context.getPackageManager().getApplicationInfo(page[0],0)))
                        .append(" 版本号 ").append(context.getPackageManager().getPackageInfo(page[0],0).getLongVersionCode()).append('\n');
            } catch(PackageManager.NameNotFoundException | RuntimeException unavailable) {text.append("该应用版本暂时无法读取\n");}
        }
        text.append("\n").append(ScanDiagnostics.read());
        text.append("\n生命周期记录 仅包含服务状态和异常位置 不含截图或输入\n").append(RuntimeHealth.read(context));
        return text.toString();
    }
}
