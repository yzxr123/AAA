package org.adguardian.app.engine;

import android.accessibilityservice.AccessibilityService;
import org.adguardian.app.runtime.RootAccess;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.SystemClock;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.settings.PreferenceStore;

import java.util.List;
import java.util.Locale;

public final class GkdAssistEngine {
    private static final long ENTRY_WINDOW_MS = 12_000L;
    private static final long ACTION_GUARD_MS = 420L;
    private static final long FEED_SCROLL_GUARD_MS = 1_100L;

    private final AccessibilityService service;
    private final Handler worker;
    private final ActionVerifier verifier;
    private volatile boolean gesturePending;
    private long gestureGeneration;
    private String packageName = "";
    private long enteredUptime;
    private long lastAutomatedActionUptime;
    private long lastFeedScrollUptime;

    public GkdAssistEngine(AccessibilityService service) {
        this(service,new Handler(Looper.getMainLooper()),new ActionVerifier(service,new Handler(Looper.getMainLooper()),
                () -> rootPackage(service),()->{}));
    }
    public GkdAssistEngine(AccessibilityService service,Handler worker,ActionVerifier verifier) {
        this.service=service;this.worker=worker;this.verifier=verifier;
    }

    private static String rootPackage(AccessibilityService service) {
        AccessibilityNodeInfo root=RootAccess.read(service);
        try {return root==null?"":NodeTarget.string(root.getPackageName());}
        finally {if(root!=null)root.recycle();}
    }
    public void onPackageEntered(String currentPackage) {
        packageName = currentPackage == null ? "" : currentPackage;
        enteredUptime = SystemClock.uptimeMillis();
        lastFeedScrollUptime = 0L;
    }

    public long lastAutomatedActionUptime() {
        return lastAutomatedActionUptime;
    }

    public boolean handle(
            String currentPackage,
            String activityName,
            int eventType,
            AccessibilityNodeIndex index
    ) {
        if (!PreferenceStore.isGkdEnabled(service) || index == null) return false;
        if (currentPackage == null || currentPackage.isEmpty()) return false;
        if (!currentPackage.equals(packageName)) onPackageEntered(currentPackage);
        long now = SystemClock.uptimeMillis();
        if (now - lastAutomatedActionUptime < ACTION_GUARD_MS) return false;

        boolean startupEnabled = PreferenceStore.isTypeEnabled(service, AdType.STARTUP);
        boolean closeEnabled = PreferenceStore.isTypeEnabled(service, AdType.POPUP)
                || PreferenceStore.isTypeEnabled(service, AdType.FLOATING)
                || PreferenceStore.isTypeEnabled(service, AdType.CARD)
                || PreferenceStore.isTypeEnabled(service, AdType.FEED);
        boolean scrollEnabled = PreferenceStore.isTypeEnabled(service, AdType.SCROLL)
                || PreferenceStore.isTypeEnabled(service, AdType.FEED);
        if (!startupEnabled && !closeEnabled && !scrollEnabled) return false;

        Rect screen = index.rootBounds();
        if (screen.width() <= 0 || screen.height() <= 0) return false;
        boolean entryWindow = now - enteredUptime <= ENTRY_WINDOW_MS;
        boolean sdkActivity = AdSdkSignatures.isAdSdkActivity(activityName);
        boolean adContext = sdkActivity || index.hasAdSdkMarker() || hasAdEvidence(index.nodes());

        Candidate best = null;
        for (AccessibilityNodeInfo node : index.nodes()) {
            Candidate candidate = score(node, screen, entryWindow, adContext, startupEnabled, closeEnabled);
            if (candidate != null && (best == null || candidate.score > best.score)) {
                best = candidate;
            }
        }
        if (best != null && perform(best,index)) {
            lastAutomatedActionUptime = SystemClock.uptimeMillis();
            return true;
        }

        if (scrollEnabled && now - lastFeedScrollUptime >= FEED_SCROLL_GUARD_MS
                && shouldTryFeedScroll(eventType) && scrollPastLabeledAd(index, screen)) {
            lastFeedScrollUptime = now;
            lastAutomatedActionUptime = now;
            return true;
        }

        return false;
    }

    private Candidate score(
            AccessibilityNodeInfo node,
            Rect screen,
            boolean entryWindow,
            boolean adContext,
            boolean startupEnabled,
            boolean closeEnabled
    ) {
        if (node == null || !node.isVisibleToUser() || !node.isEnabled()) return null;
        Rect bounds = bounds(node);
        if (!safeBounds(bounds, screen)) return null;
        String text = string(node.getText());
        String desc = string(node.getContentDescription());
        String id = string(node.getViewIdResourceName());
        String shortId = shortId(id);
        String combined = (text + ' ' + desc + ' ' + id + ' ' + shortId).toLowerCase(Locale.ROOT);
        if (unsafeFlow(combined)) return null;

        boolean explicitSkip = explicitSkip(text) || explicitSkip(desc) || explicitSkip(shortId);
        boolean genericSkip = genericSkip(text) || genericSkip(desc) || idSkip(shortId);
        boolean explicitClose = explicitClose(text) || explicitClose(desc) || idClose(shortId);
        boolean genericClose = genericClose(text) || genericClose(desc);
        boolean emptyVisualClose = isEmptyVisualClose(node, bounds, screen, adContext);
        boolean dismissible = closeEnabled && adContext && supportsDismiss(node);

        boolean skip = false;
        int score = Integer.MIN_VALUE;
        if (startupEnabled && explicitSkip) {
            skip = true;
            score = 150;
        } else if (startupEnabled && entryWindow && adContext && genericSkip && likelySkipPosition(bounds, screen)) {
            skip = true;
            score = 112;
        } else if (closeEnabled && explicitClose) {
            score = 138;
        } else if (dismissible) {
            score = 134;
        } else if (closeEnabled && adContext && genericClose && likelyClosePosition(bounds, screen)) {
            score = 102;
        } else if (closeEnabled && emptyVisualClose) {
            score = 82;
        } else {
            return null;
        }

        if (node.isClickable()) score += 22;
        if (node.isFocusable()) score += 4;
        if (combined.contains("ad") || combined.contains("splash") || combined.contains("skip")) score += 12;
        if (bounds.exactCenterX() >= screen.left + screen.width() * 0.60f) score += 10;
        if (bounds.exactCenterY() <= screen.top + screen.height() * 0.42f) score += 8;
        return new Candidate(node, bounds, score, skip, dismissible);
    }

    private boolean scrollPastLabeledAd(AccessibilityNodeIndex index, Rect screen) {
        AccessibilityNodeInfo fallbackScrollable = null;
        for (AccessibilityNodeInfo node : index.nodes()) {
            if (node == null || !node.isVisibleToUser()) continue;
            if (fallbackScrollable == null && node.isScrollable()) {
                Rect bounds = bounds(node);
                if (bounds.width() >= screen.width() * 0.70f && bounds.height() >= screen.height() * 0.40f) {
                    fallbackScrollable = node;
                }
            }
            String value = (string(node.getText()) + ' ' + string(node.getContentDescription())).trim();
            if (!isFeedAdLabel(value)) continue;
            ActionVerifier.Ticket ticket=verifier.capture(currentPackageForFeedback(),"assist:scroll","swipe",node,index,null);
            if(ticket==null)continue;
            AccessibilityNodeInfo scrollable = scrollableAncestor(node,index);
            if (scrollable != null && scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
                verifier.accepted(ticket);return true;
            }
            if (fallbackScrollable != null
                    && fallbackScrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
                verifier.accepted(ticket);return true;
            }
        }
        return false;
    }

    public boolean isGesturePending() {return gesturePending;}
    public void cancelPending() {gestureGeneration++;gesturePending=false;}
    private String currentPackageForFeedback() { return packageName; }

    private AccessibilityNodeInfo scrollableAncestor(AccessibilityNodeInfo node,AccessibilityNodeIndex index) {
        AccessibilityNodeInfo current = node;
        for (int depth = 0; current != null && depth < 9; depth++) {
            if (current.isScrollable() && current.isEnabled()) return current;
            current = index.cachedParent(current);
        }
        return null;
    }

    private boolean hasAdEvidence(Iterable<AccessibilityNodeInfo> nodes) {
        int checked = 0;
        for (AccessibilityNodeInfo node : nodes) {
            if (checked++ >= 220) break;
            String value = (string(node.getText()) + ' ' + string(node.getContentDescription()) + ' '
                    + string(node.getViewIdResourceName())).toLowerCase(Locale.ROOT);
            if (value.contains("广告") || value.contains("推广") || value.contains("赞助")

                    || value.contains("advertisement") || value.contains("sponsored")
                    || value.contains("ksad") || value.contains("pangle") || value.contains("gdt")) {
                return true;
            }
        }
        return false;
    }

    private boolean perform(Candidate candidate,AccessibilityNodeIndex index) {
        AccessibilityNodeInfo node=candidate.node;
        String key="assist:"+NodeTarget.string(node.getViewIdResourceName())+":"+NodeTarget.string(node.getText());
        ActionVerifier.Ticket ticket=verifier.capture(packageName,key,"click",node,index,null);
        if(ticket==null)return false;
        if(candidate.dismiss && node.performAction(AccessibilityNodeInfo.ACTION_DISMISS)) {
            verifier.accepted(ticket);return true;
        }
        AccessibilityNodeInfo current=node;
        for(int depth=0;current!=null && depth<7;depth++) {
            if(current.isClickable() && current.isEnabled() && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                verifier.accepted(ticket);return true;
            }
            current=index.cachedParent(current);
        }
        Path path=new Path();path.moveTo(candidate.bounds.exactCenterX(),candidate.bounds.exactCenterY());
        GestureDescription gesture=new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path,0L,48L)).build();
        long token=++gestureGeneration;gesturePending=true;
        boolean accepted;
        try {
            accepted=service.dispatchGesture(gesture,new AccessibilityService.GestureResultCallback() {
                @Override public void onCompleted(GestureDescription value) {
                    if(token!=gestureGeneration)return;gesturePending=false;
                    if(PreferenceStore.isMasterEnabled(service) && PreferenceStore.isGkdEnabled(service))verifier.accepted(ticket);
                }
                @Override public void onCancelled(GestureDescription value) {
                    if(token!=gestureGeneration)return;gesturePending=false;verifier.rejected(ticket);
                }
            },worker);
        } catch(RuntimeException error) {gesturePending=false;verifier.rejected(ticket);return false;}
        if(!accepted) {gesturePending=false;verifier.rejected(ticket);}
        else worker.postDelayed(() -> {
            if(token==gestureGeneration && gesturePending) {gesturePending=false;gestureGeneration++;verifier.rejected(ticket);}
        },1500L);
        return accepted;
    }

    private static boolean shouldTryFeedScroll(int eventType) {
        return eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                || eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED
                || eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED;
    }

    private static boolean isFeedAdLabel(String value) {
        String lower = value.toLowerCase(Locale.ROOT).replace(" ", "").trim();
        return lower.equals("广告") || lower.equals("推广") || lower.equals("赞助")
                || lower.equals("广告内容") || lower.equals("广告推广")
                || lower.equals("advertisement") || lower.equals("sponsored")
                || lower.startsWith("广告·") || lower.startsWith("广告|")
                || lower.startsWith("sponsored·");
    }

    private static boolean supportsDismiss(AccessibilityNodeInfo node) {
        return (node.getActions() & AccessibilityNodeInfo.ACTION_DISMISS) != 0;
    }

    private static boolean safeBounds(Rect bounds, Rect screen) {
        if (bounds.width() <= 0 || bounds.height() <= 0) return false;
        if (!Rect.intersects(bounds, screen)) return false;
        long area = (long) bounds.width() * bounds.height();
        long screenArea = (long) screen.width() * screen.height();
        if (screenArea <= 0 || area * 2L >= screenArea) return false;
        return bounds.width() <= screen.width() * 0.72f && bounds.height() <= screen.height() * 0.28f;
    }

    private static boolean likelySkipPosition(Rect bounds, Rect screen) {
        float cx = bounds.exactCenterX();
        float cy = bounds.exactCenterY();
        return cy <= screen.top + screen.height() * 0.58f
                && (cx >= screen.left + screen.width() * 0.52f || bounds.width() <= screen.width() * 0.24f);
    }

    private static boolean likelyClosePosition(Rect bounds, Rect screen) {
        float cx = bounds.exactCenterX();
        float cy = bounds.exactCenterY();
        boolean edge = cx <= screen.left + screen.width() * 0.34f
                || cx >= screen.left + screen.width() * 0.66f;
        return edge && cy <= screen.top + screen.height() * 0.72f;
    }

    private static boolean isEmptyVisualClose(
            AccessibilityNodeInfo node,
            Rect bounds,
            Rect screen,
            boolean adContext
    ) {
        if (!adContext || !node.isClickable()) return false;
        if (!string(node.getText()).isEmpty() || !string(node.getContentDescription()).isEmpty()) return false;
        String name = string(node.getClassName());
        if (!name.endsWith("ImageView") && !name.endsWith("ImageButton") && !name.endsWith("View")) return false;
        if (bounds.width() > screen.width() * 0.14f || bounds.height() > screen.height() * 0.10f) return false;
        return likelyClosePosition(bounds, screen);
    }

    private static boolean explicitSkip(String value) {
        String lower = value.toLowerCase(Locale.ROOT).replace(" ", "");
        return lower.contains("跳过广告") || lower.contains("跳過廣告")
                || lower.equals("skipad") || lower.equals("skipads") || lower.equals("skipadvertisement");
    }

    private static boolean genericSkip(String value) {
        String lower = AdCloseText.normalize(value).toLowerCase(Locale.ROOT).replace(" ", "");
        return lower.equals("跳过") || lower.equals("跳過") || lower.equals("skip")
                || lower.startsWith("跳过") || lower.startsWith("跳過") || lower.startsWith("skip");
    }

    private static boolean idSkip(String value) {
        String lower = value.toLowerCase(Locale.ROOT);
        return lower.contains("skip") || lower.contains("count_down") || lower.contains("countdown");
    }

    private static boolean explicitClose(String value) {
        String lower = value.toLowerCase(Locale.ROOT).replace(" ", "");
        return lower.contains("关闭广告") || lower.contains("關閉廣告") || lower.contains("关闭推广")
                || lower.equals("closead") || lower.equals("dismissad");
    }

    private static boolean genericClose(String value) {
        String lower = value.toLowerCase(Locale.ROOT).replace(" ", "");
        return lower.equals("关闭") || lower.equals("關閉") || lower.equals("close")
                || lower.equals("dismiss") || lower.equals("x") || lower.equals("×")
                || lower.equals("✕") || lower.equals("╳");
    }

    private static boolean idClose(String value) {
        String lower = value.toLowerCase(Locale.ROOT);
        if (!(lower.contains("close") || lower.contains("dismiss"))) return false;
        return lower.contains("ad") || lower.contains("splash") || lower.contains("promo")
                || lower.contains("ksad") || lower.contains("gdt") || lower.contains("pangle")
                || lower.contains("tt_");
    }

    private static boolean unsafeFlow(String value) {
        return value.contains("权限") || value.contains("授权") || value.contains("支付")
                || value.contains("付款") || value.contains("安全警告") || value.contains("风险提示")
                || value.contains("路线") || value.contains("导航") || value.contains("隐私政策")
                || value.contains("用户协议") || value.contains("permission") || value.contains("payment");
    }

    private static Rect bounds(AccessibilityNodeInfo node) {
        Rect rect = new Rect();
        node.getBoundsInScreen(rect);
        return rect;
    }

    private static String shortId(String value) {
        int slash = value.lastIndexOf('/');
        return slash >= 0 && slash + 1 < value.length() ? value.substring(slash + 1) : value;
    }

    private static String string(CharSequence value) {
        return value == null ? "" : value.toString().trim();
    }

    private static final class Candidate {
        final AccessibilityNodeInfo node;
        final Rect bounds;
        final int score;
        final boolean skip;
        final boolean dismiss;

        Candidate(AccessibilityNodeInfo node, Rect bounds, int score, boolean skip, boolean dismiss) {
            this.node = node;
            this.bounds = new Rect(bounds);
            this.score = score;
            this.skip = skip;
            this.dismiss = dismiss;
        }
    }
}
