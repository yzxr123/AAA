package org.adguardian.app.log;

import android.content.Context;
import android.os.SystemClock;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class UserEventLog {
    private static final String FILE_NAME = "qunideguanggao-events.log";
    private static final long MAX_BYTES = 96L * 1024L;
    private static final int MAX_READ_BYTES = 48 * 1024;
    private static final long DUPLICATE_WINDOW_MS = 5_000L;
    private static final Object LOCK = new Object();
    private static final SimpleDateFormat CLOCK = new SimpleDateFormat("HH:mm:ss", Locale.CHINA);
    private static String lastMessage = "";
    private static long lastMessageUptime;

    private UserEventLog() {
    }

    public static void record(Context context, String message) {
        write(context, message);
    }

    public static void warning(Context context, String message) {
        write(context, message);
    }

    public static void error(Context context, String message) {
        write(context, message);
    }

    public static String read(Context context) {
        synchronized (LOCK) {
            File file = file(context);
            if (!file.isFile() || file.length() == 0L) {
                return "暂无拦截记录";
            }
            try (FileInputStream input = new FileInputStream(file);
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                int count;
                while ((count = input.read(buffer)) != -1) {
                    output.write(buffer, 0, count);
                    if (output.size() > MAX_READ_BYTES) {
                        byte[] all = output.toByteArray();
                        output.reset();
                        output.write(all, all.length - MAX_READ_BYTES, MAX_READ_BYTES);
                    }
                }
                return output.toString(StandardCharsets.UTF_8.name());
            } catch (Exception ignored) {
                return "暂时无法读取拦截记录";
            }
        }
    }

    public static void clear(Context context) {
        synchronized (LOCK) {
            File file = file(context);
            if (file.exists()) {
                file.delete();
            }
            lastMessage="";lastMessageUptime=0;
        }
    }

    private static void write(Context context, String message) {
        if (context == null) {
            return;
        }
        String clean = clean(message);
        if (clean.isEmpty()) {
            return;
        }
        synchronized (LOCK) {
            long now = SystemClock.uptimeMillis();
            if (clean.equals(lastMessage) && now - lastMessageUptime < DUPLICATE_WINDOW_MS) {
                return;
            }
            lastMessage = clean;
            lastMessageUptime = now;
            File file = file(context);
            try {
                if (file.length() >= MAX_BYTES) {
                    new FileOutputStream(file, false).close();
                }
                String line = CLOCK.format(new Date()) + "  " + clean + "\n";
                try (FileOutputStream output = new FileOutputStream(file, true)) {
                    output.write(line.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) {
            }
        }
    }

    private static File file(Context context) {
        return new File(context.getFilesDir(), FILE_NAME);
    }

    private static String clean(String value) {
        if (value == null) {
            return "";
        }
        String clean = value.replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() <= 120 ? clean : clean.substring(0, 120);
    }
}
