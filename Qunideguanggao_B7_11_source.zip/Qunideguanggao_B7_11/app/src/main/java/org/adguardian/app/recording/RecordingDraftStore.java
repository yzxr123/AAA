package org.adguardian.app.recording;

import android.content.Context;
import android.util.AtomicFile;
import java.io.*;
import java.util.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;

/** Read-modify-write is serialized across instances. A failed verification cannot erase the captured lesson. */
public final class RecordingDraftStore {
    private static final int MAGIC=0x41524431, MAX_RECORDS=64, MAX_BYTES=1048576;
    private static final Object LOCK=new Object();
    private final AtomicFile file;
    public RecordingDraftStore(Context context) {
        file=new AtomicFile(new File(context.getFilesDir(),"ad-recording-drafts.bin"));
    }
    public List<RecordingDraft> all() throws IOException {synchronized(LOCK){return read();}}
    public void put(RecordingDraft draft) throws IOException {
        validate(draft);
        synchronized(LOCK) {
            ArrayList<RecordingDraft> next=new ArrayList<>(read());
            next.removeIf(item->item.key.equals(draft.key));
            if(next.size()>=MAX_RECORDS)throw new IOException("recording archive is full");
            next.add(draft);write(next);
        }
    }
    public void remove(String key)throws IOException {
        synchronized(LOCK){ArrayList<RecordingDraft> next=new ArrayList<>(read());next.removeIf(item->item.key.equals(key));write(next);}
    }
    public void clear()throws IOException {synchronized(LOCK){write(List.of());}}
    private List<RecordingDraft> read() throws IOException {
        if(!file.getBaseFile().exists() && !new File(file.getBaseFile()+".bak").exists())return List.of();
        try(DataInputStream in=new DataInputStream(file.openRead())) {
            if(file.getBaseFile().length()>MAX_BYTES || in.readInt()!=MAGIC)throw new IOException("invalid recording archive");
            int count=in.readInt();if(count<0||count>MAX_RECORDS)throw new IOException("recording count");
            ArrayList<RecordingDraft> records=new ArrayList<>();Set<String> keys=new HashSet<>();
            for(int i=0;i<count;i++) {
                String key=field(in),pkg=field(in),name=field(in);long version=in.readLong();int type=in.readInt();
                boolean single=in.readBoolean();int confirmed=in.readInt(),state=in.readInt();long updated=in.readLong();
                int size=in.readInt();if(size<1||size>FlowJournal.MAX_STEPS||type<0||type>=AdType.values().length)throw new IOException("invalid recording");
                ArrayList<FlowStep> steps=new ArrayList<>();
                for(int j=0;j<size;j++) {
                    FlowGuard guard=new FlowGuard(field(in),field(in),in.readFloat());
                    boolean back=in.readBoolean();long wait=in.readLong();
                    NodeTarget target=back?null:new NodeTarget(field(in),field(in),field(in),in.readFloat(),in.readFloat(),in.readFloat(),in.readFloat());
                    steps.add(new FlowStep(guard,target,back,wait));
                }
                RecordingDraft value=new RecordingDraft(key,pkg,name,version,AdType.values()[type],single,steps,confirmed,state,updated);
                validate(value);if(!keys.add(key))throw new IOException("duplicate recording");records.add(value);
            }
            if(in.read()!=-1)throw new IOException("trailing recording data");
            return Collections.unmodifiableList(records);
        }catch(RuntimeException invalid){throw new IOException("recording archive unreadable",invalid);}
    }
    private void write(List<RecordingDraft> values)throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
        out.writeInt(MAGIC);out.writeInt(values.size());
        for(RecordingDraft d:values) {
            validate(d);out.writeUTF(d.key);out.writeUTF(d.packageName);out.writeUTF(d.appName);out.writeLong(d.version);
            out.writeInt(d.type.ordinal());out.writeBoolean(d.single);out.writeInt(d.confirmed);out.writeInt(d.state);out.writeLong(d.updatedAt);out.writeInt(d.steps.size());
            for(FlowStep s:d.steps) {
                out.writeUTF(s.guard.activity);out.writeUTF(s.guard.signature);out.writeFloat(s.guard.aspect);
                out.writeBoolean(s.back);out.writeLong(s.timeoutMs);
                if(!s.back){NodeTarget t=s.target;out.writeUTF(t.id);out.writeUTF(t.name);out.writeUTF(t.label);out.writeFloat(t.x);out.writeFloat(t.y);out.writeFloat(t.width);out.writeFloat(t.height);}
            }
        }
        out.flush();if(bytes.size()>MAX_BYTES)throw new IOException("recording archive too large");
        byte[] expected=bytes.toByteArray();FileOutputStream stream=file.startWrite();
        try {
            stream.write(expected);stream.getFD().sync();file.finishWrite(stream);
            // AtomicFile.finishWrite returns void. Never announce persistence without checking actual bytes.
            try(InputStream verify=file.openRead()) {
                int position=0;byte[] buffer=new byte[4096];int size;
                while((size=verify.read(buffer))!=-1) {
                    if(position+size>expected.length)throw new IOException("recording readback length");
                    for(int i=0;i<size;i++)if(buffer[i]!=expected[position+i])throw new IOException("recording readback mismatch");
                    position+=size;
                }
                if(position!=expected.length)throw new IOException("recording readback truncated");
            }
        }catch(IOException|RuntimeException error){file.failWrite(stream);throw new IOException("recording write failed",error);}
    }
    private static String field(DataInputStream in)throws IOException{String value=in.readUTF();if(value.length()>512)throw new IOException("recording field too long");return value;}
    private static void validate(RecordingDraft d)throws IOException {
        if(d==null||d.type==null||d.version<0||d.updatedAt<0||d.confirmed<0||d.confirmed>d.steps.size()
                ||d.state<0||d.state>2||d.steps.isEmpty()||d.steps.size()>FlowJournal.MAX_STEPS||(d.single&&d.steps.size()!=1))throw new IOException("invalid recording metadata");
        for(String value:new String[]{d.key,d.packageName,d.appName})if(value==null||value.isEmpty()||value.length()>512)throw new IOException("invalid recording field");
        for(FlowStep s:d.steps) {
            if(s==null||!s.valid())throw new IOException("invalid recording step");
            if(!s.back){
                for(String value:new String[]{s.target.id,s.target.name,s.target.label})if(value==null||value.length()>512)throw new IOException("invalid recording target");
                if(!s.target.label.isEmpty()&&!AdCloseText.isClose(s.target.label))throw new IOException("arbitrary recording text");
            }
        }
        if(d.steps.get(0).back)throw new IOException("first recorded step cannot be Back");
        if(d.state==RecordingDraft.ENABLED&&d.confirmed!=d.steps.size())throw new IOException("unverified recording marked enabled");
    }
}
