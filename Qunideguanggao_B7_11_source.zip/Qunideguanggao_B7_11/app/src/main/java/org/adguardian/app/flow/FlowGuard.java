package org.adguardian.app.flow;

import java.util.Objects;

/** A screen precondition. It contains structural metadata, never page text or screenshots. */
public final class FlowGuard {
    public final String activity, signature;
    private final String legacySignature;
    public final float aspect;
    public FlowGuard(String activity,String signature,float aspect) {
        this(activity,signature,aspect,"");
    }
    public FlowGuard(String activity,String signature,float aspect,String legacySignature) {
        this.activity=activity;this.signature=signature;this.aspect=aspect;this.legacySignature=legacySignature;
    }
    public boolean valid() {
        return activity!=null && !activity.isEmpty() && activity.length()<=512
                && signature!=null && signature.matches("f[12]:[0-9a-f]{64}")
                && Float.isFinite(aspect) && aspect>.15f && aspect<6f;
    }
    public boolean matches(FlowGuard other) {
        return other!=null && valid() && other.valid() && sameActivity(other)
                && (signature.equals(other.signature) || signature.equals(other.legacySignature) || legacySignature.equals(other.signature)) && Math.abs(aspect-other.aspect)<.025f;
    }
    private boolean sameActivity(FlowGuard other) {
        if(activity.equals(other.activity))return true;
        // A structurally equal captured window can survive a missing Activity event, never two differing known Activities.
        return signature.startsWith("f2:") && other.signature.startsWith("f2:")
                && (activity.startsWith("@window:") || other.activity.startsWith("@window:"));
    }
    @Override public boolean equals(Object o) {return o instanceof FlowGuard g && matches(g);}
    @Override public int hashCode() {return 0;}
}
