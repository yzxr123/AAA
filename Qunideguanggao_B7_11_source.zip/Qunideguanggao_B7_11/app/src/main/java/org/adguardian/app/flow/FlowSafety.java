package org.adguardian.app.flow;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import org.adguardian.app.engine.*;

public final class FlowSafety {
    private FlowSafety() { }
    public static Rect bounds(AccessibilityNodeInfo node) {Rect b=new Rect();node.getBoundsInScreen(b);return b;}
    public static boolean safeTarget(NodeTarget target) {
        if(target==null)return false;
        if(target.isSafeLearningTarget())return true;
        // Explicit teaching of a small, unlabelled close container only. Its page must be guarded.
        if(!target.id.isEmpty() || !target.label.isEmpty())return false;
        NodeTarget surrogate=new NodeTarget("","android.view.View","",target.x,target.y,target.width,target.height);
        return surrogate.isSafeLearningTarget() && (target.name.equals("android.widget.LinearLayout")
                || target.name.equals("android.widget.RelativeLayout") || target.name.equals("android.widget.FrameLayout"));
    }
    public static boolean protectedLabel(CharSequence raw) {
        String s=NodeTarget.string(raw);
        return s.equals("确认支付") || s.equals("立即支付") || s.equals("支付密码") || s.equals("付款码")
                || s.equals("允许本次使用") || s.equals("授予权限") || s.equals("指纹支付")
                || s.equalsIgnoreCase("Confirm payment") || s.equalsIgnoreCase("Payment password");
    }
    public static boolean forbiddenScreen(AccessibilityNodeIndex index) {
        for(AccessibilityNodeInfo n:index.nodes())if(n.isVisibleToUser() &&
                (n.isPassword() || protectedLabel(n.getText()) || protectedLabel(n.getContentDescription())))return true;
        return false;
    }
    /** Only climb within the selected small close region. Never turn a leaf into a full-ad click. */
    public static AccessibilityNodeInfo clickTarget(AccessibilityNodeInfo leaf,AccessibilityNodeIndex index) {
        if(leaf==null || !leaf.isVisibleToUser() || !leaf.isEnabled())return null;
        NodeTarget selected=NodeTarget.captureSelected(leaf,index.rootBounds());
        if(!safeTarget(selected))return null;
        Rect original=FlowSafety.bounds(leaf),screen=index.rootBounds();
        AccessibilityNodeInfo n=leaf;
        for(int depth=0;depth<4 && n!=null;depth++) {
            Rect b=FlowSafety.bounds(n);
            if(n.isPassword() || n.isEditable() || !n.isVisibleToUser() || !n.isEnabled()
                    || b.width()>screen.width()*.55f || b.height()>screen.height()*.22f
                    || b.width()>Math.max(original.width()*3,screen.width()*.22f)
                    || b.height()>Math.max(original.height()*3,screen.height()*.12f))break;
            if(n.isClickable())return n;
            n=index.cachedParent(n);
        }
        // A coordinate gesture is allowed only at the freshly resolved small leaf, never a stored location.
        return leaf;
    }
}
