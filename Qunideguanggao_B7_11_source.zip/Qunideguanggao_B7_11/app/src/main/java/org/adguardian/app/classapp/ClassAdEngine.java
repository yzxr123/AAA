package org.adguardian.app.classapp;

import android.accessibilityservice.*;
import android.graphics.*;
import android.os.*;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;
import java.util.function.Supplier;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.FlowSafety;
import org.adguardian.app.runtime.ScanDiagnostics;
import org.adguardian.app.runtime.ScanDiagnostics.Reason;
import org.adguardian.app.settings.PreferenceStore;

/** Targeted UI adapter, not SDK hooking. No generic Back and no undocumented/fabricated resource IDs. */
public final class ClassAdEngine {
    private final AccessibilityService service;
    private final Handler worker;
    private final Supplier<String> foreground;
    private final Runnable scan;
    private final ActionVerifier verifier;
    private final ClassAdRules rules;
    private String scope="";
    private final org.adguardian.app.runtime.PackageVersionLookup versions=new org.adguardian.app.runtime.PackageVersionLookup();
    private long version=-1,entered,epoch,pausedUntil;
    private volatile long lastAction;
    private int actions;
    private boolean scoped;
    private volatile boolean pending;
    public ClassAdEngine(AccessibilityService s,Handler h,Supplier<String> foreground,Runnable scan,ActionVerifier verifier) {
        service=s;worker=new Handler(h.getLooper());this.foreground=foreground;this.scan=scan;this.verifier=verifier;rules=ClassAdRules.load(s);
    }
    public long lastAction(){return lastAction;}
    public boolean isPending(){return pending;}
    public long nextWakeUp(){long age=SystemClock.uptimeMillis()-entered;return !scoped || age>=60000 || actions>=8?-1:age<2000?380:age<8000?600:900;}
    public void cancelPending(){epoch++;pending=false;worker.removeCallbacksAndMessages(null);}
    public void onUserInteraction(){cancelPending();pausedUntil=SystemClock.uptimeMillis()+1200;}
    public void onPackageChanged(){cancelPending();versions.clear();scope="";scoped=false;pausedUntil=0;}
    public void close(){onPackageChanged();}
    private static void diagnostic(Reason reason,AccessibilityNodeIndex index,int targets){ScanDiagnostics.record(ScanDiagnostics.Area.CLASS,reason,index.cachedNodeCount(),targets);}
    public boolean handle(String pkg,String activity,AccessibilityNodeIndex index) {
        if(!ClassAdProfile.PACKAGE.equals(pkg) || !pkg.equals(foreground.get()) || !PreferenceStore.isMasterEnabled(service)
                || !PreferenceStore.isClassAdapterEnabled(service)){cancelPending();scoped=false;return false;}
        if(rules.rules.isEmpty()){diagnostic(Reason.RULES_UNAVAILABLE,index,0);scoped=false;return false;}
        version=versions.read(service,pkg);
        if(version!=ClassAdProfile.VERSION){diagnostic(version<0?Reason.VERSION_UNKNOWN:Reason.VERSION_OTHER,index,0);scoped=false;return false;}
        index.startQueryBudget(35L);
        try {
            ClassAdRules.Rule rule=rules.match(activity,index);
            if(rule==null){diagnostic(activity==null || activity.isEmpty()?Reason.ACTIVITY_UNKNOWN:Reason.NOT_AD_PAGE,index,0);cancelPending();scope="";scoped=false;return false;}
            boolean splash=rule.type==AdType.STARTUP;
            if(!PreferenceStore.isTypeEnabled(service,rule.type)){scoped=false;cancelPending();return false;}
            String nextScope=rule.key+"|"+index.root().getWindowId();
            if(!nextScope.equals(scope)){cancelPending();scope=nextScope;entered=SystemClock.uptimeMillis();actions=0;}
            scoped=true;
            if(pending || verifier.isPending()){diagnostic(Reason.WAITING,index,0);return true;}
            long now=SystemClock.uptimeMillis();if(now<pausedUntil || now-lastAction<180 || actions>=8)return false;
            if(FlowSafety.forbiddenScreen(index)){diagnostic(Reason.PROTECTED,index,0);return false;}
            AccessibilityNodeInfo leaf=ClassAdRules.visibleId(index,rule.targetId);
            if(leaf==null && rule.matchCloseText) {
                LinkedHashMap<AccessibilityNodeInfo,AccessibilityNodeInfo> candidates=new LinkedHashMap<>();
                for(AccessibilityNodeInfo n:index.nodes()) {
                    if(!n.isEnabled() || !n.isVisibleToUser() || n.isEditable() || n.isPassword())continue;
                    String text=NodeTarget.string(n.getText()),desc=NodeTarget.string(n.getContentDescription());
                    if(!AdCloseText.isClose(text) && !AdCloseText.isClose(desc))continue;
                    NodeTarget target=NodeTarget.captureSelected(n,index.rootBounds());
                    if(!FlowSafety.safeTarget(target))continue;
                    AccessibilityNodeInfo click=FlowSafety.clickTarget(n,index);
                    if(click!=null)candidates.putIfAbsent(click,n);
                }
                if(candidates.size()!=1 || index.isTraversalIncomplete()){diagnostic(index.isTraversalIncomplete()?(index.hasUnavailableChildren()?Reason.CHILD_UNAVAILABLE:Reason.TOO_MANY_NODES):candidates.isEmpty()?Reason.NO_CLOSE:Reason.AMBIGUOUS,index,candidates.size());return false;}
                leaf=candidates.values().iterator().next();
            }
            if(leaf==null){diagnostic(Reason.NO_CLOSE,index,0);return false;}
            AccessibilityNodeInfo click=FlowSafety.clickTarget(leaf,index);if(click==null)return false;
            NodeTarget descriptor=NodeTarget.captureSelected(leaf,index.rootBounds());
            String key="class:"+rule.key+":"+descriptor.id+":"+AdCloseText.normalize(descriptor.label)+":"+Math.round(descriptor.x*20)+":"+Math.round(descriptor.y*20);
            if(!verifier.allowed(pkg,key,index.root().getWindowId()))return false;
            ActionVerifier.Ticket ticket=verifier.capture(pkg,key,"click",leaf,index,null);if(ticket==null)return false;
            if(!pkg.equals(foreground.get()) || !PreferenceStore.isMasterEnabled(service)
                    || !PreferenceStore.isClassAdapterEnabled(service)
                    || !PreferenceStore.isTypeEnabled(service,splash?AdType.STARTUP:AdType.POPUP))return false;
            lastAction=now;
            boolean accepted=click.isClickable() && click.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            if(accepted){diagnostic(Reason.ACTION_REQUESTED,index,1);lastAction=now;actions++;verifier.accepted(ticket);return true;}
            Rect b=FlowSafety.bounds(click);Path path=new Path();path.moveTo(b.exactCenterX(),b.exactCenterY());
            long token=++epoch;pending=true;
            GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,45)).build();
            try {
                accepted=service.dispatchGesture(gesture,new AccessibilityService.GestureResultCallback(){
                    @Override public void onCompleted(GestureDescription g){if(token!=epoch)return;pending=false;if(pkg.equals(foreground.get()) && PreferenceStore.isMasterEnabled(service) && PreferenceStore.isClassAdapterEnabled(service) && PreferenceStore.isTypeEnabled(service,splash?AdType.STARTUP:AdType.POPUP)){verifier.accepted(ticket);scan.run();}}
                    @Override public void onCancelled(GestureDescription g){if(token!=epoch)return;pending=false;verifier.rejected(ticket);scan.run();}
                },worker);
            }catch(RuntimeException error){accepted=false;}
            if(!accepted){pending=false;verifier.rejected(ticket);return false;}
            diagnostic(Reason.ACTION_REQUESTED,index,1);lastAction=now;actions++;
            worker.postDelayed(()->{if(token==epoch && pending){pending=false;epoch++;verifier.rejected(ticket);scan.run();}},1500);
            return true;
        }catch(AccessibilityNodeIndex.QueryLimit unavailable){diagnostic(Reason.BUDGET,index,0);return false;}
        catch(RuntimeException unavailable){diagnostic(Reason.UNAVAILABLE,index,0);return false;}
        finally{index.clearQueryBudget();}
    }
}
