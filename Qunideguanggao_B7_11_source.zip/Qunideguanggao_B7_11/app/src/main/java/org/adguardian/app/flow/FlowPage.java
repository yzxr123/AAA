package org.adguardian.app.flow;

import android.graphics.Rect;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.runtime.ScanDiagnostics;
import org.adguardian.app.runtime.ScanDiagnostics.Reason;

/** Frozen pre-action view metadata. No Android nodes or arbitrary labels survive capture. */
public final class FlowPage {
    public final String pkg;
    public final long version, capturedAt;
    public final FlowGuard guard;
    public final boolean knownClassAd;
    public final Rect bounds;
    public final List<NodeTarget> targets;
    public final int nodeCount,windowId;
    private String layoutIdentity="";
    private boolean certifiedClassHome;
    public boolean isCertifiedClassHome(){return certifiedClassHome;}
    private int displayRotation=-1;
    public int displayRotation(){return displayRotation;}
    private final List<NodeTarget[]> aliases;
    private final List<NodeTarget> visibleTargets;
    private FlowPage(String pkg,long version,FlowGuard guard,Rect bounds,List<NodeTarget> targets,List<NodeTarget> visibleTargets,boolean knownClassAd,int nodeCount,int windowId,List<NodeTarget[]> aliases) {
        this.pkg=pkg;this.version=version;this.nodeCount=nodeCount;this.windowId=windowId;this.aliases=Collections.unmodifiableList(new ArrayList<>(aliases));this.guard=guard;this.knownClassAd=knownClassAd;this.bounds=new Rect(bounds);
        this.targets=Collections.unmodifiableList(new ArrayList<>(targets));
        this.visibleTargets=Collections.unmodifiableList(new ArrayList<>(visibleTargets));capturedAt=SystemClock.uptimeMillis();
    }
    public static FlowPage capture(String pkg,String activity,long version,AccessibilityNodeIndex index,int rotation) {
        FlowPage result=capture(pkg,activity,version,index);
        if(result!=null)result.displayRotation=rotation;
        return result;
    }
    public static FlowPage capture(String pkg,String activity,long version,AccessibilityNodeIndex index) {
        try {return captureChecked(pkg,activity,version,index);}
        catch(AccessibilityNodeIndex.QueryLimit exhausted){reject(Reason.BUDGET,index.cachedNodeCount());throw exhausted;}
        catch(RuntimeException unavailable){reject(Reason.UNAVAILABLE,index.cachedNodeCount());throw unavailable;}
    }
    private static FlowPage reject(Reason reason,int count) {
        ScanDiagnostics.record(ScanDiagnostics.Area.PAGE,reason,count,0);return null;
    }
    private static FlowPage captureChecked(String pkg,String activity,long version,AccessibilityNodeIndex index) {
        if(pkg==null || pkg.isEmpty())return reject(Reason.SCOPE_MISMATCH,0);
        boolean unknownActivity=activity==null || activity.isEmpty();
        if(version<0)return reject(Reason.VERSION_UNKNOWN,0);
        if(!pkg.equals(NodeTarget.string(index.root().getPackageName())))return reject(Reason.SCOPE_MISMATCH,0);
        Rect screen=index.rootBounds();if(screen.width()<=0 || screen.height()<=0)return reject(Reason.SIZE_UNKNOWN,0);
        StringBuilder topology=new StringBuilder("flow-page-v1\n");
        boolean classPopupBody=false,classPopupClose=false;
        Set<String> resourceIds=new HashSet<>();
        Map<AccessibilityNodeInfo,NodeTarget> regions=new LinkedHashMap<>();
        Map<AccessibilityNodeInfo,List<NodeTarget>> regionMembers=new LinkedHashMap<>();
        java.util.SortedSet<String> anchors=new java.util.TreeSet<>();
        anchors.add("root|"+NodeTarget.string(index.root().getClassName()));
        ArrayList<NodeTarget> controls=new ArrayList<>(),present=new ArrayList<>();int count=0,ids=0;
        for(AccessibilityNodeInfo n:index.nodes(1024)) {
            if(++count>1024)return reject(Reason.TOO_MANY_NODES,count);
            if(!n.isVisibleToUser())continue;
            if(n.isPassword() || FlowSafety.protectedLabel(n.getText()) || FlowSafety.protectedLabel(n.getContentDescription()))return reject(Reason.PROTECTED,count);
            String id=NodeTarget.string(n.getViewIdResourceName()),name=NodeTarget.string(n.getClassName());
            if(!id.isEmpty()){ids++;resourceIds.add(id);anchors.add("id|"+name+"|"+id);}
            if(id.equals("cn.luyiyuntech.stt:id/fhad_rl_content"))classPopupBody=true;
            if(id.equals("cn.luyiyuntech.stt:id/fhad_iv_delete"))classPopupClose=true;
            Rect b=FlowSafety.bounds(n);
            topology.append(index.cachedDepth(n)).append('|').append(index.cachedIndex(n)).append('|')
                    .append(name).append('|').append(id).append('|').append(n.isClickable()).append('|')
                    .append(n.isScrollable()).append('|').append(n.isEditable()).append('|')
                    .append(Math.round((b.exactCenterX()-screen.left)*16/screen.width())).append(',')
                    .append(Math.round((b.exactCenterY()-screen.top)*16/screen.height())).append(',')
                    .append(Math.round(b.width()*16f/screen.width())).append(',')
                    .append(Math.round(b.height()*16f/screen.height())).append('\n');
            NodeTarget target=NodeTarget.captureSelected(n,screen);
            if(FlowSafety.safeTarget(target)){
                present.add(target.forLearning());
                if(AdCloseText.isClose(target.label) || target.id.isEmpty()) {
                    StringBuilder lineage=new StringBuilder();AccessibilityNodeInfo parent=n;
                    for(int d=0;parent!=null && d<4;d++,parent=index.cachedParent(parent))
                        lineage.append(NodeTarget.string(parent.getClassName())).append('>');
                    anchors.add("control|"+lineage+"|"+target.id+"|"+target.forLearning().label+"|"
                            +Math.round(target.x*12)+","+Math.round(target.y*12)+","+Math.round(target.width*12)+","+Math.round(target.height*12));
                }
                if(n.isEnabled()) {
                    AccessibilityNodeInfo region=FlowSafety.clickTarget(n,index);
                    if(region==null)region=n;
                    NodeTarget item=target.forLearning(),old=regions.get(region);
                    regionMembers.computeIfAbsent(region,k->new ArrayList<>()).add(item);
                    if(old==null || (!old.label.isEmpty()==!item.label.isEmpty()
                            ? (old.id.isEmpty()&&!item.id.isEmpty()) || (old.id.isEmpty()==item.id.isEmpty() && item.width*item.height<old.width*old.height)
                            : old.label.isEmpty()&&!item.label.isEmpty()))regions.put(region,item);
                }
            }
        }
        if(index.isTraversalIncomplete())return reject(index.hasUnavailableChildren()?Reason.CHILD_UNAVAILABLE:Reason.TOO_MANY_NODES,count);
        ArrayList<NodeTarget[]> aliases=new ArrayList<>();
        for(Map.Entry<AccessibilityNodeInfo,NodeTarget> entry:regions.entrySet()) {
            NodeTarget canonical=entry.getValue();controls.add(canonical);
            for(NodeTarget member:regionMembers.get(entry.getKey()))aliases.add(new NodeTarget[]{member,canonical});
        }
        boolean classPackage=pkg.equals(org.adguardian.app.classapp.ClassAdProfile.PACKAGE) && version==org.adguardian.app.classapp.ClassAdProfile.VERSION;
        boolean promotion=resourceIds.contains(pkg+":id/close")&&resourceIds.contains(pkg+":id/tv_confirm")&&resourceIds.contains(pkg+":id/btn_pay_now");
        boolean splashLayout=classPackage&&resourceIds.contains(pkg+":id/fl_ad_container")&&resourceIds.contains(pkg+":id/fl_place_holder_container");
        if(unknownActivity && splashLayout){activity=org.adguardian.app.classapp.ClassAdProfile.SPLASH;unknownActivity=false;}
        boolean homeLayout=classPackage && org.adguardian.app.classapp.ClassAdProfile.hasHomeLayout(resourceIds);
        boolean visibleNativeAd=splashLayout || promotion || (classPopupBody&&classPopupClose);
        // A queued Splash Activity name must not overrule a fresh, complete home layout.
        // A known video Activity or an ad overlay on home still wins over background home IDs.
        if(homeLayout && !visibleNativeAd && (unknownActivity
                || activity.equals(org.adguardian.app.classapp.ClassAdProfile.SPLASH)
                || activity.equals(org.adguardian.app.classapp.ClassAdProfile.MAIN))) {
            activity=org.adguardian.app.classapp.ClassAdProfile.MAIN;unknownActivity=false;
        }
        boolean classAd=classPackage&&(org.adguardian.app.classapp.ClassAdProfile.isAdActivity(activity) || splashLayout || promotion || (classPopupBody&&classPopupClose));
        boolean namedClose=!unknownActivity && controls.stream().anyMatch(t->!t.id.isEmpty() && AdCloseText.isClose(t.label));
        if(count<2 || (ids<2 && count<4 && !namedClose && !(classAd&&count>=3&&!controls.isEmpty())))return reject(Reason.INSUFFICIENT,count);
        if(unknownActivity) {
            // Missing Activity metadata is not missing nodes. Only retain a strong, exact window guard.
            if(resourceIds.size()<2 || NodeTarget.string(index.root().getClassName()).isEmpty())return reject(Reason.ACTIVITY_UNKNOWN,count);
            activity="@window:"+NodeTarget.string(index.root().getClassName());
        }
        String legacy=count<=256?digest("f1:",topology.toString()):"";
        String fingerprint=digest("f2:",String.join("\n",anchors));
        ScanDiagnostics.record(ScanDiagnostics.Area.PAGE,Reason.READY,count,controls.size());
        FlowPage captured=new FlowPage(pkg,version,new FlowGuard(activity,fingerprint,(float)screen.width()/screen.height(),legacy),screen,controls,present,classAd,count,index.root().getWindowId(),aliases);
        captured.certifiedClassHome=homeLayout&&!classAd&&activity.equals(org.adguardian.app.classapp.ClassAdProfile.MAIN);
        SortedSet<String> layout=new TreeSet<>();
        for(String anchor:anchors)layout.add(anchor.startsWith("control|")?anchor.substring(0,anchor.lastIndexOf('|')):anchor);
        captured.layoutIdentity=digest("layout:",String.join("\n",layout));
        return captured;
    }
    private static String digest(String prefix,String value) {
        try {
            byte[] bytes=MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex=new StringBuilder(prefix);for(byte b:bytes)hex.append(String.format(Locale.ROOT,"%02x",b & 255));return hex.toString();
        }catch(java.security.NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}
    }
    boolean sameRecordingPage(FlowPage other) {
        if(other==null || !pkg.equals(other.pkg) || version!=other.version || windowId!=other.windowId
                || !guard.activity.equals(other.guard.activity) || !guard.signature.equals(other.guard.signature)
                || bounds.left!=other.bounds.left || bounds.top!=other.bounds.top || bounds.right!=other.bounds.right || bounds.bottom!=other.bounds.bottom
                || aliases.size()!=other.aliases.size())return false;
        for(int i=0;i<aliases.size();i++)for(int k=0;k<2;k++)if(!exactTarget(aliases.get(i)[k],other.aliases.get(i)[k]))return false;
        return true;
    }
    private static boolean exactTarget(NodeTarget a,NodeTarget b) {
        return a.id.equals(b.id)&&a.name.equals(b.name)&&a.label.equals(b.label)
                && Float.compare(a.x,b.x)==0&&Float.compare(a.y,b.y)==0
                && Float.compare(a.width,b.width)==0&&Float.compare(a.height,b.height)==0;
    }
    public boolean sameScope(FlowPage other) {
        return other!=null && pkg.equals(other.pkg) && version==other.version
                && org.adguardian.app.runtime.DisplayRotation.compatible(displayRotation,other.displayRotation,guard.aspect,other.guard.aspect);
    }
    public NodeTarget find(NodeTarget wanted) {
        if(wanted==null)return null;NodeTarget match=null;
        for(NodeTarget[] pair:aliases)if(sameTarget(wanted,pair[0])) {
            if(match!=null && !sameTarget(match,pair[1]))return null;match=pair[1];
        }
        return match;
    }
    public NodeTarget findCloseText(Iterable<CharSequence> texts) {
        if(texts==null)return null;NodeTarget result=null;
        for(CharSequence text:texts) {
            String raw=NodeTarget.string(text);if(!AdCloseText.isClose(raw))continue;
            for(NodeTarget t:targets)if(!t.label.isEmpty()&&AdCloseText.normalize(raw).equals(t.label)) {
                if(result!=null&&!sameTarget(result,t))return null;result=t;
            }
        }
        return result;
    }
    boolean sameLayoutAfterResize(FlowPage before,NodeTarget wanted) {
        if(before==null || wanted==null || !sameScope(before) || !guard.activity.equals(before.guard.activity)
                || !layoutIdentity.equals(before.layoutIdentity) || (bounds.left==before.bounds.left && bounds.top==before.bounds.top && bounds.right==before.bounds.right && bounds.bottom==before.bounds.bottom))return false;
        // Inset/fullscreen changes move relative coordinates. They are not evidence of dismissal.
        for(NodeTarget t:visibleTargets)if(t.id.equals(wanted.id)&&t.name.equals(wanted.name)&&t.label.equals(wanted.label))return true;
        return false;
    }
    public boolean has(NodeTarget wanted) {
        if(wanted==null)return false;
        for(NodeTarget t:visibleTargets)if(sameTarget(wanted,t))return true;
        return false;
    }
    private static boolean sameTarget(NodeTarget a,NodeTarget b) {
        return a.id.equals(b.id) && a.name.equals(b.name) && a.label.equals(b.label)
                && Math.abs(a.x-b.x)<.04f && Math.abs(a.y-b.y)<.04f
                && Math.abs(a.width-b.width)<.04f && Math.abs(a.height-b.height)<.04f;
    }
    public NodeTarget pick(float x,float y) {
        float nx=(x-bounds.left)/bounds.width(),ny=(y-bounds.top)/bounds.height();NodeTarget best=null;float area=2;
        boolean ambiguous=false;
        for(NodeTarget t:targets) {
            if(Math.abs(t.x-nx)>t.width/2 || Math.abs(t.y-ny)>t.height/2)continue;
            float a=t.width*t.height;
            if(a<area-.00001f){best=t;area=a;ambiguous=false;}
            else if(Math.abs(a-area)<.00001f) {
                boolean better=best!=null && best.label.isEmpty() && !t.label.isEmpty();
                if(better){best=t;ambiguous=false;}else if(best!=null && !sameTarget(best,t) && best.label.isEmpty()==t.label.isEmpty())ambiguous=true;
            }
        }
        return ambiguous?null:best;
    }
    public static AccessibilityNodeInfo resolve(NodeTarget target,AccessibilityNodeIndex index) {
        if(!FlowSafety.safeTarget(target))return null;AccessibilityNodeInfo result=null;
        for(AccessibilityNodeInfo n:target.candidates(index))if(n.isEnabled() && target.matches(n,index.rootBounds(),true)) {
            if(result!=null)return null;result=n;
        }
        if(index.isTraversalIncomplete())return null;
        return result;
    }
}
