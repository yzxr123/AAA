package org.adguardian.app.learning;

import android.graphics.Rect;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.adguardian.app.engine.AccessibilityNodeIndex;
import org.adguardian.app.engine.NodeTarget;

/** Immutable pre-click metadata. Never retains AccessibilityNodeInfo or user text. */
final class LearningPage {
    final String pkg,activity,guard;
    final Rect bounds;
    final long capturedAt;
    final boolean adContext;
    final List<NodeTarget> targets;

    final org.adguardian.app.flow.FlowPage snapshot;
    private LearningPage(org.adguardian.app.flow.FlowPage snapshot) {
        this.snapshot=snapshot;pkg=snapshot.pkg;activity=snapshot.guard.activity;guard=snapshot.guard.signature;
        bounds=new Rect(snapshot.bounds);adContext=snapshot.knownClassAd;targets=snapshot.targets;capturedAt=snapshot.capturedAt;
    }
    static LearningPage from(org.adguardian.app.flow.FlowPage page) {return page==null?null:new LearningPage(page);}
    static LearningPage capture(String pkg,String activity,long version,AccessibilityNodeIndex index) {
        return from(org.adguardian.app.flow.FlowPage.capture(pkg,activity,version,index));
    }
    static String signature(AccessibilityNodeIndex index) {
        return index.memoizedFingerprint("learned-page-v1",()->computeSignature(index));
    }
    private static String computeSignature(AccessibilityNodeIndex index) {
        // Fingerprint stable structural identifiers, never advertisement copy, countdowns or input values.
        java.util.SortedSet<String> anchors=new java.util.TreeSet<>();int count=0;
        for(AccessibilityNodeInfo n:index.nodes()) {
            if(++count>128)return "";
            if(!n.isVisibleToUser())continue;
            String id=NodeTarget.string(n.getViewIdResourceName());
            if(!id.isEmpty())anchors.add(id+"|"+NodeTarget.string(n.getClassName()));
        }
        if(anchors.size()<2 || index.isTraversalIncomplete())return "";
        StringBuilder data=new StringBuilder("page-v1\n").append(NodeTarget.string(index.root().getClassName())).append('\n');
        for(String anchor:anchors)data.append(anchor).append('\n');
        try {
            byte[] bytes=MessageDigest.getInstance("SHA-256").digest(data.toString().getBytes(StandardCharsets.UTF_8));
            StringBuilder hex=new StringBuilder("p1:");
            for(byte b:bytes)hex.append(String.format(java.util.Locale.ROOT,"%02x",b & 255));
            return hex.toString();
        } catch(NoSuchAlgorithmException impossible) {throw new IllegalStateException(impossible);}
    }
    NodeTarget find(NodeTarget source) {return source==null?null:snapshot.find(source.forLearning());}
    NodeTarget pick(float screenX,float screenY) {return snapshot.pick(screenX,screenY);}
}
