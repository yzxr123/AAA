# Third-party source inventory

## LiTiaotiao rule repository
User input LiTiaotiao-main.zip
Raw AllRules BasicRules ExtendedRules remain byte-identical in app/src/main/assets/ltt
Original repository license is retained in third_party/litiaotiao/LICENSE
No protected APK payload is embedded or loaded

## GKD selector and reference implementation
User input gkd-main.zip
Original selector sources and license remain in third_party/gkd-selector
Syntax-adapted JVM sources are generated in gkd-core
Original-to-generated SHA256 mapping is in gkd-core/source-manifest.json
Selected runtime files retained as reference in third_party/gkd-runtime-reference
RuleSession and Android lifecycle/action bridge are project-specific implementations

## GKD subscription
User input GKD_subscription-main.zip
Original JSON5 and upstream README retained in third_party/gkd_subscription
Frozen normalized JSON has verified semantic equivalence with original JSON5
Only four advertisement category groups are included in APK assets

## Tesseract
Tesseract4Android 4.9.0 remains a build dependency
chi_sim tessdata_fast is fetched at build time and checked against its frozen SHA256
No OCR telemetry or runtime download is enabled


## B7.11 inspected upstream implementation references

GKD GkdTileService.kt: fixA11yService and guarded remove/wait/add/recheck
GKD StatusService.kt and KeepAliveOverlayCoordinator.kt: independent foreground/overlay ownership and handoff
https://github.com/gkd-kit/gkd/blob/main/gkd-app/src/main/kotlin/li/gkd/app/service/GkdTileService.kt
https://github.com/gkd-kit/gkd/blob/main/gkd-app/src/main/kotlin/li/gkd/app/service/StatusService.kt
https://github.com/gkd-kit/gkd/blob/main/gkd-app/src/main/kotlin/li/gkd/app/platform/overlay/KeepAliveOverlayCoordinator.kt
Existing GKD original source and license are retained. The Java adapters are project-specific ports of the reviewed control flow, not the full upstream application.

SoloPi by Ant Financial Services Group, Apache-2.0 source headers
CaseRecordManager.java: select an actual node before doAndRecordAction
OperationStepExporter.java: operation index, resource id, class, package, bounds and contextual selectors
OperationStepService.java: recorded step delivery to persistent processing
https://github.com/alipay/SoloPi/blob/master/solopi-app/app/src/main/java/com/alipay/hulu/service/CaseRecordManager.java
https://github.com/alipay/SoloPi/blob/master/solopi-app/shared/src/main/java/com/alipay/hulu/shared/node/tree/export/OperationStepExporter.java
https://github.com/alipay/SoloPi/blob/master/solopi-app/shared/src/main/java/com/alipay/hulu/shared/io/OperationStepService.java
Used as implementation-pattern references; no SoloPi APK, ADB/shell recorder, screenshot pipeline, or proprietary payload is bundled.
Inspected 2026-09-22; upstream main/master references are moving branches, not binary-version identifiers.
