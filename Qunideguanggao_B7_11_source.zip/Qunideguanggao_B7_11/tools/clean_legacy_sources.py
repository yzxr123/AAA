#!/usr/bin/env python3
from pathlib import Path
import argparse

ROOT = Path(__file__).resolve().parents[1]
LEGACY_JAVA = (
    'debug/DebugLogStore.java', 'debug/DiagnosticSnapshot.java', 'debug/RuntimeState.java',
    'engine/ActionGate.java', 'engine/AppRule.java', 'engine/GenericAdEngine.java',
    'engine/RuleMatcher.java', 'engine/RuleRepository.java',
    'guard/JumpGuard.java', 'guard/SensorGuard.java',
    'network/AdDomainBlocklist.java', 'network/DnsPacket.java', 'network/LocalDnsVpnService.java',
    'vision/AdEvidenceTracker.java', 'vision/OcrSkipDetector.java',
    'vision/SplashVisionController.java', 'vision/VisionProfileStore.java',
    'vision/YoloNative.java', 'vision/YoloSkipDetector.java',
)
LEGACY_FILES = tuple('app/src/main/java/org/adguardian/app/' + p for p in LEGACY_JAVA) + (
    'app/src/main/cpp/yolo_jni.cpp', 'app/src/main/cpp/CMakeLists.txt',
    'tools/fetch_vision_deps.sh', 'tools/fetch_yolo_model.py', 'tools/fetch_ncnn.py',
    'app/src/main/assets/yolo.param', 'app/src/main/assets/yolo.bin',
)

def clean(root: Path) -> list[str]:
    root = root.resolve()
    removed = []
    for relative in LEGACY_FILES:
        path = root / relative
        if path.is_file():
            path.unlink()
            removed.append(relative)
    for pattern in ('app/src/main/jniLibs/*/libyolo*.so', 'app/src/main/jniLibs/*/libncnn.so'):
        for path in sorted(root.glob(pattern)):
            path.unlink()
            removed.append(path.relative_to(root).as_posix())
    for base in ('app/src/main/java', 'app/src/main/cpp', 'app/src/main/jniLibs'):
        folder = root / base
        if folder.is_dir():
            for path in sorted((p for p in folder.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
                if not any(path.iterdir()):
                    path.rmdir()
            if not any(folder.iterdir()):
                folder.rmdir()
    return removed

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    removed = clean(args.root)
    print('Removed recognized legacy files: ' + str(len(removed)))
    for name in removed:
        print('  ' + name)
