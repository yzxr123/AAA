#!/usr/bin/env python3
"""Validate the local CLASS rule asset consumed by ClassAdRules at runtime."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
ASSET = 'app/src/main/assets/class/cn.luyiyuntech.stt_1013.json'
PACKAGE = 'cn.luyiyuntech.stt'
PREFIX = 'com.bytedance.sdk.openadsdk.core.component.reward.activity.'
EXPECTED = {
    'class_native_promotion': ('POPUP', [], ['close', 'tv_confirm', 'btn_pay_now'], 'close', False),
    'class_native_interaction': ('POPUP', [], ['fhad_rl_content', 'fhad_iv_delete'], 'fhad_iv_delete', False),
    'class_splash': ('STARTUP', ['com.common.tang.activity.SplashActivity'], ['fl_ad_container', 'fl_place_holder_container'], 'tv_skip', True),
    'class_sdk_fullscreen': ('POPUP', [PREFIX+'TTFullScreenVideoActivity', PREFIX+'TTFullScreenVideoLandscapeActivity'], [], '', True),
}
HOME = ['navigation_bar', 'tv_today_date', 'tv_weeks', 'timetableView']


def validate(data: dict) -> None:
    if data.get('schema') != 1 or data.get('package') != PACKAGE or data.get('versionCode') != 1013:
        raise ValueError('CLASS package/version/schema differ from the uploaded APK')
    if data.get('apkSha256') != '9a64abc67f1ca5cfa55c644140af47caa5d8995da996c49e0a786a0bd8765638':
        raise ValueError('CLASS evidence APK hash mismatch')
    rules = data.get('rules')
    if not isinstance(rules, list) or len(rules) != len(EXPECTED):
        raise ValueError('Incomplete CLASS rules')
    seen = set()
    for rule in rules:
        key = rule.get('key')
        if key not in EXPECTED or key in seen:
            raise ValueError('Unknown or duplicate CLASS rule')
        seen.add(key)
        values = tuple(rule.get(k) for k in ('category', 'activities', 'allIds', 'targetId', 'matchCloseText'))
        if values != EXPECTED[key] or type(rule.get('matchCloseText')) is not bool:
            raise ValueError('CLASS rule lost its APK-derived match/action guard: '+key)
        if not isinstance(rule.get('name'), str) or not rule['name'] or not rule.get('evidence'):
            raise ValueError('CLASS human name or evidence absent')
        if set(rule) != {'key','name','category','activities','allIds','targetId','matchCloseText','evidence'}:
            raise ValueError('Unexpected CLASS rule fields')
    terminal = data.get('terminal', {})
    if terminal.get('activity') != 'com.common.tang.activity.MainActivity' or terminal.get('allIds') != HOME:
        raise ValueError('CLASS terminal must use the actual home and course layout guards')


def main() -> None:
    data = json.loads((ROOT/ASSET).read_text(encoding='utf-8'))
    validate(data)
    print('CLASS local runtime asset verified: package cn.luyiyuntech.stt version 1013 / 4 close groups / guarded timetable terminal')

if __name__ == '__main__':
    main()
