import copy
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('class_rules_validator', ROOT/'tools/validate_class_rules.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class ClassRulesTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((ROOT/module.ASSET).read_text(encoding='utf-8'))
    def test_actual_packaged_rule_asset(self):
        module.validate(self.data)
    def test_wrong_apk_version_is_not_assumed_compatible(self):
        self.data['versionCode'] = 1014
        with self.assertRaises(ValueError): module.validate(self.data)
    def test_losing_promotion_guard_fails_before_apk_build(self):
        self.data['rules'][0]['allIds'].remove('btn_pay_now')
        with self.assertRaises(ValueError): module.validate(self.data)
    def test_payment_control_can_never_be_substituted_for_close(self):
        self.data['rules'][0]['targetId'] = 'btn_pay_now'
        with self.assertRaises(ValueError): module.validate(self.data)
    def test_fake_runtime_sdk_resource_is_rejected(self):
        self.data['rules'][3]['targetId'] = 'tt_video_close_drawable'
        with self.assertRaises(ValueError): module.validate(self.data)
    def test_terminal_losing_course_structure_is_not_success(self):
        self.data['terminal']['allIds'].remove('timetableView')
        with self.assertRaises(ValueError): module.validate(self.data)
