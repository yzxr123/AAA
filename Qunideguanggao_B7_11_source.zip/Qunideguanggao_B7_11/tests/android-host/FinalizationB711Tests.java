import android.content.*;
import android.os.*;
import android.view.accessibility.*;
import java.util.*;
import java.lang.reflect.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.classapp.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.recording.*;

public final class FinalizationB711Tests {
 static final String PKG="cn.luyiyuntech.stt", SPLASH="com.common.tang.activity.SplashActivity", MAIN="com.common.tang.activity.MainActivity";
 static AccessibilityNodeInfo home(){
  AccessibilityNodeInfo r=FlowsB77Tests.root(PKG,PKG+":id/navigation_bar");
  for(String id:new String[]{"tv_today_date","tv_weeks","timetableView"})r.add(FlowsB77Tests.n(PKG+":id/"+id,null,"android.view.View",0,300,800,500,false));
  return r;
 }
 static FlowPage snapshot(AccessibilityNodeInfo r,String a){try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(r)){return FlowPage.capture(PKG,a,1013,i);}}
 static Object invoke(Object target,String name,Class<?>[] types,Object...args)throws Exception{
  try{return target.getClass().getMethod(name,types).invoke(target,args);}
  catch(NoSuchMethodException e){throw new AssertionError("missing functional entry: "+name);}
 }
 static RecordingDraft captured(TeachingB77Tests.Fixture f)throws Exception {
  f.start();f.pick();f.move("home",null,"host.example.Main",10400);f.teacher.stop();
  return new RecordingDraftStore(f.s).all().get(0);
 }
 public static void main(String[] args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("actual CLASS home anchors replace stale Splash Activity before finish",()->{
   FlowPage page=snapshot(home(),SPLASH);
   FlowsB77Tests.check(page!=null&&page.guard.activity.equals(MAIN)&&!page.knownClassAd,"stale Activity vetoes verified home");
  });
  FlowsB77Tests.run("CLASS confirmed splash step can finish on home even if no new Activity event arrived",()->{
   AccessibilityNodeInfo ad=FlowsB77Tests.root(PKG,PKG+":id/fl_ad_container");
   ad.add(FlowsB77Tests.n(PKG+":id/fl_place_holder_container",null,"android.view.View",0,200,1000,1500,false));
   ad.add(FlowsB77Tests.n(PKG+":id/tv_skip","跳过","android.widget.TextView",940,70,100,60,true));
   FlowJournal j=new FlowJournal(AdType.STARTUP);FlowPage p=snapshot(ad,SPLASH);
   FlowsB77Tests.check(j.beginClick(p,p.pick(980,100)),"no splash capture");
   FlowPage h=snapshot(home(),SPLASH);j.observe(h,10500);j.observe(h,10800);
   FlowsB77Tests.check(j.stepCount()==1,"step was not confirmed");
   FlowsB77Tests.check(j.finish("actual-record","课表").terminal.activity.equals(MAIN),"end still rejected");
  });
  FlowsB77Tests.run("home-like background with visible promotion is never promoted to finished home",()->{
   AccessibilityNodeInfo r=home();for(String id:new String[]{"close","tv_confirm","btn_pay_now"})r.add(FlowsB77Tests.n(PKG+":id/"+id,null,"android.widget.TextView",50,100,50,50,true));
   FlowsB77Tests.check(snapshot(r,SPLASH).knownClassAd,"ad over home mistaken for finish");
  });
  FlowsB77Tests.run("confirmed disk draft can be resumed and promoted once without recapturing step",()->{
   var f=new TeachingB77Tests.Fixture();RecordingDraft draft=captured(f);
   FlowsB77Tests.check(draft.confirmed==1&&f.replay.store().all().isEmpty(),"wrong precondition");
   invoke(f.teacher,"resumeDraft",new Class<?>[]{String.class},draft.key);Handler.advance(SystemClock.now);f.observe();f.save();
   FlowsB77Tests.check(f.replay.store().all().size()==1,"confirmed draft cannot become executable");
   FlowsB77Tests.check(new RecordingDraftStore(f.s).all().get(0).state==RecordingDraft.ENABLED,"draft still says waiting");f.close();
  });
  FlowsB77Tests.run("unfinished draft cannot be resumed as fully confirmed executable steps",()->{
   var f=new TeachingB77Tests.Fixture();f.start();f.pick();RecordingDraft d=new RecordingDraftStore(f.s).all().get(0);f.teacher.stop();
   invoke(f.teacher,"resumeDraft",new Class<?>[]{String.class},d.key);Handler.advance(SystemClock.now);
   FlowsB77Tests.check(!f.teacher.isActive()&&f.replay.store().all().isEmpty(),"unconfirmed step promoted");f.close();
  });
  FlowsB77Tests.run("explicit select execute captures before dispatch and removes need for late click event",()->{
   var f=new TeachingB77Tests.Fixture();f.start();
   var target=f.s.root.children.get(1);int before=target.clicks;
   invoke(f.teacher,"selectAndExecuteAt",new Class<?>[]{float.class,float.class},980f,100f);Handler.advance(SystemClock.now);
   FlowsB77Tests.check(target.clicks>before || f.s.gestures>0,"selected control was never executed");
   FlowsB77Tests.check(new RecordingDraftStore(f.s).all().size()==1,"selected operation not persisted before event");
   f.move("home",null,"host.example.Main",10400);f.save();FlowsB77Tests.check(f.replay.store().all().size()==1,"execute lesson not activated");f.close();
  });
  System.out.println("B7.11 finalization cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("finalization regressions");
 }
}
