import android.os.*;
import android.view.accessibility.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.settings.PreferenceStore;
public class IntegrationB77Tests {
 public static void main(String[] args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("CLASS targeted adapter is reachable from real RuleEngine independently of GKD",()->{
   FlowsB77Tests.Service s=new FlowsB77Tests.Service();s.getPackageManager().packageVersion=1013;
   s.root=ClassAdapterB77Tests.root();AccessibilityNodeInfo t=ClassAdapterB77Tests.close(null,"3s | 跳过");s.root.add(t);
   PreferenceStore.setGkdEnabled(s,false);PreferenceStore.setLiTiaotiaoEnabled(s,false);PreferenceStore.setLearnedEnabled(s,false);
   RuleEngine e=new RuleEngine(s,new Handler(Looper.getMainLooper()),()->{},()->ClassAdapterB77Tests.PKG);
   FlowsB77Tests.check(e.handle(ClassAdapterB77Tests.PKG,ClassAdapterB77Tests.AD,32,s.root)&&t.clicks==1,"dedicated adapter not wired");e.close();
  });
  FlowsB77Tests.run("multi-step replay is wired to RuleEngine and excludes simultaneous OCR ownership",()->{
   FlowsB77Tests.Service s=new FlowsB77Tests.Service();s.root=FlowsB77Tests.page("video","跳过");new FlowStore(s).add(FlowsB77Tests.flow());
   PreferenceStore.setGkdEnabled(s,false);PreferenceStore.setLiTiaotiaoEnabled(s,false);
   RuleEngine e=new RuleEngine(s,new Handler(Looper.getMainLooper()),()->{},()->"host.example");
   FlowsB77Tests.check(e.handle("host.example","host.example.Ad",32,s.root)&&s.root.children.get(1).clicks==1,"stored flow not wired");
   FlowsB77Tests.check(e.isWaitingForRules()&&!e.beginExternalAction()&&e.nextWakeUp()>=0,"OCR can interfere or no replay retry");
   e.onUserInteraction();FlowsB77Tests.check(!e.isWaitingForRules(),"manual user click did not stop replay");e.close();
  });
  System.out.println("B7.7 integration cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);if(FlowsB77Tests.fail>0)throw new AssertionError("integration failures");
 }
}
