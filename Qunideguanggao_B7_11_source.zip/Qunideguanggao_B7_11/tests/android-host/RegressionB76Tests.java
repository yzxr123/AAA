import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.*;
import android.view.accessibility.*;
import android.widget.TextView;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.learning.*;
import org.adguardian.app.runtime.*;
import org.adguardian.app.service.*;

public class RegressionB76Tests {
    static int passed,failed;
    interface Case {void run() throws Exception;}
    static void check(boolean v,String message){if(!v)throw new AssertionError(message);}
    static void run(String name,Case task) {
        Handler.tasks.clear();SystemClock.now=10000;
        try {for(String fieldName:new String[]{"owner","requestedAt"}){Field f=ProtectionService.class.getDeclaredField(fieldName);f.setAccessible(true);f.set(null,fieldName.equals("owner")?null:Long.valueOf(0));}}catch(Exception e){throw new AssertionError(e);}
        Object owner=new Object();AccessibilityState.connected(owner);AccessibilityState.disconnected(owner);
        File file=new File(new Context().getFilesDir(),"learned-ad-rules.bin");
        file.delete();new File(file+".new").delete();new File(file+".bak").delete();
        try {task.run();passed++;System.out.println("PASS "+name);}catch(Throwable e){failed++;System.out.println("FAIL "+name+" -> "+e);}
    }
    static void authorize(Context c){c.getContentResolver().settings.put(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,c.getPackageName()+"/"+AdAccessibilityService.class.getName());}
    static class TestService extends AccessibilityService {public void onAccessibilityEvent(AccessibilityEvent e){}public void onInterrupt(){}}
    static class Windows implements WindowManager {
        View panel;
        public void addView(View v,LayoutParams p){panel=v;}
        public void removeView(View v){if(panel==v)panel=null;}
    }
    static View button(View root,String text){
        if(root instanceof TextView t&&text.contentEquals(t.getText()))return root;
        if(root instanceof ViewGroup g)for(View child:g.children){View v=button(child,text);if(v!=null)return v;}
        return null;
    }
    static AccessibilityNodeInfo root(){AccessibilityNodeInfo r=new AccessibilityNodeInfo();r.pkg="host.example";r.id="host.example:id/screen";r.name="android.widget.FrameLayout";r.bounds=new Rect(0,0,1080,2400);r.clickable=false;return r;}
    static AccessibilityNodeInfo close(){AccessibilityNodeInfo n=new AccessibilityNodeInfo();n.id="host.example:id/close_button";n.name="android.widget.TextView";n.text="关闭广告";n.bounds=new Rect(940,80,1040,145);return n;}
    static class Fixture {
        TestService s=new TestService();Windows windows=new Windows();Handler worker=new Handler(Looper.getMainLooper());
        LearnedRuleEngine engine=new LearnedRuleEngine(s,worker,new ActionVerifier(s,worker,()->"host.example",()->{}),()->"host.example");
        LearningController learning=new LearningController(s,worker,()->"host.example",engine,()->{});
        AccessibilityNodeInfo n=close();
        Fixture(){s.services.put(Context.WINDOW_SERVICE,windows);s.root=root();s.root.add(n);}
        void start(){learning.start(AdType.POPUP);Handler.advance(10000);observe();}
        void observe(){try(AccessibilityNodeIndex idx=AccessibilityNodeIndex.build(s.root)){learning.observe("host.example","host.example.Main",idx);}}
        void click(){AccessibilityEvent e=new AccessibilityEvent();e.type=1;e.pkg="host.example";e.source=n;learning.clicked(e);}
        void save(){View v=button(windows.panel,"保存");check(v!=null&&v.isEnabled(),"no captured target to save");v.performClick();Handler.advance(10000);Handler.advance(10200);Handler.advance(10500);}
    }
    public static void main(String[] args)throws Exception {
        run("missing secure setting and empty manager must remain unknown not denied",()->{
            Context c=new Context();c.services.put(Context.ACCESSIBILITY_SERVICE,new AccessibilityManager());
            AccessibilityState.Snapshot s=AccessibilityState.read(c);
            check(!s.known&&!s.permissionText().contains("未允许"),"unreadable setting treated as revoked permission");
        });
        run("live system service proves permission when secure and manager are temporarily unavailable",()->{
            Context c=new Context();Object owner=new Object();AccessibilityState.connected(owner);AccessibilityState.initialized(owner,true);
            check(AccessibilityState.read(c).running(),"real connected service is reported unauthorized");AccessibilityState.disconnected(owner);
        });
        run("guard is not stopped solely by unavailable permission read after a verified grant",()->{
            Context c=new Context();authorize(c);check(ProtectionService.shouldRun(c),"baseline grant not seen");
            c.getContentResolver().settings.remove(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            check(ProtectionService.shouldRun(c),"transient missing provider stops foreground guard");
            c.getContentResolver().settings.put(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,"");
            check(!ProtectionService.shouldRun(c),"explicit revocation ignored");
        });
        run("OCR action ownership is invalidated on foreground app switch",()->{
            TestService s=new TestService();RuleEngine e=new RuleEngine(s,new Handler(Looper.getMainLooper()),()->{},()->"host.example");
            e.onPackageEntered("host.example");check(e.beginExternalAction(),"cannot begin initial OCR action");long old=e.externalActionToken();
            e.onPackageEntered("other.example");Handler.advance(12000);
            check(e.beginExternalAction(),"new application permanently blocked by old OCR action");e.endExternalAction(old);
            check(!e.beginExternalAction(),"stale completion freed new OCR action");e.close();
        });
        run("dynamic skip countdown retains the same taught button",()->{
            AccessibilityNodeInfo r=root(),n=close();n.text="跳过 5 秒";r.add(n);NodeTarget t=NodeTarget.capture(n,r.bounds).forLearning();n.text="跳过 4 秒";
            check(t.matches(n,r.bounds,true),"changing countdown invalidates learned selector");n.text="立即安装";
            check(!t.matches(n,r.bounds,true),"unrelated target label accepted");
        });
        run("invalid learned values must not overwrite a readable local rule store",()->{
            Context c=new Context();LearnedRuleStore store=new LearnedRuleStore(c);store.clear();
            NodeTarget target=new NodeTarget("host.example:id/x","android.view.View","",Float.NaN,.2f,.1f,.03f);
            try{store.add(new LearnedRule("bad","host.example","Test","host.example.Main",1,target,true));throw new AssertionError("nonfinite rule written");}catch(IOException expected){}
            check(new LearnedRuleStore(c).isReadable(),"store corrupted by its own write");
        });
        run("learning freezes the observed ad page before a click changes the page",()->{
            Fixture f=new Fixture();f.start();f.click();f.s.root.children.clear();try(AccessibilityNodeIndex idx=AccessibilityNodeIndex.build(f.s.root)){f.learning.observe("host.example","host.example.After",idx);}Handler.advance(10000);
            f.save();check(f.engine.store().all().size()==1,"after-click page overwrote teaching context");
        });
        run("source node must be copied at event intake not resolved after queued work",()->{
            Fixture f=new Fixture();f.start();AccessibilityEvent event=new AccessibilityEvent();event.type=1;event.pkg="host.example";
            final boolean[] exists={true};event.sourceLookup=()->exists[0]?f.n:null;
            f.learning.clicked(event);exists[0]=false;f.s.root.children.clear();Handler.advance(10000);
            f.save();check(f.engine.store().all().size()==1,"late source lookup lost disappearing ad control");
        });
        run("saving while the original close target remains must not claim learned success",()->{
            Fixture f=new Fixture();f.start();f.click();Handler.advance(10000);f.save();
            check(f.engine.store().all().isEmpty(),"unchanged advertisement was saved as successfully closed");f.learning.stop();
        });
        run("a user taught unique ad close button does not require the literal word advertisement",()->{
            Fixture f=new Fixture();f.n.text="×";
            AccessibilityNodeInfo anchor=new AccessibilityNodeInfo();anchor.id="host.example:id/panel_content";anchor.name="android.webkit.WebView";
            anchor.clickable=false;anchor.bounds=new Rect(0,150,1080,2200);f.s.root.add(anchor);
            f.start();f.click();f.s.root.children.clear();Handler.advance(10000);f.save();
            check(f.engine.store().all().size()==1,"ad with no accessible advertisement label cannot be taught");
            LearnedRule rule=f.engine.store().all().get(0);f.s.root.add(f.n);f.s.root.add(anchor);
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(f.s.root)){check(rule.match("host.example","host.example.Main",1,index)==f.n,"taught page still fails recognition");}
            anchor.id="host.example:id/payment_form";
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(f.s.root)){check(rule.match("host.example","host.example.Main",1,index)==null,"different normal page must not be closed");}
        });
        run("learning overlay cannot hide the active target application tree",()->{
            TestService service=new TestService();service.root=root();service.root.pkg=service.getPackageName();service.root.window=9;
            AccessibilityWindowInfo overlay=new AccessibilityWindowInfo();overlay.type=AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY;overlay.id=9;overlay.root=service.root;
            AccessibilityWindowInfo app=new AccessibilityWindowInfo();app.id=1;app.active=true;app.root=root();service.windows.add(overlay);service.windows.add(app);
            Method read=RootAccess.class.getMethod("readFor",AccessibilityService.class,String.class);
            check(read.invoke(null,service,"host.example")==app.root,"overlay chosen instead of actual application");
        });
        run("root fallback must not operate behind a different foreground application",()->{
            TestService service=new TestService();service.root=root();service.root.pkg="payment.example";
            AccessibilityWindowInfo background=new AccessibilityWindowInfo();background.root=root();service.windows.add(background);
            Method read=RootAccess.class.getMethod("readFor",AccessibilityService.class,String.class);
            check(read.invoke(null,service,"host.example")==null,"stale background app becomes actionable");
        });
        run("a binder failure during service configuration must not crash the process",()->{
            AdAccessibilityService s=new AdAccessibilityService();authorize(s);s.root=root();s.failServiceInfo=true;
            Method connect=AdAccessibilityService.class.getDeclaredMethod("onServiceConnected");connect.setAccessible(true);
            connect.invoke(s);Handler.advance(10000);
            check(AccessibilityState.read(s).authorized&&AccessibilityState.read(s).failed,"configuration fault not exposed without clearing authorization");
            s.onDestroy();
        });
        run("retry initialization must not simulate another Android system connection",()->{
            AdAccessibilityService s=new AdAccessibilityService();authorize(s);s.root=root();
            Method connect=AdAccessibilityService.class.getDeclaredMethod("onServiceConnected");connect.setAccessible(true);connect.invoke(s);Handler.advance(10000);
            int count=s.systemConnectedCalls;AccessibilityState.initialized(s,false);AdAccessibilityService.retryInitialization();Handler.advance(10000);
            check(s.systemConnectedCalls==count,"application invoked onServiceConnected as a fake rebind");
            check(AccessibilityState.read(s).running(),"connected runtime did not recover");s.onDestroy();
        });
        run("explicit node selection teaches a small unlabeled image without recording arbitrary coordinates",()->{
            Fixture f=new Fixture();f.n.id=null;f.n.text=null;f.n.name="android.widget.ImageView";
            AccessibilityNodeInfo anchor=new AccessibilityNodeInfo();anchor.id="host.example:id/content_panel";anchor.clickable=false;anchor.bounds=new Rect(0,180,1080,2200);f.s.root.add(anchor);f.start();
            Method select=LearningController.class.getMethod("selectAt",float.class,float.class);
            select.invoke(f.learning,990f,110f);Handler.advance(10000);f.s.root.children.remove(f.n);f.save();
            check(f.engine.store().all().size()==1,"unlabeled close button not learned");
            LearnedRule rule=new LearnedRuleStore(f.s).all().get(0);f.s.root.children.add(0,f.n);
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(f.s.root)){check(rule.match("host.example","host.example.Main",1,index)==f.n,"structural replay did not match original page");}
        });
        run("teaching must restore notification debounce on stop",()->{
            Fixture f=new Fixture();f.s.serviceInfo.notificationTimeout=60;f.start();
            check(f.s.serviceInfo.notificationTimeout==0,"teaching retained delayed click-event delivery");f.learning.stop();
            check(f.s.serviceInfo.notificationTimeout==60,"ordinary operation left high event frequency after teaching");
        });
        run("one click enable must not send an unreadable existing grant back to authorization",()->{
            org.adguardian.app.MainActivity a=new org.adguardian.app.MainActivity();
            Method enable=org.adguardian.app.MainActivity.class.getDeclaredMethod("enableEverything");enable.setAccessible(true);enable.invoke(a);
            check(a.activityStarts==0,"unknown authorization was treated as permission denial");
        });
        run("missing OEM settings page must not terminate the app and its service",()->{
            org.adguardian.app.MainActivity a=new org.adguardian.app.MainActivity();a.activityStartFailure=true;
            Method open=org.adguardian.app.MainActivity.class.getDeclaredMethod("openAccessibilitySettings");open.setAccessible(true);open.invoke(a);
        });
        run("changing anonymous web content must not invalidate stable taught close controls",()->{
            Fixture f=new Fixture();f.n.text="×";AccessibilityNodeInfo web=new AccessibilityNodeInfo();web.name="android.webkit.WebView";web.clickable=false;web.bounds=new Rect(0,200,1080,2200);f.s.root.add(web);
            f.start();f.click();f.s.root.children.remove(f.n);Handler.advance(10000);f.save();
            LearnedRule rule=f.engine.store().all().get(0);f.s.root.children.add(0,f.n);
            AccessibilityNodeInfo changing=new AccessibilityNodeInfo();changing.name="android.view.View";changing.text="unrelated advertising content";web.add(changing);
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(f.s.root)){check(rule.match("host.example","host.example.Main",1,index)==f.n,"unstable content tree invalidates the stable close button");}
        });
        run("native duplicate node wrappers are released when canonical index entries are reused",()->{
            AccessibilityNodeInfo original=close(),duplicate=close();Object token=new Object();original.logicalToken=token;duplicate.logicalToken=token;
            AccessibilityNodeInfo root=new AccessibilityNodeInfo(){@Override public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByViewId(String id){return java.util.Arrays.asList(duplicate);}};
            root.add(original);
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)){check(index.cachedChild(root,0)==original,"child not stored");check(index.fastQuery(root,"id",original.id).get(0)==original,"native duplicate not canonicalized");}
            check(original.recycles==1 && duplicate.recycles==1,"an obtained duplicate wrapper was abandoned instead of released");
        });
        run("explicit global accessibility off is not treated as an unknown retained grant",()->{
            Context c=new Context();authorize(c);check(ProtectionService.shouldRun(c),"initial authorization missing");
            c.getContentResolver().settings.remove(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            c.getContentResolver().settings.put(Settings.Secure.ACCESSIBILITY_ENABLED,"0");
            check(AccessibilityState.read(c).known&&!AccessibilityState.read(c).authorized&&!ProtectionService.shouldRun(c),"explicit global switch off did not stop protection");
        });
        run("known blind image targets still require actual disappearance during outcome verification",()->{
            TestService s=new TestService();s.root=root();AccessibilityNodeInfo image=close();image.id=null;image.text=null;image.name="android.widget.ImageView";s.root.add(image);
            ActionVerifier v=new ActionVerifier(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});
            ActionVerifier.Ticket ticket;try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(s.root)){ticket=v.capture("host.example","image","click",image,index,null);}
            v.accepted(ticket);check(v.isPending(),"structural learned target was not verified");
            Handler.advance(10150);Handler.advance(10350);Handler.advance(10900);
            check(!v.allowed("host.example","image",s.root.getWindowId()),"unchanged image was incorrectly confirmed absent");
        });
        run("an exhausted learned query budget yields to other rule engines instead of aborting the scan",()->{
            Fixture f=new Fixture();
            AccessibilityNodeInfo slow=new AccessibilityNodeInfo(){@Override public AccessibilityNodeInfo getChild(int i){SystemClock.now+=100;return super.getChild(i);}};
            slow.pkg="host.example";slow.bounds=new Rect(0,0,1080,2400);slow.add(f.n);f.s.root=slow;
            NodeTarget target;try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(slow)){target=NodeTarget.capture(f.n,index.rootBounds());}
            f.engine.store().add(new LearnedRule("slow","host.example","test","host.example.Main",1,target,true));
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(slow)){check(!f.engine.handle("host.example","host.example.Main",index),"slow query should yield");index.checkBudget();}
        });
        run("B7.5 learned records migrate without deleting previous user rules",()->{
            Fixture f=new Fixture();NodeTarget target;try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(f.s.root)){target=NodeTarget.capture(f.n,index.rootBounds());}
            File file=new File(f.s.getFilesDir(),"learned-ad-rules.bin");
            try(DataOutputStream out=new DataOutputStream(new FileOutputStream(file))){
                out.writeInt(0x51414431);out.writeInt(1);out.writeUTF("old");out.writeUTF("host.example");out.writeUTF("test");out.writeUTF("host.example.Main");
                out.writeLong(1);out.writeBoolean(true);out.writeInt(AdType.POPUP.ordinal());
                out.writeUTF(target.id);out.writeUTF(target.name);out.writeUTF(target.label);out.writeFloat(target.x);out.writeFloat(target.y);out.writeFloat(target.width);out.writeFloat(target.height);
            }
            LearnedRuleStore store=new LearnedRuleStore(f.s);check(store.isReadable()&&store.all().size()==1,"previous format was dropped");
            store.setEnabled("old",false);LearnedRuleStore next=new LearnedRuleStore(f.s);check(next.isReadable()&&next.all().size()==1&&!next.all().get(0).enabled,"migration did not preserve rule toggle");
        });
        System.out.println("B7.6 regressions passed="+passed+" failed="+failed);
        if(failed>0)throw new AssertionError("behavioral regressions: "+failed);
    }
}
