import android.app.AlertDialog;
import android.content.*;
import android.os.*;
import android.graphics.Rect;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.Files;
import java.util.*;
import org.adguardian.app.MainActivity;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.learning.*;
import org.adguardian.app.recording.*;
import org.adguardian.app.service.*;

public final class RecordingB710Tests {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void call(Object target,String method)throws Exception{Method m=target.getClass().getDeclaredMethod(method);m.setAccessible(true);m.invoke(target);}
 public static void awaitFiles()throws Exception {
  for(int n=0;n<8;n++){
   for(Thread t:Thread.getAllStackTraces().keySet())if(t.getName().equals("AdRecordFiles"))t.join(4000);
   Handler.advance(SystemClock.now);Thread.sleep(5);
  }
 }
 static File file(String name){return new File(new Context().getFilesDir(),name);}
 static LearnedRule rule(String key){var f=FlowsB77Tests.flow();return new LearnedRule(key,"host.example","测试","host.example.Ad",1,new NodeTarget("host.example:id/close_"+key,"android.widget.TextView","关闭",.9f,.04f,.08f,.025f),true,AdType.POPUP,f.steps.get(0).guard.signature);}
 static RecordingDraft draft(String key){var f=FlowsB77Tests.flow();return new RecordingDraft(key,f.packageName,f.appName,f.versionCode,f.type,false,List.of(f.steps.get(0)),0,RecordingDraft.CAPTURED,System.currentTimeMillis());}
 static void offline()throws Exception {
  var a=AdAccessibilityService.class.getDeclaredField("activeService");a.setAccessible(true);((java.lang.ref.Reference<?>)a.get(null)).clear();
 }
 public static void main(String[]args)throws Exception{
  if(args.length>0 && args[0].equals("child-read")){
   check(new RecordingDraftStore(new Context()).all().size()==1,"new JVM cannot reload captured record");
   check(new FlowStore(new Context()).all().isEmpty(),"child saw executable rule for an unverified draft");return;
  }
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("single-rule writers from independent contexts retain both entries",()->{
   file("learned-ad-rules.bin").delete();var a=new LearnedRuleStore(new Context());var b=new LearnedRuleStore(new Context());
   a.add(rule("one"));b.add(rule("two"));check(new LearnedRuleStore(new Context()).all().size()==2,"second stale writer lost first rule");file("learned-ad-rules.bin").delete();
  });
  FlowsB77Tests.run("live single-rule reader sees offline manager disable",()->{
   file("learned-ad-rules.bin").delete();var engine=new LearnedRuleStore(new Context());engine.add(rule("one"));
   new LearnedRuleStore(new Context()).setEnabled("one",false);check(!engine.all().get(0).enabled,"live reader replays a rule disabled from offline manager");file("learned-ad-rules.bin").delete();
  });
  FlowsB77Tests.run("stored flows remain visible when accessibility is disconnected",()->{
   offline();new FlowStore(new Context()).add(FlowsB77Tests.flow());AlertDialog.lastItems=null;call(new MainActivity(),"showLearnedFlows");awaitFiles();
   check(AlertDialog.lastItems!=null && AlertDialog.lastItems.length==1 && AlertDialog.lastTitle.contains("已学习"),"offline management depended on accessibility connection");
  });
  FlowsB77Tests.run("offline management can disable a flow without false saved callback",()->{
   offline();var f=FlowsB77Tests.flow();new FlowStore(new Context()).add(f);var a=new MainActivity();
   Method m=MainActivity.class.getDeclaredMethod("changeLearnedFlow",LearnedFlow.class,int.class);m.setAccessible(true);m.invoke(a,f,0);awaitFiles();
   check(!new FlowStore(new Context()).all().get(0).enabled,"missing service skipped write but management reported success");
  });
  FlowsB77Tests.run("captured drafts are visible in UI without accessibility authorization",()->{
   offline();RegressionB710Tests.clean();new RecordingDraftStore(new Context()).put(draft("draft"));AlertDialog.lastItems=null;
   call(new MainActivity(),"showRecordingDrafts");awaitFiles();check(AlertDialog.lastItems!=null && AlertDialog.lastItems.length==1 && AlertDialog.lastItems[0].toString().contains("草稿"),"saved draft hidden by permissions");
  });
  FlowsB77Tests.run("stored single-button rules are visible offline",()->{
   offline();file("learned-ad-rules.bin").delete();new LearnedRuleStore(new Context()).add(rule("one"));AlertDialog.lastItems=null;
   call(new MainActivity(),"showLearnedRules");awaitFiles();check(AlertDialog.lastItems!=null && AlertDialog.lastItems.length==1,"offline single-button data hidden");file("learned-ad-rules.bin").delete();
  });
  FlowsB77Tests.run("feedback interruption does not cancel an explicit active recording",()->{
   var windows=new RegressionB76Tests.Windows();var s=ServiceFlowB77Tests.create(windows);
   AdAccessibilityService.beginFlowLearning(AdType.POPUP);Handler.advance(10200);s.onInterrupt();Handler.advance(10300);
   try {check(RegressionB76Tests.button(windows.panel,"选取下一步")!=null,"feedback-only interruption canceled the recorder");}finally{s.onDestroy();Handler.advance(10400);}
  });
  FlowsB77Tests.run("a second JVM loads unfinished capture from real filesystem",()->{
   RegressionB710Tests.clean();new RecordingDraftStore(new Context()).put(draft("persisted"));
   java.lang.Process p=new ProcessBuilder(System.getProperty("java.home")+"/bin/java","-Djava.io.tmpdir="+System.getProperty("java.io.tmpdir"),"-cp",System.getProperty("java.class.path"),"RecordingB710Tests","child-read").inheritIO().start();
   check(p.waitFor()==0,"cross-process reload failed");
  });
  FlowsB77Tests.run("unknown terminal page retains steps without making executable rule",()->{
   RegressionB710Tests.clean();var f=new TeachingB77Tests.Fixture();f.start();f.pick();f.s.root=null;f.save();
   check(new RecordingDraftStore(f.s).all().get(0).steps.size()==1,"verification failure discarded captured step");
   check(f.replay.store().all().isEmpty(),"unknown terminal falsely enabled flow");f.close();
  });
  FlowsB77Tests.run("interrupted multi-step lesson stores the pending second step",()->{
   RegressionB710Tests.clean();var f=new TeachingB77Tests.Fixture();f.start();f.click();f.move("endcard","关闭","host.example.Ad",10400);f.click();f.teacher.stop();
   var d=new RecordingDraftStore(f.s).all().get(0);check(d.steps.size()==2 && d.confirmed==1,"pending second action lost");check(f.replay.store().all().isEmpty(),"unfinished flow enabled");f.close();
  });
  FlowsB77Tests.run("corrupt draft cannot be overwritten by next capture",()->{
   RegressionB710Tests.clean();byte[] damaged={1,2,3,4};Files.write(RegressionB710Tests.drafts().toPath(),damaged);
   try{new RecordingDraftStore(new Context()).put(draft("new"));throw new AssertionError("corrupt file replaced");}catch(IOException expected){}
   check(Arrays.equals(damaged,Files.readAllBytes(RegressionB710Tests.drafts().toPath())),"old bytes destroyed");RegressionB710Tests.clean();
  });
  FlowsB77Tests.run("archive capacity never silently evicts earlier captured lessons",()->{
   RegressionB710Tests.clean();var store=new RecordingDraftStore(new Context());for(int i=0;i<64;i++)store.put(draft("d"+i));byte[] before=Files.readAllBytes(RegressionB710Tests.drafts().toPath());
   try{store.put(draft("overflow"));throw new AssertionError("archive limit ignored");}catch(IOException expected){}
   check(Arrays.equals(before,Files.readAllBytes(RegressionB710Tests.drafts().toPath())),"capacity failure changed stored data");RegressionB710Tests.clean();
  });
  FlowsB77Tests.run("physical rotation cancels teaching even when window keeps portrait proportions",()->{
   var root=FlowsB77Tests.page("video","跳过");FlowPage a,b;
   try(var index=AccessibilityNodeIndex.build(root)){a=FlowPage.capture("host.example","host.example.Ad",1,index,0);}
   var home=FlowsB77Tests.page("home",null);try(var index=AccessibilityNodeIndex.build(home)){b=FlowPage.capture("host.example","host.example.Main",1,index,1);}
   var j=new FlowJournal(AdType.POPUP);j.beginClick(a,FlowsB77Tests.target(root));j.observe(b,10500);check(j.cancelled(),"real rotation treated as inset change");
  });
  FlowsB77Tests.run("flow replay tolerates fullscreen first stage and inset terminal",()->{
   var f=FlowsB77Tests.flow();var s=new FlowsB77Tests.Service();s.root=FlowsB77Tests.page("video","跳过");
   var home=FlowsB77Tests.page("home",null);home.bounds=new Rect(0,96,1080,2180);var terminal=FlowsB77Tests.snap(home,"host.example.Main");
   var engine=new FlowReplayEngine(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});engine.store().add(new LearnedFlow(f.key,f.packageName,f.appName,1,f.type,true,f.steps,terminal.guard));
   check(FlowsB77Tests.handle(engine,s,"host.example.Ad"),"first page rejected by unrelated terminal aspect");
   s.root=FlowsB77Tests.page("endcard","关闭");Handler.advance(10400);FlowsB77Tests.handle(engine,s,"host.example.Ad");Handler.advance(10700);FlowsB77Tests.handle(engine,s,"host.example.Ad");
   check(s.root.children.get(1).clicks==1,"second page not clicked");s.root=home;Handler.advance(11000);FlowsB77Tests.handle(engine,s,"host.example.Main");Handler.advance(11300);FlowsB77Tests.handle(engine,s,"host.example.Main");
   check(engine.completedCount()==1,"inset terminal never completed");engine.close();
  });
  RegressionB710Tests.clean();
  System.out.println("B7.10 recording/lifecycle cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("recording regressions");
 }
}
