import android.os.*;
import android.content.*;
import android.view.accessibility.*;
import java.io.*;
import java.util.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.learning.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.classapp.*;

public class LearningB79Tests {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static RegressionB76Tests.Fixture fresh() {
  File f=new File(new Context().getFilesDir(),"learned-ad-rules.bin");f.delete();new File(f+".bak").delete();
  return new RegressionB76Tests.Fixture();
 }
 public static void main(String[] args)throws Exception{
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("single-button capture does not reject a 300-node stable advertisement",()->{
   var f=fresh();for(int i=0;i<300;i++)f.s.root.add(FlowsB77Tests.n(null,"BODY_"+i,"android.widget.TextView",0,300,800,30,false));
   f.n.id=null;f.n.text=null;f.n.name="android.widget.ImageView";f.s.root.add(FlowsB77Tests.n("host.example:id/content_panel",null,"android.webkit.WebView",0,200,1080,2000,false));
   f.start();f.learning.selectAt(990,110);Handler.advance(10000);f.s.root.children.remove(f.n);f.save();
   check(f.engine.store().all().size()==1,"single-button entry still uses the obsolete 128-node rejection");f.learning.stop();
  });
  FlowsB77Tests.run("single-button click may arrive after the next page snapshot",()->{
   var f=fresh();f.start();var close=f.n;
   SystemClock.now=10100;f.s.root=FlowsB77Tests.page("home",null);f.observe();
   f.learning.clicked(RegressionB79Tests.click("host.example",close,10030,null));Handler.advance(10100);
   f.save();check(f.engine.store().all().size()==1,"single-button history still overwrites pre-click data");f.learning.stop();
  });
  FlowsB77Tests.run("single-button learning resolves unique close event text after source death",()->{
   var f=fresh();f.n.text="| 跳过";f.start();f.learning.clicked(RegressionB79Tests.click("host.example",null,10000,"3s | 跳过"));Handler.advance(10000);
   f.s.root.children.remove(f.n);f.save();check(f.engine.store().all().size()==1,"single-button source null throws away safe event text");f.learning.stop();
  });
  FlowsB77Tests.run("single-button selected container without resource ID is stored with structural guards and reloads",()->{
   var f=fresh();f.n.id=null;f.n.text=null;f.n.name="android.widget.LinearLayout";
   f.s.root.add(FlowsB77Tests.n("host.example:id/content_panel",null,"android.webkit.WebView",0,200,1080,2000,false));f.start();
   f.learning.selectAt(990,110);Handler.advance(10000);f.s.root.children.remove(f.n);f.save();
   var list=new LearnedRuleStore(f.s).all();check(list.size()==1,"small selected LinearLayout is still impossible to learn");f.s.root.add(f.n);
   try(var index=AccessibilityNodeIndex.build(f.s.root)){check(list.get(0).match("host.example","host.example.Main",1,index)==f.n,"reloaded guarded container cannot replay");}f.learning.stop();
  });
  FlowsB77Tests.run("single-button picker retries transient teardown and stops after cancel",()->{
   var f=fresh();f.start();var actual=f.s.root;f.s.root=null;f.learning.selectAt(990,110);Handler.advance(10000);
   f.s.root=actual;Handler.advance(10120);f.s.root.children.remove(f.n);f.save();check(f.engine.store().all().size()==1,"picker teardown transient not retried");f.learning.stop();
  });
  FlowsB77Tests.run("single-button negative version cache recovers within same foreground session",()->{
   var f=fresh();var pm=new RegressionB78Tests.PM();pm.failures=1;f.s.pm=pm;
   f.start();f.click();Handler.advance(10000);Handler.advance(11000);f.observe();f.click();Handler.advance(11000);f.s.root.children.remove(f.n);RegressionB76Tests.button(f.windows.panel,"保存").performClick();Handler.advance(11000);Handler.advance(11200);Handler.advance(11500);
   check(f.engine.store().all().size()==1,"negative version remained permanently unrecordable");f.learning.stop();
  });
  FlowsB77Tests.run("CLASS native close rule needs all three APK layout controls",()->{
   var f=new ClassAdapterB77Tests.Fixture();var r=ClassAdapterB77Tests.root();var close=ClassAdapterB77Tests.close(ClassAdProfile.PACKAGE+":id/close",null);r.add(close);
   r.add(FlowsB77Tests.n(ClassAdProfile.PACKAGE+":id/tv_confirm",null,"android.widget.TextView",100,500,400,80,true));f.s.root=r;
   check(!f.handle("")&&close.clicks==0,"partial normal dialog was treated as promotion");f.engine.close();
  });
  FlowsB77Tests.run("unknown Activity requires distinct stable anchor IDs not repeated list IDs",()->{
   var r=FlowsB77Tests.root("host.example",null);for(int i=0;i<4;i++)r.add(FlowsB77Tests.n("host.example:id/item",null,"android.widget.TextView",0,300+i*40,100,30,false));
   try(var index=AccessibilityNodeIndex.build(r)){check(FlowPage.capture("host.example","",1,index)==null,"duplicate list ID masquerades as strong exact window metadata");}
  });
  FlowsB77Tests.run("an unknown Activity is allowed only when the exact structural guard agrees",()->{
   var page=FlowsB77Tests.snap(FlowsB77Tests.page("video","跳过"),"host.example.Ad");
   FlowPage missing;try(var index=AccessibilityNodeIndex.build(FlowsB77Tests.page("video","跳过"))){missing=FlowPage.capture("host.example","",1,index);}
   check(missing!=null&&page.guard.matches(missing.guard),"matching window guard should survive missing metadata");
   var unrelated=FlowsB77Tests.snap(FlowsB77Tests.page("home",null),"host.example.Ad");check(!unrelated.guard.matches(missing.guard),"different structural page bypassed guard");
   check(!page.guard.matches(FlowsB77Tests.snap(FlowsB77Tests.page("video","跳过"),"host.example.Other").guard),"two conflicting known Activities matched");
  });
  FlowsB77Tests.run("an anonymous third-party sparse page does not inherit CLASS trust",()->{
   var r=FlowsB77Tests.root("host.example",null);r.add(FlowsB77Tests.n(null,null,"android.webkit.WebView",0,0,1080,2400,false));r.add(FlowsB77Tests.n(null,null,"android.widget.ImageView",940,70,70,60,true));
   try(var index=AccessibilityNodeIndex.build(r)){check(FlowPage.capture("host.example","host.example.Ad",1,index)==null,"CLASS-only evidence leaked into other apps");}
  });
  FlowsB77Tests.run("CLASS APK evidence must not trust an unverified newer version",()->{
   var r=FlowsB77Tests.root(ClassAdProfile.PACKAGE,null);r.add(FlowsB77Tests.n(null,null,"android.webkit.WebView",0,0,1080,2400,false));r.add(FlowsB77Tests.n(null,null,"android.widget.ImageView",940,70,70,60,true));
   try(var index=AccessibilityNodeIndex.build(r)){check(FlowPage.capture(ClassAdProfile.PACKAGE,ClassAdProfile.VIDEO,9999,index)==null,"sparse trusted ad path ignored installed version");}
  });
  System.out.println("B7.9 single-button and safety regressions passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("B7.9 single-button and safety regressions");
 }
}
