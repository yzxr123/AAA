import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import org.adguardian.app.flow.*;
import org.adguardian.app.engine.*;
public class FlowEdgesB77Tests {
  public static void main(String[] args) throws Exception {
    FlowsB77Tests.pass=FlowsB77Tests.fail=0;
    FlowsB77Tests.run("disabled but still visible close is not a completed stage",()->{
      AccessibilityNodeInfo r=FlowsB77Tests.page("video","跳过");FlowPage before=FlowsB77Tests.snap(r,"host.example.Ad");
      FlowJournal j=new FlowJournal(AdType.POPUP);j.beginClick(before,FlowsB77Tests.target(r));r.children.get(1).enabled=false;
      FlowPage after=FlowsB77Tests.snap(r,"host.example.Ad");j.observe(after,10200);j.observe(after,10500);
      FlowsB77Tests.check(j.pending()&&j.stepCount()==0,"disabled control falsely confirmed gone");
      FlowsB77Tests.check(after.find(FlowsB77Tests.target(r))==null,"disabled target is actionable");
    });
    FlowsB77Tests.run("rotation between committed stages invalidates recording",()->{
      AccessibilityNodeInfo r=FlowsB77Tests.page("video","跳过");FlowJournal j=new FlowJournal(AdType.POPUP);j.beginClick(FlowsB77Tests.snap(r,"host.example.Ad"),FlowsB77Tests.target(r));
      FlowPage b=FlowsB77Tests.snap(FlowsB77Tests.page("endcard","关闭"),"host.example.Ad");j.observe(b,10200);j.observe(b,10500);
      AccessibilityNodeInfo rotated=FlowsB77Tests.page("endcard","关闭");rotated.bounds=new Rect(0,0,2400,1080);j.observe(FlowsB77Tests.snap(rotated,"host.example.Ad"),10800);
      FlowsB77Tests.check(j.cancelled(),"rotation after committed step was accepted");
    });
    FlowsB77Tests.run("large clickable ad parent is never selected as close target",()->{
      AccessibilityNodeInfo r=FlowsB77Tests.page("video","跳过");r.clickable=true;r.children.get(1).clickable=false;
      try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(r)){
        FlowsB77Tests.check(FlowSafety.clickTarget(r.children.get(1),i)==r.children.get(1),"large ad parent selected");
      }
    });
    FlowsB77Tests.run("pure positional canvas and passwords remain rejected",()->{
      AccessibilityNodeInfo r=FlowsB77Tests.root("host.example",null);
      FlowsB77Tests.check(FlowsB77Tests.snap(r,"host.example.Ad")==null,"full canvas learned");
      r=FlowsB77Tests.page("secret","关闭");r.children.get(0).password=true;
      FlowsB77Tests.check(FlowsB77Tests.snap(r,"host.example.Ad")==null,"password page learned");
    });
    FlowsB77Tests.run("an ineffective taught click yields promptly to other engines",()->{
      FlowsB77Tests.Service service=new FlowsB77Tests.Service();service.root=FlowsB77Tests.page("video","跳过");
      FlowReplayEngine engine=new FlowReplayEngine(service,new android.os.Handler(android.os.Looper.getMainLooper()),()->"host.example",()->{});
      engine.store().add(FlowsB77Tests.flow());FlowsB77Tests.handle(engine,service,"host.example.Ad");
      android.os.Handler.advance(12800);FlowsB77Tests.handle(engine,service,"host.example.Ad");
      FlowsB77Tests.check(!engine.isActive()&&engine.completedCount()==0&&service.root.children.get(1).clicks==1,"ineffective step blocked normal pipeline too long");engine.close();
    });
    FlowsB77Tests.run("a stable unrelated activity cancels the learned workflow without clicking",()->{
      FlowsB77Tests.Service service=new FlowsB77Tests.Service();service.root=FlowsB77Tests.page("video","跳过");
      FlowReplayEngine engine=new FlowReplayEngine(service,new android.os.Handler(android.os.Looper.getMainLooper()),()->"host.example",()->{});
      engine.store().add(FlowsB77Tests.flow());FlowsB77Tests.handle(engine,service,"host.example.Ad");
      service.root=FlowsB77Tests.page("unrelated","关闭");android.os.Handler.advance(10300);FlowsB77Tests.handle(engine,service,"host.example.Settings");
      android.os.Handler.advance(10800);FlowsB77Tests.handle(engine,service,"host.example.Settings");
      FlowsB77Tests.check(!engine.isActive()&&service.root.children.get(1).clicks==0,"unrelated activity kept replay alive");engine.close();
    });
    FlowsB77Tests.run("a verified new ad stage can reuse the same close ID and label",()->{
      AccessibilityNodeInfo a=FlowsB77Tests.page("video","跳过"),b=FlowsB77Tests.page("endcard","跳过");
      FlowJournal j=new FlowJournal(AdType.POPUP);j.beginClick(FlowsB77Tests.snap(a,"host.example.Ad"),FlowsB77Tests.target(a));
      FlowPage second=FlowsB77Tests.snap(b,"host.example.Ad");j.observe(second,10300);j.observe(second,10600);
      FlowsB77Tests.check(j.stepCount()==1&&!j.pending(),"new stage with reused close label never confirmed");
      FlowsB77Tests.check(j.beginClick(second,FlowsB77Tests.target(b)),"second stage cannot be taught");
      FlowPage home=FlowsB77Tests.snap(FlowsB77Tests.page("home",null),"host.example.Main");j.observe(home,10900);j.observe(home,11200);
      FlowsB77Tests.check(j.finish("same-label","Test").steps.size()==2,"two-stage reused-label flow not preserved");
    });
    System.out.println("B7.7 flow edge cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
    if(FlowsB77Tests.fail>0)throw new AssertionError("edge regressions");
  }
}
