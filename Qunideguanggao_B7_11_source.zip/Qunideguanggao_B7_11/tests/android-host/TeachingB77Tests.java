import android.content.*;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.settings.PreferenceStore;

public class TeachingB77Tests {
  static class Fixture {
    FlowsB77Tests.Service s=new FlowsB77Tests.Service();
    Handler h=new Handler(Looper.getMainLooper());
    String pkg="host.example",activity="host.example.Ad";
    RegressionB76Tests.Windows windows=new RegressionB76Tests.Windows();
    FlowReplayEngine replay=new FlowReplayEngine(s,h,()->pkg,()->{});
    FlowTeachingController teacher=new FlowTeachingController(s,h,()->pkg,()->activity,replay,()->{});
    Fixture(){s.services.put(Context.WINDOW_SERVICE,windows);s.root=FlowsB77Tests.page("video","3s | 跳过");PreferenceStore.setOcrEnabled(s,false);}
    void start(){teacher.start(AdType.POPUP);Handler.advance(10000);observe();}
    void observe(){try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(s.root)){teacher.observe(pkg,activity,i);}}
    void pick(){teacher.selectAt(980,100);Handler.advance(SystemClock.now);}
    void click(){AccessibilityEvent e=new AccessibilityEvent();e.type=1;e.pkg=pkg;e.source=s.root.children.get(1);teacher.clicked(e);Handler.advance(SystemClock.now);}
    void move(String key,String label,String a,long time){s.root=FlowsB77Tests.page(key,label);activity=a;Handler.advance(time);observe();Handler.advance(time+250);observe();}
    void save(){teacher.finish();Handler.advance(SystemClock.now);Handler.advance(SystemClock.now+250);}
    void close(){teacher.stop();replay.close();}
  }
  public static void main(String[] args)throws Exception {
    FlowsB77Tests.pass=FlowsB77Tests.fail=0;
    FlowsB77Tests.run("explicit teaching captures two selected controls and saves only after final confirmation",()->{
      Fixture f=new Fixture();f.start();f.pick();f.move("endcard","关闭","host.example.Ad",10400);
      FlowsB77Tests.check(f.replay.store().all().isEmpty(),"saved before explicit finish");
      f.pick();f.move("home",null,"host.example.Main",11000);f.save();
      FlowsB77Tests.check(f.replay.store().all().size()==1&&f.replay.store().all().get(0).steps.size()==2&&!f.teacher.isActive(),"two-step lesson missing: "+f.teacher.status());
      FlowsB77Tests.check(f.s.gestures==0&&f.s.backActions==0,"selection injected user click");f.close();
    });
    FlowsB77Tests.run("event source is captured before the dismissed node becomes unavailable",()->{
      Fixture f=new Fixture();f.start();f.click();f.move("home",null,"host.example.Main",10400);f.save();
      FlowsB77Tests.check(f.replay.store().all().size()==1,"event lesson not captured: "+f.teacher.status());f.close();
    });
    FlowsB77Tests.run("explicit Back is recorded once only after an actual first dismissal",()->{
      Fixture f=new Fixture();f.start();f.teacher.recordBack();Handler.advance(10000);FlowsB77Tests.check(f.s.backActions==0,"first blind Back allowed");
      f.pick();f.move("endcard","关闭","host.example.Ad",10400);f.teacher.recordBack();Handler.advance(SystemClock.now);
      FlowsB77Tests.check(f.s.backActions==1,"explicit Back not sent once");f.move("home",null,"host.example.Main",11000);f.save();
      LearnedFlow flow=f.replay.store().all().get(0);FlowsB77Tests.check(flow.steps.size()==2&&flow.steps.get(1).back,"Back step missing");f.close();
    });
    FlowsB77Tests.run("cancel and timeout remove teaching UI without saving a partial workflow",()->{
      Fixture f=new Fixture();f.start();f.pick();f.teacher.stop();Handler.advance(10400);
      FlowsB77Tests.check(f.windows.panel==null&&f.replay.store().all().isEmpty(),"cancel left overlay or data");f.start();Handler.advance(200000);
      FlowsB77Tests.check(!f.teacher.isActive()&&f.windows.panel==null&&f.replay.store().all().isEmpty(),"teaching not bounded");f.close();
    });
    FlowsB77Tests.run("master disabled before save cannot persist the lesson",()->{
      Fixture f=new Fixture();f.start();f.pick();f.move("home",null,"host.example.Main",10400);PreferenceStore.setMasterEnabled(f.s,false);f.save();
      FlowsB77Tests.check(f.replay.store().all().isEmpty()&&!f.teacher.isActive(),"disabled lesson saved");f.close();
    });
    FlowsB77Tests.run("unchanged visible target cannot finish learning",()->{
      Fixture f=new Fixture();f.start();f.pick();Handler.advance(10600);f.observe();f.save();
      FlowsB77Tests.check(f.replay.store().all().isEmpty()&&f.teacher.isActive(),"unchanged target was called a full flow");f.close();
    });
    FlowsB77Tests.run("an unreadable later manual step cannot be saved as a complete shorter flow",()->{
      Fixture f=new Fixture();f.start();f.pick();f.move("endcard","关闭","host.example.Ad",10400);
      AccessibilityEvent missing=new AccessibilityEvent();missing.type=1;missing.pkg="host.example";missing.source=null;
      f.teacher.clicked(missing);Handler.advance(SystemClock.now);
      f.move("home",null,"host.example.Main",11000);f.save();
      FlowsB77Tests.check(f.replay.store().all().isEmpty(),"uncaptured second action silently omitted from saved flow");f.close();
    });
    FlowsB77Tests.run("cancel while the system is returning a page prevents a stale taught Back",()->{
      class InterruptedService extends FlowsB77Tests.Service {
        Runnable hook;
        @Override public AccessibilityNodeInfo getRootInActiveWindow(){if(hook!=null){Runnable r=hook;hook=null;r.run();}return root;}
      }
      InterruptedService service=new InterruptedService();service.services.put(Context.WINDOW_SERVICE,new RegressionB76Tests.Windows());
      Handler handler=new Handler(Looper.getMainLooper());FlowReplayEngine replay=new FlowReplayEngine(service,handler,()->"host.example",()->{});
      FlowTeachingController teacher=new FlowTeachingController(service,handler,()->"host.example",()->"host.example.Ad",replay,()->{});
      service.root=FlowsB77Tests.page("video","跳过");teacher.start(AdType.POPUP);Handler.advance(10000);
      teacher.selectAt(980,100);Handler.advance(10000);service.root=FlowsB77Tests.page("endcard","关闭");Handler.advance(10400);Handler.advance(10650);
      service.hook=teacher::stop;teacher.recordBack();Handler.advance(10700);
      FlowsB77Tests.check(service.backActions==0,"cancelled capture still executed Back");teacher.stop();replay.close();
    });
    System.out.println("B7.7 teaching cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
    if(FlowsB77Tests.fail>0)throw new AssertionError("teaching regressions");
  }
}
