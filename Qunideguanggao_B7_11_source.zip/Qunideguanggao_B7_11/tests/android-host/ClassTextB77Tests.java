import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import org.adguardian.app.engine.NodeTarget;
public class ClassTextB77Tests {
    static int pass,fail;
    static void test(String value,String expected) {
        AccessibilityNodeInfo n=new AccessibilityNodeInfo();n.id=null;n.name="android.widget.TextView";
        n.text=value;n.bounds=new Rect(900,70,1040,140);
        NodeTarget t=NodeTarget.captureSelected(n,new Rect(0,0,1080,2400));
        boolean ok=t!=null && t.isSafeLearningTarget() && t.forLearning().label.equals(expected);
        if(ok){pass++;System.out.println("PASS CLASS text "+value);}else{fail++;System.out.println("FAIL CLASS text "+value+" expected="+expected);}
    }
    public static void main(String[] args) {
        test("跳过","跳过");test("跳过 3秒","跳过");test("| 跳过","跳过");
        test("3s | 跳过","跳过");test("跳过 | 4s","跳过");test(" 3 秒 ｜ 跳过广告 ","跳过广告");
        if(fail>0)throw new AssertionError("CLASS countdown/separator regressions="+fail);
        System.out.println("CLASS close label cases passed="+pass);
    }
}
