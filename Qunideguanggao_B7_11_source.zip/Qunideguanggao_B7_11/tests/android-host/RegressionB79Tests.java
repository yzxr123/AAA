import android.os.*;
import android.view.accessibility.*;
import java.util.*;
import org.adguardian.app.classapp.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;

public class RegressionB79Tests {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static AccessibilityEvent click(String pkg,AccessibilityNodeInfo source,long time,String text){
  AccessibilityEvent e=new AccessibilityEvent();e.type=1;e.pkg=pkg;e.source=source;e.time=time;
  if(text!=null)e.text.add(text);return e;
 }
 static AccessibilityNodeInfo n(String id,String label,String cls,int x,int y,int w,int h,boolean c){return FlowsB77Tests.n(id,label,cls,x,y,w,h,c);}
 public static void main(String[] a)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("anchored node page is recordable when Android has not reported an Activity",()->{
   TeachingB77Tests.Fixture f=new TeachingB77Tests.Fixture();f.activity="";f.start();f.pick();f.move("home",null,"host.example.Main",10400);f.save();
   check(f.replay.store().all().size()==1,"real data was discarded solely because Activity is unknown: "+f.teacher.status());f.close();
  });
  FlowsB77Tests.run("late click delivery uses the pre-event snapshot rather than the already opened home page",()->{
   TeachingB77Tests.Fixture f=new TeachingB77Tests.Fixture();f.start();var close=f.s.root.children.get(1);
   SystemClock.now=10100;f.s.root=FlowsB77Tests.page("home",null);f.activity="host.example.Main";f.observe();
   f.teacher.clicked(click(f.pkg,close,10040,null));Handler.advance(10100);Handler.advance(10400);f.observe();Handler.advance(10800);f.observe();f.save();
   check(f.replay.store().all().size()==1,"old pre-click page was lost before event delivery: "+f.teacher.status());f.close();
  });
  FlowsB77Tests.run("explicit teaching can record a unique skip from event text when source is already null",()->{
   TeachingB77Tests.Fixture f=new TeachingB77Tests.Fixture();f.start();f.teacher.clicked(click(f.pkg,null,10000,"3s | 跳过"));Handler.advance(10000);
   f.move("home",null,"host.example.Main",10400);f.save();check(f.replay.store().all().size()==1,"null event source discarded its valid unique close text: "+f.teacher.status());f.close();
  });
  FlowsB77Tests.run("a clickable close container and its image are one target not two ambiguous buttons",()->{
   var root=FlowsB77Tests.page("video",null);
   var parent=n(null,null,"android.widget.FrameLayout",940,70,80,60,true);
   parent.add(n(null,null,"android.widget.ImageView",940,70,80,60,false));root.add(parent);
   var page=FlowsB77Tests.snap(root,"host.example.Ad");check(page!=null&&page.pick(980,100)!=null,"ancestor and image were incorrectly treated as independent choices");
  });
  FlowsB77Tests.run("CLASS native promotion popup is closed by its joint APK resource guard even without Activity metadata",()->{
   ClassAdapterB77Tests.Fixture f=new ClassAdapterB77Tests.Fixture();var root=ClassAdapterB77Tests.root();
   var close=n(ClassAdProfile.PACKAGE+":id/close",null,"android.widget.ImageView",920,100,70,70,true);root.add(close);
   root.add(n(ClassAdProfile.PACKAGE+":id/tv_confirm",null,"android.widget.TextView",200,450,500,100,true));
   var pay=n(ClassAdProfile.PACKAGE+":id/btn_pay_now",null,"android.widget.TextView",200,600,500,100,true);root.add(pay);f.s.root=root;
   check(f.handle("")&&close.clicks==1&&pay.clicks==0,"APK dialog_ad close rule not installed or blocked by unrelated Activity");f.engine.close();
  });
  FlowsB77Tests.run("CLASS splash layout IDs can identify its SDK host without a reported Activity",()->{
   ClassAdapterB77Tests.Fixture f=new ClassAdapterB77Tests.Fixture();var r=ClassAdapterB77Tests.root();
   r.add(n(ClassAdProfile.PACKAGE+":id/fl_ad_container",null,"android.widget.FrameLayout",0,0,1080,2000,false));
   r.add(n(ClassAdProfile.PACKAGE+":id/fl_place_holder_container",null,"android.widget.FrameLayout",0,0,1080,2000,false));
   var skip=ClassAdapterB77Tests.close(ClassAdProfile.PACKAGE+":id/tv_skip","跳过");r.add(skip);f.s.root=r;
   check(f.handle("")&&skip.clicks==1,"splash required an event name despite exact APK layout anchors");f.engine.close();
  });
  FlowsB77Tests.run("CLASS exact IDs fall back to an available hierarchy when native ID search returns empty",()->{
   ClassAdapterB77Tests.Fixture f=new ClassAdapterB77Tests.Fixture();var r=new AccessibilityNodeInfo(){@Override public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByViewId(String id){return List.of();}};
   r.pkg=ClassAdProfile.PACKAGE;r.bounds=new android.graphics.Rect(0,0,1080,2400);
   r.add(n(ClassAdProfile.PACKAGE+":id/fhad_rl_content",null,"android.widget.RelativeLayout",100,300,800,1200,false));
   var close=n(ClassAdProfile.PACKAGE+":id/fhad_iv_delete",null,"android.widget.ImageView",930,200,70,70,true);r.add(close);f.s.root=r;
   check(f.handle(ClassAdProfile.MAIN)&&close.clicks==1,"CLASS ID branch bypassed the existing hierarchy fallback");f.engine.close();
  });
  FlowsB77Tests.run("a sparse SDK ad page with an exposed small control is not rejected by an arbitrary four-node minimum",()->{
   var r=FlowsB77Tests.root(ClassAdProfile.PACKAGE,null);
   r.add(n(null,null,"android.webkit.WebView",0,0,1080,2400,false));r.add(n(null,null,"android.widget.ImageView",940,70,70,60,true));
   try(var idx=AccessibilityNodeIndex.build(r)){check(FlowPage.capture(ClassAdProfile.PACKAGE,ClassAdProfile.VIDEO,1013,idx)!=null,"valid three-node SDK window was labelled no data");}
  });
  FlowsB77Tests.run("a second manual close arriving before the old confirmation timer is not silently dropped",()->{
   TeachingB77Tests.Fixture f=new TeachingB77Tests.Fixture();f.start();f.click();
   SystemClock.now=10200;f.s.root=FlowsB77Tests.page("endcard","关闭");f.observe();f.teacher.clicked(click(f.pkg,f.s.root.children.get(1),10220,null));Handler.advance(10220);
   f.move("home",null,"host.example.Main",10700);f.save();
   check(f.replay.store().all().size()==1&&f.replay.store().all().get(0).steps.size()==2,"quick second close vanished while previous step pending: "+f.teacher.status());f.close();
  });
  FlowsB77Tests.run("missing advertised children mean incomplete data not proof that a button disappeared",()->{
   var r=FlowsB77Tests.page("home",null);r.children.add(null);
   try(var idx=AccessibilityNodeIndex.build(r)){FlowPage p=FlowPage.capture("host.example","host.example.Main",1,idx);check(p==null,"null Binder child was silently accepted as a complete terminal page");}
  });
  System.out.println("B7.9 first regressions passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("B7.9 recording and CLASS regressions");
 }
}
