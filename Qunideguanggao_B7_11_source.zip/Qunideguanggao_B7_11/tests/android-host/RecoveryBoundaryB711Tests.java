import android.content.*;import android.os.*;import org.adguardian.app.runtime.*;
public final class RecoveryBoundaryB711Tests {
 public static void main(String[]args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("unknown secure setting plus status observer never creates a recovery notification loop",()->{
   var c=RecoveryB711Tests.setup();RecoveryB711Tests.consent(c,true);
   c.getContentResolver().settings.remove(RecoveryB711Tests.KEY);c.getContentResolver().settings.remove(android.provider.Settings.Secure.ACCESSIBILITY_ENABLED);
   Object r=RecoveryB711Tests.make(c);
   AccessibilityState.Watch w=new AccessibilityState.Watch(c,()->{try{r.getClass().getMethod("request",boolean.class).invoke(r,false);}catch(Exception e){throw new RuntimeException(e);}});
   try{RecoveryB711Tests.request(r,false);Handler.advance(13000);FlowsB77Tests.check(!AccessibilityState.read(c).connected,"unknown became running");}
   finally{w.close();RecoveryB711Tests.close(r);}
  });
  FlowsB77Tests.run("automatic repair never enables an explicitly disabled global accessibility switch",()->{
   var c=RecoveryB711Tests.setup();RecoveryB711Tests.consent(c,true);c.getContentResolver().settings.put(android.provider.Settings.Secure.ACCESSIBILITY_ENABLED,"0");
   String original=c.getContentResolver().settings.get(RecoveryB711Tests.KEY);Object r=RecoveryB711Tests.make(c);try{RecoveryB711Tests.request(r,false);Handler.advance(14000);
   FlowsB77Tests.check("0".equals(c.getContentResolver().settings.get(android.provider.Settings.Secure.ACCESSIBILITY_ENABLED))&&original.equals(c.getContentResolver().settings.get(RecoveryB711Tests.KEY)),"automatic repair overwrote the user's global off choice");}finally{RecoveryB711Tests.close(r);}
  });
  FlowsB77Tests.run("rollback restores own temporary component without undoing a new global off choice",()->{
   var c=RecoveryB711Tests.setup();RecoveryB711Tests.consent(c,true);Object r=RecoveryB711Tests.make(c);RecoveryB711Tests.request(r,true);
   c.getContentResolver().settings.put(android.provider.Settings.Secure.ACCESSIBILITY_ENABLED,"0");RecoveryB711Tests.close(r);
   FlowsB77Tests.check(RecoveryB711Tests.self(c)&&"0".equals(c.getContentResolver().settings.get(android.provider.Settings.Secure.ACCESSIBILITY_ENABLED)),"rollback undid global off");
  });
  FlowsB77Tests.run("explicit confirmed repair can enable the global switch needed by the requested service",()->{
   var c=RecoveryB711Tests.setup();RecoveryB711Tests.consent(c,true);c.getContentResolver().settings.put(android.provider.Settings.Secure.ACCESSIBILITY_ENABLED,"0");
   Object r=RecoveryB711Tests.make(c);try{RecoveryB711Tests.request(r,true);Handler.advance(14000);
   FlowsB77Tests.check(RecoveryB711Tests.self(c)&&"1".equals(c.getContentResolver().settings.get(android.provider.Settings.Secure.ACCESSIBILITY_ENABLED)),"explicit repair did not perform requested restoration");}finally{RecoveryB711Tests.close(r);}
  });
  System.out.println("B7.11 recovery boundary cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);if(FlowsB77Tests.fail>0)throw new AssertionError("recovery boundary");
 }
}
