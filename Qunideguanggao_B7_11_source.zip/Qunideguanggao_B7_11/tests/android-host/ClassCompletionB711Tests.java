import android.content.*;import android.os.*;import android.view.accessibility.*;
import org.adguardian.app.flow.*;import org.adguardian.app.engine.*;import org.adguardian.app.recording.*;
public final class ClassCompletionB711Tests {
 static final String P="cn.luyiyuntech.stt",A="com.common.tang.activity.SplashActivity";
 static class F {
  FlowsB77Tests.Service service=new FlowsB77Tests.Service();Handler handler=new Handler(Looper.getMainLooper());String activity=A;
  FlowReplayEngine replay=new FlowReplayEngine(service,handler,()->P,()->{});
  FlowTeachingController teacher=new FlowTeachingController(service,handler,()->P,()->activity,replay,()->{});
  F(){service.pm.packageVersion=1013;service.services.put(Context.WINDOW_SERVICE,new RegressionB76Tests.Windows());service.root=FlowsB77Tests.root(P,P+":id/fl_ad_container");
   service.root.add(FlowsB77Tests.n(P+":id/fl_place_holder_container",null,"android.view.View",0,200,1000,1600,false));
   service.root.add(FlowsB77Tests.n(P+":id/tv_skip","3s | 跳过","android.widget.TextView",940,70,100,60,true));}
  void start(){teacher.start(AdType.STARTUP);Handler.advance(10000);try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(service.root)){teacher.observe(P,activity,i);}teacher.selectAt(980,100);Handler.advance(10000);}
  void seeHome(){service.root=FinalizationB711Tests.home();Handler.advance(10400);try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(service.root)){teacher.observe(P,activity,i);}Handler.advance(10700);try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(service.root)){teacher.observe(P,activity,i);}Handler.advance(10900);Handler.advance(11200);}
  void close(){teacher.stop();replay.close();}
 }
 public static void main(String[]args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("CLASS one confirmed splash action promotes automatically only on verified actual home",()->{
   F f=new F();f.start();f.seeHome();
   FlowsB77Tests.check(f.replay.store().all().size()==1&&!f.teacher.isActive(),"actual home reached but captured step remains permanently draft");
   FlowsB77Tests.check(new RecordingDraftStore(f.service).all().get(0).state==RecordingDraft.ENABLED,"archive was not marked enabled");f.close();
  });
  FlowsB77Tests.run("Activity name alone is not an automatic CLASS completion certificate",()->{
   F f=new F();f.start();f.activity="com.common.tang.activity.MainActivity";f.service.root=FlowsB77Tests.root(P,P+":id/unknown");
   f.service.root.add(FlowsB77Tests.n(P+":id/random",null,"android.view.View",0,400,900,900,false));Handler.advance(10400);Handler.advance(10700);Handler.advance(11200);
   FlowsB77Tests.check(f.replay.store().all().isEmpty(),"Activity-only home saved without layout evidence");f.close();
  });
  FlowsB77Tests.run("CLASS stale Splash cannot apply ad closing to the verified ordinary home",()->{
   var service=new FlowsB77Tests.Service();service.root=FinalizationB711Tests.home();
   service.root.add(FlowsB77Tests.n(P+":id/normal_close","关闭","android.widget.TextView",900,100,80,60,true));
   try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(service.root)){
    var rule=org.adguardian.app.classapp.ClassAdRules.load(service).match(A,i);
    FlowsB77Tests.check(rule==null,"stale Splash still turns normal home close into ad action");
   }
  });
  FlowsB77Tests.run("CLASS visible native promotion on home is retained when Splash metadata is stale",()->{
   var service=new FlowsB77Tests.Service();service.root=FinalizationB711Tests.home();
   for(String id:new String[]{"close","tv_confirm","btn_pay_now"})service.root.add(FlowsB77Tests.n(P+":id/"+id,null,"android.widget.TextView",900,100,80,60,true));
   try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(service.root)){
    var rule=org.adguardian.app.classapp.ClassAdRules.load(service).match(A,i);
    FlowsB77Tests.check(rule!=null&&rule.key.equals("class_native_promotion"),"actual promotion was hidden by home certificate");
   }
  });
  FlowsB77Tests.run("CLASS actual splash container remains an ad even with background home IDs",()->{
   var service=new FlowsB77Tests.Service();service.root=FinalizationB711Tests.home();
   for(String id:new String[]{"fl_ad_container","fl_place_holder_container"})service.root.add(FlowsB77Tests.n(P+":id/"+id,null,"android.view.View",0,200,1000,1500,false));
   try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(service.root)){
    var rule=org.adguardian.app.classapp.ClassAdRules.load(service).match(A,i);
    FlowsB77Tests.check(rule!=null&&rule.key.equals("class_splash"),"actual splash container was mistaken for finished home");
   }
  });
  FlowsB77Tests.run("reported anonymous View at ten percent seventy-five percent keeps its guarded target when finalized",()->{
   F f=new F();f.service.root.children.remove(f.service.root.children.size()-1);
   f.service.root.add(FlowsB77Tests.n(null,null,"android.view.View",76,1770,64,60,true));
   f.teacher.start(AdType.STARTUP);Handler.advance(10000);
   try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(f.service.root)){f.teacher.observe(P,A,i);}
   f.teacher.selectAt(108,1800);Handler.advance(10000);
   var draft=new RecordingDraftStore(f.service).all().get(0);
   FlowsB77Tests.check(draft.steps.size()==1&&draft.steps.get(0).target.id.isEmpty(),"anonymous target was not captured");
   f.seeHome();var result=f.replay.store().all();
   FlowsB77Tests.check(result.size()==1,"reported-shaped record stayed as an inactive draft");
   var target=result.get(0).steps.get(0).target;
   FlowsB77Tests.check(target.name.equals("android.view.View")&&Math.abs(target.x-.1f)<.001f&&Math.abs(target.y-.75f)<.001f,"stored target silently replaced");
   f.close();
  });
  System.out.println("B7.11 CLASS completion cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);if(FlowsB77Tests.fail>0)throw new AssertionError("CLASS completion");
 }
}
