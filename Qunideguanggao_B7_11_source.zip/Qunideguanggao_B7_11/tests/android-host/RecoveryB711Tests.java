import android.content.*;
import android.os.*;
import android.provider.Settings;
import java.lang.reflect.*;
import org.adguardian.app.runtime.AccessibilityState;
import org.adguardian.app.settings.PreferenceStore;

public final class RecoveryB711Tests {
 static final String KEY=Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES;
 static final String OWN="org.adguardian.app/org.adguardian.app.service.AdAccessibilityService";
 static final String OTHER="example.reader/.ReadService";
 static class C extends Context {
  boolean grant=true;
  @Override public int checkSelfPermission(String p){return p.equals("android.permission.WRITE_SECURE_SETTINGS")&&!grant?-1:0;}
 }
 static Class<?> type()throws Exception{try{return Class.forName("org.adguardian.app.runtime.AccessibilityRecovery");}catch(ClassNotFoundException e){throw new AssertionError("missing real recovery implementation");}}
 static Object make(C c)throws Exception{return type().getConstructor(Context.class,Handler.class).newInstance(c,new Handler(Looper.getMainLooper()));}
 static void consent(C c,boolean b)throws Exception{type().getMethod("setEnabled",Context.class,boolean.class).invoke(null,c,b);}
 static void request(Object r,boolean explicit)throws Exception{r.getClass().getMethod("request",boolean.class).invoke(r,explicit);Handler.advance(SystemClock.now);}
 static void close(Object r)throws Exception{((AutoCloseable)r).close();Handler.advance(SystemClock.now);}
 static C setup(){C c=new C();c.getContentResolver().settings.put(KEY,OTHER+":"+OWN);c.getContentResolver().settings.put(Settings.Secure.ACCESSIBILITY_ENABLED,"1");return c;}
 static boolean self(C c){return AccessibilityState.containsComponent(c.getContentResolver().settings.get(KEY),c.getPackageName(),AccessibilityState.SERVICE_NAME);}
 public static void main(String[]args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("ordinary mode never writes privileged system settings",()->{
   C c=setup();Object r=make(c);request(r,false);FlowsB77Tests.check(self(c),"ordinary mode changed enabled list");close(r);
  });
  FlowsB77Tests.run("opt-in without granted WSS never removes enabled service",()->{
   C c=setup();c.grant=false;consent(c,true);Object r=make(c);request(r,true);FlowsB77Tests.check(self(c),"unauthorized mutation");close(r);
  });
  FlowsB77Tests.run("granted disconnected service uses remove wait readd with fresh other components",()->{
   C c=setup();consent(c,true);Object r=make(c);request(r,true);
   FlowsB77Tests.check(!self(c)&&c.getContentResolver().settings.get(KEY).contains(OTHER),"did not isolate own removal");
   c.getContentResolver().settings.put(KEY,OTHER+":another.reader/.Service");
   Handler.advance(10999);FlowsB77Tests.check(!self(c),"no reconnect delay");
   Handler.advance(11000);FlowsB77Tests.check(self(c)&&c.getContentResolver().settings.get(KEY).contains("another.reader"),"clobbered concurrent settings");
   Handler.advance(13000);FlowsB77Tests.check(!AccessibilityState.read(c).connected,"system connection was forged");close(r);
  });
  FlowsB77Tests.run("automatic recovery does not undo a user-disabled accessibility component",()->{
   C c=setup();consent(c,true);c.getContentResolver().settings.put(KEY,OTHER);Object r=make(c);request(r,false);
   Handler.advance(14000);FlowsB77Tests.check(!self(c),"auto re-enabled withdrawn service");close(r);
  });
  FlowsB77Tests.run("closing recovery during temporary removal restores original own setting",()->{
   C c=setup();consent(c,true);Object r=make(c);request(r,true);FlowsB77Tests.check(!self(c),"precondition");close(r);
   FlowsB77Tests.check(self(c)&&c.getContentResolver().settings.get(KEY).contains(OTHER),"left own authorization removed");
  });
  FlowsB77Tests.run("user pauses master during removal rolls back config without resuming ads",()->{
   C c=setup();consent(c,true);Object r=make(c);request(r,true);PreferenceStore.setMasterEnabled(c,false);Handler.advance(11000);
   FlowsB77Tests.check(self(c)&&!PreferenceStore.isMasterEnabled(c),"pause either lost authorization or turned ads on");close(r);
  });
  FlowsB77Tests.run("already connected healthy service is never bounced",()->{
   C c=setup();consent(c,true);Object own=new Object();AccessibilityState.connected(own);AccessibilityState.initialized(own,true);
   try{Object r=make(c);request(r,true);FlowsB77Tests.check(self(c),"disrupted healthy service");close(r);}finally{AccessibilityState.disconnected(own);}
  });
  FlowsB77Tests.run("foreground protection remains eligible during our own temporary removal",()->{
   C c=setup();consent(c,true);Object r=make(c);request(r,true);
   FlowsB77Tests.check(org.adguardian.app.service.ProtectionService.shouldRun(c),"watcher killed protection halfway through recovery");close(r);
  });
  System.out.println("B7.11 recovery cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("recovery regressions");
 }
}
