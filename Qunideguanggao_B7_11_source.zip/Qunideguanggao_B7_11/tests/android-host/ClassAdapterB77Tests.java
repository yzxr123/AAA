import android.accessibilityservice.*;
import android.os.*;
import android.graphics.*;
import android.view.accessibility.*;
import org.adguardian.app.classapp.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.settings.PreferenceStore;

public class ClassAdapterB77Tests {
    static final String PKG="cn.luyiyuntech.stt",SPLASH="com.common.tang.activity.SplashActivity",HOME="com.common.tang.activity.MainActivity",AD="com.bytedance.sdk.openadsdk.core.component.reward.activity.TTFullScreenVideoActivity";
    static int pass,fail;
    interface Case {void run()throws Exception;}
    static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
    static void run(String n,Case c){Handler.tasks.clear();SystemClock.now=10000;try{c.run();pass++;System.out.println("PASS "+n);}catch(Throwable e){fail++;System.out.println("FAIL "+n+" "+e);}}
    static class Service extends AccessibilityService {public void onAccessibilityEvent(AccessibilityEvent e){}public void onInterrupt(){} }
    static AccessibilityNodeInfo root(){AccessibilityNodeInfo r=FlowsB77Tests.root(PKG,PKG+":id/root");return r;}
    static AccessibilityNodeInfo close(String id,String label){return FlowsB77Tests.n(id,label,"android.widget.TextView",900,70,140,65,true);}
    static class Fixture {Service s=new Service();Handler h=new Handler(Looper.getMainLooper());ActionVerifier verifier=new ActionVerifier(s,h,()->PKG,()->{});ClassAdEngine engine=new ClassAdEngine(s,h,()->PKG,()->{},verifier);Fixture(){s.getPackageManager().packageVersion=1013;s.root=root();}boolean handle(String a){try(AccessibilityNodeIndex i=AccessibilityNodeIndex.build(s.root)){return engine.handle(PKG,a,i);}}}
    public static void main(String[] args) throws Exception {
        run("CLASS visible native splash skip is clicked",()->{Fixture f=new Fixture();AccessibilityNodeInfo n=close(PKG+":id/tv_skip","跳过");f.s.root.add(n);check(f.handle(SPLASH)&&n.clicks==1,"native skip not executed");f.engine.close();});
        run("CLASS hidden native skip yields to SDK countdown node",()->{Fixture f=new Fixture();AccessibilityNodeInfo old=close(PKG+":id/tv_skip","跳过");old.visible=false;AccessibilityNodeInfo sdk=close(null,"3s | 跳过");f.s.root.add(old).add(sdk);check(f.handle(SPLASH)&&sdk.clicks==1&&old.clicks==0,"hidden ID used or SDK missed");f.engine.close();});
        run("CLASS interstitial long after startup creates its own bounded session",()->{Fixture f=new Fixture();check(!f.handle(HOME),"home acted");Handler.advance(60000);AccessibilityNodeInfo n=close(null,"| 跳过");f.s.root.add(n);check(f.handle(AD)&&n.clicks==1,"late interstitial not detected");f.engine.close();});
        run("CLASS stage2 in the same Activity is rechecked rather than finished on stage1",()->{Fixture f=new Fixture();AccessibilityNodeInfo a=close(null,"跳过");f.s.root.add(a);check(f.handle(AD),"no first action");f.s.root.children.clear();Handler.advance(10200);Handler.advance(10500);AccessibilityNodeInfo b=close(null,"关闭");b.bounds=new Rect(20,70,90,140);f.s.root.add(b);Handler.advance(10800);check(f.handle(AD)&&b.clicks==1,"second stage not queried");check(f.s.backActions==0,"blind back used");f.engine.close();});
        run("CLASS SDK close text uses only bounded clickable parent",()->{Fixture f=new Fixture();AccessibilityNodeInfo p=FlowsB77Tests.n(null,null,"android.widget.LinearLayout",890,60,160,90,true);AccessibilityNodeInfo t=close(null,"关闭");t.clickable=false;p.add(t);f.s.root.add(p);check(f.handle(AD)&&p.clicks==1&&f.s.root.clicks==0,"small parent not used safely");f.engine.close();});
        run("CLASS normal timetable and wrong versions do not activate dedicated close",()->{Fixture f=new Fixture();AccessibilityNodeInfo n=close(PKG+":id/close","关闭");f.s.root.add(n);check(!f.handle(HOME)&&n.clicks==0,"normal close acted");f.s.getPackageManager().packageVersion=1014;f.engine.onPackageChanged();check(!f.handle(AD)&&n.clicks==0,"unknown version targeted");f.engine.close();});
        run("CLASS reward page no-ID template and duplicate close nodes are not guessed",()->{Fixture f=new Fixture();f.s.root.add(close(null,"关闭"));check(!f.handle(AD.replace("FullScreen","Reward")),"reward page misclassified");f.s.root.add(close(null,"关闭"));check(!f.handle(AD)&&f.s.backActions==0,"ambiguous close guessed");f.engine.close();});
        run("CLASS declared popup requires content and close pair in the same window",()->{Fixture f=new Fixture();AccessibilityNodeInfo n=close(PKG+":id/fhad_iv_delete",null);n.name="android.widget.ImageView";f.s.root.add(n);check(!f.handle(HOME),"close alone matched");AccessibilityNodeInfo c=FlowsB77Tests.n(PKG+":id/fhad_rl_content",null,"android.widget.RelativeLayout",0,150,1080,2100,false);f.s.root.add(c);check(f.handle(HOME)&&n.clicks==1,"paired popup missed");f.engine.close();});
        run("CLASS absent close target does not trigger Back and active polling expires",()->{Fixture f=new Fixture();check(!f.handle(AD),"empty ad acted");check(f.engine.nextWakeUp()>=0,"no finite retry");Handler.advance(90000);check(!f.handle(AD)&&f.engine.nextWakeUp()<0&&f.s.backActions==0,"permanent polling/back");f.engine.close();});
        run("CLASS startup category off does not click or poll",()->{Fixture f=new Fixture();PreferenceStore.setTypeEnabled(f.s,AdType.STARTUP,false);AccessibilityNodeInfo n=close(PKG+":id/tv_skip","跳过");f.s.root.add(n);check(!f.handle(SPLASH)&&f.engine.nextWakeUp()<0&&n.clicks==0,"category ignored");f.engine.close();});
        run("CLASS foreground changes during lookup cannot inject into the next app",()->{
            Service service=new Service();service.getPackageManager().packageVersion=1013;
            String[] foreground={PKG};Handler h=new Handler(Looper.getMainLooper());
            ActionVerifier verifier=new ActionVerifier(service,h,()->foreground[0],()->{});
            ClassAdEngine engine=new ClassAdEngine(service,h,()->foreground[0],()->{},verifier);
            AccessibilityNodeInfo n=new AccessibilityNodeInfo(){@Override public CharSequence getText(){foreground[0]="other.example";return "跳过";}};
            n.name="android.widget.TextView";n.bounds=new Rect(900,70,1040,135);n.clickable=true;
            service.root=root().add(n);
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(service.root)){engine.handle(PKG,AD,index);}
            check(n.clicks==0&&service.gestures==0,"stale CLASS lookup still clicked");engine.close();
        });
        System.out.println("B7.7 CLASS cases passed="+pass+" failed="+fail);if(fail>0)throw new AssertionError("CLASS failures "+fail);
    }
}
