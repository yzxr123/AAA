import android.content.*;import android.os.*;import android.app.AlertDialog;import android.view.accessibility.*;
import java.util.*;import java.lang.reflect.*;
import org.adguardian.app.MainActivity;import org.adguardian.app.flow.*;import org.adguardian.app.recording.*;
import org.adguardian.app.runtime.*;
public final class ReviewB711Tests {
 static void check(boolean b,String s){FlowsB77Tests.check(b,s);}
 public static void main(String[] args)throws Exception{
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("retry finalization on confirmed draft creates one executable rule and keeps the same archive",()->{
   var f=new TeachingB77Tests.Fixture();RecordingDraft d=FinalizationB711Tests.captured(f);
   f.teacher.resumeDraft(d.key);check(f.teacher.isActive(),"restore loading did not reserve teaching mode");Handler.advance(SystemClock.now);f.save();
   check(f.replay.store().all().size()==1,"no executable result");String key=f.replay.store().all().get(0).key;
   // Simulate process stopped after committed flow but before archive annotation.
   new RecordingDraftStore(f.s).put(d);f.teacher.resumeDraft(d.key);Handler.advance(SystemClock.now);f.save();
   check(f.replay.store().all().size()==1&&f.replay.store().all().get(0).key.equals(key),"retry duplicated automation");
   check(new RecordingDraftStore(f.s).all().size()==1,"continuation spawned another archive");f.close();
  });
  FlowsB77Tests.run("explicit executed first step does not swallow a fast different manual second step",()->{
   var f=new TeachingB77Tests.Fixture();f.start();f.teacher.selectAndExecuteAt(980,100);Handler.advance(10000);
   f.move("endcard","关闭","host.example.Ad",10180);f.click();
   f.move("home",null,"host.example.Main",10600);f.save();
   check(f.replay.store().all().size()==1&&f.replay.store().all().get(0).steps.size()==2,"fast second manual step was suppressed");f.close();
  });
  FlowsB77Tests.run("resume on wrong app leaves captured draft and never enables it",()->{
   var f=new TeachingB77Tests.Fixture();RecordingDraft d=FinalizationB711Tests.captured(f);
   f.pkg="another.app";f.activity="another.app.Main";f.s.root=FlowsB77Tests.root(f.pkg,"another.app:id/home");
   f.teacher.resumeDraft(d.key);Handler.advance(SystemClock.now);f.save();
   check(f.replay.store().all().isEmpty()&&new RecordingDraftStore(f.s).all().get(0).state==RecordingDraft.CAPTURED,"wrong app enabled");f.close();
  });
  FlowsB77Tests.run("cancel pending draft load stops all later UI activation",()->{
   var f=new TeachingB77Tests.Fixture();RecordingDraft d=FinalizationB711Tests.captured(f);
   f.teacher.resumeDraft(d.key);f.teacher.stop();Handler.advance(SystemClock.now+500);
   check(!f.teacher.isActive()&&f.windows.panel==null,"stale restore created overlay");f.close();
  });
  FlowsB77Tests.run("confirmed draft management has a real continuation action",()->{
   var f=new TeachingB77Tests.Fixture();RecordingDraft d=FinalizationB711Tests.captured(f);
   MainActivity a=new MainActivity();RecordingB710Tests.call(a,"showRecordingDrafts");RecordingB710Tests.awaitFiles();
   AlertDialog.lastListener.onClick(null,0);
   check(Arrays.asList(AlertDialog.lastItems).contains("继续校验并启用"),"management still only view and delete");f.close();
  });
  FlowsB77Tests.run("feedback recovery requests cannot shorten GKD reconnect waiting interval",()->{
   var c=RecoveryB711Tests.setup();RecoveryB711Tests.consent(c,true);Object r=RecoveryB711Tests.make(c);
   RecoveryB711Tests.request(r,true);RecoveryB711Tests.request(r,false);Handler.advance(10999);
   check(!RecoveryB711Tests.self(c),"settings observer prematurely rolled back active transaction");Handler.advance(11000);
   check(RecoveryB711Tests.self(c),"own component not restored");RecoveryB711Tests.close(r);
  });
  FlowsB77Tests.run("low level pause before select execute cannot dispatch to a new app",()->{
   var f=new TeachingB77Tests.Fixture();f.start();int before=f.s.root.children.get(1).clicks;
   f.teacher.selectAndExecuteAt(980,100);f.pkg="other.app";Handler.advance(10000);
   check(f.s.root.children.get(1).clicks==before&&f.s.gestures==0,"input escaped app scope");f.close();
  });
  FlowsB77Tests.run("CLASS exact SDK page cannot be overwritten by home-like background anchors",()->{
   FlowPage p=FinalizationB711Tests.snapshot(FinalizationB711Tests.home(),"com.bytedance.sdk.openadsdk.core.component.reward.activity.TTFullScreenVideoActivity");
   check(p.knownClassAd,"real SDK Activity mistaken for endpoint");
  });
  FlowsB77Tests.run("closing an idle second recovery instance cannot interrupt the active transaction",()->{
   var c=RecoveryB711Tests.setup();RecoveryB711Tests.consent(c,true);Object first=RecoveryB711Tests.make(c),second=RecoveryB711Tests.make(c);
   RecoveryB711Tests.request(first,true);RecoveryB711Tests.close(second);
   check(!RecoveryB711Tests.self(c),"unrelated close undid another active recovery");Handler.advance(11000);check(RecoveryB711Tests.self(c),"first recovery did not restore");RecoveryB711Tests.close(first);
  });
  System.out.println("B7.11 review cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);if(FlowsB77Tests.fail>0)throw new AssertionError("review regressions");
 }
}
