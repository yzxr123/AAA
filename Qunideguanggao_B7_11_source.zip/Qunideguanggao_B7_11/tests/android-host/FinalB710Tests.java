import android.app.*;
import android.content.*;
import android.os.*;
import android.view.accessibility.*;
import android.graphics.Rect;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import org.adguardian.app.MainActivity;
import org.adguardian.app.classapp.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.learning.*;
import org.adguardian.app.recording.*;
import org.adguardian.app.runtime.*;
import org.adguardian.app.service.*;

public class FinalB710Tests {
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static AccessibilityNodeInfo classPage(String key,String text,boolean home){
  AccessibilityNodeInfo r=FlowsB77Tests.page(key,text);
  assign(r);
  if(home){r.bounds=new Rect(0,96,1080,2180);r.id=ClassAdProfile.PACKAGE+":id/navigation_bar";
   r.add(FlowsB77Tests.n(ClassAdProfile.PACKAGE+":id/tv_today_date",null,"android.widget.TextView",40,200,300,50,false));
   r.add(FlowsB77Tests.n(ClassAdProfile.PACKAGE+":id/tv_weeks",null,"android.widget.TextView",360,200,300,50,false));
   r.add(FlowsB77Tests.n(ClassAdProfile.PACKAGE+":id/timetableView",null,"android.view.View",0,300,1080,1650,false));assign(r);}
  return r;
 }
 static void assign(AccessibilityNodeInfo n){n.pkg=ClassAdProfile.PACKAGE;if(n.id!=null)n.id=n.id.replace("host.example",ClassAdProfile.PACKAGE);for(var child:n.children)assign(child);}
 public static void main(String[]args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("CLASS two-stage lesson commits across fullscreen to actual home-anchor geometry",()->{
   RegressionB710Tests.clean();var f=new TeachingB77Tests.Fixture();f.pkg=ClassAdProfile.PACKAGE;f.s.getPackageManager().packageVersion=1013;f.activity=ClassAdProfile.VIDEO;f.s.root=classPage("video","3s | 跳过",false);f.start();f.pick();
   f.s.root=classPage("endcard","关闭",false);Handler.advance(10400);f.observe();Handler.advance(10650);f.observe();f.pick();
   f.activity=ClassAdProfile.MAIN;f.s.root=classPage("home",null,true);Handler.advance(11000);f.observe();Handler.advance(11300);f.observe();f.save();
   check(f.replay.store().all().size()==1 && f.replay.store().all().get(0).steps.size()==2,"CLASS two-stage record rejected: "+f.teacher.status());
   var d=new RecordingDraftStore(f.s).all().get(0);check(d.state==RecordingDraft.ENABLED&&d.confirmed==2,"archive did not track verified CLASS flow");f.close();
  });
  FlowsB77Tests.run("window inset change alone cannot confirm a still-visible captured button",()->{
   var root=FlowsB77Tests.page("video","跳过");var a=FlowsB77Tests.snap(root,"host.example.Ad");var j=new FlowJournal(AdType.POPUP);j.beginClick(a,FlowsB77Tests.target(root));
   root.bounds=new Rect(0,96,1080,2180);var b=FlowsB77Tests.snap(root,"host.example.Ad");j.observe(b,10400);j.observe(b,10700);
   check(j.stepCount()==0 && j.pending(),"insets alone counted as closing an unchanged ad");
  });
  FlowsB77Tests.run("returning to UI never requests authorization solely because connection is absent",()->{
   var a=new MainActivity();RegressionB710Tests.authorize(a);var method=MainActivity.class.getDeclaredMethod("onCreate",Bundle.class);method.setAccessible(true);method.invoke(a,new Bundle());
   var resume=MainActivity.class.getDeclaredMethod("onResume");resume.setAccessible(true);resume.invoke(a);Handler.advance(10500);
   check(a.activityStarts==0,"onResume opened permission settings without user action");
   check(AccessibilityState.read(a).authorized,"preserved authorization became denial");
   var pause=MainActivity.class.getDeclaredMethod("onPause");pause.setAccessible(true);pause.invoke(a);
  });
  FlowsB77Tests.run("a dropped AtomicFile commit is detected instead of reporting successful archive persistence",()->{
   RegressionB710Tests.clean();var store=new RecordingDraftStore(new Context());store.put(RecordingB710Tests.draft("old"));byte[] old=Files.readAllBytes(RegressionB710Tests.drafts().toPath());
   android.util.AtomicFile.dropNextCommit=true;
   try {store.put(RecordingB710Tests.draft("new"));throw new AssertionError("unchecked void finishWrite called a save");}catch(IOException expected){}
   finally{android.util.AtomicFile.dropNextCommit=false;}
   check(Arrays.equals(old,Files.readAllBytes(RegressionB710Tests.drafts().toPath())),"old draft not preserved");
  });
  FlowsB77Tests.run("a dropped active flow commit never changes the in-memory enabled list",()->{
   var store=new FlowStore(new Context());store.add(FlowsB77Tests.flow());var f=FlowsB77Tests.flow();android.util.AtomicFile.dropNextCommit=true;
   try{store.add(new LearnedFlow("second",f.packageName,f.appName,f.versionCode,f.type,true,f.steps,f.terminal));throw new AssertionError("unchecked active flow write");}catch(IOException expected){}
   finally{android.util.AtomicFile.dropNextCommit=false;}
   check(store.all().size()==1 && new FlowStore(new Context()).all().size()==1,"in-memory and on-disk flows disagree");
  });
  FlowsB77Tests.run("a dropped single-button commit never reports the second rule saved",()->{
   var file=RecordingB710Tests.file("learned-ad-rules.bin");file.delete();var store=new LearnedRuleStore(new Context());store.add(RecordingB710Tests.rule("old"));android.util.AtomicFile.dropNextCommit=true;
   try{store.add(RecordingB710Tests.rule("new"));throw new AssertionError("unchecked single-rule write");}catch(IOException expected){}
   finally{android.util.AtomicFile.dropNextCommit=false;}
   check(store.all().size()==1 && new LearnedRuleStore(new Context()).all().size()==1,"single-rule write was falsely accepted");file.delete();
  });
  FlowsB77Tests.run("clearing a draft does not clear verified workflows or single rules",()->{
   RegressionB710Tests.clean();new RecordingDraftStore(new Context()).put(RecordingB710Tests.draft("draft"));new FlowStore(new Context()).add(FlowsB77Tests.flow());
   new RecordingDraftStore(new Context()).remove("draft");check(new FlowStore(new Context()).all().size()==1,"draft deletion also deleted enabled flow");
  });
  FlowsB77Tests.run("draft write failure is not announced as captured data written",()->{
   RegressionB710Tests.clean();Files.write(RegressionB710Tests.drafts().toPath(),new byte[]{1,2,3});var f=new TeachingB77Tests.Fixture();f.start();f.pick();
   check(f.teacher.status().contains("写入失败") && !f.teacher.status().contains("已写入"),"save hint ignored writer error: "+f.teacher.status());f.close();RegressionB710Tests.clean();
  });
  System.out.println("B7.10 final audit cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("final audit regressions");
 }
}
