import android.content.*;import android.os.*;import android.view.*;import java.lang.reflect.*;
public final class OverlayB711Tests {
 static class Windows implements WindowManager {
  java.util.Set<View> views=new java.util.HashSet<>();boolean fail;
  public void addView(View v,LayoutParams p){if(fail)throw new IllegalStateException();views.add(v);}
  public void removeView(View v){views.remove(v);}
 }
 static Object make(Context c)throws Exception{
  try{return Class.forName("org.adguardian.app.service.ProtectionOverlay").getConstructor(Context.class).newInstance(c);}
  catch(ClassNotFoundException e){throw new AssertionError("missing independent foreground overlay");}
 }
 static void sync(Object o,boolean accessibility)throws Exception{o.getClass().getMethod("sync",boolean.class).invoke(o,accessibility);}
 static void close(Object o)throws Exception{((AutoCloseable)o).close();}
 public static void main(String[] args)throws Exception{
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("authorized foreground overlay works even when accessibility is disconnected",()->{
   Context c=new Context();Windows w=new Windows();c.services.put(Context.WINDOW_SERVICE,w);c.getContentResolver().settings.put("overlay_allowed","1");
   Object o=make(c);sync(o,false);FlowsB77Tests.check(w.views.size()==1,"no replacement attachment");sync(o,false);FlowsB77Tests.check(w.views.size()==1,"duplicate views");close(o);FlowsB77Tests.check(w.views.isEmpty(),"view leaked");
  });
  FlowsB77Tests.run("without overlay permission no application overlay is silently attached",()->{
   Context c=new Context();Windows w=new Windows();c.services.put(Context.WINDOW_SERVICE,w);Object o=make(c);sync(o,false);FlowsB77Tests.check(w.views.isEmpty(),"unconsented overlay");close(o);
  });
  FlowsB77Tests.run("handoff waits then releases status overlay only while replacement stays available",()->{
   Context c=new Context();Windows w=new Windows();c.services.put(Context.WINDOW_SERVICE,w);c.getContentResolver().settings.put("overlay_allowed","1");
   Object o=make(c);sync(o,false);sync(o,true);Handler.advance(10999);FlowsB77Tests.check(w.views.size()==1,"handoff dropped too early");
   sync(o,false);Handler.advance(11000);FlowsB77Tests.check(w.views.size()==1,"stale handoff removed only remaining overlay");sync(o,true);Handler.advance(12000);FlowsB77Tests.check(w.views.isEmpty(),"handoff never released old overlay");close(o);
  });
  System.out.println("B7.11 overlay cases passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);if(FlowsB77Tests.fail>0)throw new AssertionError("overlay regressions");
 }
}
