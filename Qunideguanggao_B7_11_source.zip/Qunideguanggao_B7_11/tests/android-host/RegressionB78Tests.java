import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.view.accessibility.*;
import java.util.*;
import org.adguardian.app.classapp.*;
import org.adguardian.app.engine.*;
import org.adguardian.app.flow.*;
import org.adguardian.app.runtime.*;
import org.adguardian.app.service.*;
import org.adguardian.app.settings.*;

/** Production-entry regression probes. Android boundaries are explicitly controlled, not claimed as a device. */
public class RegressionB78Tests {
 static void check(boolean ok,String m){if(!ok)throw new AssertionError(m);}
 static void event(AdAccessibilityService s,String pkg,String cls,int type){AccessibilityEvent e=new AccessibilityEvent();e.type=type;e.pkg=pkg;e.name=cls;s.onAccessibilityEvent(e);}
 static class PM extends PackageManager {
   int failures,calls; boolean strictActivities;
   @Override public PackageInfo getPackageInfo(String pkg,int f)throws NameNotFoundException {calls++;if(failures-->0)throw new NameNotFoundException();return super.getPackageInfo(pkg,f);}
   @Override public ActivityInfo getActivityInfo(ComponentName c,int f)throws NameNotFoundException {
    if(strictActivities && c.getClassName().startsWith("android."))throw new NameNotFoundException();return super.getActivityInfo(c,f);
   }
 }
 static AdAccessibilityService connected()throws Exception {
   AdAccessibilityService s=new AdAccessibilityService();s.services.put(Context.WINDOW_SERVICE,new RegressionB76Tests.Windows());
   PM pm=new PM();pm.strictActivities=true;pm.packageVersion=1013;s.pm=pm;
   s.root=ClassAdapterB77Tests.root();
   PreferenceStore.setLiTiaotiaoEnabled(s,false);PreferenceStore.setGkdEnabled(s,false);PreferenceStore.setOcrEnabled(s,false);PreferenceStore.setClassAdapterEnabled(s,false);
   RegressionB76Tests.authorize(s);
   var method=AdAccessibilityService.class.getDeclaredMethod("onServiceConnected");method.setAccessible(true);method.invoke(s);Handler.advance(10000);return s;
 }
 public static void main(String[] args)throws Exception {
  FlowsB77Tests.pass=FlowsB77Tests.fail=0;
  FlowsB77Tests.run("queued Activity followed by Dialog must preserve the real Activity",()->{
   AdAccessibilityService s=connected();try {
    event(s,ClassAdProfile.PACKAGE,ClassAdProfile.VIDEO,32);
    event(s,ClassAdProfile.PACKAGE,"android.app.Dialog",32);
    event(s,ClassAdProfile.PACKAGE,"android.widget.FrameLayout",2048);
    Handler.advance(10300);
    check(ClassAdProfile.VIDEO.equals(AdAccessibilityService.lastObservedPage()[1]),"Activity event lost during coalescing: "+Arrays.toString(AdAccessibilityService.lastObservedPage()));
   } finally{s.onDestroy();Handler.advance(11000);}
  });
  FlowsB77Tests.run("CLASS version query may recover in the same foreground session",()->{
   ClassAdapterB77Tests.Fixture f=new ClassAdapterB77Tests.Fixture();PM pm=new PM();pm.packageVersion=1013;pm.failures=1;f.s.pm=pm;
   AccessibilityNodeInfo close=ClassAdapterB77Tests.close(null,"跳过");f.s.root.add(close);
   check(!f.handle(ClassAdProfile.VIDEO)&&close.clicks==0,"unknown version acted");
   Handler.advance(12000);check(f.handle(ClassAdProfile.VIDEO)&&close.clicks==1,"one transient lookup failure permanently disabled CLASS");f.engine.close();
  });
  FlowsB77Tests.run("flow teaching retries failed package metadata without leaving the app",()->{
   TeachingB77Tests.Fixture f=new TeachingB77Tests.Fixture();PM pm=new PM();pm.failures=1;f.s.pm=pm;
   f.start();Handler.advance(12000);f.observe();f.pick();f.move("home",null,"host.example.Main",12500);f.save();
   check(f.replay.store().all().size()==1,"failed version was cached forever: "+f.teacher.status());f.close();
  });
  FlowsB77Tests.run("flow replay retries failed version lookup in the same foreground app",()->{
   FlowsB77Tests.Service s=new FlowsB77Tests.Service();s.root=FlowsB77Tests.page("video","跳过");PM pm=new PM();pm.failures=1;s.pm=pm;
   FlowReplayEngine engine=new FlowReplayEngine(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});engine.store().add(FlowsB77Tests.flow());
   check(!FlowsB77Tests.handle(engine,s,"host.example.Ad"),"unknown version replayed");Handler.advance(12000);
   check(FlowsB77Tests.handle(engine,s,"host.example.Ad")&&s.root.children.get(1).clicks==1,"replay cached failed metadata forever");engine.close();
  });
  FlowsB77Tests.run("an own overlay must not permit reading the covered previous application",()->{
   FlowsB77Tests.Service s=new FlowsB77Tests.Service();s.root=FlowsB77Tests.root(s.getPackageName(),null);s.root.window=9;
   AccessibilityWindowInfo overlay=new AccessibilityWindowInfo();overlay.id=9;overlay.type=4;overlay.layer=9;overlay.active=true;overlay.root=s.root;
   AccessibilityWindowInfo front=new AccessibilityWindowInfo();front.id=2;front.layer=5;front.active=true;front.focused=true;front.root=FlowsB77Tests.root("other.example",null);
   AccessibilityWindowInfo behind=new AccessibilityWindowInfo();behind.id=1;behind.layer=1;behind.root=FlowsB77Tests.page("video","跳过");
   s.windows=List.of(overlay,front,behind);AccessibilityNodeInfo result=RootAccess.readFor(s,"host.example");check(result==null,"returned background app behind foreground app");
  });
  FlowsB77Tests.run("explicit selection must refresh the native root instead of trusting the cached copy",()->{
   TeachingB77Tests.Fixture f=new TeachingB77Tests.Fixture();f.start();f.pick();
   check(f.s.root.refreshCalls>0,"selection never refreshed system cached root");f.close();
  });
  FlowsB77Tests.run("a 300-node timetable page can be captured within the query budget",()->{
   AccessibilityNodeInfo root=FlowsB77Tests.page("home",null);
   for(int n=0;n<300;n++)root.add(FlowsB77Tests.n(null,"course body","android.widget.TextView",30,300,100,30,false));
   check(FlowsB77Tests.snap(root,"host.example.Main")!=null,"valid timetable rejected at hard 256-node limit");
  });
  FlowsB77Tests.run("adding passive anonymous creative text must not invalidate guarded replay",()->{
   AccessibilityNodeInfo root=FlowsB77Tests.page("video","跳过");FlowPage before=FlowsB77Tests.snap(root,"host.example.Ad");
   root.children.get(0).add(FlowsB77Tests.n(null,"different creative","android.widget.TextView",10,400,500,150,false));
   FlowPage after=FlowsB77Tests.snap(root,"host.example.Ad");check(before.guard.matches(after.guard),"full ad creative topology was used as an exact replay key");
  });
  FlowsB77Tests.run("learned node lookup falls back when a provider returns an empty native fast query",()->{
   AccessibilityNodeInfo root=new AccessibilityNodeInfo(){@Override public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByViewId(String s){return List.of();}};
   root.pkg="host.example";root.bounds=new android.graphics.Rect(0,0,1080,2400);
   AccessibilityNodeInfo close=FlowsB77Tests.n("host.example:id/close","关闭","android.widget.TextView",940,70,100,60,true);root.add(close);
   NodeTarget target=NodeTarget.captureSelected(close,root.bounds).forLearning();try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)){check(FlowPage.resolve(target,index)==close,"native search empty disabled a visible learned node");}
  });
  FlowsB77Tests.run("a null-root transition retries without requiring a second application event",()->{
   AdAccessibilityService s=connected();try {
    s.root=null;event(s,ClassAdProfile.PACKAGE,ClassAdProfile.VIDEO,32);Handler.advance(10300);
    s.root=ClassAdapterB77Tests.root();Handler.advance(10800);
    check(ClassAdProfile.VIDEO.equals(AdAccessibilityService.lastObservedPage()[1]),"root missing on first event permanently lost page without another event");
   }finally{s.onDestroy();Handler.advance(12000);}
  });

  FlowsB77Tests.run("initialization must retain Activity and Dialog before engines are ready",()->{
   AdAccessibilityService s=new AdAccessibilityService();s.services.put(Context.WINDOW_SERVICE,new RegressionB76Tests.Windows());
   PM pm=new PM();pm.strictActivities=true;pm.packageVersion=1013;s.pm=pm;s.root=ClassAdapterB77Tests.root();RegressionB76Tests.authorize(s);
   PreferenceStore.setOcrEnabled(s,false);PreferenceStore.setClassAdapterEnabled(s,false);
   var connect=AdAccessibilityService.class.getDeclaredMethod("onServiceConnected");connect.setAccessible(true);connect.invoke(s);
   try {event(s,ClassAdProfile.PACKAGE,ClassAdProfile.VIDEO,32);event(s,ClassAdProfile.PACKAGE,"android.app.Dialog",32);Handler.advance(10400);
    check(ClassAdProfile.VIDEO.equals(AdAccessibilityService.lastObservedPage()[1]),"startup events were dropped");
   }finally{s.onDestroy();Handler.advance(12000);}
  });
  FlowsB77Tests.run("unknown package versions are rate limited but never authorize an action",()->{
   FlowsB77Tests.Service s=new FlowsB77Tests.Service();PM pm=new PM();pm.failures=99;s.pm=pm;
   PackageVersionLookup versions=new PackageVersionLookup();for(int i=0;i<20;i++)check(versions.read(s,"host.example")==-1,"unknown version became valid");
   check(pm.calls==1,"repeated Binder reads without negative TTL");Handler.advance(10800);check(versions.read(s,"host.example")==-1&&pm.calls==2,"version not retried after TTL");
  });
  FlowsB77Tests.run("obsolete root cannot confirm selection or save a flow",()->{
   TeachingB77Tests.Fixture f=new TeachingB77Tests.Fixture();f.start();f.s.root.refreshValid=false;f.pick();f.save();
   check(f.replay.store().all().isEmpty(),"obsolete page learned successfully");f.close();
  });
  FlowsB77Tests.run("transient picker teardown is retried before declaring capture impossible",()->{
   TeachingB77Tests.Fixture f=new TeachingB77Tests.Fixture();f.start();var root=f.s.root;f.s.root=null;f.teacher.selectAt(980,100);Handler.advance(10000);
   f.s.root=root;Handler.advance(10300);f.move("home",null,"host.example.Main",10800);f.save();
   check(f.replay.store().all().size()==1,"single transient root miss permanently discarded explicit selection");f.close();
  });
  FlowsB77Tests.run("deferred explicit selection cannot cross a foreground application change",()->{
   TeachingB77Tests.Fixture f=new TeachingB77Tests.Fixture();f.start();var root=f.s.root;f.s.root=null;f.teacher.selectAt(980,100);Handler.advance(10000);
   f.pkg="other.example";f.s.root=root;Handler.advance(10500);f.teacher.finish();Handler.advance(11000);
   check(f.replay.store().all().isEmpty(),"late picker coordinates escaped their original app");f.close();
  });
  FlowsB77Tests.run("passive creative layout changes cannot commit an unchanged close action",()->{
   var root=FlowsB77Tests.page("video","跳过");var before=FlowsB77Tests.snap(root,"host.example.Ad");
   var journal=new FlowJournal(AdType.POPUP);check(journal.beginClick(before,before.pick(980,100)),"setup failed");
   root.children.get(0).add(FlowsB77Tests.n(null,"private creative body","android.widget.TextView",10,400,300,90,false));
   journal.observe(FlowsB77Tests.snap(root,"host.example.Ad"),10300);journal.observe(FlowsB77Tests.snap(root,"host.example.Ad"),10600);
   check(journal.stepCount()==0&&journal.pending(),"cosmetic content committed a fake step");
  });
  FlowsB77Tests.run("over-budget or protected timetable pages cannot produce a guard",()->{
   var root=FlowsB77Tests.page("home",null);for(int i=0;i<1100;i++)root.add(FlowsB77Tests.n(null,"course text","android.widget.TextView",30,300,80,40,false));
   check(FlowsB77Tests.snap(root,"host.example.Main")==null,"truncated page was accepted");
   root=FlowsB77Tests.page("home",null);root.add(FlowsB77Tests.n(null,"确认支付","android.widget.TextView",30,300,80,40,false));
   check(FlowsB77Tests.snap(root,"host.example.Main")==null,"payment page was accepted");
  });
  FlowsB77Tests.run("empty native query fallback still rejects two indistinguishable close controls",()->{
   AccessibilityNodeInfo root=new AccessibilityNodeInfo(){@Override public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByViewId(String id){return List.of();}};
   root.pkg="host.example";root.bounds=new android.graphics.Rect(0,0,1080,2400);
   var a=FlowsB77Tests.n("host.example:id/close","关闭","android.widget.TextView",940,70,100,60,true);
   var b=FlowsB77Tests.n("host.example:id/close","关闭","android.widget.TextView",940,70,100,60,true);root.add(a).add(b);
   try(var idx=AccessibilityNodeIndex.build(root)){check(FlowPage.resolve(NodeTarget.captureSelected(a,root.bounds).forLearning(),idx)==null,"ambiguous fallback picked the first control");}
  });
  FlowsB77Tests.run("frequent Dialog events must not query package metadata on every scan",()->{
   AdAccessibilityService s=connected();try {
    PM pm=new PM(){int seen;@Override public ActivityInfo getActivityInfo(ComponentName c,int f)throws NameNotFoundException {
      calls++;if(c.getClassName().equals("android.app.Dialog"))throw new NameNotFoundException();return new ActivityInfo();}};
    pm.packageVersion=1013;s.pm=pm;
    event(s,ClassAdProfile.PACKAGE,ClassAdProfile.VIDEO,32);event(s,ClassAdProfile.PACKAGE,"android.app.Dialog",32);Handler.advance(10200);int first=pm.calls;
    for(int i=0;i<5;i++){event(s,ClassAdProfile.PACKAGE,"android.app.Dialog",32);Handler.advance(10201+i);}
    check(pm.calls<=first+1,"Dialog was negatively queried every pass");
   }finally{s.onDestroy();Handler.advance(13000);}
  });

  FlowsB77Tests.run("B7.7 stored guard remains compatible with an unchanged B7.8 page",()->{
   var page=FlowsB77Tests.snap(FlowsB77Tests.page("video","跳过"),"host.example.Ad");
   // Fingerprint produced by compiling and running the original B7.7 FlowPage on this same fixture.
   var old=new FlowGuard("host.example.Ad","f1:1adfbac95f491f4126927fa674ad2a1e44268f43d68d8f8f755123434c55f499",1080f/2400);
   check(old.matches(page.guard),"unchanged legacy recording was lost");
  });
  FlowsB77Tests.run("copy diagnostics explains missing Activity without exporting page content",()->{
   var s=new FlowsB77Tests.Service();s.root=FlowsB77Tests.page("video","跳过");s.root.children.get(0).text="PRIVATE_COURSE_OR_ACCOUNT";s.root.id=null;s.root.children.get(0).id=null;s.root.children.get(1).id=null;s.root.add(FlowsB77Tests.n(null,null,"android.view.View",0,1800,1080,200,false));
   try(var idx=AccessibilityNodeIndex.build(s.root)){check(FlowPage.capture("host.example","",1,idx)==null,"unknown Activity accepted");}
   var report=RuntimeDiagnostics.read(s);
   check(report.contains("尚未确认真实页面"),"cannot distinguish missing Activity from no close button");
   check(!report.contains("PRIVATE_COURSE_OR_ACCOUNT"),"exported private text");
  });
  FlowsB77Tests.run("CLASS diagnostic distinguishes unknown version from a nonmatching ad template",()->{
   var f=new ClassAdapterB77Tests.Fixture();PM pm=new PM();pm.failures=1;f.s.pm=pm;f.handle(ClassAdProfile.VIDEO);
   check(RuntimeDiagnostics.read(f.s).contains("应用版本暂时不可读取"),"silent CLASS gate has no reason");f.engine.close();
  });
  FlowsB77Tests.run("active replay refreshes native root before looking for the next ad layer",()->{
   AdAccessibilityService s=ServiceFlowB77Tests.create(new RegressionB76Tests.Windows());
   try {AdAccessibilityService.withLearnedFlows(store->{try{store.add(FlowsB77Tests.flow());}catch(Exception e){throw new RuntimeException(e);}},()->{});Handler.advance(10300);
    ServiceFlowB77Tests.event(s,2048,"android.widget.FrameLayout",null,10400);Handler.advance(10800);
    check(s.root.refreshCalls>0,"active replay continued on an unrefreshed cached page");
   }finally{s.onDestroy();Handler.advance(14000);}
  });

  FlowsB77Tests.run("an Activity resolved after a newer same-app state must not overwrite that state",()->{
   ActivityTracker tracker=new ActivityTracker();tracker.note("host.example","host.example.Ad");
   String stale=tracker.resolve("host.example",name->{tracker.note("host.example","host.example.Main");return true;});
   check(!"host.example.Ad".equals(stale),"stale Activity validation committed after a newer event");
   check("host.example.Main".equals(tracker.resolve("host.example",name->true)),"latest Activity not resolved");
  });
  System.out.println("B7.8 boundary regressions passed="+FlowsB77Tests.pass+" failed="+FlowsB77Tests.fail);
  if(FlowsB77Tests.fail>0)throw new AssertionError("B7.8 boundary regressions");
 }
}
