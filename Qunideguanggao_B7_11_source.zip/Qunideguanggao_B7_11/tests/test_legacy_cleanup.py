import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]

class LegacyCleanupTests(unittest.TestCase):
    def module(self):
        spec = importlib.util.spec_from_file_location('cleanup', ROOT / 'tools/clean_legacy_sources.py')
        mod = importlib.util.module_from_spec(spec)
        self.assertIn('def clean(', (ROOT / 'tools/clean_legacy_sources.py').read_text(),
                      'legacy cleanup must expose explicit root without deleting current sources on import')
        spec.loader.exec_module(mod)
        return mod

    def test_only_recognized_legacy_files_are_removed(self):
        mod = self.module()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            old = root / 'app/src/main/java/org/adguardian/app/vision/YoloSkipDetector.java'
            new = root / 'app/src/main/java/org/adguardian/app/gkd/GkdSubscriptionEngine.java'
            custom = root / 'app/src/main/java/custom/UsefulExtension.java'
            so = root / 'app/src/main/jniLibs/arm64-v8a/libcustom.so'
            for path in (old, new, custom, so):
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text('preserve unless recognized obsolete')
            removed = mod.clean(root)
            self.assertFalse(old.exists())
            self.assertTrue(new.exists())
            self.assertTrue(custom.exists())
            self.assertTrue(so.exists())
            self.assertIn(old.relative_to(root).as_posix(), removed)

    def test_cleaning_current_source_is_idempotent(self):
        mod = self.module()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertEqual(mod.clean(root), [])
            self.assertEqual(mod.clean(root), [])

if __name__ == '__main__':
    unittest.main()
