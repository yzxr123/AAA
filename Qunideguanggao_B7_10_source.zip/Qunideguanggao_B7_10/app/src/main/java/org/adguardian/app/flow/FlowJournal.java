package org.adguardian.app.flow;

import java.util.*;
import org.adguardian.app.engine.*;

/** Worker-confined teaching state. An observation never writes a rule; finish() needs explicit UI confirmation. */
public final class FlowJournal {
    public static final int MAX_STEPS=8;
    private final AdType type;
    private final ArrayList<FlowStep> steps=new ArrayList<>();
    private FlowStep pending;
    private FlowPage before,latest;
    private FlowGuard stable;
    private long firstStable;
    private String pkg="";
    private long version=-1;
    private float sessionAspect;
    private int sessionRotation=-1;
    private boolean cancelled;
    public FlowJournal(AdType type){this.type=type;}
    public int stepCount(){return steps.size();}
    public java.util.List<FlowStep> capturedSteps(){
        java.util.ArrayList<FlowStep> copy=new java.util.ArrayList<>(steps);
        if(pending!=null)copy.add(pending);
        return java.util.Collections.unmodifiableList(copy);
    }
    public String targetPackage(){return pkg;}
    public long targetVersion(){return version;}
    public boolean pending(){return pending!=null;}
    public boolean cancelled(){return cancelled;}
    public FlowStep pendingStep(){return pending;}
    public boolean beginClick(FlowPage page,NodeTarget target) {
        if(page==null || page.find(target)==null || !FlowSafety.safeTarget(target))return false;
        return begin(page,new FlowStep(page.guard,target,false,30000));
    }
    public boolean beginBack(FlowPage page) {
        if(steps.isEmpty() || page==null || page.guard.activity.startsWith("@window:"))return false;
        // A timetable home page is an exit path, not an advertisement return step.
        if(page.pkg.equals("cn.luyiyuntech.stt") && page.guard.activity.equals("com.common.tang.activity.MainActivity"))return false;
        return begin(page,new FlowStep(page.guard,null,true,30000));
    }
    private boolean begin(FlowPage page,FlowStep step) {
        if(cancelled || pending!=null || steps.size()>=MAX_STEPS || !step.valid())return false;
        if(pkg.isEmpty()){pkg=page.pkg;version=page.version;sessionAspect=page.guard.aspect;sessionRotation=page.displayRotation();}
        if(!pkg.equals(page.pkg) || version!=page.version || (latest!=null && !latest.sameScope(page)))return false;
        before=page;latest=page;pending=step;stable=null;firstStable=0;return true;
    }
    /** A distinct explicit click on the observed next page supplies a second piece of transition evidence. */
    public boolean advanceBeforeClick(FlowPage page,NodeTarget target,long eventTime) {
        if(cancelled || pending==null || pending.back || before==null || !before.sameScope(page)
                || page.find(target)==null || pending.guard.matches(page.guard)
                || (stable==null || !stable.matches(page.guard)) || eventTime<firstStable)return false;
        steps.add(pending);pending=null;before=null;stable=null;firstStable=0;return true;
    }
    public void discardPending(){pending=null;before=null;stable=null;firstStable=0;}
    public void cancel(){cancelled=true;pending=null;latest=null;stable=null;}
    public void observe(FlowPage page,long now) {
        if(cancelled)return;
        if(page==null){stable=null;return;}
        if(!pkg.isEmpty() && (!pkg.equals(page.pkg) || version!=page.version || !org.adguardian.app.runtime.DisplayRotation.compatible(sessionRotation,page.displayRotation(),sessionAspect,page.guard.aspect))){cancel();return;}
        latest=page;
        if(pending==null)return;
        boolean changed=pending.back?!pending.guard.matches(page.guard)
                :!page.sameLayoutAfterResize(before,pending.target) && (!page.has(pending.target) || !pending.guard.matches(page.guard));
        if(!changed){stable=null;return;}
        if(stable==null || !stable.matches(page.guard)){stable=page.guard;firstStable=now;return;}
        if(now-firstStable<120)return;
        steps.add(pending);pending=null;before=null;stable=null;
    }
    public LearnedFlow finish(String key,String appName) {
        if(cancelled || pending!=null || steps.isEmpty() || latest==null)throw new IllegalStateException("teaching unfinished");
        FlowStep last=steps.get(steps.size()-1);
        if(last.guard.matches(latest.guard) && (last.back || latest.has(last.target)))throw new IllegalStateException("last target still present");
        if(pkg.equals("cn.luyiyuntech.stt") && (!latest.guard.activity.equals("com.common.tang.activity.MainActivity") || latest.knownClassAd))
            throw new IllegalStateException("not returned to timetable");
        return new LearnedFlow(key,pkg,appName,version,type,true,steps,latest.guard);
    }
}
