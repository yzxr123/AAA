package org.adguardian.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import org.adguardian.app.runtime.AccessibilityState;
import org.adguardian.app.runtime.RuntimeDiagnostics;
import org.adguardian.app.service.ProtectionService;
import org.adguardian.app.learning.LearnedRule;
import org.adguardian.app.flow.LearnedFlow;
import org.adguardian.app.flow.FlowStore;
import org.adguardian.app.recording.RecordingDraft;
import org.adguardian.app.recording.RecordingDraftStore;
import org.adguardian.app.learning.LearnedRuleStore;
import java.io.IOException;
import java.util.ArrayList;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.PowerManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.adguardian.app.engine.AdType;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.service.AdAccessibilityService;
import org.adguardian.app.settings.PreferenceStore;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class MainActivity extends android.app.Activity {
    private TextView permissionStatus;
    private TextView runtimeStatus;
    private Switch learnedSwitch;
    private AccessibilityState.Watch statusWatch;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private TextView eventLogView;
    private TextView backgroundStatus;
    private Switch protectionSwitch;
    private Switch liTiaotiaoSwitch;
    private Switch gkdSwitch;
    private Switch classAdapterSwitch;
    private Switch ocrSwitch;
    private Switch keepAliveSwitch;
    private final Map<AdType, Switch> typeSwitches = new EnumMap<>(AdType.class);
    private boolean changingSwitches;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildContent());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(statusWatch==null)statusWatch=new AccessibilityState.Watch(this,() -> {
            updatePermissionStatus();updateBackgroundStatus();syncSwitches();
        });
        ProtectionService.sync(this);
        updatePermissionStatus();
        refreshEventLog();
        syncSwitches();
        updateBackgroundStatus();
    }

    @Override protected void onPause() {
        if(statusWatch!=null)statusWatch.close();statusWatch=null;
        super.onPause();
    }
    @Override protected void onDestroy() {ui.removeCallbacksAndMessages(null);super.onDestroy();}
    private void settingsChanged() {
        AdAccessibilityService.notifySettingsChanged();
        ProtectionService.sync(this);
        updatePermissionStatus();updateBackgroundStatus();
    }
    private ScrollView buildContent() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        root.addView(text("去你的广告", 28, true));
        TextView subtitle = text("规则优先处理广告 需要时再使用 OCR", 15, false);
        subtitle.setTextColor(Color.rgb(85, 85, 85));
        root.addView(subtitle, marginTop(dp(4)));

        permissionStatus = text("", 15, true);
        root.addView(permissionStatus, marginTop(dp(22)));
        runtimeStatus=text("",14,false);root.addView(runtimeStatus,marginTop(dp(6)));

        Button enableAll = new Button(this);
        enableAll.setText("一键开启全部广告屏蔽");
        enableAll.setAllCaps(false);
        enableAll.setTextSize(17);
        enableAll.setOnClickListener(v -> enableEverything());
        root.addView(enableAll, marginTop(dp(12)));

        Button permission = new Button(this);
        permission.setText("查看辅助功能设置");
        permission.setAllCaps(false);
        permission.setOnClickListener(v -> openAccessibilitySettings());
        root.addView(permission, marginTop(dp(8)));

        backgroundStatus = text("", 13, false);
        backgroundStatus.setTextColor(Color.rgb(95, 95, 95));
        root.addView(backgroundStatus, marginTop(dp(8)));

        Button backgroundPermission = new Button(this);
        backgroundPermission.setText("允许后台持续运行");
        backgroundPermission.setAllCaps(false);
        backgroundPermission.setOnClickListener(v -> requestBackgroundPermission());
        root.addView(backgroundPermission, marginTop(dp(6)));
        Button notifications=smallButton("允许显示保护通知");notifications.setOnClickListener(v -> requestNotificationPermission());root.addView(notifications,marginTop(dp(4)));
        Button restore=smallButton("检查并恢复服务");restore.setOnClickListener(v -> recoverService());root.addView(restore,marginTop(dp(6)));
        Button diagnostics=smallButton("复制运行状态");diagnostics.setOnClickListener(v -> {
            new Thread(() -> {String result=RuntimeDiagnostics.read(getApplicationContext());ui.post(() -> copyText(result));},"AdStatusRead").start();
        });root.addView(diagnostics,marginTop(dp(4)));

        root.addView(sectionTitle("运行方式"), marginTop(dp(20)));
        keepAliveSwitch = optionSwitch("后台持续保护", PreferenceStore.isKeepAliveEnabled(this));
        keepAliveSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setKeepAliveEnabled(this, enabled);
            if(enabled)requestNotificationPermission();
            settingsChanged();
        });
        root.addView(keepAliveSwitch, marginTop(dp(2)));

        TextView keepAliveHint = text("使用一条无声音的常驻通知保持后台保护 关闭界面不会主动停止服务 厂商省电限制需在系统中允许自启动", 13, false);
        keepAliveHint.setTextColor(Color.rgb(95, 95, 95));
        root.addView(keepAliveHint, marginTop(dp(4)));

        root.addView(sectionTitle("总开关"), marginTop(dp(20)));
        protectionSwitch = optionSwitch("广告屏蔽", PreferenceStore.isMasterEnabled(this));
        protectionSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setMasterEnabled(this, enabled);
            settingsChanged();
        });
        root.addView(protectionSwitch, marginTop(dp(4)));

        root.addView(sectionTitle("识别方式"), marginTop(dp(20)));
        liTiaotiaoSwitch = optionSwitch("李跳跳规则", PreferenceStore.isLiTiaotiaoEnabled(this));
        liTiaotiaoSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setLiTiaotiaoEnabled(this, enabled);
            settingsChanged();
        });
        root.addView(liTiaotiaoSwitch, marginTop(dp(2)));

        gkdSwitch = optionSwitch("GKD 广告规则", PreferenceStore.isGkdEnabled(this));
        gkdSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setGkdEnabled(this, enabled);
            settingsChanged();
        });
        root.addView(gkdSwitch, marginTop(dp(2)));

        classAdapterSwitch=optionSwitch("CLASS 课表增强识别",PreferenceStore.isClassAdapterEnabled(this));
        classAdapterSwitch.setOnCheckedChangeListener((button,enabled) -> {
            if(changingSwitches)return;
            PreferenceStore.setClassAdapterEnabled(this,enabled);settingsChanged();
        });
        root.addView(classAdapterSwitch,marginTop(dp(2)));

        ocrSwitch = optionSwitch("OCR 视觉识别", PreferenceStore.isOcrEnabled(this));
        ocrSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
            if (changingSwitches) return;
            PreferenceStore.setOcrEnabled(this, enabled);
            settingsChanged();
        });
        root.addView(ocrSwitch, marginTop(dp(2)));

        TextView ocrHint = text("OCR 默认开启 仅在规则没有处理成功时工作 关闭后不再发起截图 正在处理的识别结束后释放资源", 13, false);
        ocrHint.setTextColor(Color.rgb(95, 95, 95));
        root.addView(ocrHint, marginTop(dp(4)));

        Button builtins=smallButton("查看 CLASS 内置规则");
        builtins.setOnClickListener(v -> showDetails("CLASS 内置广告规则",org.adguardian.app.classapp.ClassAdRules.describe(this)));
        root.addView(builtins,marginTop(dp(6)));

        root.addView(sectionTitle("手动学习"),marginTop(dp(20)));
        learnedSwitch=optionSwitch("使用已学习的广告规则",PreferenceStore.isLearnedEnabled(this));
        learnedSwitch.setOnCheckedChangeListener((button,enabled) -> {
            if(changingSwitches)return;
            PreferenceStore.setLearnedEnabled(this,enabled);settingsChanged();
        });root.addView(learnedSwitch,marginTop(dp(4)));
        root.addView(text("每捕获一个关闭步骤立即保存录制草稿 结束校验通过后才启用自动回放 中断后可从录制记录查看 最多八步 不保存截图和输入内容",13,false),marginTop(dp(4)));
        Button teachFlow=smallButton("学习完整关闭流程");teachFlow.setOnClickListener(v -> startFlowLearning());root.addView(teachFlow,marginTop(dp(6)));
        Button drafts=smallButton("查看录制记录和草稿");drafts.setOnClickListener(v -> showRecordingDrafts());root.addView(drafts,marginTop(dp(6)));
        Button manageFlow=smallButton("管理已学习流程");manageFlow.setOnClickListener(v -> showLearnedFlows());root.addView(manageFlow,marginTop(dp(4)));
        Button teach=smallButton("只学习一个关闭按钮");teach.setOnClickListener(v -> startLearning());root.addView(teach,marginTop(dp(4)));
        Button manage=smallButton("管理单按钮规则");manage.setOnClickListener(v -> showLearnedRules());root.addView(manage,marginTop(dp(4)));

        root.addView(sectionTitle("广告类型"), marginTop(dp(20)));
        for (AdType type : AdType.values()) {
            Switch typeSwitch = optionSwitch(type.displayName(), PreferenceStore.isTypeEnabled(this, type));
            typeSwitch.setOnCheckedChangeListener((buttonView, enabled) -> {
                if (changingSwitches) return;
                PreferenceStore.setTypeEnabled(this, type, enabled);
                settingsChanged();
            });
            typeSwitches.put(type, typeSwitch);
            root.addView(typeSwitch, marginTop(dp(2)));
        }

        TextView privacy = text("所有识别均在本机完成", 13, false);
        privacy.setTextColor(Color.rgb(95, 95, 95));
        root.addView(privacy, marginTop(dp(12)));

        TextView recordTitle = sectionTitle("拦截记录");
        root.addView(recordTitle, marginTop(dp(24)));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(buttons, marginTop(dp(8)));

        Button refresh = smallButton("刷新");
        refresh.setOnClickListener(v -> refreshEventLog());
        buttons.addView(refresh, weightedButtonParams());

        Button copy = smallButton("复制");
        copy.setOnClickListener(v -> copyEventLog());
        buttons.addView(copy, weightedButtonParams());

        Button clear = smallButton("清空");
        clear.setOnClickListener(v -> {
            UserEventLog.clear(this);
            refreshEventLog();
        });
        buttons.addView(clear, weightedButtonParams());

        eventLogView = text("暂无拦截记录", 12, false);
        eventLogView.setTextIsSelectable(true);
        eventLogView.setTextColor(Color.rgb(35, 35, 35));
        eventLogView.setBackgroundColor(Color.rgb(242, 242, 242));
        eventLogView.setPadding(dp(10), dp(10), dp(10), dp(10));
        eventLogView.setMinHeight(dp(130));
        root.addView(eventLogView, marginTop(dp(8)));
        return scroll;
    }

    private void enableEverything() {
        PreferenceStore.enableAllAds(this);
        syncSwitches();
        settingsChanged();
        AccessibilityState.Snapshot state=AccessibilityState.read(this);
        if(state.known && !state.authorized) {
            Toast.makeText(this, "请允许辅助功能权限", Toast.LENGTH_SHORT).show();
            openAccessibilitySettings();
        } else {
            requestNotificationPermission();
            Toast.makeText(this, state.running()?"全部广告屏蔽已开启":(state.known?"所有开关已开启 正在等待服务连接":"所有开关已开启 正在核对系统授权状态"), Toast.LENGTH_SHORT).show();
        }
    }

    private void syncSwitches() {
        changingSwitches = true;
        if (protectionSwitch != null) protectionSwitch.setChecked(PreferenceStore.isMasterEnabled(this));
        if (liTiaotiaoSwitch != null) liTiaotiaoSwitch.setChecked(PreferenceStore.isLiTiaotiaoEnabled(this));
        if (gkdSwitch != null) gkdSwitch.setChecked(PreferenceStore.isGkdEnabled(this));
        if (ocrSwitch != null) ocrSwitch.setChecked(PreferenceStore.isOcrEnabled(this));
        if(classAdapterSwitch!=null)classAdapterSwitch.setChecked(PreferenceStore.isClassAdapterEnabled(this));
        if(learnedSwitch!=null)learnedSwitch.setChecked(PreferenceStore.isLearnedEnabled(this));
        if (keepAliveSwitch != null) keepAliveSwitch.setChecked(PreferenceStore.isKeepAliveEnabled(this));
        for (Map.Entry<AdType, Switch> entry : typeSwitches.entrySet()) {
            entry.getValue().setChecked(PreferenceStore.isTypeEnabled(this, entry.getKey()));
        }
        changingSwitches = false;
    }

    private void openAccessibilitySettings() {
        openSystemPage(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    private void openSystemPage(Intent intent) {
        try {startActivity(intent);}
        catch(RuntimeException unavailable) {
            Toast.makeText(this,"系统没有提供这个设置入口 请从系统设置打开应用信息",Toast.LENGTH_LONG).show();
            org.adguardian.app.runtime.RuntimeHealth.failure(this,"系统设置入口不可用",unavailable);
        }
    }

    private void requestBackgroundPermission() {
        ProtectionService.sync(this);
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager != null && powerManager.isIgnoringBatteryOptimizations(getPackageName())) {
            new AlertDialog.Builder(this).setMessage("已允许电池优化豁免 部分手机还需要在应用信息中允许自启动和后台活动").setPositiveButton("应用信息",(d,w) -> openSystemPage(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())))).setNegativeButton("返回",null).show();
            return;
        }
        Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        openSystemPage(intent);
    }

    private void updateBackgroundStatus() {
        if (backgroundStatus == null) return;
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean allowed = powerManager != null && powerManager.isIgnoringBatteryOptimizations(getPackageName());
        backgroundStatus.setText((allowed?"电池优化豁免 已允许":"电池优化豁免 尚未允许")+"\n"
                +(ProtectionService.isRunning()?"常驻通知保护 已启动":"常驻通知保护 未启动")
                +(ProtectionService.startProblem().isEmpty()?"":"\n"+ProtectionService.startProblem()));
        backgroundStatus.setTextColor(allowed ? Color.rgb(20, 120, 60) : Color.rgb(160, 90, 30));
    }

    private void updatePermissionStatus() {
        if(permissionStatus==null)return;
        AccessibilityState.Snapshot state=AccessibilityState.read(this);
        permissionStatus.setText(state.permissionText());
        permissionStatus.setTextColor(state.authorized?Color.rgb(20,120,60):Color.rgb(160,50,50));
        if(runtimeStatus!=null)runtimeStatus.setText(state.runtimeText());
    }
    private void requestNotificationPermission() {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},75);
    }
    private void recoverService() {
        AccessibilityState.Snapshot state=AccessibilityState.read(this);
        ProtectionService.sync(this);
        if(!state.known) {
            Toast.makeText(this,"正在核对系统状态 没有确认权限被撤销 请稍后重试",Toast.LENGTH_LONG).show();
            ui.postDelayed(this::updatePermissionStatus,1000L);return;
        }
        if(!state.authorized) {openAccessibilitySettings();return;}
        if(state.failed) {AdAccessibilityService.retryInitialization();return;}
        if(state.connected) {AdAccessibilityService.notifySettingsChanged();updatePermissionStatus();return;}
        new AlertDialog.Builder(this).setTitle("授权保留但服务未连接")
                .setMessage("系统授权仍然存在 但系统还没有重新连接服务 这不是重新申请权限\n请在应用信息中允许自启动和后台活动 并检查电池限制\n检查并恢复仅能重试已连接服务的内部初始化 不能代替系统重新绑定已断开的辅助服务")
                .setPositiveButton("辅助功能设置",(d,w) -> openAccessibilitySettings())
                .setNegativeButton("返回",null).show();
    }
    private void startFlowLearning() {
        if(!PreferenceStore.isMasterEnabled(this)){Toast.makeText(this,"请先开启广告屏蔽总开关",Toast.LENGTH_SHORT).show();return;}
        if(!AccessibilityState.read(this).running()){recoverService();return;}
        new AlertDialog.Builder(this).setTitle("学习完整关闭流程")
                .setItems(new String[]{"开屏广告流程","弹窗广告流程"},(dialog,which) -> {
                    AdType type=which==0?AdType.STARTUP:AdType.POPUP;
                    if(!PreferenceStore.isTypeEnabled(this,type)){Toast.makeText(this,"请先开启对应的广告类型",Toast.LENGTH_SHORT).show();return;}
                    new AlertDialog.Builder(this).setTitle("依次关闭每一层广告")
                            .setMessage("开始后自动拦截和 OCR 会暂时暂停 请在三分钟内完成 最多八步\n每一层可直接手动关闭 没捕获到时使用 选取下一步 先选控件再手动关闭\n等待提示当前步骤已确认 再关闭下一层\n需要返回时点 记录并返回 这个按钮会实际执行一次返回\n每步先写入录制草稿 回到课表或目标页面后点 完成并保存 校验通过才启用\n没有可读取小控件的整张画布不会记录坐标盲点")
                            .setPositiveButton("开始学习",(d,w) -> {
                                if(AdAccessibilityService.beginFlowLearning(type))moveTaskToBack(true);
                                else Toast.makeText(this,"请等待辅助功能服务连接",Toast.LENGTH_SHORT).show();
                            }).setNegativeButton("取消",null).show();
                }).show();
    }
    private void showLearnedFlows() {
        ArrayList<LearnedFlow> snapshot=new ArrayList<>();final boolean[] readable={true};
        runRecordIo(() -> {FlowStore store=new FlowStore(this);readable[0]=store.isReadable();snapshot.addAll(store.all());},() -> {
            if(isFinishing() || isDestroyed())return;
            if(!readable[0]) {
                new AlertDialog.Builder(this).setTitle("流程数据无法读取").setMessage("原文件已保留 不会用空规则覆盖 可以取消 或明确清空后重新学习")
                        .setPositiveButton("清空流程",(d,w) -> changeLearnedFlow(null,2)).setNegativeButton("取消",null).show();return;
            }
            if(snapshot.isEmpty()){new AlertDialog.Builder(this).setMessage("还没有通过结束校验的完整流程 已捕获步骤请到 查看录制记录和草稿 查看")
                    .setPositiveButton("返回",null).show();return;}
            String[] names=new String[snapshot.size()];
            for(int i=0;i<names.length;i++){LearnedFlow f=snapshot.get(i);names[i]=(f.enabled?"已开启 ":"已关闭 ")+f.appName+"  "+f.steps.size()+" 步  "+(i+1);}
            new AlertDialog.Builder(this).setTitle("已学习流程").setItems(names,(d,i) -> editLearnedFlow(snapshot.get(i)))
                    .setNegativeButton("返回",null).setNeutralButton("清空流程",(d,w) -> {
                        new AlertDialog.Builder(this).setMessage("确定删除所有多步骤流程吗 单按钮规则不受影响")
                                .setPositiveButton("删除",(a,b) -> changeLearnedFlow(null,2)).setNegativeButton("取消",null).show();
                    }).show();
        });
    }
    private void editLearnedFlow(LearnedFlow flow) {
        new AlertDialog.Builder(this).setTitle(flow.appName+"  "+flow.steps.size()+" 步")
                .setItems(new String[]{flow.enabled?"关闭这条流程":"开启这条流程","删除这条流程","查看记录步骤"},(d,w) -> {
                    if(w==2)showDetails("已记录的关闭流程",org.adguardian.app.flow.LearningDetails.describe(flow));else changeLearnedFlow(flow,w);
                })
                .setNegativeButton("返回",null).show();
    }
    private void changeLearnedFlow(LearnedFlow flow,int action) {
        final String[] result={"已保存"};
        runRecordIo(() -> {
            FlowStore store=new FlowStore(this);
            try{if(action==2)store.clear();else if(action==1)store.remove(flow.key);else store.setEnabled(flow.key,!flow.enabled);}
            catch(IOException error){result[0]="保存失败 原流程未改变";}
        },() -> {if(!isFinishing() && !isDestroyed()){settingsChanged();Toast.makeText(this,result[0],Toast.LENGTH_SHORT).show();showLearnedFlows();}});
    }
    private void startLearning() {
        if(!AccessibilityState.read(this).running()) {recoverService();return;}
        new AlertDialog.Builder(this).setTitle("选择要学习的广告")
                .setItems(new String[]{"开屏广告","弹窗广告"},(dialog,which) -> {
                    AdType type=which==0?AdType.STARTUP:AdType.POPUP;
                    new AlertDialog.Builder(this).setTitle("学习一次关闭操作")
                            .setMessage("开始后自动拦截会暂时暂停 请在九十秒内打开广告\n可以直接手动关闭 或点 选取按钮 再点广告关闭位置 选取后仍由你手动关闭广告\n捕获后先保存草稿 最后点 保存 校验通过后启用自动规则 不保存截图或输入内容\n提示条挡住按钮时可点 移动提示条")
                            .setPositiveButton("开始学习",(d,w) -> {
                                if(AdAccessibilityService.beginLearning(type))moveTaskToBack(true);
                                else Toast.makeText(this,"请等待辅助功能服务连接",Toast.LENGTH_SHORT).show();
                            }).setNegativeButton("取消",null).show();
                }).show();
    }
    private void showLearnedRules() {
        ArrayList<LearnedRule> snapshot=new ArrayList<>();final boolean[] readable={true};
        runRecordIo(() -> {LearnedRuleStore store=new LearnedRuleStore(this);readable[0]=store.isReadable();snapshot.addAll(store.all());},() -> {
            if(isFinishing() || isDestroyed())return;
            if(!readable[0]) {
                new AlertDialog.Builder(this).setTitle("单按钮规则数据无法读取")
                        .setMessage("原文件已保留 不会用空规则覆盖 可以取消 或明确清空后重新学习")
                        .setPositiveButton("清空单按钮规则",(d,w) -> changeLearnedRule(null,2)).setNegativeButton("取消",null).show();return;
            }
            if(snapshot.isEmpty()) {new AlertDialog.Builder(this).setMessage("还没有通过校验的单按钮规则 已捕获内容请到 查看录制记录和草稿 查看").setPositiveButton("返回",null).show();return;}
            String[] names=new String[snapshot.size()];
            for(int i=0;i<names.length;i++) {LearnedRule r=snapshot.get(i);names[i]=(r.enabled?"已开启 ":"已关闭 ")+r.appName+" "+r.type.displayName()+" "+(i+1);}
            new AlertDialog.Builder(this).setTitle("已学习规则")
                    .setItems(names,(d,position) -> editLearnedRule(snapshot.get(position)))
                    .setNegativeButton("返回",null).setNeutralButton("清空全部",(d,w) -> {
                        new AlertDialog.Builder(this).setMessage("确定删除全部学习规则吗")
                                .setPositiveButton("删除",(a,b) -> changeLearnedRule(null,2)).setNegativeButton("取消",null).show();
                    }).show();
        });
    }
    private void editLearnedRule(LearnedRule rule) {
        new AlertDialog.Builder(this).setTitle(rule.appName)
                .setItems(new String[]{rule.enabled?"关闭这条规则":"开启这条规则","删除这条规则","查看记录内容"},
                        (d,w) -> {if(w==2)showDetails("已记录的关闭按钮",org.adguardian.app.flow.LearningDetails.describe(rule));else changeLearnedRule(rule,w);}).setNegativeButton("返回",null).show();
    }
    private void changeLearnedRule(LearnedRule rule,int action) {
        final String[] result={"已保存"};
        runRecordIo(() -> {
            LearnedRuleStore store=new LearnedRuleStore(this);
            try {
                if(action==2)store.clear();
                else if(action==1)store.remove(rule.key);
                else store.setEnabled(rule.key,!rule.enabled);
            } catch(IOException error) {result[0]="保存失败 原规则未改变";}
        },() -> {if(!isFinishing() && !isDestroyed()) {settingsChanged();Toast.makeText(this,result[0],Toast.LENGTH_SHORT).show();showLearnedRules();}});
    }
    // Local records do not depend on a live AccessibilityService or its worker lifecycle.
    private void runRecordIo(Runnable action,Runnable completed) {
        new Thread(() -> {
            try {action.run();ui.post(() -> {if(!isFinishing()&&!isDestroyed())completed.run();});}
            catch(RuntimeException failure) {
                org.adguardian.app.runtime.RuntimeHealth.failure(getApplicationContext(),"本地记录读写失败",failure);
                ui.post(() -> {if(!isFinishing()&&!isDestroyed())showDetails("本地记录操作未完成","未能确认本次读写 请检查存储空间 原文件不会用空记录覆盖");});
            }
        },"AdRecordFiles").start();
    }
    private void showRecordingDrafts() {
        ArrayList<RecordingDraft> records=new ArrayList<>();String[] error={""};
        runRecordIo(() -> {
            try{records.addAll(new RecordingDraftStore(this).all());}
            catch(IOException e){error[0]="录制文件无法读取 原文件已保留 不会自动清空";}
        },() -> {
            if(!error[0].isEmpty()){showDetails("录制记录无法读取",error[0]);return;}
            if(records.isEmpty()){showDetails("录制记录和草稿","还没有已写入的录制步骤 捕获成功后这里立即保留记录 不需要等待辅助功能连接");return;}
            java.util.Collections.reverse(records);String[] names=new String[records.size()];
            for(int i=0;i<names.length;i++){
                RecordingDraft d=records.get(i);names[i]=d.appName+"  "+d.steps.size()+" 步  "+d.stateText();
            }
            new AlertDialog.Builder(this).setTitle("录制记录和草稿").setItems(names,(dialog,index) -> {
                RecordingDraft d=records.get(index);
                new AlertDialog.Builder(this).setTitle(d.appName+"  录制记录")
                    .setItems(new String[]{"查看捕获内容","删除这份录制记录"},(a,which)->{
                        if(which==0)showDetails("已保存的录制内容",org.adguardian.app.flow.LearningDetails.describe(d));
                        else new AlertDialog.Builder(this).setMessage("只删除这份录制草稿 不删除已经启用的规则 或其他录制记录")
                            .setPositiveButton("删除",(c,w)->changeRecording(d.key)).setNegativeButton("取消",null).show();
                    }).setNegativeButton("返回",null).show();
            }).setNegativeButton("返回",null).show();
        });
    }
    private void changeRecording(String key) {
        String[] error={""};runRecordIo(() -> {
            try{new RecordingDraftStore(this).remove(key);}catch(IOException e){error[0]="删除未完成 原记录未被清空";}
        },() -> {if(error[0].isEmpty())showRecordingDrafts();else showDetails("录制记录",error[0]);});
    }
    private void showDetails(String title,String value) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(value).setPositiveButton("返回",null)
                .setNeutralButton("复制内容",(d,w) -> {
                    ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                    if(clipboard!=null){clipboard.setPrimaryClip(ClipData.newPlainText(title,value));Toast.makeText(this,"已复制记录内容",Toast.LENGTH_SHORT).show();}
                }).show();
    }
    private void copyText(String value) {
        if(isFinishing() || isDestroyed())return;
        ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        if(clipboard!=null) {clipboard.setPrimaryClip(ClipData.newPlainText("去你的广告运行状态",value));Toast.makeText(this,"已复制运行状态",Toast.LENGTH_SHORT).show();}
    }

    private void refreshEventLog() {
        if (eventLogView != null) eventLogView.setText(UserEventLog.read(this));
    }

    private void copyEventLog() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null) {
            Toast.makeText(this, "无法复制", Toast.LENGTH_SHORT).show();
            return;
        }
        clipboard.setPrimaryClip(ClipData.newPlainText("去你的广告", UserEventLog.read(this)));
        Toast.makeText(this, "已复制", Toast.LENGTH_SHORT).show();
    }

    private Switch optionSwitch(String value, boolean checked) {
        Switch view = new Switch(this);
        view.setText(value);
        view.setTextSize(16);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setChecked(checked);
        view.setPadding(0, dp(7), 0, dp(7));
        return view;
    }

    private TextView sectionTitle(String value) {
        return text(value, 16, true);
    }

    private Button smallButton(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        button.setTextSize(13);
        button.setMinWidth(0);
        return button;
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1.0f
        );
        params.leftMargin = dp(2);
        params.rightMargin = dp(2);
        return params;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(Color.rgb(20, 20, 20));
        if (bold) view.setTypeface(view.getTypeface(), Typeface.BOLD);
        return view;
    }

    private LinearLayout.LayoutParams marginTop(int top) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.topMargin = top;
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
