package org.adguardian.app.recording;

import android.content.Context;
import java.io.IOException;
import java.util.*;
import org.adguardian.app.engine.AdType;
import org.adguardian.app.flow.FlowStep;

/** Worker-side writer for a user's explicit lesson. It never enables automation. */
public final class RecordingSession {
    private final Context context;
    private final RecordingDraftStore store;
    private final String key=UUID.randomUUID().toString();
    private final boolean single;
    private final AdType type;
    private volatile RecordingDraft saved;
    private volatile String problem="";
    public RecordingSession(Context context,boolean single,AdType type){this.context=context;store=new RecordingDraftStore(context);this.single=single;this.type=type;}
    public boolean isStored(){return saved!=null;}
    public int count(){return saved==null?0:saved.steps.size();}
    public String key(){return key;}
    public String problem(){return problem;}
    public boolean persist(String pkg,long version,List<FlowStep> steps,int confirmed,int state) {
        if(steps.isEmpty())return false;
        String name=pkg;
        try{CharSequence label=context.getPackageManager().getApplicationLabel(context.getPackageManager().getApplicationInfo(pkg,0));if(label!=null&&!label.toString().isEmpty())name=label.toString();}catch(Exception unavailable){}
        if(name.length()>512)name=name.substring(0,512);
        RecordingDraft next=new RecordingDraft(key,pkg,name,version,type,single,steps,confirmed,state,System.currentTimeMillis());
        try{store.put(next);saved=next;problem="";return true;}
        catch(IOException|RuntimeException failure){problem="录制内容写入失败 已保存的旧记录未被清空 请检查存储空间";return false;}
    }
    public boolean mark(int confirmed,int state) {
        RecordingDraft old=saved;
        return old!=null&&persist(old.packageName,old.version,old.steps,confirmed,state);
    }
}
