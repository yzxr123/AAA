# B7.8 构建

versionName 0.7.8-b7.8
versionCode 28
原始包名和 dev-signing.jks 保持不变
同一版本源码 ZIP 与独立工作流要成对使用
工作流必须位于 .github/workflows/build-apk.yml
直接上传完整 ZIP 由 inline Python 定位 实际版本验证 独立目录展开
不得恢复成只接受根目录固定文件名的旧逻辑
新的源码准备测试必须与工作流 REQUIRED 文件契约同步

验证 tools/run_host_tests.py
CI 运行真实 gkd-core Kotlin测试 Android接口模拟测试 再 assembleRelease
没有 Android SDK 或真实手机时不能宣称 APK 已构建或广告实测通过
APK50MiB限制与实际RAM不同
不要把测试替身打进生产APK
不要删除新flow或classapp类 当作旧残留清理
