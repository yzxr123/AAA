# 去你的广告 B7.5

Read `.agents/skills/android-ad-guardian/SKILL.md` and `docs/B7.5-design.md` before changes

This is an offline Android phone application not a desktop tool
One complete APK Keep its app identity and stable signing key unchanged
No INTERNET permission and no app update subsystem in this revision

B7.5 invariants

System authorization and live service connection are separate states
Use normalized system enabled component configuration for authorization and owned lifecycle state for runtime
Never infer denied permission from a missing running instance and never force-write secure settings
Use a separate quiet foreground service with a visible ongoing notification for requested background protection
Do not claim immunity to OEM task killers Android force-stop or OS background-start restrictions
Do not add wake locks silent audio restart loops privileged shells or hidden Activity launches

Runtime pipeline

User-confirmed local learned rules then unchanged LiTiaotiao then actual bundled GKD subscription and selector then constrained structural assistance then optional local OCR
No generic SDK-activity Back fallback Input dispatch success is not ad removal
ActionVerifier uses at most three bounded no-screenshot UI checks and independent cancellation generations
No null-root success No stale gesture timeout affecting a newer gesture

Learning

Explicit user start only No passive all-day logging No screenshots passwords input values or arbitrary page text in persisted learned rules
Exactly scoped app page app version current ad evidence and a unique visible current target
Require user confirmation before saving Allow per-rule enable disable delete and clear
Stop after cancellation timeout permission loss or master disable

Performance

Keep worker event coalescing lazy shared NodeIndex package-indexed GKD loading and 512px RGB565 OCR unchanged
No OCR tasks while teaching or while an action is being verified
Maintain 50 MiB APK ceiling This is not an RSS or PSS memory promise

Validation and delivery

Run tools/run_host_tests.py including complete UI Java compilation against host API doubles
Actual Android SDK compilation device lifecycle survival and native OCR remain distinct validation layers
Deliver complete Qunideguanggao_B7_5_source.zip plus standalone build-apk-B7.5.yml
The workflow accepts an intact source ZIP at repository root Do not require uploading files individually
