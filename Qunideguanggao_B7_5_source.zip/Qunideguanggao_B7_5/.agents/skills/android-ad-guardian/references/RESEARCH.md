# B7.5 核对记录

用户给定 gkd-main 的纯 Selector 源码及 A11yContext ResolvedRule AppRule GlobalRule GkdAction 等参考文件
原始 selector 38 文件保存在 third_party
不把外层加固壳当作李跳跳 SDK

Android Bitmap 硬件图像不能直接交给普通软件 Canvas
AOSP Bitmap.createBitmap 对硬件源存在软件复制路径 因此只 createScaledBitmap 不足以证明降低全屏副本峰值
本版选择 HardwareRenderer RenderNode ImageReader 小尺寸 GPU 输出后再 copy RGB565
公开 API 存在与宿主签名编译不构成实际 GPU 成功证据

代码设计中的时间上限与图像像素上限是参数
不是实测 CPU RAM 开屏延迟或99%广告覆盖率
SDK构建与手机回归必须分别记录

## 本轮核对的官方机制

https://developer.android.com/reference/android/accessibilityservice/AccessibilityService
系统管理无障碍服务绑定 用户授权和服务生命周期不可混用

https://developer.android.com/reference/android/provider/Settings.Secure#ENABLED_ACCESSIBILITY_SERVICES
读取授权组件列表 使用 ComponentName 规范化而不是任意子串

https://developer.android.com/develop/background-work/services/fgs/service-types
specialUse 前台服务需声明类型与对应权限并提供用途 通知不能被伪装成隐形永生进程

https://raw.githubusercontent.com/gkd-kit/gkd/main/gkd-app/src/main/kotlin/li/gkd/app/service/StatusService.kt
GKD区分 canA11y 和 A11yService.isRunning 并用独立 StatusService 显示状态
本项目参考职责拆分 不导入它的特权自动授权功能

用户说的优进和CLASS课程表的精确包名版本没有证据 不编造专项适配
复制运行状态让用户主动提供实际型号系统最近进程退出和目标应用信息
