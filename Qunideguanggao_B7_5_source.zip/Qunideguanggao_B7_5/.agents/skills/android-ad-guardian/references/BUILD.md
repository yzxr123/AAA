# B7.5 构建

Java 17 Gradle 8.13 AGP 8.13.2 Kotlin JVM 2.3.10
Android compileSdk 36 targetSdk 36 minSdk 30 arm64-v8a
Tesseract4Android 4.9.0
Release R8 和资源压缩 稳定开发签名用于此私人测试工程
运行 APK 大小阈值 50 MiB 不表示内存阈值

工作流 .github/workflows/build-apk.yml
支持仓库根目录 Qunideguanggao_B7_5_source.zip 自动展开
固定目录 Qunideguanggao_B7_5 先验证版本 再拒绝越界路径和符号链接
只清理确认的旧模块 不再使用旧 Java 白名单删新增类

python3 tools/validate_project.py
python3 -m unittest discover -s tests -p 'test_*.py' -v
gradle :gkd-core:verifyGkdRuntime :gkd-core:verifyAndroidHost
gradle :app:assembleRelease :app:lintRelease

离线宿主测试替代路径
python3 tools/run_host_tests.py
需要本地 kotlinc javac java
本次本地编译器 Kotlin 1.9.0 Java 21 输出目标17
不是 CI Kotlin2.3.10 的实际 Gradle构建结果

OCR模型在构建机下载并校验固定SHA256
源码包当前没有实际模型字节
手机安装成品 APK 后不需要联网下载模型
GKD 和李跳跳规则已物理内置源码 构建不拉远程规则

Android后端宿主API替身仅在 tests 下
禁止把替身类添加到 app 的 production sourceSets
图形截图 Tesseractnative 真机响应率与后台存活仍需设备验证
