# B7.5 架构

AdAccessibilityService 主线程收集最新窗口状态 合并事件
独立 HandlerThread 初始化 RuleEngine 并加载规则
同一线程拥有 LTT 状态 GKD RuleSession 节点索引以及动作完成回调

LearnedRuleEngine 用户确认的本地范围规则优先 关闭或不匹配时直接跳过
LiTiaotiaoRuleEngine 随后执行
GkdSubscriptionEngine 使用 GkdRuleRepository 前台应用分片 加 gkd-core 真实 Selector
GkdAssistEngine 只是沿用旧版结构辅助 不是官方 GKD 引擎
OCR 只有规则没有处理或等待动作时才能介入

GkdNodeAdapter 使用每轮 AccessibilityNodeIndex
索引懒读取 原生 ID 和文本 FastQuery 命中后不先扫描整树
原始根节点由调用方回收 索引只回收拥有的子节点
不得把旧索引或旧窗口节点用于下一轮动作查询

OCR takeScreenshot 系统回调后交给 OCR 单工作线程
HardwareRenderer RenderNode ImageReader 建立小尺寸目标
读取缩小图为 RGB565 后逐块 Tesseract
结果回规则线程 验证前台应用 当前根节点和会话令牌
延迟动作 手势回调和截图都必须防止跨会话结果使用

AccessibilityState 使用系统授权设置和已绑定实例的独立状态
MainActivity onResume 读取并注册 ContentObserver 与实例通知 onPause 注销
ProtectionService 为 specialUse 独立前台服务 低打扰通知 START_STICKY
Activity任务移除不主动停止上述服务 按后台开关 总开关及系统授权管理
系统强停与厂商限制不能绕过 真实断连不能通过修改显示伪装恢复
ActionVerifier 输入请求接受后有限次检查目标 不把空根节点或手势接受等同成功
RootAccess 在平台IPC异常时返回未知结果 后续界面事件继续尝试
LearningController 只有用户主动开启才捕获一次点击 限时且确认后保存
学习期间暂停自动操作和OCR learned-ad-rules.bin 原子写入每应用页面版本限定规则
