# B7.5 规则

LTT AllRules BasicRules ExtendedRules 直接使用用户输入原始字节
328 条应用入口 795 条 popup_rules
SHA256 在 tools/validate_project.py 固定检查

GKD 原始 JSON5 保存于 third_party/gkd_subscription/gkd.json5
严格 JSON 副本 source.json 经 JSON5 解析对比后固定前后 SHA256
source-provenance.json 记录输入身份
build_gkd_bundle.py 只按四种广告组类别挑选 整组字段不改
开屏广告 局部广告 全屏广告 分段广告

原始 scopeKeys 关联组不可遗漏
原始 preKeys 的部分退休替代键可不存在 只能关联实际存在的前置规则
matches anyMatches excludeMatches excludeAllMatches 由真实 Selector 执行
动作 actionCd actionMaximum actionCdKey actionMaximumKey matchDelay actionDelay matchTime forcedTime resetMatch priorityTime 均须保留
多步规则依赖前一个真正成功动作
none 是状态步骤 不点击

每次更新必须重新生成资产和 fixtures 运行所有 2600 个选择器与每应用规则构造测试
不可仅检查规则数量而忽略执行条件和负向排除
运行时只加载广告资产分片 完整非广告订阅留在源包而非 APK

B7.5 动作状态

保留上游动作序列的输入完成语义 同时单独核对可见目标是否离开当前页面
输入被系统接受不再直接写广告已关闭 成功目标核对不表示通过了某应用全部广告
取消 断连 错误 超时不会记作成功
学习规则和原始订阅分开存储 不改写订阅
学习必须用户开始并确认 规则要检查包名 Activity 版本 当前广告证据和唯一目标
