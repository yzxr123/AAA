package org.adguardian.app.learning;

import android.content.Context;
import android.util.AtomicFile;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.adguardian.app.engine.NodeTarget;
import org.adguardian.app.engine.AdType;

public final class LearnedRuleStore {
    private static final int MAGIC=0x51414431;
    public static final int MAX_RULES=64;
    private final AtomicFile file;
    private List<LearnedRule> rules=new ArrayList<>();
    private boolean readable=true;
    public LearnedRuleStore(Context context) {
        file=new AtomicFile(new File(context.getFilesDir(),"learned-ad-rules.bin"));
        if(!file.getBaseFile().exists() && !new File(file.getBaseFile()+".bak").exists())return;
        try(DataInputStream in=new DataInputStream(file.openRead())) {
            if(file.getBaseFile().length()>131072L || in.readInt()!=MAGIC)throw new IOException("invalid rule data");
            int count=in.readInt();
            if(count<0 || count>MAX_RULES)throw new IOException("rule limit");
            ArrayList<LearnedRule> loaded=new ArrayList<>();
            for(int i=0;i<count;i++) {
                String key=field(in),pkg=field(in),name=field(in),activity=field(in);
                long version=in.readLong();boolean enabled=in.readBoolean();
                int type=in.readInt();if(type<0 || type>=AdType.values().length)throw new IOException("invalid type");
                NodeTarget target=new NodeTarget(field(in),field(in),field(in),in.readFloat(),in.readFloat(),in.readFloat(),in.readFloat());
                if(pkg.isEmpty() || activity.isEmpty() || !finite(target) || !target.isSafeLearningTarget())throw new IOException("invalid target");
                loaded.add(new LearnedRule(key,pkg,name,activity,version,target,enabled,AdType.values()[type]));
            }
            if(in.read()!=-1)throw new IOException("trailing rule data");
            rules=loaded;
        } catch(IOException error) { readable=false; }
    }
    public boolean isReadable() { return readable; }
    public List<LearnedRule> all() { return Collections.unmodifiableList(rules); }
    public boolean hasPackage(String pkg) {
        for(LearnedRule rule:rules)if(rule.enabled && rule.packageName.equals(pkg))return true;
        return false;
    }
    public void add(LearnedRule rule) throws IOException {
        if(!readable)throw new IOException("local rules need repair");
        ArrayList<LearnedRule> next=new ArrayList<>(rules);
        next.removeIf(old -> old.packageName.equals(rule.packageName) && old.activityName.equals(rule.activityName)
                && old.target.id.equals(rule.target.id) && old.target.label.equals(rule.target.label)
                && Math.abs(old.target.x-rule.target.x)<0.025f && Math.abs(old.target.y-rule.target.y)<0.025f);
        if(next.size()>=MAX_RULES)throw new IOException("rule limit reached");
        next.add(rule);save(next);
    }
    public void setEnabled(String key,boolean enabled) throws IOException {
        if(!readable)throw new IOException("unreadable rule file");
        ArrayList<LearnedRule> next=new ArrayList<>();
        for(LearnedRule rule:rules)next.add(rule.key.equals(key)?rule.withEnabled(enabled):rule);
        save(next);
    }
    public void remove(String key) throws IOException {
        if(!readable)throw new IOException("unreadable rule file");
        ArrayList<LearnedRule> next=new ArrayList<>(rules);next.removeIf(rule -> rule.key.equals(key));save(next);
    }
    public void clear() throws IOException {save(new ArrayList<>());readable=true;}
    private void save(List<LearnedRule> next) throws IOException {
        FileOutputStream stream=file.startWrite();
        try {
            DataOutputStream out=new DataOutputStream(stream);out.writeInt(MAGIC);out.writeInt(next.size());
            for(LearnedRule rule:next) {
                out.writeUTF(rule.key);out.writeUTF(rule.packageName);out.writeUTF(rule.appName);out.writeUTF(rule.activityName);
                out.writeLong(rule.versionCode);out.writeBoolean(rule.enabled);out.writeInt(rule.type.ordinal());
                NodeTarget t=rule.target;out.writeUTF(t.id);out.writeUTF(t.name);out.writeUTF(t.label);
                out.writeFloat(t.x);out.writeFloat(t.y);out.writeFloat(t.width);out.writeFloat(t.height);
            }
            out.flush();if(stream.getChannel().size()>131072L)throw new IOException("rule storage limit");file.finishWrite(stream);rules=new ArrayList<>(next);
        } catch(IOException error) {file.failWrite(stream);throw error;}
    }
    private static String field(DataInputStream in)throws IOException {
        String text=in.readUTF();if(text.length()>512)throw new IOException("field limit");return text;
    }
    private static boolean finite(NodeTarget t) {
        return Float.isFinite(t.x)&&Float.isFinite(t.y)&&Float.isFinite(t.width)&&Float.isFinite(t.height)
                && t.x>=0 && t.x<=1 && t.y>=0 && t.y<=1;
    }
}
