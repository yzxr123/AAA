package org.adguardian.app.learning;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.pm.PackageManager;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.function.Supplier;
import org.adguardian.app.engine.AccessibilityNodeIndex;
import org.adguardian.app.engine.ActionVerifier;
import org.adguardian.app.settings.PreferenceStore;

public final class LearnedRuleEngine {
    private final AccessibilityService service;
    private final Handler handler;
    private final ActionVerifier verifier;
    private final Supplier<String> foreground;
    private LearnedRuleStore store;
    private String packageName="";
    private long version=-1;
    private long generation;
    private long gestureGeneration;
    private volatile boolean pending;
    private volatile long lastAction;
    public LearnedRuleEngine(AccessibilityService service,Handler handler,ActionVerifier verifier,Supplier<String> foreground) {
        this.service=service;this.handler=handler;this.verifier=verifier;this.foreground=foreground;
        store=new LearnedRuleStore(service);
    }
    public LearnedRuleStore store() { return store; }
    public void reload() {cancel();store=new LearnedRuleStore(service);packageName="";}
    public boolean isPending() {return pending;}
    public long lastAction() {return lastAction;}
    public void cancel() {generation++;pending=false;}
    public void onPackageChanged() {cancel();packageName="";}
    public boolean handle(String pkg,String activity,AccessibilityNodeIndex index) {
        if(!PreferenceStore.isMasterEnabled(service) || !PreferenceStore.isLearnedEnabled(service) || !store.hasPackage(pkg))return false;
        if(pending)return true;
        if(!pkg.equals(packageName)) {
            cancel();packageName=pkg;
            try {version=service.getPackageManager().getPackageInfo(pkg,0).getLongVersionCode();}
            catch(PackageManager.NameNotFoundException error) {version=-1;}
        }
        index.startQueryBudget(40L);
        try {
            for(LearnedRule rule:store.all()) {
                if(!PreferenceStore.isTypeEnabled(service,rule.type))continue;
                String key="learned:"+rule.key;
                if(!verifier.allowed(pkg,key,index.root().getWindowId()))continue;
                AccessibilityNodeInfo target=rule.match(pkg,activity,version,index);
                if(target==null)continue;
                ActionVerifier.Ticket ticket=verifier.capture(pkg,key,"click",target,index,null);
                if(ticket==null)return false;
                if(target.isClickable() && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    lastAction=SystemClock.uptimeMillis();verifier.accepted(ticket);return true;
                }
                Rect bounds=new Rect();target.getBoundsInScreen(bounds);
                Path path=new Path();path.moveTo(bounds.exactCenterX(),bounds.exactCenterY());
                GestureDescription gesture=new GestureDescription.Builder().addStroke(
                        new GestureDescription.StrokeDescription(path,0L,45L)).build();
                long epoch=generation;long token=++gestureGeneration;pending=true;lastAction=SystemClock.uptimeMillis();
                boolean accepted;
                try {
                    accepted=service.dispatchGesture(gesture,new AccessibilityService.GestureResultCallback() {
                        @Override public void onCompleted(GestureDescription value) {
                            if(epoch!=generation || token!=gestureGeneration)return;
                            pending=false;
                            if(pkg.equals(foreground.get()) && PreferenceStore.isMasterEnabled(service)
                                    && PreferenceStore.isLearnedEnabled(service))verifier.accepted(ticket);
                        }
                        @Override public void onCancelled(GestureDescription value) {
                            if(epoch!=generation || token!=gestureGeneration)return;pending=false;verifier.rejected(ticket);
                        }
                    },handler);
                } catch(RuntimeException error) {pending=false;verifier.rejected(ticket);return false;}
                if(!accepted) {pending=false;verifier.rejected(ticket);}
                else handler.postDelayed(() -> {
                    if(pending && epoch==generation && token==gestureGeneration) {pending=false;gestureGeneration++;verifier.rejected(ticket);}
                },1500L);
                return accepted;
            }
        } finally {index.clearQueryBudget();}
        return false;
    }
}
