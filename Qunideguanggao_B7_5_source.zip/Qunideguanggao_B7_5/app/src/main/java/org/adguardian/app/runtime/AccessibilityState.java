package org.adguardian.app.runtime;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.database.ContentObserver;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import java.util.List;
import java.util.concurrent.CopyOnWriteArraySet;
import org.adguardian.app.service.AdAccessibilityService;
import org.adguardian.app.settings.PreferenceStore;

public final class AccessibilityState {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final CopyOnWriteArraySet<Runnable> LISTENERS = new CopyOnWriteArraySet<>();
    private static Object owner;
    private static boolean ready;
    private static boolean failed;

    private AccessibilityState() { }

    public static boolean containsComponent(String enabled, String pkg, String serviceName) {
        if (enabled == null || pkg == null || serviceName == null) return false;
        ComponentName expected = new ComponentName(pkg, serviceName);
        for (String part : enabled.split(":")) {
            ComponentName component = ComponentName.unflattenFromString(part.trim());
            if (expected.equals(component)) return true;
        }
        return false;
    }

    public static Snapshot read(Context context) {
        boolean known = true;
        boolean authorized = false;
        try {
            String enabled = Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled != null) {
                authorized = containsComponent(enabled, context.getPackageName(),
                        AdAccessibilityService.class.getName());
            } else {
                authorized = listedByManager(context);
            }
        } catch (RuntimeException error) {
            try { authorized = listedByManager(context); known = authorized; }
            catch (RuntimeException unavailable) { known = false; }
        }
        synchronized (AccessibilityState.class) {
            return new Snapshot(known, authorized, owner != null, ready, failed,
                    PreferenceStore.isMasterEnabled(context));
        }
    }

    private static boolean listedByManager(Context context) {
        AccessibilityManager manager = (AccessibilityManager) context.getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        List<AccessibilityServiceInfo> list = manager.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        if (list == null) return false;
        for (AccessibilityServiceInfo info : list) {
            if (info.getResolveInfo() == null || info.getResolveInfo().serviceInfo == null) continue;
            android.content.pm.ServiceInfo service = info.getResolveInfo().serviceInfo;
            String name = service.name.startsWith(".") ? service.packageName + service.name : service.name;
            if (context.getPackageName().equals(service.packageName)
                    && AdAccessibilityService.class.getName().equals(name)) return true;
        }
        return false;
    }

    public static synchronized void connected(Object source) {
        if (owner == source) return;
        owner = source; ready = false; failed = false; changed();
    }
    public static synchronized void initialized(Object source, boolean ok) {
        if (owner != source) return;
        ready = ok; failed = !ok; changed();
    }
    public static synchronized void disconnected(Object source) {
        if (owner != source) return;
        owner = null; ready = false; failed = false; changed();
    }
    public static void changed() {
        for (Runnable listener : LISTENERS) MAIN.post(listener);
    }

    public static final class Snapshot {
        public final boolean known, authorized, connected, ready, failed, enabled;
        Snapshot(boolean known, boolean authorized, boolean connected, boolean ready, boolean failed, boolean enabled) {
            this.known=known;this.authorized=authorized;this.connected=connected;
            this.ready=ready;this.failed=failed;this.enabled=enabled;
        }
        public boolean running() { return authorized && connected && ready && enabled; }
        public String permissionText() {
            if (!known) return "辅助功能权限 暂时无法读取 请查看系统设置";
            return authorized ? "辅助功能权限 已允许" : "辅助功能权限 未允许";
        }
        public String runtimeText() {
            if (!enabled) return "广告保护 已暂停";
            if (!known) return "广告保护 请确认辅助功能设置";
            if (!authorized) return "广告保护 等待辅助功能授权";
            if (!connected) return "广告保护 服务未连接 系统授权仍然保留";
            if (failed) return "广告保护 初始化失败 请尝试恢复服务";
            if (!ready) return "广告保护 正在准备规则";
            return "广告保护 正在运行";
        }
    }

    public static final class Watch implements AutoCloseable {
        private final Context context;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Runnable callback;
        private final Runnable notify;
        private final ContentObserver observer;
        private boolean closed;
        private boolean registered;
        public Watch(Context context, Runnable callback) {
            this.context=context; this.callback=callback;
            notify=() -> { if(!closed)this.callback.run(); };
            observer=new ContentObserver(handler) {
                @Override public void onChange(boolean selfChange) { notify.run(); }
            };
            LISTENERS.add(notify);
            try {
                context.getContentResolver().registerContentObserver(Settings.Secure.getUriFor(
                        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES),false,observer);
                registered=true;
                context.getContentResolver().registerContentObserver(Settings.Secure.getUriFor(
                        Settings.Secure.ACCESSIBILITY_ENABLED),false,observer);
            } catch(RuntimeException unavailable) { }

        }
        @Override public void close() {
            closed=true;LISTENERS.remove(notify);
            if(registered) {
                try {context.getContentResolver().unregisterContentObserver(observer);}catch(RuntimeException unavailable) { }
            }
            handler.removeCallbacksAndMessages(null);
        }
    }
}
