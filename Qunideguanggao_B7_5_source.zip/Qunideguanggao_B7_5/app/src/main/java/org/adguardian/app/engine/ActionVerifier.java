package org.adguardian.app.engine;

import android.accessibilityservice.AccessibilityService;
import org.adguardian.app.runtime.RootAccess;
import android.os.Handler;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.LinkedHashMap;
import java.util.function.Supplier;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.settings.PreferenceStore;

public final class ActionVerifier {
    private final AccessibilityService service;
    private final Handler worker;
    private final Supplier<String> foreground;
    private final Runnable requestScan;
    private final LinkedHashMap<String,Long> failures=new LinkedHashMap<>();
    private volatile Ticket pending;
    private long generation;
    private volatile long lastAction;
    private long lastWarning=-60000L;

    public ActionVerifier(AccessibilityService service,Handler worker,Supplier<String> foreground,Runnable requestScan) {
        this.service=service;this.worker=new Handler(worker.getLooper());
        this.foreground=foreground;this.requestScan=requestScan;
    }
    public boolean isPending() { return pending!=null; }
    public long lastAction() { return lastAction; }
    public boolean allowed(String pkg,String key,int window) {
        Long until=failures.get(pkg+"|"+key+"|"+window);
        return until==null || until<=SystemClock.uptimeMillis();
    }
    public Ticket capture(String pkg,String key,String action,AccessibilityNodeInfo target,
                          AccessibilityNodeIndex index,String expression) {
        if(pending!=null || !allowed(pkg,key,index.root().getWindowId()))return null;
        NodeTarget saved=NodeTarget.capture(target,index.rootBounds());
        return new Ticket(pkg,key,action,index.root().getWindowId(),saved,expression,generation);
    }
    public void accepted(Ticket ticket) {
        if(ticket==null || ticket.generation!=generation || !ticket.pkg.equals(foreground.get()))return;
        lastAction=SystemClock.uptimeMillis();
        pending=ticket;
        if(ticket.target==null && (ticket.expression==null || ticket.expression.isEmpty())) {
            UserEventLog.record(service,"已执行广告操作 关闭结果尚未确认");
            pending=null;return;
        }
        worker.postDelayed(() -> verify(ticket,0),150L);
    }
    public void rejected(Ticket ticket) {
        if(ticket==null || ticket.generation!=generation)return;
        block(ticket);requestScan.run();
    }
    public void cancel() { generation++;pending=null;worker.removeCallbacksAndMessages(null); }
    public void onPackageChanged() { cancel();failures.clear(); }
    private void verify(Ticket ticket,int check) {
        if(pending!=ticket || ticket.generation!=generation)return;
        if(!PreferenceStore.isMasterEnabled(service) || !ticket.pkg.equals(foreground.get())) {cancel();return;}
        AccessibilityNodeInfo root=RootAccess.read(service);
        boolean known=false;
        boolean present=true;
        try {
            if(root!=null && ticket.pkg.contentEquals(NodeTarget.string(root.getPackageName()))) {
                try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(root)) {
                    index.startQueryBudget(35L);
                    if(ticket.expression!=null && !ticket.expression.isEmpty())present=index.expressionExists(ticket.expression);
                    else {
                        present=false;
                        for(AccessibilityNodeInfo node:ticket.target.candidates(index)) {
                            if(ticket.target.matches(node,index.rootBounds(),false)) {present=true;break;}
                        }
                    }
                    known=true;
                }
            }
        } catch(RuntimeException error) {
            known=false;
        } finally { if(root!=null)root.recycle(); }
        if(known && !present)ticket.absentChecks++;else ticket.absentChecks=0;
        if(ticket.absentChecks>=2) {
            pending=null;
            UserEventLog.record(service,"back".equals(ticket.action)?"原广告目标已离开当前页面":"广告关闭目标已消失");
            requestScan.run();return;
        }
        if(check<2) {worker.postDelayed(() -> verify(ticket,check+1),check==0?200L:550L);return;}
        pending=null;
        block(ticket);
        if(known && present && SystemClock.uptimeMillis()-lastWarning>=60000L) {
            lastWarning=SystemClock.uptimeMillis();
            UserEventLog.warning(service,"当前广告尚未关闭 可尝试手动学习");
        }
        requestScan.run();
    }
    private void block(Ticket ticket) {
        failures.put(ticket.pkg+"|"+ticket.key+"|"+ticket.window,SystemClock.uptimeMillis()+5000L);
        if(failures.size()>64)failures.remove(failures.keySet().iterator().next());
    }
    public static final class Ticket {
        final String pkg,key,action,expression;
        final int window;
        final NodeTarget target;
        final long generation;
        int absentChecks;
        Ticket(String pkg,String key,String action,int window,NodeTarget target,String expression,long generation) {
            this.pkg=pkg;this.key=key;this.action=action;this.window=window;
            this.target=target;this.expression=expression;this.generation=generation;
        }
    }
}
