package org.adguardian.app.learning;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.IOException;
import java.util.UUID;
import java.util.function.Supplier;
import org.adguardian.app.engine.AccessibilityNodeIndex;
import org.adguardian.app.engine.AdType;
import org.adguardian.app.engine.NodeTarget;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.settings.PreferenceStore;

public final class LearningController {
    private final AccessibilityService service;
    private final Handler worker;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Supplier<String> foreground;
    private final LearnedRuleEngine engine;
    private final Runnable resume;
    private volatile boolean active;
    private volatile long generation;
    private volatile LearnedRule candidate;
    private AdType type=AdType.POPUP;
    private String pagePackage="",pageActivity="";
    private Rect pageBounds=new Rect();
    private boolean adPage;
    private long observedAt;
    private WindowManager windows;
    private LinearLayout panel;
    private TextView message;
    private Button save;

    public LearningController(AccessibilityService service,Handler worker,Supplier<String> foreground,
                              LearnedRuleEngine engine,Runnable resume) {
        this.service=service;this.worker=worker;this.foreground=foreground;this.engine=engine;this.resume=resume;
    }
    public boolean isActive() {return active;}
    public void start(AdType value) {
        stop();active=true;type=value;long token=++generation;
        worker.post(() -> {pagePackage="";pageActivity="";adPage=false;candidate=null;});
        if(!showPanel()) {active=false;UserEventLog.error(service,"无法显示学习提示 请重新连接辅助功能");resume.run();return;}
        main.postDelayed(() -> {
            if(active && token==generation) {stop();UserEventLog.record(service,"本次学习已结束 未保存新规则");}
        },90000L);
    }
    public void observe(String pkg,String activity,AccessibilityNodeIndex index) {
        if(!active || candidate!=null || service.getPackageName().equals(pkg))return;
        index.startQueryBudget(35L);
        try {
            pagePackage=pkg;pageActivity=activity;pageBounds=new Rect(index.rootBounds());
            adPage=LearnedRule.hasAdContext(index);observedAt=SystemClock.uptimeMillis();
        } catch(AccessibilityNodeIndex.QueryLimit limit) {adPage=false;}
        finally {index.clearQueryBudget();}
    }
    public void clicked(AccessibilityEvent value) {
        if(!active || candidate!=null)return;
        String pkg=NodeTarget.string(value.getPackageName());
        if(pkg.isEmpty() || pkg.equals(service.getPackageName()))return;
        AccessibilityEvent copy=AccessibilityEvent.obtain(value);
        long token=generation;
        worker.post(() -> {
            AccessibilityNodeInfo node=null;
            try {
                if(!active || token!=generation || candidate!=null)return;
                node=copy.getSource();
                if(node==null || !pkg.equals(pagePackage) || pageActivity.isEmpty()
                        || !adPage || SystemClock.uptimeMillis()-observedAt>15000L) {
                    hint(token,"未能读取广告关闭按钮 请重试 不会保存猜测坐标");return;
                }
                NodeTarget target=NodeTarget.capture(node,pageBounds);
                if(target==null || !target.isSafeLearningTarget()) {
                    hint(token,"这个控件不适合自动操作 请点击明确的广告关闭按钮");return;
                }
                long version=service.getPackageManager().getPackageInfo(pkg,0).getLongVersionCode();
                String app=service.getPackageManager().getApplicationLabel(
                        service.getPackageManager().getApplicationInfo(pkg,0)).toString();
                if(!active || token!=generation)return;
                candidate=new LearnedRule(UUID.randomUUID().toString(),pkg,app,pageActivity,version,target.forLearning(),true,type);
                hint(token,"已记录关闭按钮 只有广告确实消失后才点 保存 否则点 重试");
            } catch(PackageManager.NameNotFoundException | RuntimeException error) {
                hint(token,"未能读取本次操作 请重试");
            } finally {if(node!=null)node.recycle();copy.recycle();}
        });
    }
    private void hint(long token,String text) {
        main.post(() -> {if(active && token==generation && message!=null) {message.setText(text);save.setEnabled(candidate!=null);}});
    }
    private boolean showPanel() {
        windows=(WindowManager)service.getSystemService(Context.WINDOW_SERVICE);
        if(windows==null)return false;
        panel=new LinearLayout(service);panel.setOrientation(LinearLayout.VERTICAL);
        int p=Math.round(10*service.getResources().getDisplayMetrics().density);
        panel.setPadding(p,p,p,p);panel.setBackgroundColor(Color.rgb(248,248,248));
        message=new TextView(service);message.setTextColor(Color.BLACK);message.setTextSize(14);
        message.setText("学习中 自动拦截暂时暂停 请打开目标广告并手动关闭 一次只记录一个关闭按钮");
        panel.addView(message);
        LinearLayout buttons=new LinearLayout(service);buttons.setOrientation(LinearLayout.HORIZONTAL);panel.addView(buttons);
        save=new Button(service);save.setText("保存");save.setEnabled(false);save.setOnClickListener(v -> confirm());buttons.addView(save);
        Button retry=new Button(service);retry.setText("重试");retry.setOnClickListener(v -> {
            long token=++generation;candidate=null;
            worker.post(() -> {adPage=false;pagePackage="";resume.run();});
            hint(token,"请重新打开同一广告 并点击真正的关闭按钮");
            main.postDelayed(() -> {if(active && token==generation)stop();},90000L);
        });buttons.addView(retry);
        Button cancel=new Button(service);cancel.setText("取消");cancel.setOnClickListener(v -> stop());buttons.addView(cancel);
        WindowManager.LayoutParams params=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;
        try {windows.addView(panel,params);return true;}
        catch(RuntimeException error) {panel=null;message=null;save=null;return false;}
    }
    private void confirm() {
        LearnedRule selected=candidate;
        if(!active || selected==null)return;
        long token=generation;save.setEnabled(false);
        worker.post(() -> {
            if(!active || token!=generation || !PreferenceStore.isLearnedEnabled(service))return;
            try {
                engine.store().add(selected);
                main.post(() -> {if(active && token==generation) {stop();UserEventLog.record(service,"学习规则已保存 只对刚才的应用和页面生效");}});
            } catch(IOException error) {hint(token,"保存失败 本地规则最多保存六十四条 请先检查或清理学习规则");}
        });
    }
    public void stop() {
        boolean wasActive=active;
        active=false;generation++;candidate=null;
        main.removeCallbacksAndMessages(null);
        if(panel!=null && windows!=null) {
            try {windows.removeView(panel);}catch(RuntimeException error) { }
        }
        panel=null;message=null;save=null;
        if(wasActive)resume.run();
    }
}
