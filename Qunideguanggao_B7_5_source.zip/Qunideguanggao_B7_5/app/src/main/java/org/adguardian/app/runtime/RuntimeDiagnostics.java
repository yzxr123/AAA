package org.adguardian.app.runtime;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.os.Build;
import android.os.PowerManager;
import android.os.Process;
import java.util.List;
import org.adguardian.app.service.ProtectionService;
import org.adguardian.app.service.AdAccessibilityService;
import android.content.pm.PackageManager;

public final class RuntimeDiagnostics {
    private RuntimeDiagnostics() { }
    public static String read(Context context) {
        AccessibilityState.Snapshot state=AccessibilityState.read(context);
        StringBuilder text=new StringBuilder("去你的广告 B7.5 运行状态\n");
        text.append("设备 ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        text.append("Android ").append(Build.VERSION.RELEASE).append(" API ").append(Build.VERSION.SDK_INT).append('\n');
        text.append(state.permissionText()).append('\n').append(state.runtimeText()).append('\n');
        text.append("常驻通知保护 ").append(ProtectionService.isRunning()?"已启动":"未启动").append('\n');
        PowerManager power=(PowerManager)context.getSystemService(Context.POWER_SERVICE);
        text.append("电池优化豁免 ").append(power!=null && power.isIgnoringBatteryOptimizations(context.getPackageName())).append('\n');
        if(!ProtectionService.startProblem().isEmpty())text.append(ProtectionService.startProblem()).append('\n');
        ActivityManager manager=(ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
        if(manager!=null && Build.VERSION.SDK_INT>=30) {
            try {
                List<ApplicationExitInfo> exits=manager.getHistoricalProcessExitReasons(context.getPackageName(),0,3);
                for(ApplicationExitInfo exit:exits) {
                    if(exit.getPid()==Process.myPid())continue;
                    text.append("最近进程退出 时间 ").append(exit.getTimestamp()).append(" 系统原因 ")
                            .append(exit.getReason()).append(" 状态 ").append(exit.getStatus()).append('\n');
                }
            } catch(RuntimeException error) {text.append("系统没有提供进程退出记录\n");}
        }
        if(RootAccess.lastFailureUptime()>0)text.append("最近界面读取失败 设备开机后毫秒 ").append(RootAccess.lastFailureUptime()).append('\n');
        String[] page=AdAccessibilityService.lastObservedPage();
        if(!page[0].isEmpty()) {
            text.append("最近检测应用包名 ").append(page[0]).append('\n').append("最近检测页面 ").append(page[1]).append('\n');
            try {
                text.append("应用名称 ").append(context.getPackageManager().getApplicationLabel(context.getPackageManager().getApplicationInfo(page[0],0)))
                        .append(" 版本号 ").append(context.getPackageManager().getPackageInfo(page[0],0).getLongVersionCode()).append('\n');
            } catch(PackageManager.NameNotFoundException | RuntimeException unavailable) {text.append("该应用版本暂时无法读取\n");}
        }
        return text.toString();
    }
}
