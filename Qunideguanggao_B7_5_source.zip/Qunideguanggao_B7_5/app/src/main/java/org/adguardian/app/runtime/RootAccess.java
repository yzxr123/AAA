package org.adguardian.app.runtime;

import android.accessibilityservice.AccessibilityService;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;

public final class RootAccess {
    private static volatile long lastFailure;
    private RootAccess() { }
    public static AccessibilityNodeInfo read(AccessibilityService service) {
        try {return service.getRootInActiveWindow();}
        catch(RuntimeException unavailable) {lastFailure=SystemClock.uptimeMillis();return null;}
    }
    public static long lastFailureUptime() {return lastFailure;}
}
