import android.accessibilityservice.AccessibilityService;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.concurrent.atomic.AtomicInteger;
import org.adguardian.app.MainActivity;
import org.adguardian.app.engine.*;
import org.adguardian.app.learning.*;
import org.adguardian.app.log.UserEventLog;
import org.adguardian.app.runtime.AccessibilityState;
import org.adguardian.app.service.AdAccessibilityService;
import org.adguardian.app.service.ProtectionService;
import org.adguardian.app.service.ProtectionBootReceiver;
import org.adguardian.app.settings.PreferenceStore;

public final class RuntimeLearningB75Tests {
    private static int passed;
    private interface Case {void run() throws Exception;}
    private static void check(boolean ok,String message) {if(!ok)throw new AssertionError(message);}
    private static void run(String name,Case test)throws Exception {
        Handler.tasks.clear();SystemClock.now=5000;
        Object owner=new Object();AccessibilityState.connected(owner);AccessibilityState.disconnected(owner);
        File file=new File(new Context().getFilesDir(),"learned-ad-rules.bin");file.delete();new File(file+".new").delete();
        test.run();passed++;System.out.println("PASS "+name);
    }
    private static void authorize(Context c) {
        c.getContentResolver().settings.put(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
                c.getPackageName()+"/"+AdAccessibilityService.class.getName());
    }
    private static void call(Object object,String name)throws Exception {
        Method method=object.getClass().getDeclaredMethod(name);method.setAccessible(true);method.invoke(object);
    }
    private static Object field(Object object,String name)throws Exception {
        Field field=object.getClass().getDeclaredField(name);field.setAccessible(true);return field.get(object);
    }
    private static final class Service extends AccessibilityService {
        boolean rootFailure;
        @Override public AccessibilityNodeInfo getRootInActiveWindow(){if(rootFailure)throw new IllegalStateException("simulated dead accessibility connection");return root;}
        public void onAccessibilityEvent(AccessibilityEvent e){} public void onInterrupt(){}
    }
    private static final class ControlledService extends AccessibilityService {
        final java.util.List<GestureResultCallback> callbacks=new java.util.ArrayList<>();
        final java.util.List<android.accessibilityservice.GestureDescription> descriptions=new java.util.ArrayList<>();
        public void onAccessibilityEvent(AccessibilityEvent e){} public void onInterrupt(){}
        @Override public boolean dispatchGesture(android.accessibilityservice.GestureDescription d,GestureResultCallback c,Handler h) {
            callbacks.add(c);descriptions.add(d);gestures++;return true;
        }
        void complete(int i){callbacks.get(i).onCompleted(descriptions.get(i));}
    }
    private static final class Windows implements WindowManager {
        View panel;
        public void addView(View view,LayoutParams p){panel=view;}
        public void removeView(View view){panel=null;}
    }
    private static View button(View root,String text) {
        if(root instanceof TextView v && text.contentEquals(v.getText()))return root;
        if(root instanceof ViewGroup group)for(View child:group.children){View v=button(child,text);if(v!=null)return v;}
        return null;
    }
    private static AccessibilityNodeInfo root() {
        AccessibilityNodeInfo r=new AccessibilityNodeInfo();r.pkg="host.example";r.name="android.widget.FrameLayout";
        r.bounds=new Rect(0,0,1080,2400);r.clickable=false;return r;
    }
    private static AccessibilityNodeInfo target() {
        AccessibilityNodeInfo n=new AccessibilityNodeInfo();n.id="host.example:id/ad_close";n.text="关闭广告";
        n.bounds=new Rect(950,90,1040,150);return n;
    }
    private static LearnedRule learned(AccessibilityNodeInfo node,AccessibilityNodeInfo root) {
        return new LearnedRule("one","host.example","测试应用","host.example.Main",1,
                NodeTarget.capture(node,root.bounds).forLearning(),true,AdType.POPUP);
    }
    public static void main(String[] args)throws Exception {
        run("secure component list is authoritative even when manager reports no live service",()->{
            Context c=new Context();authorize(c);c.services.put(Context.ACCESSIBILITY_SERVICE,new AccessibilityManager());
            AccessibilityState.Snapshot s=AccessibilityState.read(c);
            check(s.authorized&&!s.connected&&!s.running(),"authorization conflated with running");
            check(s.permissionText().contains("已允许")&&s.runtimeText().contains("未连接"),"wrong user states");
        });
        run("short and full component names are parsed exactly",()->{
            check(AccessibilityState.containsComponent("other/.Service:host.app/.Guard","host.app","host.app.Guard"),"short component missing");
            check(!AccessibilityState.containsComponent("host.app.other/host.app.Guard","host.app","host.app.Guard"),"prefix authorized wrong package");
        });
        run("explicitly empty system setting overrides stale cached manager entry",()->{
            Context c=new Context();c.getContentResolver().settings.put(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,"");
            AccessibilityManager m=new AccessibilityManager();android.accessibilityservice.AccessibilityServiceInfo i=new android.accessibilityservice.AccessibilityServiceInfo();
            i.resolve=new android.content.pm.ResolveInfo();i.resolve.serviceInfo=new android.content.pm.ServiceInfo();
            i.resolve.serviceInfo.packageName=c.getPackageName();i.resolve.serviceInfo.name=AdAccessibilityService.class.getName();m.enabled.add(i);
            c.services.put(Context.ACCESSIBILITY_SERVICE,m);check(!AccessibilityState.read(c).authorized,"stale manager permission survived revocation");
        });
        run("stale service destruction cannot disconnect a replacement instance",()->{
            Context c=new Context();authorize(c);Object old=new Object(),next=new Object();
            AccessibilityState.connected(old);AccessibilityState.initialized(old,true);
            AccessibilityState.connected(next);AccessibilityState.initialized(next,true);AccessibilityState.disconnected(old);
            check(AccessibilityState.read(c).running(),"old destruction overwrote new owner");AccessibilityState.disconnected(next);
        });
        run("UI refreshes separate permission and connection without off on toggles",()->{
            MainActivity activity=new MainActivity();authorize(activity);
            Method create=MainActivity.class.getDeclaredMethod("onCreate",android.os.Bundle.class);create.setAccessible(true);create.invoke(activity,new android.os.Bundle());
            call(activity,"onResume");
            check(((TextView)field(activity,"permissionStatus")).getText().toString().contains("已允许"),"UI falsely denied permission");
            check(((TextView)field(activity,"runtimeStatus")).getText().toString().contains("未连接"),"disconnection invisible");
            Object owner=new Object();AccessibilityState.connected(owner);AccessibilityState.initialized(owner,true);Handler.advance(5000);
            check(((TextView)field(activity,"runtimeStatus")).getText().toString().contains("正在运行"),"UI never observed connection");
            activity.getContentResolver().settings.put(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,"");activity.getContentResolver().change();
            check(((TextView)field(activity,"permissionStatus")).getText().toString().contains("未允许"),"revocation not refreshed");
            call(activity,"onPause");check(activity.getContentResolver().observers.isEmpty(),"UI observers leaked after pause");AccessibilityState.disconnected(owner);
        });
        run("swiping task does not destroy initialized rule engine",()->{
            AdAccessibilityService s=new AdAccessibilityService();authorize(s);s.root=root();call(s,"onServiceConnected");Handler.advance(5000);
            check(AccessibilityState.read(s).running(),"service not ready");Object engine=field(s,"ruleEngine");
            s.onTaskRemoved(new Intent("swipe"));check(AccessibilityState.read(s).running()&&field(s,"ruleEngine")==engine,"swipe destroyed engine");
            check(s.foregroundStarts>0,"foreground protection never requested");call(s,"onServiceConnected");check(field(s,"ruleEngine")==engine,"duplicate connection recreated engine");
            AccessibilityNodeInfo ad=target();s.root.add(ad);AccessibilityEvent e=new AccessibilityEvent();e.pkg="host.example";e.name="host.example.Main";e.type=32;
            s.onAccessibilityEvent(e);Handler.advance(6000);check(ad.clicks>0||s.gestures>0,"advertisement event after swipe not processed");s.onDestroy();
        });
        run("unbind clears live service but does not erase system authorization",()->{
            AdAccessibilityService s=new AdAccessibilityService();authorize(s);s.root=root();call(s,"onServiceConnected");Handler.advance(5000);
            s.onUnbind(new Intent("unbind"));AccessibilityState.Snapshot state=AccessibilityState.read(s);
            check(state.authorized&&!state.connected&&!state.ready,"unbind changed authorization or left stale live state");s.onDestroy();
        });
        run("initialization completion after unbind cannot revive stale state",()->{
            AdAccessibilityService s=new AdAccessibilityService();authorize(s);call(s,"onServiceConnected");s.onUnbind(new Intent("unbind"));Handler.advance(5000);
            check(!AccessibilityState.read(s).connected&&field(s,"ruleEngine")==null,"late initialization revived dead instance");s.onDestroy();
        });
        run("background guard is sticky but respects user disable and reboot preferences",()->{
            ProtectionService s=new ProtectionService();authorize(s);s.services.put(Context.NOTIFICATION_SERVICE,new NotificationManager());s.onCreate();
            check(s.onStartCommand(new Intent("start"),0,1)==android.app.Service.START_STICKY&&s.starts==1,"guard did not enter foreground");
            s.onTaskRemoved(new Intent("swipe"));check(s.stops==0,"guard stopped with task");
            PreferenceStore.setKeepAliveEnabled(s,false);ProtectionService.sync(s);check(s.serviceStops>0,"disable ignored");s.onDestroy();
            Context c=new Context();authorize(c);new ProtectionBootReceiver().onReceive(c,new Intent(Intent.ACTION_BOOT_COMPLETED));check(c.foregroundStarts==1,"enabled boot did not request guard");
            PreferenceStore.setMasterEnabled(c,false);new ProtectionBootReceiver().onReceive(c,new Intent(Intent.ACTION_BOOT_COMPLETED));check(c.foregroundStarts==1,"disabled app restarted after boot");
        });
        run("an accepted action on unchanged UI reports failure and backs off",()->{
            Service s=new Service();s.root=root();AccessibilityNodeInfo n=target();s.root.add(n);UserEventLog.clear(s);
            AtomicInteger retry=new AtomicInteger();ActionVerifier verifier=new ActionVerifier(s,new Handler(Looper.getMainLooper()),()->"host.example",retry::incrementAndGet);
            ActionVerifier.Ticket t;try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(s.root)){t=verifier.capture("host.example","key","back",n,index,null);}
            verifier.accepted(t);Handler.advance(5150);Handler.advance(5350);Handler.advance(5900);
            check(!verifier.isPending()&&!verifier.allowed("host.example","key",1),"failed target not gated");
            String log=UserEventLog.read(s);check(!log.contains("已消失")&&!log.contains("已自动返回")&&log.contains("尚未关闭"),"false success instead of unchanged target");
            check(retry.get()==1,"verification did not allow alternative rules");
        });
        run("only two known absent samples confirm target disappearance",()->{
            Service s=new Service();s.root=root();AccessibilityNodeInfo n=target();s.root.add(n);UserEventLog.clear(s);
            ActionVerifier verifier=new ActionVerifier(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});
            ActionVerifier.Ticket t;try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(s.root)){t=verifier.capture("host.example","key","click",n,index,null);}
            verifier.accepted(t);s.root.children.clear();Handler.advance(5150);check(verifier.isPending(),"one transient frame falsely confirmed");
            Handler.advance(5350);check(!verifier.isPending()&&UserEventLog.read(s).contains("目标已消失"),"confirmed disappearance absent");
        });
        run("null roots or cancel are never treated as confirmed disappearance",()->{
            Service s=new Service();s.root=root();AccessibilityNodeInfo n=target();s.root.add(n);UserEventLog.clear(s);
            ActionVerifier verifier=new ActionVerifier(s,new Handler(Looper.getMainLooper()),()->"host.example",()->{});
            ActionVerifier.Ticket t;try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(s.root)){t=verifier.capture("host.example","key","click",n,index,null);}
            verifier.accepted(t);s.root=null;Handler.advance(5150);Handler.advance(5350);Handler.advance(5900);
            check(!UserEventLog.read(s).contains("已消失"),"null tree confirmed disappearance");verifier.cancel();verifier.accepted(t);check(!verifier.isPending(),"stale ticket revived after cancellation");
        });
        run("learned rules are exact app page version scoped and need current ad evidence",()->{
            AccessibilityNodeInfo r=root(),n=target();r.add(n);LearnedRule rule=learned(n,r);
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(r)) {
                check(rule.match("host.example","host.example.Main",1,index)==n,"valid local learned rule did not match");
                check(rule.match("other","host.example.Main",1,index)==null,"rule crossed apps");
                check(rule.match("host.example","host.example.Payment",1,index)==null,"rule crossed pages");
                check(rule.match("host.example","host.example.Main",2,index)==null,"outdated app rule replayed");
            }
            n.text="普通关闭";try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(r)){check(rule.match("host.example","host.example.Main",1,index)==null,"normal UI replayed learned rule");}
        });
        run("ambiguous learned selectors and password fields are rejected",()->{
            AccessibilityNodeInfo r=root(),n=target();r.add(n);LearnedRule rule=learned(n,r);r.add(target());
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(r)){check(rule.match("host.example","host.example.Main",1,index)==null,"ambiguous target clicked");}
            n.password=true;check(NodeTarget.capture(n,r.bounds)==null,"password captured");n.password=false;n.editable=true;check(NodeTarget.capture(n,r.bounds)==null,"input captured");
            n.editable=false;n.text="立即安装";check(!NodeTarget.capture(n,r.bounds).isSafeLearningTarget(),"install CTA learned as close action");
        });
        run("learned store persists reload supports per rule disable and never saves arbitrary labels",()->{
            Context c=new Context();AccessibilityNodeInfo r=root(),n=target();n.text="用户的私人文本";r.add(n);
            LearnedRule rule=learned(n,r);check(rule.target.label.isEmpty(),"private label retained");
            LearnedRuleStore store=new LearnedRuleStore(c);store.add(rule);LearnedRuleStore read=new LearnedRuleStore(c);
            check(read.all().size()==1&&read.all().get(0).target.label.isEmpty(),"persistence altered sanitized target");
            store.setEnabled(rule.key,false);check(!new LearnedRuleStore(c).hasPackage("host.example"),"per rule disable not durable");
            store.remove(rule.key);check(new LearnedRuleStore(c).all().isEmpty(),"rule deletion did not persist");
        });
        run("corrupt learned data does not overwrite last file until explicit reset",()->{
            Context c=new Context();File file=new File(c.getFilesDir(),"learned-ad-rules.bin");byte[] bad={0,1,2,3};Files.write(file.toPath(),bad);
            LearnedRuleStore store=new LearnedRuleStore(c);check(!store.isReadable(),"corrupt store accepted");
            try{store.remove("x");throw new AssertionError("corrupt store overwritten");}catch(IOException expected){}
            check(java.util.Arrays.equals(Files.readAllBytes(file.toPath()),bad),"corrupt data silently destroyed");store.clear();check(new LearnedRuleStore(c).isReadable(),"explicit reset did not repair");
        });
        run("learning is opt in transient and saves only after user confirms",()->{
            Service s=new Service();Windows windows=new Windows();s.services.put(Context.WINDOW_SERVICE,windows);s.root=root();AccessibilityNodeInfo n=target();s.root.add(n);
            Handler worker=new Handler(Looper.getMainLooper());ActionVerifier verifier=new ActionVerifier(s,worker,()->"host.example",()->{});
            LearnedRuleEngine engine=new LearnedRuleEngine(s,worker,verifier,()->"host.example");LearningController learning=new LearningController(s,worker,()->"host.example",engine,()->{});
            AccessibilityEvent event=new AccessibilityEvent();event.pkg="host.example";event.type=1;event.source=n;
            learning.clicked(event);Handler.advance(5000);check(engine.store().all().isEmpty(),"passive everyday click was recorded");
            learning.start(AdType.POPUP);Handler.advance(5000);
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(s.root)){learning.observe("host.example","host.example.Main",index);}
            learning.clicked(event);Handler.advance(5000);check(engine.store().all().isEmpty(),"unconfirmed demonstration persisted");
            check(button(windows.panel,"保存").isEnabled(),"valid demonstration did not become confirmable");
            button(windows.panel,"保存").performClick();Handler.advance(5000);
            check(engine.store().all().size()==1&&!learning.isActive()&&windows.panel==null,"confirmed demonstration missing or overlay leaked");
        });
        run("learning cancel and timeout leave no rules or overlay",()->{
            Service s=new Service();Windows w=new Windows();s.services.put(Context.WINDOW_SERVICE,w);Handler worker=new Handler(Looper.getMainLooper());
            LearnedRuleEngine engine=new LearnedRuleEngine(s,worker,new ActionVerifier(s,worker,()->"host.example",()->{}),()->"host.example");
            LearningController controller=new LearningController(s,worker,()->"host.example",engine,()->{});
            controller.start(AdType.POPUP);controller.stop();check(!controller.isActive()&&w.panel==null&&engine.store().all().isEmpty(),"cancel left tracking active");
            controller.start(AdType.POPUP);Handler.advance(95000);check(!controller.isActive()&&w.panel==null&&engine.store().all().isEmpty(),"timeout left tracking active");
        });
        run("local learned engine obeys master integration and category switches",()->{
            Service s=new Service();s.root=root();AccessibilityNodeInfo n=target();s.root.add(n);LearnedRuleStore store=new LearnedRuleStore(s);store.add(learned(n,s.root));
            Handler worker=new Handler(Looper.getMainLooper());LearnedRuleEngine engine=new LearnedRuleEngine(s,worker,new ActionVerifier(s,worker,()->"host.example",()->{}),()->"host.example");
            PreferenceStore.setTypeEnabled(s,AdType.POPUP,false);try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(s.root)){check(!engine.handle("host.example","host.example.Main",index),"disabled ad category learned rule acted");}
            PreferenceStore.setTypeEnabled(s,AdType.POPUP,true);PreferenceStore.setLearnedEnabled(s,false);try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(s.root)){check(!engine.handle("host.example","host.example.Main",index),"disabled learned switch acted");}
            PreferenceStore.setLearnedEnabled(s,true);try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(s.root)){check(engine.handle("host.example","host.example.Main",index)&&n.clicks==1,"enabled local rule did not act");}
        });
        run("temporary Binder root failure cannot kill action verification worker",()->{
            Service service=new Service();service.root=root();AccessibilityNodeInfo n=target();service.root.add(n);UserEventLog.clear(service);
            ActionVerifier verifier=new ActionVerifier(service,new Handler(Looper.getMainLooper()),()->"host.example",()->{});
            ActionVerifier.Ticket t;try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(service.root)){t=verifier.capture("host.example","key","click",n,index,null);}
            verifier.accepted(t);service.rootFailure=true;
            Handler.advance(5150);Handler.advance(5350);Handler.advance(5900);
            check(!verifier.isPending()&&!UserEventLog.read(service).contains("已消失"),"failed Binder call wedged worker or falsely confirmed action");
        });
        run("old gesture watchdog cannot cancel a later rule gesture",()->{
            ControlledService service=new ControlledService();service.root=root();AccessibilityNodeInfo n=target();n.text="跳过";n.id=null;n.clickable=false;service.root.add(n);
            Handler worker=new Handler(Looper.getMainLooper());
            org.adguardian.app.gkd.GkdSubscriptionEngine engine=new org.adguardian.app.gkd.GkdSubscriptionEngine(service,worker,()->{},()->"host.example");
            try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(service.root)){check(engine.handle("host.example","host.example.Main",index),"first gesture absent");}
            Handler.advance(5050);service.complete(0);service.root.children.clear();Handler.advance(5200);Handler.advance(5400);
            service.root.window=2;AccessibilityNodeInfo second=target();second.text="跳过";second.id=null;second.clickable=false;service.root.add(second);
            Handler.advance(6200);try(AccessibilityNodeIndex index=AccessibilityNodeIndex.build(service.root)){check(engine.handle("host.example","host.example.Second",index),"second gesture absent");}
            check(engine.isGesturePending(),"second gesture not pending");Handler.advance(6545);
            check(engine.isGesturePending(),"first gesture timeout canceled later gesture");service.complete(1);check(!engine.isGesturePending(),"real second completion not accepted");engine.close();
        });
        System.out.println("B7.5 runtime UI lifecycle verification learning host cases passed="+passed+" (Android API doubles not a device test)");
    }
}
